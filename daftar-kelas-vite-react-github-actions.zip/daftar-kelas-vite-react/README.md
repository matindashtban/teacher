# دفتر کلاس — Vite + React + Android APK

## تبدیل ساختار
- کد HTML تک‌فایلی به پروژه Vite منتقل شده است.
- React، Chart.js، html2canvas و jsPDF از npm نصب و همراه برنامه bundle می‌شوند؛ در کد، fallbackهای CDN حذف شده‌اند.
- Capacitor برای بسته‌بندی نسخه وب در اپ اندروید استفاده می‌شود.
- GitHub Actions با هر push به شاخه `main` یا `master` و همچنین با اجرای دستی، APK آزمایشی می‌سازد.

## دریافت APK از GitHub
1. این پوشه را در یک مخزن GitHub بارگذاری کنید.
2. به تب **Actions** بروید.
3. اجرای **Build Android APK** را باز کنید.
4. در بخش **Artifacts** فایل `daftar-kelas-debug-apk` را دانلود کنید.
5. فایل داخل آن `app-debug.apk` است.

## اجرای محلی
```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

این workflow یک **debug APK** می‌سازد، نه نسخه امضاشده برای انتشار در Google Play.
