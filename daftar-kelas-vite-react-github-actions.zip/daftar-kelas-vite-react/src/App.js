import React from 'react';
import { createRoot } from 'react-dom/client';
import Chart from 'chart.js/auto';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import './style.css';

// Compatibility bridge for the original application code.
// All dependencies are bundled locally by Vite; no CDN is required.
window.React = React;
window.ReactDOM = { createRoot };
window.Chart = Chart;
window.html2canvas = html2canvas;
window.jspdf = { jsPDF };

// ============================================================
        // ذخیره‌سازی
        // ============================================================
        // چرا IndexedDB به‌جای localStorage؟
        // localStorage معمولاً فقط ۵ تا ۱۰ مگابایت جا دارد و همین باعث می‌شد با
        // اضافه‌شدن چند عکس آزمون، حافظه پر شود و ذخیره‌سازی‌های بعدی بی‌سروصدا
        // شکست بخورند. IndexedDB ظرفیتش معمولاً بر اساس فضای خالی گوشی محاسبه
        // می‌شود (اغلب صدها مگابایت تا چند گیگابایت)، پس این مشکل عملاً از بین
        // می‌رود. علاوه بر این IndexedDB داخل اکثر WebViewهای اندرویدی (همون
        // چیزی که برنامه‌سازها برای ساخت اپ استفاده می‌کنند) هم پشتیبانی می‌شود.
        const DATA_KEY = 'school-data-v4'; // کلید قدیمی در localStorage (برای مهاجرت خودکار)
        const IDB_NAME = 'school-data-db';
        const IDB_STORE = 'kv';
        const IDB_KEY = 'main';

        if (typeof Chart !== 'undefined') {
            Chart.defaults.font.family = "'Vazirmatn', Tahoma, sans-serif";
        }

        function isIndexedDBAvailable() {
            try {
                return typeof indexedDB !== 'undefined' && indexedDB !== null;
            } catch (e) {
                return false;
            }
        }

        function openIDB() {
            return new Promise((resolve, reject) => {
                const req = indexedDB.open(IDB_NAME, 1);
                req.onupgradeneeded = () => {
                    const db = req.result;
                    if (!db.objectStoreNames.contains(IDB_STORE)) {
                        db.createObjectStore(IDB_STORE);
                    }
                };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error || new Error('خطا در باز کردن IndexedDB'));
            });
        }

        async function idbGet(key) {
            const db = await openIDB();
            return new Promise((resolve, reject) => {
                const tx = db.transaction(IDB_STORE, 'readonly');
                const store = tx.objectStore(IDB_STORE);
                const req = store.get(key);
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            });
        }

        async function idbSet(key, value) {
            const db = await openIDB();
            return new Promise((resolve, reject) => {
                const tx = db.transaction(IDB_STORE, 'readwrite');
                const store = tx.objectStore(IDB_STORE);
                const req = store.put(value, key);
                req.onsuccess = () => resolve(true);
                req.onerror = () => reject(req.error);
            });
        }

        // خواندن نسخه‌ی قدیمی داده از localStorage (فقط برای مهاجرت یک‌باره)
        function loadLegacyLocalStorageData() {
            try {
                const saved = localStorage.getItem(DATA_KEY);
                if (saved) {
                    const parsed = JSON.parse(saved);
                    return { ...emptyData(), ...parsed };
                }
            } catch (e) {
                console.error('legacy load error', e);
            }
            return null;
        }

        function emptyData() {
            return {
                students: [],
                studentPoints: {},
                studentGroups: {},
                pointHistory: [],
                exams: {},
                attendance: {},
                attendanceDays: {},
                attendanceSettings: {},
                tasks: [],
                parentMeetings: [],
                teacherNotes: [],
                weeklySchedule: {},
                budgeting: {},
                performance: {},
                performanceByGrade: {},
                performanceRowTexts: {},
                performanceCustomRows: [],
                performanceHiddenRowIds: [],
                users: {},
                meta: {},
                classes: [],
                activeClassId: ''
            };
        }

        function normalizeData(raw) {
            return {
                students: raw.students || [],
                studentPoints: raw.studentPoints || {},
                studentGroups: raw.studentGroups || {},
                pointHistory: Array.isArray(raw.pointHistory) ? raw.pointHistory : [],
                exams: raw.exams || {},
                attendance: raw.attendance || {},
                attendanceDays: raw.attendanceDays || {},
                attendanceSettings: raw.attendanceSettings || {},
                tasks: Array.isArray(raw.tasks) ? raw.tasks : [],
                parentMeetings: Array.isArray(raw.parentMeetings) ? raw.parentMeetings : [],
                teacherNotes: Array.isArray(raw.teacherNotes) ? raw.teacherNotes : [],
                weeklySchedule: raw.weeklySchedule || {},
                budgeting: raw.budgeting || {},
                performance: raw.performance || {},
                performanceByGrade: (raw.performanceByGrade && typeof raw.performanceByGrade === 'object') ? raw.performanceByGrade : {},
                performanceRowTexts: (raw.performanceRowTexts && typeof raw.performanceRowTexts === 'object') ? raw.performanceRowTexts : {},
                performanceCustomRows: Array.isArray(raw.performanceCustomRows) ? raw.performanceCustomRows : [],
                performanceHiddenRowIds: Array.isArray(raw.performanceHiddenRowIds) ? raw.performanceHiddenRowIds : [],
                users: raw.users || {},
                meta: raw.meta || {},
                aboutMe: typeof raw.aboutMe === 'string' ? raw.aboutMe : '',
                classes: Array.isArray(raw.classes) ? raw.classes : [],
                activeClassId: typeof raw.activeClassId === 'string' ? raw.activeClassId : ''
            };
        }

        // بارگذاری داده: اول از IndexedDB می‌خواند؛ اگر خالی بود ولی نسخه‌ی قدیمی
        // در localStorage وجود داشت (کاربرانی که از قبل از این برنامه استفاده
        // می‌کردند)، آن را یک‌بار به IndexedDB منتقل می‌کند تا چیزی گم نشود.
        async function loadDataAsync() {
            if (!isIndexedDBAvailable()) {
                const legacy = loadLegacyLocalStorageData();
                return { data: legacy || emptyData(), backend: 'localStorage' };
            }
            try {
                const stored = await idbGet(IDB_KEY);
                if (stored) {
                    return { data: normalizeData(stored), backend: 'indexeddb' };
                }
                const legacy = loadLegacyLocalStorageData();
                if (legacy) {
                    await idbSet(IDB_KEY, legacy);
                    return { data: legacy, backend: 'indexeddb' };
                }
                return { data: emptyData(), backend: 'indexeddb' };
            } catch (e) {
                console.error('idb load error, falling back to localStorage', e);
                const legacy = loadLegacyLocalStorageData();
                return { data: legacy || emptyData(), backend: 'localStorage' };
            }
        }

        async function saveDataAsync(data, backend) {
            if (backend === 'indexeddb') {
                try {
                    await idbSet(IDB_KEY, data);
                    return { ok: true };
                } catch (e) {
                    console.error('idb save error', e);
                    return { ok: false, error: e };
                }
            }
            // fallback (فقط وقتی IndexedDB اصلاً در دسترس نباشد)
            try {
                localStorage.setItem(DATA_KEY, JSON.stringify(data));
                return { ok: true };
            } catch (e) {
                console.error('save error', e);
                return { ok: false, error: e };
            }
        }

        // بکاپ خودکار داخلی: یک snapshot مستقل در IndexedDB (یا localStorage در حالت جایگزین)
        let autoBackupTimer = null;
        let autoBackupPending = null;
        function scheduleAutoBackup(snapshot, backend) {
            autoBackupPending = { snapshot, backend };
            if (autoBackupTimer) clearTimeout(autoBackupTimer);
            autoBackupTimer = setTimeout(async () => {
                const pending = autoBackupPending;
                autoBackupPending = null;
                try {
                    const record = { savedAt: new Date().toISOString(), data: pending.snapshot };
                    if (pending.backend === 'indexeddb' && isIndexedDBAvailable()) {
                        await idbSet('auto-backup-latest', record);
                    } else {
                        localStorage.setItem('school-data-auto-backup', JSON.stringify(record));
                    }
                } catch (e) {
                    console.error('automatic backup error', e);
                }
            }, 12000);
        }
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState !== 'hidden' || !autoBackupPending) return;
            clearTimeout(autoBackupTimer);
            const pending = autoBackupPending;
            autoBackupPending = null;
            const record = { savedAt: new Date().toISOString(), data: pending.snapshot };
            if (pending.backend === 'indexeddb' && isIndexedDBAvailable()) { idbSet('auto-backup-latest', record).catch(() => {}); }
            else { try { localStorage.setItem('school-data-auto-backup', JSON.stringify(record)); } catch (e) {} }
        });
        async function getAutoBackup() {
            try {
                if (isIndexedDBAvailable()) {
                    const record = await idbGet('auto-backup-latest');
                    if (record && record.data) return record;
                }
            } catch (e) { console.error('auto backup read error', e); }
            try {
                const record = JSON.parse(localStorage.getItem('school-data-auto-backup') || 'null');
                return record && record.data ? record : null;
            } catch (e) { return null; }
        }

        // تخمین حجم داده (بر حسب مگابایت) — برای نمایش در تب پشتیبان‌گیری
        function estimateDataSizeMB(data) {
            try {
                return JSON.stringify(data).length / (1024 * 1024);
            } catch (e) {
                return 0;
            }
        }

        // دریافت میزان واقعی فضای اشغال‌شده و سقف مجاز از خود مرورگر/گوشی، اگر پشتیبانی شود
        async function getStorageEstimate() {
            try {
                if (navigator.storage && navigator.storage.estimate) {
                    const { usage, quota } = await navigator.storage.estimate();
                    if (typeof usage === 'number' && typeof quota === 'number' && quota > 0) {
                        return {
                            usageMB: usage / (1024 * 1024),
                            quotaMB: quota / (1024 * 1024),
                            percent: Math.min(100, Math.round((usage / quota) * 100))
                        };
                    }
                }
            } catch (e) {
                console.error('storage estimate error', e);
            }
            return null;
        }

        function isStorageAvailable() {
            if (isIndexedDBAvailable()) return true;
            try {
                const testKey = '__storage_test__';
                localStorage.setItem(testKey, '1');
                localStorage.removeItem(testKey);
                return true;
            } catch (e) {
                return false;
            }
        }

        // تبدیل ساده و مطمئن فایل به Base64 (بدون canvas، چون canvas روی بعضی
        // مرورگرهای موبایل/وب‌ویوها می‌تواند گیر کند یا خیلی کند شود)
        function fileToBase64(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
                reader.readAsDataURL(file);
            });
        }

        // فشرده‌سازی تصویر قبل از ذخیره در localStorage.
        // چرا لازم است: عکس‌های دوربین موبایل معمولاً چند مگابایتی هستند و بعد از
        // تبدیل به Base64 حدود ۳۳٪ حجم بیشتری هم می‌گیرند. حافظه localStorage در
        // اکثر مرورگرها فقط حدود ۵ تا ۱۰ مگابایت است. وقتی این سقف پر شود،
        // localStorage.setItem بی‌سروصدا خطا می‌دهد: برنامه در همان لحظه (در حافظه‌ی
        // مرورگر) درست کار می‌کند، اما چیزی واقعاً ذخیره نمی‌شود؛ با خروج و ورود دوباره
        // (یا رفرش صفحه) همه‌ی داده‌های ثبت‌شده‌ی بعد از پر شدن حافظه از بین می‌روند.
        // برای همین همه‌ی عکس‌های آزمون قبل از ذخیره کوچک و فشرده می‌شوند.
        function compressImage(file, maxDim = 1280, quality = 0.7) {
            return new Promise((resolve) => {
                const objectUrl = URL.createObjectURL(file);
                const img = new Image();
                const cleanup = () => URL.revokeObjectURL(objectUrl);

                img.onload = () => {
                    try {
                        let { width, height } = img;
                        if (width > maxDim || height > maxDim) {
                            if (width >= height) {
                                height = Math.round(height * (maxDim / width));
                                width = maxDim;
                            } else {
                                width = Math.round(width * (maxDim / height));
                                height = maxDim;
                            }
                        }
                        const canvas = document.createElement('canvas');
                        canvas.width = width;
                        canvas.height = height;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, width, height);
                        const dataUrl = canvas.toDataURL('image/jpeg', quality);
                        cleanup();
                        resolve(dataUrl);
                    } catch (e) {
                        cleanup();
                        // اگر فشرده‌سازی به هر دلیلی شکست خورد، حداقل خود فایل اصلی ذخیره شود
                        fileToBase64(file).then(resolve).catch(() => resolve(null));
                    }
                };
                img.onerror = () => {
                    cleanup();
                    fileToBase64(file).then(resolve).catch(() => resolve(null));
                };
                img.src = objectUrl;
            });
        }

        function uid() {
            return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
        }

        function escHtml(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }
        function todayISO() {
            const d = new Date();
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        }

        // ============================================================
        // تبدیل تاریخ شمسی <-> میلادی (بدون وابستگی به تنظیمات مرورگر/گوشی)
        // ============================================================
        function jDiv(a, b) { return ~~(a / b); }
        function jMod(a, b) { return a - ~~(a / b) * b; }

        const JALALI_BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];

        function jalCal(jy) {
            const bl = JALALI_BREAKS.length;
            let gy = jy + 621, leapJ = -14, jp = JALALI_BREAKS[0], jm, jump = 0, n, i;
            for (i = 1; i < bl; i += 1) {
                jm = JALALI_BREAKS[i];
                jump = jm - jp;
                if (jy < jm) break;
                leapJ = leapJ + jDiv(jump, 33) * 8 + jDiv(jMod(jump, 33), 4);
                jp = jm;
            }
            n = jy - jp;
            leapJ = leapJ + jDiv(n, 33) * 8 + jDiv(jMod(n, 33) + 3, 4);
            if (jMod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
            const leapG = jDiv(gy, 4) - jDiv((jDiv(gy, 100) + 1) * 3, 4) - 150;
            const march = 20 + leapJ - leapG;
            if (jump - n < 6) n = n - jump + jDiv(jump, 33) * 33;
            let leap = jMod(jMod(n + 1, 33) - 1, 4);
            if (leap === -1) leap = 4;
            return { leap, gy, march };
        }

        function g2d(gy, gm, gd) {
            let d = jDiv((gy + jDiv(gm - 8, 6) + 100100) * 1461, 4)
                + jDiv(153 * jMod(gm + 9, 12) + 2, 5)
                + gd - 34840408;
            d = d - jDiv(jDiv(gy + 100100 + jDiv(gm - 8, 6), 100) * 3, 4) + 752;
            return d;
        }

        function d2g(jdn) {
            const j0 = 4 * jdn + 139361631;
            const j = j0 + jDiv(jDiv(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
            const i = jDiv(jMod(j, 1461), 4) * 5 + 308;
            const gd = jDiv(jMod(i, 153), 5) + 1;
            const gm = jMod(jDiv(i, 153), 12) + 1;
            const gy = jDiv(j, 1461) - 100100 + jDiv(8 - gm, 6);
            return { gy, gm, gd };
        }

        function j2d(jy, jm, jd) {
            const r = jalCal(jy);
            return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - jDiv(jm, 7) * (jm - 7) + jd - 1;
        }

        function d2j(jdn) {
            const gy = d2g(jdn).gy;
            let jy = gy - 621;
            const r = jalCal(jy);
            const jdn1f = g2d(gy, 3, r.march);
            let k = jdn - jdn1f, jm, jd;
            if (k >= 0) {
                if (k <= 185) {
                    jm = 1 + jDiv(k, 31);
                    jd = jMod(k, 31) + 1;
                    return { jy, jm, jd };
                }
                k -= 186;
            } else {
                jy -= 1;
                k += 179;
                if (r.leap === 1) k += 1;
            }
            jm = 7 + jDiv(k, 30);
            jd = jMod(k, 30) + 1;
            return { jy, jm, jd };
        }

        function isoToJalali(isoDate) {
            const [gy, gm, gd] = isoDate.split('-').map(Number);
            return d2j(g2d(gy, gm, gd));
        }

        function jalaliToIso(jy, jm, jd) {
            const { gy, gm, gd } = d2g(j2d(jy, jm, jd));
            const pad = n => String(n).padStart(2, '0');
            return `${gy}-${pad(gm)}-${pad(gd)}`;
        }

        function jalaliDaysInMonth(jy, jm) {
            if (jm <= 6) return 31;
            if (jm <= 11) return 30;
            return jalCal(jy).leap === 1 ? 30 : 29;
        }

        const JALALI_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
        // پایه‌های تحصیلی مقطع ابتدایی — برای انتخاب پایه‌ی هر دانش‌آموز از یک لیست (به‌جای تایپ دستی)
        const GRADE_LABELS = { '1': 'اول', '2': 'دوم', '3': 'سوم', '4': 'چهارم', '5': 'پنجم', '6': 'ششم' };
        const GRADE_ORDER = ['1', '2', '3', '4', '5', '6'];
        function gradeName(g) { return GRADE_LABELS[g] ? `پایه ${GRADE_LABELS[g]}` : ''; }
        const PERSIAN_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        function toPersianDigits(num) {
            return String(num).replace(/[0-9]/g, d => PERSIAN_DIGITS[d]);
        }

        function toShamsi(isoDate) {
            try {
                const { jy, jm, jd } = isoToJalali(isoDate);
                return toPersianDigits(`${jd} ${JALALI_MONTHS[jm - 1]} ${jy}`);
            } catch {
                return isoDate;
            }
        }

        function getDayName(isoDate) {
            try {
                const days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
                const d = new Date(isoDate + 'T12:00:00');
                return days[d.getDay()] || '';
            } catch {
                return '';
            }
        }

        function getShamsiWithDay(isoDate) {
            const shamsi = toShamsi(isoDate);
            const day = getDayName(isoDate);
            return `${shamsi} - ${day}`;
        }

        const SUBJECTS = ['فارسی', 'ریاضی', 'علوم', 'قرآن', 'املا', 'هنر', 'مطالعات', 'هدیه آسمان', 'آزمون جامع'];
        // انواع آزمون — برای افزودن نوع جدید (مثلاً «آزمون میان‌ترم») فقط یک ردیف به این لیست اضافه کنید.
        const EXAM_TYPES = [
            { value: 'quiz', label: 'آزمونک کلاسی', plural: 'آزمونک‌ها', desc: 'ارزیابی کوتاه حین تدریس', icon: '⚡' },
            { value: 'monthly', label: 'آزمون ماهانه', plural: 'آزمون‌های ماهانه', desc: 'ارزیابی پایان ماه', icon: '📅' }
        ];
        const getExamTypeLabel = t => (EXAM_TYPES.find(x => x.value === t) || {}).label || 'بدون نوع';
        const GRADE_OPTIONS = [
            { value: 'excellent', label: 'خیلی خوب', class: 'excellent' },
            { value: 'good', label: 'خوب', class: 'good' },
            { value: 'acceptable', label: 'قابل قبول', class: 'acceptable' },
            { value: 'needs_work', label: 'نیاز به تلاش بیشتر', class: 'needs_work' }
        ];

        function getGradeLabel(val) {
            const found = GRADE_OPTIONS.find(g => g.value === val);
            return found ? found.label : val;
        }

        function getGradeClass(val) {
            const found = GRADE_OPTIONS.find(g => g.value === val);
            return found ? found.class : '';
        }

        function getGradeScore(val) {
            const map = { excellent: 4, good: 3, acceptable: 2, needs_work: 1 };
            return map[val] || 0;
        }

        // ============================================================
        // انیمیشن هنگام اسکرول (Scroll Reveal) - جایگزین سبک AOS
        // چرا کتابخانه‌ی AOS نیاورده‌ایم؟ این برنامه کاملاً آفلاین کار می‌کند
        // (بدون هیچ درخواست شبکه‌ای)، پس به‌جای بارگذاری یک کتابخانه‌ی بیرونی
        // از IntersectionObserver خود مرورگر استفاده می‌کنیم؛ سبک‌تر است و
        // وابستگی اینترنتی اضافه نمی‌کند.
        // ============================================================
        function useReveal(threshold = 0.15) {
            const ref = React.useRef(null);
            const [visible, setVisible] = React.useState(false);
            React.useEffect(() => {
                const el = ref.current;
                if (!el || visible) return;
                if (typeof IntersectionObserver === 'undefined') {
                    setVisible(true);
                    return;
                }
                const io = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            setVisible(true);
                            io.disconnect();
                        }
                    });
                }, { threshold, rootMargin: '0px 0px -30px 0px' });
                io.observe(el);
                return () => io.disconnect();
            }, [threshold, visible]);
            return [ref, visible];
        }

        // کامپوننت عمومی برای نمایش انیمیشنِ ظاهرشدن هنگام اسکرول.
        // animation: 'up' | 'right' | 'left' | 'zoom'
        // delay: تأخیر به میلی‌ثانیه (برای پشت‌سرهم ظاهر شدن آیتم‌های یک لیست)
        // as: نوع تگ (پیش‌فرض div؛ برای ردیف‌های جدول از 'tr' استفاده کنید)
        function Reveal({ children, className, delay, animation, threshold, as, flat, style, ...rest }) {
            const [ref, visible] = useReveal(threshold);
            const tag = as || 'div';
            const isFlat = flat || tag === 'tr'; // transform روی tr در همه‌ی مرورگرها قابل‌اعتماد نیست
            const anim = (!isFlat && animation && animation !== 'up') ? ` reveal-${animation}` : '';
            const flatCls = isFlat ? ' reveal-flat' : '';
            const cls = `reveal${anim}${flatCls}${visible ? ' reveal-visible' : ''}${className ? ' ' + className : ''}`;
            const finalStyle = delay ? { transitionDelay: `${Math.min(delay, 600)}ms`, ...(style || {}) } : (style || undefined);
            return React.createElement(tag, {
                ref,
                className: cls,
                style: finalStyle,
                ...rest
            }, children);
        }

        // ============================================================
        // برنامه اصلی
        // ============================================================
        // ============================================================
        // انتخابگر تاریخ شمسی (روز / ماه / سال) - جایگزین input نوع date
        // ============================================================
        // ============================================================
        // نمایش تمام‌صفحه‌ی عکس آزمون
        // ============================================================
        function ImageLightbox({ images, index, onClose, onNavigate }) {
            const [scale, setScale] = React.useState(1);
            const [pos, setPos] = React.useState({ x: 0, y: 0 });
            const pointersRef = React.useRef(new Map());
            const lastDistRef = React.useRef(null);
            const dragStartRef = React.useRef(null);
            const lastTapRef = React.useRef(0);
            const imgRef = React.useRef(null);
            const wheelRef = React.useRef(null);

            // listener بومی با passive:false تا preventDefault واقعاً صفحه را اسکرول نکند
            React.useEffect(() => {
                const el = wheelRef.current;
                if (!el) return;
                const onWheel = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setScale(prev => Math.min(5, Math.max(1, prev - e.deltaY * 0.0015)));
                };
                el.addEventListener('wheel', onWheel, { passive: false });
                return () => el.removeEventListener('wheel', onWheel);
            }, []);

            const clampScale = (s) => Math.min(5, Math.max(1, s));

            // با عوض شدن عکس، زوم ریست شود
            React.useEffect(() => {
                setScale(1);
                setPos({ x: 0, y: 0 });
                pointersRef.current.clear();
                lastDistRef.current = null;
                dragStartRef.current = null;
            }, [index]);

            React.useEffect(() => {
                const handleKey = (e) => {
                    if (e.key === 'Escape') onClose();
                    if (e.key === 'ArrowLeft' && index < images.length - 1) onNavigate(index + 1);
                    if (e.key === 'ArrowRight' && index > 0) onNavigate(index - 1);
                };
                document.addEventListener('keydown', handleKey);
                return () => document.removeEventListener('keydown', handleKey);
            }, [index, images.length]);

            const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

            const toggleZoom = (clientX, clientY) => {
                setScale(prev => {
                    if (prev > 1) {
                        setPos({ x: 0, y: 0 });
                        return 1;
                    }
                    return 2.5;
                });
            };

            const handlePointerDown = (e) => {
                e.stopPropagation();
                if (e.currentTarget.setPointerCapture) {
                    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) {}
                }
                pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

                if (pointersRef.current.size === 1) {
                    dragStartRef.current = { x: e.clientX, y: e.clientY, posX: pos.x, posY: pos.y };
                    const now = Date.now();
                    if (now - lastTapRef.current < 300) {
                        toggleZoom(e.clientX, e.clientY);
                        dragStartRef.current = null;
                    }
                    lastTapRef.current = now;
                } else if (pointersRef.current.size === 2) {
                    const pts = Array.from(pointersRef.current.values());
                    lastDistRef.current = dist(pts[0], pts[1]);
                }
            };

            const handlePointerMove = (e) => {
                if (!pointersRef.current.has(e.pointerId)) return;
                e.stopPropagation();
                pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

                if (pointersRef.current.size === 2) {
                    const pts = Array.from(pointersRef.current.values());
                    const newDist = dist(pts[0], pts[1]);
                    if (lastDistRef.current) {
                        const ratio = newDist / lastDistRef.current;
                        setScale(prev => clampScale(prev * ratio));
                    }
                    lastDistRef.current = newDist;
                } else if (pointersRef.current.size === 1 && dragStartRef.current && scale > 1) {
                    const dx = e.clientX - dragStartRef.current.x;
                    const dy = e.clientY - dragStartRef.current.y;
                    setPos({ x: dragStartRef.current.posX + dx, y: dragStartRef.current.posY + dy });
                }
            };

            const endPointer = (e) => {
                pointersRef.current.delete(e.pointerId);
                if (pointersRef.current.size < 2) lastDistRef.current = null;
                if (pointersRef.current.size === 0) dragStartRef.current = null;
            };

            const hasPrev = index > 0;
            const hasNext = index < images.length - 1;

            return React.createElement('div', {
                onClick: onClose,
                style: {
                    position: 'fixed',
                    top: 0, left: 0, right: 0, bottom: 0,
                    background: 'rgba(0,0,0,0.92)',
                    zIndex: 1000,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden'
                }
            },
                React.createElement('button', {
                    onClick: onClose,
                    style: {
                        position: 'absolute',
                        top: 'max(68px, calc(env(safe-area-inset-top, 0px) + 32px))',
                        left: 'max(14px, calc(env(safe-area-inset-left, 0px) + 12px))',
                        background: 'rgba(255,255,255,0.22)',
                        color: '#fff',
                        borderRadius: '50%',
                        width: 48, height: 48,
                        minWidth: 48,
                        minHeight: 48,
                        fontSize: 28,
                        lineHeight: 1,
                        zIndex: 10020,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        padding: 0,
                        border: '1px solid rgba(255,255,255,0.35)',
                        cursor: 'pointer',
                        touchAction: 'manipulation'
                    }
                }, '×'),
                images.length > 1 &&
                React.createElement('div', {
                    style: {
                        position: 'absolute',
                        top: 14, right: 14,
                        color: '#fff',
                        fontSize: 13,
                        background: 'rgba(255,255,255,0.15)',
                        padding: '4px 10px',
                        borderRadius: 12
                    }
                }, `${toPersianDigits(index + 1)} / ${toPersianDigits(images.length)}`),
                React.createElement('div', {
                    ref: wheelRef,
                    style: {
                        width: '100%',
                        flex: 1,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        overflow: 'hidden',
                        touchAction: 'none'
                    },
                    onClick: (e) => e.stopPropagation(),
                    onPointerDown: handlePointerDown,
                    onPointerMove: handlePointerMove,
                    onPointerUp: endPointer,
                    onPointerCancel: endPointer,
                    onPointerLeave: endPointer
                },
                    React.createElement('img', {
                        ref: imgRef,
                        src: images[index],
                        draggable: false,
                        style: {
                            maxWidth: '94vw',
                            maxHeight: '85vh',
                            objectFit: 'contain',
                            borderRadius: 6,
                            transform: `translate(${pos.x}px, ${pos.y}px) scale(${scale})`,
                            transition: pointersRef.current.size > 0 ? 'none' : 'transform 0.15s ease-out',
                            cursor: scale > 1 ? 'grab' : 'zoom-in',
                            touchAction: 'none',
                            userSelect: 'none'
                        }
                    })
                ),
                images.length > 1 && scale === 1 &&
                React.createElement('div', {
                    style: { display: 'flex', gap: 16, marginTop: 16, zIndex: 1002 },
                    onClick: (e) => e.stopPropagation()
                },
                    React.createElement('button', {
                        onClick: () => hasPrev && onNavigate(index - 1),
                        disabled: !hasPrev,
                        className: 'btn-ghost',
                        style: { background: 'rgba(255,255,255,0.15)', color: '#fff', opacity: hasPrev ? 1 : 0.35 }
                    }, '‹ قبلی'),
                    React.createElement('button', {
                        onClick: () => hasNext && onNavigate(index + 1),
                        disabled: !hasNext,
                        className: 'btn-ghost',
                        style: { background: 'rgba(255,255,255,0.15)', color: '#fff', opacity: hasNext ? 1 : 0.35 }
                    }, 'بعدی ›')
                ),
                scale > 1 &&
                React.createElement('div', {
                    className: 'text-small',
                    style: { color: 'rgba(255,255,255,0.7)', marginTop: 10 }
                }, 'برای برگشت به حالت عادی، دوبار ضربه بزنید')
            );
        }

        function JalaliDatePicker({ value, onChange }) {
            const { jy, jm, jd } = React.useMemo(() => {
                try {
                    return isoToJalali(value);
                } catch {
                    return isoToJalali(todayISO());
                }
            }, [value]);

            const daysCount = jalaliDaysInMonth(jy, jm);
            const dayOptions = Array.from({ length: daysCount }, (_, i) => i + 1);
            const yearOptions = [];
            for (let y = jy + 5; y >= jy - 20; y--) yearOptions.push(y);

            const update = (newJy, newJm, newJd) => {
                const maxDay = jalaliDaysInMonth(newJy, newJm);
                const safeDay = Math.min(newJd, maxDay);
                onChange(jalaliToIso(newJy, newJm, safeDay));
            };

            return React.createElement('div', { className: 'flex gap-4', style: { flexWrap: 'nowrap' } },
                React.createElement('select', {
                    value: jd,
                    onChange: e => update(jy, jm, parseInt(e.target.value, 10)),
                    style: { flex: 1 }
                },
                    dayOptions.map(d => React.createElement('option', { key: d, value: d }, toPersianDigits(d)))
                ),
                React.createElement('select', {
                    value: jm,
                    onChange: e => update(jy, parseInt(e.target.value, 10), jd),
                    style: { flex: 1.6 }
                },
                    JALALI_MONTHS.map((m, idx) => React.createElement('option', { key: m, value: idx + 1 }, m))
                ),
                React.createElement('select', {
                    value: jy,
                    onChange: e => update(parseInt(e.target.value, 10), jm, jd),
                    style: { flex: 1 }
                },
                    yearOptions.map(y => React.createElement('option', { key: y, value: y }, toPersianDigits(y)))
                )
            );
        }

        function App() {
            const [data, setData] = React.useState(null);
            const [backend, setBackend] = React.useState('indexeddb');
            const [user, setUser] = React.useState(null);
            const [toast, setToast] = React.useState(null);
            const [manuallyLoggedOut, setManuallyLoggedOut] = React.useState(false);

            React.useEffect(() => {
                let cancelled = false;
                loadDataAsync().then(({ data: loaded, backend: b }) => {
                    if (!cancelled) {
                        setData(loaded);
                        setBackend(b);
                    }
                });
                return () => { cancelled = true; };
            }, []);

            const showToast = (msg, kind = 'success') => {
                setToast({ msg, kind });
                // پیام را به لایه نمایشی سراسری هم می‌فرستیم تا واقعاً روی صفحه دیده شود.
                // AppWrapper پیام را نمایش می‌دهد؛ این رویداد برای همه بخش‌های برنامه یکسان است.
                try {
                    document.dispatchEvent(new CustomEvent('show-toast', { detail: { msg, kind } }));
                } catch (e) {}
                // پاک‌کردن وضعیت داخلی پیام، بدون اثر روی داده‌های برنامه
                setTimeout(() => setToast(null), kind === 'error' ? 7000 : 3000);
            };

            // ذخیره‌سازی خوش‌بینانه: بلافاصله در حافظه‌ی برنامه به‌روزرسانی می‌شود تا
            // رابط کاربری فوری واکنش نشان دهد، و هم‌زمان به‌صورت ناهمگام در IndexedDB
            // نوشته می‌شود. با IndexedDB (به‌جای localStorage) این نوشتن تقریباً هیچ‌وقت
            // به‌خاطر کمبود جا شکست نمی‌خورد؛ اگر هم به هر دلیلی شکست بخورد، پیام خطا نشان داده می‌شود.
            const latestDataRef = React.useRef(null);
            const save = (arg) => {
                const newData = typeof arg === 'function' ? arg(latestDataRef.current || data) : arg;
                latestDataRef.current = newData;
                setData(newData);
                saveDataAsync(newData, backend).then(result => {
                    if (!result.ok) {
                        showToast('⚠️ ذخیره‌سازی ناموفق بود! لطفاً فضای خالی گوشی را بررسی کنید یا از تب «پشتیبان‌گیری» یک بکاپ بگیرید.', 'error');
                    } else {
                        scheduleAutoBackup(newData, backend);
                    }
                });
                return true;
            };

            latestDataRef.current = data;

            // ورود خودکار معلم (برنامه تک‌کاربره است)، مگر اینکه کاربر عمداً خارج شده باشد.
            // این افکت قبل از هر return شرطی تعریف شده تا ترتیب هوک‌ها همیشه ثابت بماند.
            React.useEffect(() => {
                if (!data || user || manuallyLoggedOut) return;
                const users = data.users || {};
                const teacherUsername = Object.keys(users).find(u => users[u] && users[u].role === 'teacher');
                if (!teacherUsername) {
                    save({ ...data, users: { ...users, teacher: { role: 'teacher', name: 'سید محمد رضا حسینی', studentIds: [] } } });
                } else {
                    setUser({ username: teacherUsername, ...users[teacherUsername] });
                }
            }, [data, user, manuallyLoggedOut]);

            if (data === null) {
                return React.createElement('div', { className: 'container' }, 'در حال بارگذاری...');
            }

            if (!user) {
                if (manuallyLoggedOut) {
                    return React.createElement('div', { className: 'container' },
                        React.createElement('div', { className: 'card', style: { textAlign: 'center', padding: 40 } },
                            React.createElement('div', { style: { fontSize: 48 } }, '👋'),
                            React.createElement('h3', null, 'از حساب خود خارج شدید'),
                            React.createElement('div', { style: { color: '#767267', margin: '10px 0 20px' } }, 'اطلاعات شما روی این دستگاه ذخیره باقی می‌ماند.'),
                            React.createElement('button', { className: 'btn-primary', onClick: () => setManuallyLoggedOut(false) }, 'ورود مجدد')
                        )
                    );
                }
                return React.createElement('div', { className: 'container' }, 'در حال ورود...');
            }

            return React.createElement(TeacherApp, {
                data, save, user,
                setUser: (u) => { if (u) setManuallyLoggedOut(false); setUser(u); },
                onLogout: () => { setManuallyLoggedOut(true); setUser(null); },
                showToast,
                storageOk: isStorageAvailable()
            });
        }

        function ToastMessage({ toast }) {
            const isError = toast.kind === 'error';
            return React.createElement('div', {
                className: `ui-toast ${isError ? 'ui-toast-error' : 'ui-toast-success'}`
            },
                React.createElement('div', { className: 'ui-toast-icon' }, isError ? '!' : '✓'),
                React.createElement('div', { className: 'ui-toast-text' }, toast.msg),
                React.createElement('div', { className: 'ui-toast-progress' })
            );
        }

        function AppHeader({ title, user, onLogout, onWeekly }) {
            return React.createElement('div', { className: 'header' },
                React.createElement('img', {
                    className: 'header-logo',
                    src: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAcAAAACWCAYAAABJhVgtAAEAAElEQVR42uydd5hdVbn/P2utvfdp0/tMJr1XEhJ6SULvKjgB7IoN0Z+9XFGTsffGvfaCXhVJwI6ioBCa9JZGeibT+5nTd1lr/f44kxiwXNu9ouZ9nvNAyHDmnL33er9v+b7fV3DUjtpR+3c1Ya2VQgg9+efqq9/y9vMWzV94UTyZWl5XUxOXUiaLxWK2WMjvGR3qveeXt9/+y1/feutjAFJKvv/976t169bpo5fyqB21o3bUjto/DfhJKQE46fQzj7t+401fvPexR7v6B0btH7Og6NsdT+0Ibrnjrns3fPa6NwK1AHfccYdz9HIetaN21I7aUfsnsPVSKQWQfP3b3/uFBx550hwCubFcZH7alY0+89CIfvvmcXPN7WPmP+4aNd/YNq4fG85HucmfKxQj++Pb7uvqeMnr1gFYaxUgjl7bo/bPZEcjt6N21P7twO+DRmud+MSnr/vJVS972Zm1tRVmXzbUP96eVt95qiAeLyaViZJQCiACbAgxK2pSPsfV9fPypTXmuTMrzCVnnTRtyZwZNy4/dtGxQoh3WWuVEMIA9uh1/pc1ORnoWEB0dMDQEAJWs3nzZgOYf6oyyL/xjTz03Y8e1qP2b/PMW2uFEMK77qvf+uWrrnzh6a6jwo37R52PPJgWTw4nIXRRIz4ik8VGeaSJIVQMm1KEFXFIOIhExHnzPD54Qsoc2yzsaEGor/3XVz/1rne84W133HGHs3bt2n86R3jU/myf+Sf9ZUcHatMm/mmCoH+HDFDR2JigsTFg2/bwiFtp/9Kbe9SO2j+z89q4caMUQugPfPo/v/PKV7zkdI0JP3Z/r/vhJw1+WIfXO4Hp78WOjUDog4zQ0kFIDyQoLwk1DZjptfxiT8ieoXH56fMq7UXtleGrX/uat6ajnF67du07169f73R2dh4FwH9B8GuaxqyYmzrOIbZSolMKX3pevOjImq7i8MRvNm0a3/LP5E//9TPAVpJtpdr6Yi6oCsPQaIKMAl9Nq9YTAN5EgT34R7PCo/YsPqMC1gOd9q99NtevX++8//3vj178ihe/6Nr3fuq/57XUhW95oMf9zDYHp9SA2deL6O5DjPRjCxl0bhCKBVBAqhInVYGWDiTrkc3tuC0NlKYlqVcuX7/Isc+ZVRVt39fnvu/azst/cOPXN954441H2aH/OiYBM2Va9WXSJt8gVXhiwoliKeniSLBOAuEliEQm9PP2M1ufGugECof+v6MA+I8zt6Km4sSgJvZSWV9xkhBY19fjsZLuDcfzWyPEkHYZikrR3jCV30MPxaPP+lH7R1tHR4d63eteJ9asWWOUlMbaMuYJKdDaiE2bNslt27bZzs5Ou379egHIDRs22ElnI++8805x5513sn37drtp0yYDMFn6dL570w92v+Cy57R//dEJXvvrjFR+ArNvAD28B9JZzMgw5CaYOz3GghlV5KM8T+wYZrTPQH0dKp6EylZs7TS86Y2UWmtoafb41aUJs7Q2Ib55w88OvuIFF8+z1oZCiKPB5L9I5keysWVWfXjn/FY9f9F8ZebMj4mWRs+EgWBgMGuf2Oazq7fBsSJJNpv/5RPb5XOhq/RszwTFv/JNi9fWTnXqijfNPHv18ekVC/ADQWF0FAbHiPb0FJ2hseHYRLEviuRjGLtPm2Af6B25Kbk9PEJ49Nk/av+Xtn79erlhwwYmiSSHrBaoAS8OwSgwdDgslxJj/nSALaVEa62kEPoVr7n62g9/4P0fDBxXn/PDQD01IpF7D6J79uKkx4l6+5nZ7vGhd57H+WtmU1NZiQUOHBzl+hs28/Gv/oaSqEMkq7A1FYiW5TjtDYSpai5YXOLbz5saFTNZp/MD7772a5//zw9v3LjxaBb4T+5HN4JcVxWbubAy9alXritecv75daaldZGoqFHCUZWIMCKKRhgZHueJh/fau+5rju7bW+V2pbu+X9gZf+Ugg4XJ93pWguCzFQDFMyKHv/TiScDEYFbVuTO2n/zmN7qPmZR1wqQ4p34qBzJd9pHB7So4uB+9ax+2f4LYaL7gZPJdYUnckbWx66OBgYefzTfuqP2LORpr5brJgfSVp5xy6lmXnHdBbaL6lKmtsxZXVKYqIt93h8aL2V27tm3v6Tvwm80P3HvH0I4dW6dNmz/7jLPPWF3Z2rgy5jqtQRiNFgr5PpP3n9y9a+fWu++4bQcwDOqML1z/nZ9d/dIr4p/e3M1bH4qJZFFTeHwnKn0Q3TfA4rYSG7/+BhbNqCWIQowFawye46GU4Cd3bOPl13yNtKlHJCuwTVNg6lxUSwORKvGN59bYly1v4Hs/+kX6za952cLh4eFBa+3R3vr/mc9cP+nP//pS+TMt3lo7rSEKv3jV8+UF735ztfGcNlnK9WDCDJIQa120W0OyuhFpigzs7OZT18votofrnYL2v777QN+rJn35s7IU6jy7buBh0HvmDVTAnx9JdiDYBKk5TbPN3Eb3icIoxbxQjoizKyFYNmUFtdWNdnDuUoZX9NjuroMiGBpPiu6DC9W2rtZk1/iTGXiIo3NNR+1/36SU0qwTQp9w6qkrL3vRS9922vKVV5yw7BhEojyonjcQE+AQVmMuPGkkmzvpsW1PXbt738H0vBnTalYuWUpVZRIrQIchvh+RKQX0Dw6yZ9++/tt/fceuO+/97Zxjlh2T6E0H9obtoSCIYfrSONkM1o+odCb40idexaIZNRSKWRAprDFYaylEJXTkc8naxbzv7c/hTe/6Ll58NuFIL8QqkZUetqaBbz6ZFxcsqIlOOe742oue97zzv/HlL1+/fv161dnZGR29zf9LPnP1esU1G6y4QmlM52StXICQ2Pfe7nDnnbB5u4VNf4yZKdevX8+GDRus2LBBdGzfLjYNbRJsxs6vr08Wyf3nxaeGF1x1RZ0Wulam01twggKpvEIUwMgSIpbFnxhD1LbRMjtFx0Va/XZ7QY8XwktmtdR/ad/A6MM8S/uBz0oHvwgqRNXU5uG4nxsaGhoHgr/oDTo6FJs26cqTpl6XOH/K64frGiMbTnFU5Ry010hCWjwvZFlTGw3xBPePDuE5MatSAzp91yYn+PljD+buGV+DoIg9yg7954yG/ynumZBSWGNsxfs2fOgDZ5679pqTVi138yZhnxgp6a1jWbFtVMqujMVViiZPM7sKc/KUFMe0JGSVQgxH2IOjJd015ot0ECCEYnpVws6oVTRXeyoFIl8IeWxPN4umN9ndYyWx+oYSNmOJdmxFjPehB3q48NQmfvaNqymUQqQjMYHFWgvCgogw1oJwSWctay54K/vGXFSqFp2cAnOXEpvdgu/4XPe8+uj1C2vU57/2jR+88bWvev7kbODRMujf2zo6FDfdrLGHMcWF2HTwBGQnOKJULgArJZz2Xoem7ZZNh8HwaefkmYemrbntomXTMj/tvNrVK1Z6quRnSQRFTL9D+lHDYI+GhKJ9hkP1LJ+wzYVkBdKP+PAXpfnO3XEjJP+5e//gm5+tAOg8W5zV7Hjt1KgqvrIo7eJ4Q9PLqqtrZ1aFQXZG85ThkeLE1/ft2fexP9OxCW7apAGBNEsr4zGEG4lxo9E6wnUUPjmKQYb7ejLIhCLp1KJkSuQnSko3+5YWucTDmxHYYAdHxyP+KWz9+vVyzZo1cs2aNVpKaYUQ/PrXv3aGh4fts7QPJW2ZmdL8ns/9581vfsUrTqlMuvahwYL+1ONp9csh5WRDB4yLdD2sttgoAGVUxbYxTm8VnNxQaW/pnhA7xpWT8y2RKYNUyivSnog4rQXOaVd29Ywqc+qyWRIicfcTEX7BxysWMKNDOFEWSllOPvYksCCsxYZR2VeJyZln6yCEQWtDdWWME1fMZ9/NDyMrq9CFIcgWMToAN8Ztu0N5zRIpZk6ddjwQU0r5R8/Q3xv8Nio2rdNAFTOe+5rYqpNXtS1aeGyspnZmiBUUM5nC8Oje0QPd24KdDzxqd9w/jBn6JZs7Rw9niO/7jUPn2qg21bTUts+61m2LN/uBM2GGswfd0q4tMT3e215j3nPBCs8snRaIoJDHiwLMmKT7gYgHH42TbW7EK8Hgk2Mc7wYkG0DLCaT0OGeZx6+eFE6m5HY00/yeQQbzz8bn4NkCgI6orfiQ46iLW7Qwp1VPq1s8fSalkXTN/spszUPpvo8G7ZHt6Tn4qcko4s+5iHVUyjm5GknjgYLQToGxhgxhbhdeY5FYwkfbGL5wmRtP0juxh5HxR3HTg8LxtXKSiWRQCI4etme5bezoUB0bN1ohhDli9syx1kZr166N4DADkmfR4RPr198hhRD6Df+x/ltvffFLTxEyEXzwwUH3C3u1GiomcEKHRP844UQOG0UoqVDxOLqmklx1LT/vtvy8OxJCVOKGGpUzUPKRNiJIeuws1rBzzPC1PaGYlxpWV8+NuGRxC3vHJtnpvsYJNa51MEows70RKyxaW6QUWNTTjqiwBm0t2UKBusZKCLLIUoCKwKRHMH4zOA77+wpyNMLMmj27ffWZ5562+de/vL2jo0Nu2rRJ//nXZv3hylRnZ+dfywP417TV6x02rYuYcvyFidNe8rn6NefOnjJlBh6SbLaIDjRSyZqGObGVLaezsjDe95LhXfdR2LPlcb+v6x67+7F+Rnb8ak7n2i3djZUvTsxa/OmXXkLNcYs1XaOWh3ZP47GdU/HHNM1VB2hv7SEuNMVQ49o4xXREX0bhnn0mtRVxdFhkeGc3PSN7mFcMUFKgCWlNGjmtIWV3j8Zaa6aGCwe7OVQGfVYFo/9oABSAaW5uXpgVEStSTdUvnX+yOGnqAtMwZ6Yo7O1juLtPy/FADouha5qbm7cNDg7e8j9EEgKLdeLOQl1NazFhGZRaHFPVyswT1/Cjnfcykd3CPFvCFGPs92sQNeCoAtL0oYMsIrLWDSP/6Gl7dpvduFGJdes0QnDJ+eevuuh5F3ZMnTpjTXV1dUMumy9mshOb77vvgV8IIX72bCqNbty4Ua5btzZ6zuWveOfrrnnVudrGwjfess/77mgKKSpxe8bRB3oojQ4jQo2wAiEE1gFiLrK6BTm1GRoqUD1F9OAIujiCDAN0ECCExk1WYmsbMa017ErGefOeiI17R4kLB+IuRhXRMYmKBMYP6B+aIOsLIq1RwgVACXu4RyJQBKFlcDxH0ffBFIm0DyhEdhSTD3HiHvt6imw/OGGOnT7NmTVv3urNv/7l7YsWvU7Apj+Vv8v165EbNmzQSil7BOiVU+Uyk1Vu2LBBdnZ26n9bMFy93mFzZxSf/dxr1YXXfFCtPQs/XYq2PDkgCiOhoBQX5UGYEBxtE5WeSTTWIxdeJhuXdywnO7Y817OV4u4Hrz3Y/9S2KFua84Lnlmo+fMmtEbZdRIuG8I83dv9wm3ykPyH8rpRNVselH8tirSQSIY5naFs8j7B1FsMHBglTtXjVY+hEERsXaA1WSLwopD5hTV9VTOlC2NTRgRoaQmze/C9WAu3o6FCLFi2yANu3bxebNm36czM0Adg5LS2NIyW9dnl9y4p3nX25OKV+qvE9JUVNFTEGmJGPqZPCRnG39moztrR6enX1vV0TE+k/6swmCTDOzKrVcl6NtDaMxqqNM+GOsLvnAUqVGazQhNEITfkYY1nFQ9lunKoCTkXRylAJVRTjbuhmj0aez1o7JOml33DVi857zrqON0yZteC8BXPmSSZLBGX6CIvPPHvt61avXv2rt7/9tS/cubNvbMOGDeIfqVLS0dGhrrjiCt2y5LhVl79g3YbZDVOia+/qd+4seVQWPfI792MGhpD5LKaQwYwNQSmPVi5UpHDiAsaHIT2GTrro7BhukEeGBl0qUvZACh0NYGO9kJ6J01KDaqznt0MxcCQyAdoBm0oSprOA5c6Hu1h7QYFG16cqJTDKQQuBY8EKix/69PZn6U4btmzbDSbARiWEjGO1QBSKyIYK8uMhj+0eFifNmoMf2hMANmxYYzo7/3DZesOGDUIIoTs7MZ3lH6pYsGBZ2+LFx8UJhrj5pz8dNMaMCyECwAghMMb8+2mOToKft+jyd4pz3/JBtfxYndsxKjJDBUcIB0coiGkMGmslwsZFKSOknx7HCoOMSeNWpYyqP5X41FOTaP+42r5HePGil1gTJJ3xxqUkCmli3gRLZiqWzMrAimER+AEyEhAYrNW4zYKKaIyGQg+yopZSTJBqzTJttouoFpANEMbDFEOETJFMuIzHhbNpE7pchHl29QL/VgD8Y6WNP/tLhjLWrsOJxccvOnbBSVMWkr/rcRGMZ4nXVGN0nnzvOLNzhhlelbeLTN7kI+9PvuGi9RY6SbTWnKimVuFbK2iu4IloEDE6SpDwiKmQroKhymtmYfsSQhNnTOykVMzYRNogcuapNJmxo52LZy34IYQwn/nE+vdfduVL3zt1ykwAotKWKMj9WnphF740yNj5pqbqPHvJJZecM5Ee+7oQ4jnWWtX5h7zx/132Z4UQ4tVXXPrx552zNn7L3hF9y6gSjSrJ0FN7MX0jyOwIerAbsuMsntPE3DkzmMjleXxbH+N7ctDcgCGEQjXSLxD0D0MxC54BLcqv6iRKltBjCm0tUQHcmU2YahcdBFAqIUMJUQRxxUMPPsEDjy9j4YxGFrgxKmIWlMBoGC34DIxnuX/nAPds62fHtietcKywJsSKABwXEQUYbSCfIz0uhQBqahumADHHcZ7ZBzw89jF5L+a/7DWvP7t9zoJLly5esGBqY01zfVWtjHTAG9557cR4Lkjv27t775bHH/zh9V/98s1CiH4hBO973/vkv4Xk2vr1ks73R27N8S9Rx1/2UeavjLK7+pTNGyGMAiLKtX6DwEEIVe7zSYN1JBiJLVpZKk5I+idQMSwqZs+cskfMb8+JCU9SPfYoUXEALePoZAtRIkU8WYPy8pj0QVyKWCEhCTWtg5ixe6mvn4aNRqiY51PZ1k52dJCYMshMxPBYSD7Q0nMcXDf54ZkzZ84pFov/PTAwMMxfyup/NgLg+vXrZWdnp1myYMmFc+bMfKcVIjfUP/jt3z78wI+A0urVq53Nmzf/j/TnSEdtyViscv/ERHTvtl1O4uGdot4XNK1spuTEGe4dFuNujamonBZLqdzZRTPxS2D4j77h+ztNFdSRkIuzqoQuCZEMU7Q5cbplRBAWSRKwfPoylkSLCeKt7Jw4iB7PIgtFVAZUFMvB0UH4Z3HmpzZu/P73L33Ocy5VXlyXitsR2f9SpvgrB5XHyBrcIMJP3yjDwtupaHtreM55511y1VUvO1tKeds/akC7o6NDCSHM3BVrTzv7tNPWjEZCf+Shoto+VIPTl0aMFHHyw0RdT7Gg1fCRz1zBWacspKIyhrUhe/vG+Oa37+OT121GW4VNpDEDfZx+/GyuuPREZsxsppgr8Jt7d/LtTVvIDvk4OsKWCqhsG0Hgo+a2gNAIA0J5aClQiTgD3X386paHKVxwGk/1ZVnSWEVlKka2UGAwE7D50X3ct72Hvq4uckNDqFQLkRQIGYEbYhC4kYaxbjJjjSIq69LUJBKJxkKh0DvZhLUdHR3q5ptv1uuE0PPnz1/1ole+5prjjjvxihXHHBNvqkkCUMJighAULFJeNVCtzWnT+0cvO+PFL3nphiceefhrb3nT//twZ2dnZlJ39F95zGKymGHbnPYzPmemnmeDnkFps1pgZTnjFxqlBEJKopKPjXS5VJ7wkEKBtlijEcZgJagAEew/IE5vuZ5YIk1eVCCLBRQBIgzQ2QxuQWGJg7VIE4CQZYKUVYimJA1NJbS/DZWsgFg1pbE0FbkisiAI9hse7m0jLypFlchSaycWuyn3U2nPvVq4ddf0d4/9avJ7/d3mFf9PAfAQ+M2aNeuC+sban1VXVlJTV8eUlpbz6xvr7+zq6X7t5s2bd3Z0dKg/0fy2AFbIBsd1Kvb29ed3JobiTVFosyImutMB3qypbDm5lXuKiO0jOygWBxfkkvvGKR6m8P6+vQ/pfjwxy1Sqxggfr+gKVQiobHARcQ8ZDwiky5bcMD496Pwo3bkDIHM4kcbLKwhlhr909OKo/a/bITLLf//39Td0dFx+qaYUlkauc+3E9eCO46YWIkUt2loMEV7xUYpjHySIrZTNTWvsWWeted/Xv379bzo6Ov63D53o6OiQi173OrEGuPPOOwGoq6tTN23a5J919smXLD9+lbjuyXH74IEAd6KbsGcEZ6IbM7yfxTMdbv3O/6O9rZYg0oQFH43DjJZ6PvQfz2PJnDZe/oZv4Ev4yLuewztefx6HltsCXHrecl515am8/HVf4bHt21GtzehiHhkE2EqJbKrBJjxMXSVCN2BLeWI17dz6o3sYyoY0LJnL/S7UxuI4KmI8XeTRbSNkRsZIP3InQlYIo5IIaRGeKGejGKQBbIG6qhTSYkfGJhqLxeI0R6keyvNmh8Cq4e3vWb/hrHPOv/rME0+QygUfEz3YVxB3duflvUOa/olIxKRLa0rb9hrsWbNr7elt1Zxx6kn1p5180jsXLVx4wYYPfeCFnZ2dW/6lQbBjo6BznRb1p78rWHFmjUZHpCPnMCCJCKksekLD4ABVqkRtpUc2oxnLG4xbCzUpqPJQHght0SVNtdnKabO6MFqSCjShDhFW4kiBFIayCoKPJkIcGtEWAoxFTpTA00jXJSoVUekx4pEmlCARpH2PJ+OLyMyfQ2mki+HB3cbV2lRXyTlCim/70xJvGDvYu4nfFzz5pwBAMdmkTlankv+lCwW6u/Z153UpmDN9xozldYvWpFLxR4QQb9y0adPX/wQIlr+4tBKUHS9mhu8N8vXF6dOZiE0lfsJq4staeOSpUXof30nox4mZiuq4jVcHZWz6QxdO0IkptMZOdqqjChtZEwah9Coq2GPzWOIofNyoyHSvDWyePdEowomwuQykQ8GEhkz0EGCwz34x138Xu+OO9Y4QIvr0R9716ud3rLvMUApKPR/zdGkDSXcawltB5OfQ5h5ENIaVFbheHV6QJhr4vPJqT9KnnXLyqZecteY8IcQt/0Nw9leD3saNG62U0mzatEmzaRPPKLZGEJu1YM701wgZszfvzilMDMYGEKO7sIUxyAzwqc9cQ3tbLcWij1ASIywWTVgEYzNc2XECt/zyMVTC4V3/7wIi38dHlYkyxmB0xDGLpvDdr1/Nmee+m6HxcUyNgWISm21AxePYXB5KBZSUaDz8TC+MTfDbTTfaJf1LTHbabNUtPIJSxMGuIfoOdAfh4DakiyuT7UKLMuCamIeIeeAIQiWpP+l4Fq2aLSj55ooXXOlufeLhN2x/9O69SqnBzs5OKmoaTlv/oU999ZUve8H8mmRks76vb9yRl9/bZZyH0zGyOReMW3a2AaCNQBjxX4+OsKqpyFXLquyVC1qic885a2myInXX5z7/uas6Ozt/8C8quya56XINTBdTVr1ETl9ibDGtbCSxToTVBoVCD/Qz1YzzxhdP55KTW2ipTTGSD3ls1xD3PjbCHdv2sWV/jMhKqEhAEGd53cMsaZtARzFcIqzRYMFiy051smEnrHxmDaZMsoksUluU9ZFWYJQAaxFJS+MKxXtWbeFAbjv3dTVyz4wT5YGhhJS5kpkydLDZ9O/bWD195sf3d+2/Fv6xq5Ocv+qmgG5vb18SaT1jaGioZ/HSxT+Wgo4HHnzgYyuXLXtTZSqRmtbe9jVjTOOmTZs++qfKoVqbvOMq5USB6olgS2wmo0477ElDn4LMKGo0KyiG2q1od2xq2sWMbX1wUh3/93NKgdA1arnXlMK1gdWOphRlUFiMiCDMI/Mhc2dPx7hJnhJ96GIWGfrWZiIZpMNslAsfOjJLPWr/eFuzZoOBTlYdd96L47GEKY78RNmJj1MVl1gDpcIDCDuIIyzKKCIjMFKi3Bilwq9xxrczZeoKu/bsNa//ye133jLZi/t79fXUlVdeqTdt2qQn37Pu7EsuWbJo0ZLTEnGv4kBXjzM8lvG3bNk2kkhVnHnaiadU3NtTME8NKilsDTY/gLBxdC5k2ZJpnHLSPPJ+DiUcjLZgRbmlo0BYgR8U+eCGdSRiEh2WiPDAaqwtK7dI6ZCdCFg4u4U3va2Dd777uzi1jej8GGKwF1MKIJvBLaQJevdC0M9FZy/geed2cPyqWaKltUrGYh7GCPySbw8eHBSbN989fsP3c+EjDw+1m1hknepaYePVaDeOk6xExyowKkFapfjqI2NMr6mTa09cYt7x7muvePPVV+0eH+799FkXXvyiF77kZZ+59MKLHEc50S93Tjif3FpQtw9UgBE4w6M4QwUoFCAKwPoo10HU1hLVprgvV8N9O3Pi9lUH3A+e1apPO/mkGlfIm4sFc/7ll19+678eCHYI7CZILn+T076q2opEZEoFRxCBkSjlontHOaUhy42dJzKltbYMYCagstplZtscLl0zh2IY8dT+UTb/tp9bt+zmwYdGuOi4h3BTeSKjMFGZacwh8JvsJ5YzCvEH+hCH/qb8bFpbBj9lwToCmVI0VXs06zwnTN/Jy4MRdqWruemJBfL2R6eYirF+mTPyHa1Tp97e3919G4sWeTQ2Gv4BC3X/GgC0AMaYwA+CASGluONXt990wllr5qRzuZF77r7jdc0tbV8XOLalqeEjxfnzt2/evPknfwAEJzM4eUBYCJPxxv1Fn4l0GkUcVXIQzRVoH0hUI5uniEjOJi6K18DWz8P7h38vC5STn63eafFrXSgGOCpJVU0jtiRIWwftgqyqIFXbzsFsibQRCJNHaN+qPMLmzM7SuNlzFHKeXb0/KaUBqiobvbnWWmlGf2xUVCAMKlCqG1eUqfoIiRUSQQB2AuEkiXvj6OwvJfUrWHXccefU11etklI+vH49srPzbzpwh9mogFh93oXPX33a6a+cO3vOivnzZzcuWbQQ11Fks3lyhYDugWF6hodpaWyzP96dkfnxCOVnsIUMChfju6xYMpeKlCST8xBKczgmP7QRApcosrQ2JUFAaBTGGo5QBMFicF0XP4w4Z/VKPl77PcYK40gVoUf2I/NZnCBHsH8ny+fW8vGPvYWzT198xAnXwhiDFpZUpSeaGmtZtXJB8zVXv5wf/Pg+NnziO2J3d4ZYhULrEtH4MDJWAY6DoYZf7A5IJdJ8Zm2NuOjcM+1T1/y/t9xy6y9e8N71nbNPXrGCfJg3H7pnxPn4Ey6RjpEYHCQ8OEQ0PIrMFXCjEkIatNCEtoCJ1yMbZxKb0gStNdzweETPeJ+67sIWfeLxJ8iXvexF3/75Tzct7ujoGJ28H/8KgauAmzRQKWraOpg220ZhQYpIgtTlnlw+Q1u0l693nseU1hSFvC4LpKOwRCibwwiB6zismNfMinn1vIljOLi7G+fRLxJNGEzSQUTmsC7MoaDQWv5oDiAn/7L82NmyWJAUk85YE0YRImPRyRZshaE6nOB4Zx/zVx5kfGyF/MWeZlvt9OI53mXAbWzfHjyjWa7YtIn/i+zwrwbAMAwHTOT0pBy1ZPb0qUvv3/7QC9rrWq977PGnXrR4cb40b+bU/47ZpKlIeP9Z1173yObNm3v5A+xQI7VnrOkrFGPD2qRqVGWFDbUj7LR6Esub0KUmor480WiFLB7ot8prr61onTYv139wGFYrOAyqArAV0BhVebN0TICPiIQiiguaGlpoSzXRU9qHyQ3y4z13I6vmYkONl01jigU830H7/lbIjx3FnGePrV+/XnR2dtpF0+fOklY1IUAP75LSCnQtSCSOdQmVQUiLFSHWCow1CClwpKCUvUVE+o3Rscef5jz/kguf8+Vv3vDwGtbLTv5qFqEQZcUZ+5JXvvLK008/+83LFy86bvGcGeAKeovW3tNd1HktqfcUDRVVLFzaIFaKeZII0V+aAKNQuVGCwiiilIagRFUsTmTB4mCQSKsPt7uNFOVykxHkSxFCgZQCx1oQ5Q3PQpTVXEATRQInFqe+SjDafQBbNw8RFlEyTdC7hyufs4gvfvrVVFcnKPklsBKLxViFthJpLQJLKCKM1db1jHjBFadz1tnH8vq3f4lNN9+PmjoNY/oxB0s4SIxwMVPr+cGuCY5t98SbjhG86qUvTV16+ZWzZ0ytM5nMuHjnQ6H82tY83kQKp3uc4sgoKj2IF2WISmP46REIJomjqThOKkSXSviZDCo3E2d+K3cfKNJ5R7/69vnT9cUXXtT4qS985b+EEOte/epXu+VS8z979aZDwiYNyTnUz2u1NXUQBlJagdACYhFRVzcvu7iN+a2V5HI+jgvC+AihsFKUxyGMIoogCgMC4RMnSVXlGMaOQtbBYPGEBGnQUoIVKGvRhwIq+ztQ/F3UJ8sAaSaBUHD4GS0L0haxpgfHB6s8Ai+FETGqZI5LavZzu20VMWKIuHnpvEULF0wotV1G9pEgnbt3tL/rKZ7emlD/m0D4V7NAh4eHJ5Kxtt4az1uVcuWJj+yd+M+6bNXoKUtaP94nB05FejYZb7Ux15la66a+5bUEVw4M5H4/a4tUSjh+viC8cakNTl0NgWxHuJVkh0vYbBH68mVJTj2uo6TrqMqW8+g/eC9zehV7iI7I/3RQ7Z2SrEvMKyhhlaqQ1qlibGKMiUKOeHWWRByW10+h1FDLo4NZrD9OZAuoghYypwgL+vHJA3R0COJZZkbmC8bGDKCCQjOMW5Kej0kajAzAlA8wkcQqgRUgCBEyBsHj+OlHRKr+VNaevfakL3/zBtZs2GD4q0Yi1kspP2CMMZVv3/Cxr6y7fN0Vi+Y3k8uhf9AT8fNxX25NR6Ivl3BymRIU8ySkZU5NjBNbEly8MMlQ1oHKSnRBI9wkpjAEKmJPVx896SIVUgPeZFFKHH4QpbSkiyGDA+PMmFKLSkRo5O82OU/y6ow1+Nqhe2ScwBjwc6ADPGPxe7t40eXH8a3PvBJrI4pBgBCirPdpyjGqeoZPE0KKKBIEQYm6mgTf/9rbqK/+Kl/65h047e0YkSbq60JV1SPHXXRdBZ95cIKTpsQ5tr3GtoTGOpGSn+ny+ebDGkGcaNd+zFgfopjBlgoEgwNIcqxc3MS0aQ3oIOKxx/vp7h/BrdNEwRAi1wvRYrxFs/jhds3n2sfUtSc1Rld0rOvYum3ny7/6hU9/81+jFDpUvvqVM89UrcsksjKypaJj7aQOgF/AyfRxzkmLsFikNOVypHARWJSZvIGHkmFhiVkHTJGcqWFscBGzewdI1UEp5eBUamRCE8UFBosbgjUSayVIC+LICoM4YqCFp2WM1poys0WWy/YiCiAMiISHmNBMpBvJtr2YwG5DDT0Vr4ii1e0xsTpQcaKEH1XXNm3z/eK9fmHi+yP93b+d9MXwvzQ/+LfMAQYaq10jbbNbv3DeVNZdc17ssrq2xik/fXKEKtUTxlJSDQw6NuZ4K0uq+pXt7bnP9vRQ4ggGp3XksNbGidU3z8yMToAYFLa2mWhsGKvqEFIiIh/rSEwsIYTnQLL2bGA9u3cHk+GJpQPYBKbVWRi1OQKPSNqUM6VpHhN+N9n0QUrSIfQlu4c0iao4juMi1DiODq2Td4Qe8/soRF21s2qrx/eNTxwFwWeHdXZ2WiklT+3vOzg4erBHcMx01fo8k937S5moKiKlQMcUAlPu3QuBnOxTEBnAxZE5ovEfS+pPZda8ecdWV1fXSinH/4p7LKzdgBCdyXd/8JM/e+1rX32644pw4yM5dd1eXz1WSCDGFE6xhPTT2IkM2rcUlcODiRIPxrN8c6eDp6oQVqMjgVAOVjiQrGTLni6e2DvCipkN1LgGOwmC1lqsjSgUBA9t7+eJbfu55MyVzJuanHQ+k1BpwQoBymUsXWT3viEKfgA2QtoS/mA3px8/iy997BWgs0QmBkaijf4fLkUZWaUUlEohwon4r0+/irGxLBt//CReWz3hRBfmYBKVWI5y4wwHKT511zjfu7RNOLIofjKi+ehDGhtV43btw2RGEBPj6PFRbPoAF1+0iDe+6iWceOxMUrHyuG//YJa3bvguN9z0EGpKO1F2FNU7QFRTjWyYwgfuTLOqSclzZ9fZE08+/cPf/K9P3dTR0fH30J38Q5Js/1e+QMCdGoQnE1NeIZpnY3UoiTQWjXUsdiDLstaQYxc1EpR8pBSHAahcnjj0Z3v4z9IqtIyoqKplaMHruf3mbqaHO2msDkjVOVTWOXh1Gl2h0CmDcMBIDVogtThMjDFH4pA5BLDPIM1YgRG2jMEonBBsFnZ0JchVnU1w7CWI3LDNjG43on+bjQ3tFp4JHaX9Y1xHHqMqG1/Xlqx6OCyVPj/cu/cHQP5/AwT/FgCUCulZpQV2YlmLjd0Yj/o4+9i6aOkxJ6qULLr3PNZje4cikZ1QSVCLI9GyGAYePhIACaOckEJFkYhJo6kgx1hYwCBRWiLjHpEwWC1QbkwGuRIu3gLi8akI0cXheZIyAsZaq+ebFgdtQgKbJxg/SENljIaaRsbyRYJSxKKpC9k7ZskFgwg5jo1K1makUAW7W03op8brj4LOs8ys1loKIUqbb7tl5xlnXjzNnXKWHchMJ9mznSpX4NQYdMxghUBKWe5NiPKhtTLEk2BydwrCcT1v3rLaV7/6pad84hOf/9lfuK5H3HHHHUoIEb3+He/+0itf9sLT81EUfPQx7d38lCQ35iGGhxBdu4hGsxAUESbCERJXCcJ4NU79TPLparLTQlypCXWENAG6lEfagL69Xdz+m62I1cuZ3epSW5lCSYWQgpxv2HtwjLu29LH1YJ7k1i4qEtOpr6hAuuWypwVCq0inMzzy2F4O9o5SLBUQBNiwSNL1+diHXkoqFhGUXIx1sEdq50z6eHuI5HBkmD/5ZykFgZE4UY7PfPJVPPDEO+geHMGrrMQf7UWMtePGPWRdA7/aO87tB/KcOruCD95xkPTjElU8gB4eReTGsPkslWaQz33uSl5+5ZqySwhKFIMAIk1TvcfXP/9K+nuGufPRAbzqZsL8ILanBs9JELnwsQcjeWJ7UZ+79vSWK1/3ztcKIT7xt2SBZVLTFfpISbZDi4X/jxRoBAjj4c0y1XPmm7p2dBCVO5vCoIQl6p9g9VmzqKxMkcsVynOA/wOpy8oAjEcSn7aVp5Ix1/HAvbfgH3iA6oO7mZbM0V4f0VBnSVYLvGqJqDCYlABPIoXFYrDiEFO0PIpRxrlDfUFxeGLCCtASlAEVRGQGHO7eEcev3Q6Vi7CNrcKZNVfpuZfg5w/iDOyyftcWy+AuU1MYdBw/vyruyW+3OwveWshGrx0b23M/f+chevXX3RxoraioM448s97Rc2ZU5WI9QyXT3ACnrWlT01o9IUKfqa3zxMmnrLWJilpn687+hkwhGqlMJvsLhUL60D2prKxpUUTHR/HpxxRjrTGb6cXE5gpkDJvwcGMeUXECfB9HB+ixYeHZwZjSwzdFhUL34ZO7Y7uB6trYiorPRnOcCh0hKmMJ4ShDOjeClIIaKXEjh4miYthINAVMcQyyPvJAaO1uPoO2j4QNmSzDHF3h8iyyO++8U3V1dZm+3u76OXNaz194zMk2X4jJkcdvpTIBMg4yZtHKYpE4k0fSWrBClUui2QyRt9JW1C+XA/091T/80U+/f+edd/6e9uSfcowXXXSRvur1b/3Em1979dVVDU3hWx7Oet/fqtFdecTWbYh92xHZIZSfRecy2OwEuhAQmQLC5LATWdR4BhNpVFU1OAqCEmpgGCkDdGYITyqmzJzGY3v2MpGLSI8X2N8zwoNbe7jvqT47NBGI+370PVK1NaaYqBdJR5OKx5FYCpGleyTLvQ/sZv+BCbZufZytd92OW11PlI540+sv5uUvOINCMQTpYIw+srB1OKi3iLJjs5P8CHFoZKv8UkjCyKehpoq6VDU/vPkORG01xlpEFEPHqxEpj0grBgOfbm245eEQPZJBDuzFpvsw6T7cwgA3f/UqOi45AT/00bocxExq5BOEhrjnsmTBNL737V8QuhEWH6EtIpKo2gb25X2mN0tx1sw6m0okT37gyUd//KXPf34YkJs3b/6LwMpaK5csWWKstfKMU49feP5Fx82fPW15zZbtW4qdnZ0lKSXve9/7/uL3/ctstYIu4yQXP8cuvOw5ct7SyOZ9ZU1UzuQx0N3Fu185j/mzmgiCECnLAHjo9btGtXg6sUWUUxfHETS2t9C26Djic04hX7eMXWY6u8ZS9Pb6ZAZKhCMGOWEQGQF5hTEWFEipynOnk6mHsAKMQpjyqROU5wElFoPECnCLkm2PCz65ZRVR/WIiKtDZEuFoBpMpgddIYupi4S0+RbhLTpWltiUYt9ok/aKJO7pVKPsix/VuK+YzPZOJm/mHAuC06kDmiK+ohtknTneqlswtsmKmEm40QqK2GV11Gqnmy6ltPF3MmnWMiUldtWP7jmTg019dWz2ezWYnAKhoEJ4pHi8Tzcf4sZZEaWQAWTVXSBnDOg4y7kJ+ArIT2KAgiIxOtNVIU+x/PEoPPkhHh2T7dgFYtyG+OH5M9VvCFouOpHCtg6MkJaEJbIgnIjybonnKHIYjn1I0Cn7aytFAqAPRcGFL6dMVU+L9pV2lwlHIeVaYsNaKzs5O0dXVZYUQjKfz+/Yf2HPpymOW1S5eebHpzlkZbv0NNdUOuArlgBCyrIjOZAlGSBAuUZCjGMVFsum5FAvZeT/5yU9+9Y53vKt7/fr1/6ND6+jYqN7//sv16Rd2PO+Nr37J55YuWBC997Ex51s7EN7uCfTuR2B0CFXKo0cHMZkRamsVy+bW0tYgyA0PUxocxcQirJ/HGc+jZQpRX4WSIaavD1scx0kl6N6xg9qqOBVN7WzbP8bBgSL7esfoGpmwPSVPPHnHTzJ99//gyaHxqFVPaRN+PhKjI1n29eXYsXechx86wMEJQ59f5Ncbb8QvFLGxWurrarnuU2+kpjqO1mBMxKGF7UKUXZe15c0PCoOWk31UEVFOP+TTSqJCCKLQMH/BLH5z72N0dw2gKqqwocY6DlRWI+JVHMxaHhqQ+GlgaB9mtA9ZLCGGd/HFD13B5c89gVIpi1QuWFkG0UlXI4QkCELapzfy1O49PPnANtzKetAWI11sVRV4cXZlrbholquPmdkaHxzPNZy95rSb7rzzTvnnBjeTZCtn7dq1+oqOjue/5/3Xfu/KF794w7nnPOeqU9asufr5lz33xQvmzYvfdvuvH968eXO4ceNGtWnTpv8dEFz/Mti8GbfumI+bYy6eZRoarM2UJFYjpMBk8sxQ/bz3tScT9wRlacCnlz2F/R1zmGdkhmUclCgkFckYLS31zJk1g+mLj6Ni8VkUp55CjzuX3ekKdvcYBnt88oMB0YjGHQcKDk4IAl2WRxMSpMBIixWTGaKwk9QVBRZU2uFX9yaiTYPHWNG6WJp4AuE45dkeDWYipDgwgT9aQAYJTONsosWrhKmYK8PxtI4x6LlRcYlwGgZLhbGnflf5+78vgZaFr4cptjeRHwkj8VQmbo+rEmSzhqDqHLxpb0AlF1EsZigVIsIgks85b40JwomTP/vlG35h/cZHDr1ZXtbmKqPxAaWzQ8Yv1iVr66xvi8KUClCIEfluOeKorECoJDZstqVwD1aLWb/zTuX+n66MLQiTIQZrRBSToSsI0bgxr1xmMnkWzj6RfekiOVlCOAGSwIoCQqTNQaLSQSFLR3t+/2DbuLFDdXRstEIKI4RAKcXtt9/ubNiwlrvuYnjXzj3XffZTH/3sBz70WbvgnNfZPWM7xPC+G2lyYxglcJNgpAE1mcmYCAtIT+DkNwtTHNDLjlmlzj33rI7vfGfTfZMC2X8SiDdu7DBCrPPOOevsT5xw3HF86rGc+M97MiLRqwn370fkC+D7RAP7OWZBBVe/9FLOXLOE6W0pQix9PWm+fP3dfOZbj0KFgwmHMX1duE016OoabFMrxh9CRx5CJfnel7/H4pMXUTdnAW6shrgKyI8OsHPrExODOx7uSaamVgzv7VGP/eh223jJxezpLjKRLyF1iGc0fuRz7+0/I93fi5OqIcrB6vNWMG92E8ViadIn/i47EICxFm0FBd+QKfok4zGSCRdv0sHytOkCAwiM0SQqLC998QU8cPXHEQ0tWJ1H5Iewow0IK7AVSUp+hDcxRphO4wZFwuFeXnTJcbzyxWsolQooFSMKeQbp53f9qyCwvOaqy/jxDx/DL5bbQbI4iukfxEnWsqurxBcfGlcfObfNnHLcygsSifo2oP/P7RtNlkyjt73zLde85qpX/eecuQuIgiJST1ibqBPz58xtP/nkUz584sknv/Db377+devWrbvrjjvWO2vX/t0VaCSdnSYB7To1/TRb24wtBJLJbNwRDuHwOKeuqKa1sZJ8PouQzu/6fdYiXRcrJ8v/UYSNdBkQJ1sCh0mbErCynK1V1NCUsjTU+wRTq5lYtoDBsQvo6xqgZ/8u9vY+QWx4C7V9/UxLpJleXyLVAE61JZa0yBTIuIXYJCHrEEtUgTQWMxbx67211sgG5UmBxKApBzvWmEnmssDmDPncOKo/jUgmmJi7BHdthSrcWjRV/PYkN+Vfn5Izz8gP7d/y9+gJ/rU9QFFuOET3F4gd11VMtSxILFVLTzyLlpNeRK6iZrIp6+GpAD+WIAgNZ605mSef2HLZxlsfv72+tXXBaH//Tvof8WmsGxHC90RYJFHTSJB0MckaRH0dqqkKEs2YXAGyRexoQUQZhSvrVwGCjRsNG8qn2Kkwp1AhUJG0Rmt0YBCEWBGjNhHDVSGP5wbIulVY4aC0jzGR9TKKWMm7uwDDY3MQHJ0C/EdmfLI8VycAqpKQLGg9sHbt2kgIwate9Sr3rp/97Dub77r3uM9/+oPP7/zQdd60iz5O/6aDiH33Ux9TWGXQcTWpYyjLkaqKcD0XUeqmNL5ZJNsuZ82Jp1/yne9s+sSko/yjpInV69crIUR0ylnPveg5Z50x+4nBUH/2/gll+xVBz3ZsZohYOksxvZ+3vPZ03v/255JKxNBYgsAgLMyZXsMnOteRqEnxgY/+FKehAXp3I+prUUsXY2a0I4Mh9FAvqrIGKzVb738C8dBDOCqFjQo2yo8ZGNwL1ZWFsHEu1uXAXb8VX3l8J7OOWUnj9NkInWH4wJP07NqGnx7X0ksK4imJ9jjzzOXIMkXvMDnCHlEAtTpkYKLIg08N0j0wQW1VglWzpjB/ajXWM88YiZ4ETqnw/RJnnLactvZ6+ibGkJUeFLKI9AjWTWKdBFJodDZABQYbWpIxw+tfcV6ZtCEctJ6cZzzyN4jJbAZBGJRYtXIm55+/jJt+eBfuzCWE/gRibBBT24hscfn2ViuuWF4wZ689vXLDRz+wQQjx6snn6U9H9OutlJdL/YJLXrD25S985efnzF2g/dGfEaW/rhD7hHAWIKpfbN2Ki/Tq1WsXtzQ23B5Lxl+4dm3nple/+tXuV77ylb+jbvBqCZttkJx7jGhb6lFdpUWmoKyZJHdFBpkZ59xT5h8uazrWECiBp0HFYwRD49jekTJgtjcg6qvQrkJqgw4jjAHHCrRUWGlxtAVrMMJgXQcpK0m4MWqqqpjd1kZh1XLGs+czMtBHz8EufnvgKR7pfYjG7q1M99I010ZU10GyUmEqLLEEEBfImMDGLFHGUhgWVMw6TtR2O2L8wEGoiaB5Cl5lFcbRaFuEwENItyzCjoRsAI8PEc2egl1yuUyPjwcN4Y56adX6PFwG68XviaH8H5JgQDtbS0H+oera2RfMO/k5ONOWkQ7AHc9RVVmFm4wzEaQpuQ4m3iiD9Kg57pjW5fc9sHsWeXXrokWL3O3btwdWmjHH0W7ChoxPlIRqrEbW1WDi8bIiddaHXFAe2HS0RMUwsno5KZoQchALdKJEjVxlUwqsEsaxNDlxqisUvbEYRVOiwk3hhR5juRw2rnGMb/2ClgxbK8bDXwABtyL+Xs78mVnzUfvT12tyk7t+xQufd8kVL7jqmikzpi8tRYWqzNjozicffOCWN76z86tf+cpXuq21Y0KIF/3XF6/fXl3X/IF3vudaW3n2J2T/pldQ27WLSDkopSfnmqJyX2JyubmMRdjxW2XYdrk5cc2JsxbOaT5PCPGNPyWNdueGDUZ0dqoz1p745vlzZ9q33dbHcEEgJ8YwuQwiylMc6+ZNV5/Jp95zKToMKPkaKUEJCK0mVzJISlzzyvP58U8f4MntPciKRqLhLhhvwiRcRLwCmUihfR9i1cj62ZhiP1EksKW8SFQ1qHPPv+zYZUsXIB2HbL7IUG8fu3fsDB+571a5726lSCTAHwcPRKpaWa8aE6sm5kmOWT6j/Cha8XskPrD4Aezpy7FtVx/9Bw748aoqVyoha5viTHG9I/+3Ix5vgQkipk2pZvVpx3DD925HJmvRfq68ocL3kUZjDEi/gIpKBKU8C6bXs2BRO5EuTxxp8/vcEnsEB0cBxsDVV1/OLb/4LWExB8bFMgy5YWLMZjDj8O2tI+qzZ07Tzz37nFc9cum6H0kpf/4/yN7J8u+qqL/yFc/buGjpAjkxfLNxht8mnao2rNsI2Z8hh34swtylTlh3rZ6/aKn7hmuu3jgxduDir3zlKz87pI38dzkFHddYNm22qnbWZbb9GCLpWBmYMrtSCcJ8hoZ4npNXTCOIIoRyAI3SFhmPU7rtYfK3PUhNKNDDI+i6OsyCqThzpyFmNCCn1KEqkmgLTjEEYzFyEnCsLCsOCYtVceLWYhOGpLXU1SSY1lrH0sXzyGRO4sDQOnoP7OaBvU8QdD9J5fBW2r1BZnkBDVWKVLXEq3ax8YBoSNA7Mo3/eO+bnLc1zOfORw5y2/193Lurj559PeClIFWLqNWgIghdhIgwQoJRRAfHEI1zMfPPcPXeUZNUmQubp05dPNjdue1vzQL/NgBMJosmStuSVWakWK9yA4O0OpK6mgak49DQXEPcmYaTloyO3UbdwDfsurmPs3WxfOm37un50foOTGcnlNLFLZU1hZ0euXZHx6wblkR+dBihCijq0UqVP6oE4caEVZ51qmoqTb75eJ0f/CkCS2Xt8bbOXaEThkghVCxBkCmQ9gPCphZ0UTMybDhv3rEkojEeHbsfHU3g5BzhlHRUyhRHjzjZfzVgdXSg6ICbrhCayarDe99rZWfnP175/Nne6xNCOB/7xEeuu2Jdx2umTZt95N8fe/rq849dfuKpr77xxhveLYT4hpSS1vqpP//ylz974ew5M05e96LX6uCcT6l9P7+adqeHlPRwqyK0V84wlBFYaZCegy3ehs48xZzFi+25Z573uh17vvWtjRs3mkMbC57RkJFSCFPbPHXxkvlzTh0MfG7vCpTIWsTIADIsEI2NsmbVdD78zkvx/QyCFNYaoshMMlFBSTFJQpDMnNHAkw8+hlNZQ5AdQY6NIGoaoKENE1mEdrDjA5goRCbqsZkCi5bP51tfvZZVK+Y8k5qJNtbdvauXD33ser73/VtRVc2EQmLdJCIWx9gk9TVxWurriKKo3O87gh5fro4ZSpElnSvazT+7Kf/45rtK8VRNxfgrXxhfsLCNtoSHcMWRZJHfHRUhEQ6sWrWIG779k/KuQF2CUgFRzCH9AlY4WONjdAg6j+PEGS/6GMfDQUwO/D/94j+Nyi8dfL/E8cfP4jmXnGK//707RWx6Al/ksBOjmIl2RGM133l8nCuWZThxwWxOXnvutRt/sPEXf0r27pCSz7XXvuOd55x3UUNQ6ovkyNucVEygq08j1D4xm0eXBpAT30eXulXY/A2zcMFyrnndO76fzUYnb9iwYQvw9wBBwabLNZDSySkXiPopyGIgrXaQWISyRGMjHL+gimlT6iiUgnKAJRziRhOUCuQ+v5HG3nFMTIAjkP1jsKebIPkoIulh2uoQi6ejlsxEzJ2Cjccw0SFhs3JfV06m3+XRm8klflLhuB7xeJxkKk59SyPHLGhjfGIpQ4NFhg8Mc7B3C/v7niQxvJ32ni5aY1mceERvpoqxxc9labKWmY0OVz1/CVc9fyEjo0Xue3KE3zwwyOZHD/L47hi2rh63wUPbePkBlxJCiLIhtnq+GIvP0q1yX8z1S2+E7lfT0SEmVWP+7wGwp4die10FA719cjjbb6u8FlEx4dPc4mJchZCVuHqAYPxG2sw38Fr2qUTBmBMXe2fefI86+/3v1z9eDc5m3++vC3I9IhoTwoQm8rsRTgoRxTChRiivHLhqi1AKazBeZaOy+br5enDwpwBeXewMU+86SoVaWqXiwqGmsYVMmKYymaJaKoaCEdy4wB8eRJSGkUGAGRc4BVXChpm/3YmDEOjy8murgJS1RJ2dHCXV/Enm3UYphNCf+9wnv/a617315Y5DVBr5kYhyP5FSj0PyeCvrnm9OP/2s5lkz53596dKlZ7756je/q2u46/Ep9bXf/uynPrZ05sxplceffJHdku8X+za/lYWqCNMFplpihYskKjfmlYeWvdj+G0SqqlOcfu45yz775W9NlVIe+EON9dWr75SbN2PmzJ9/zOwZczkwUtIH0p4iPY4dG0HYHIwN87zz15BwIZf3wIsQ0e+vK7GmnIlOn1YHYRZhAwiyqOwEUUU91DWWf8YYhA2wRQulgFQs4mv/+Q5WrZiD7xeEERKhZVkVZlIybO78Nr705fewa18fDz68G9XQhpFJVMIhChSVCYeKlEekI6w94tgbgwV0pKmo9KirivwHbr99mCgxwy9mxM+/8SPzhhdfKk3CInzztC8lD4E6EmNg1sxWVExaG/lCuDGISth8Dl3IgZcAE2CMDzZkfDhgz4FxZk2vpiaVwJ28Nkf+AmN+N9NmjUAKgbCa17z8+eLHN23GFLMgYpjiGOHoMDHPYdQk+OjdBfWd5ybMMcevPGHJ/ONWCiEe/iNZoJBSaqD+lFNOvtqLxW2u679UXB6gmDoXsr9FFncQODGMV4Mr27CZewgH/0NK+aXo5FPOTD3/ip0fFUJcYK2Vf/ueybL6i1KVa2TNtOaoImVVYVwaWx5Id7QhGh7nvMvmoKTGWEvcWnwh0QkP/5FtuLsGkVVJQh3hGIsJ0sicg5pwMJ4k1jdI9NhucGNk2+tJ/ceV6PZmHF+D/N3c4JEByJH/bqxAiiQJHSBjLlX1U2irC/HnNZPJLmJs+GIGhg4w3HuQrp6dhGGWlsWLmH/qGhoaW1DakskUsDJJVXUFl6xNccnaORSLIXc80M07vvIE2wabkM3eoc40whpMYBCiDh1rk4ghhDN+IqAmVWP+6qRF/rU+q/xLe4p4yQcnivnSti33i4SMbGFkhIGD3aQPPMbEE9dD1/8jFbyDVMUeRK1HQRt76XGeuujUytdYi1doq6wGKPqFO3XY83hNLKOUP2IxGqNAlEKIBAJNeUGDBcellIuXowOIJ2ls0dXiHFWlIDQIYylGAX1RgbwjiDJDhFqgEh7f2XID28K9yFRAKKRxsxKy9olMhu7Js/eXX8gOlBBYIbB1iyo6Tnxh6ofPu7Z5y8s+OG/XZe+av2P2qd71wJQ/UBo9Cn7WSiHW6Y984L3vv+oVr3q5IwtBvu8djh15oXL1r4UbywpV+KI0By91SoNfse1Tm8xrX/umF/z2kd8++qY3vayzd3T8rse3HVj33ne/79HtW34jZp/yYuse81Z2HzCIHoENBcaUMFYjbJn07MZApn8hIj+tz1h9hvuG173qNGst69ev/73zsGbNGgCmtDbPjMVj/GRn3hayBVShhNAlTFjETTgsWjq1PCCsFMIIpJBlSSorJtcEKQwSl4gVKxajKqswOgIDdnQYxoewlJA1cURjNbaqEre2HhNVsvqckzjpxIUUCgHWxtBhWew7sJZIC3SkmMjkyeVLXHzlFchkFSJVC1W1kKwCE+B6YIQk1GCNmYzuy+QWJcB1FA6atSsWxX940zdbr3zBxWNrzzjdPuesVaVp1Z51lXOkVPJhgBJCIGX53xtbGm1NlWPwsyAsIvTB5LA6KGcXxmJ0hJQxhsZG2NM7zthERKEQAAqLxAgOv46k8AtpUFIRlAKOWzWbCy88EX98CEeGiOI4ZnSIaDyHVBG37ve5Z3/OHn/sEvXcKy79KOBu3Ljx9871HXfcoay1vH/DW1675vTzKoL8XqNy3xXWm4mKcsjCVpQYxglHUIXdGFNCxRvw0zcT9n1ehWAXzlu4du7cuVOEEPoPPT9/mS0qSxrULH2jaVuIUNpEkVfuzzohYT6gWo2z+qR2jDY4wqIFuEFIJF38e7bjIolSDnEbTgojSAgNjm+Q2RJy7wBqYAxnbIz4rfcz+t3biDkOGv0/zhGKSQKNwoByCFWCyFPImEMyWUVLYx3z59dxwknHcNpzLmTNK/4f57z2fZx8+QuZNXsalXEFysFRLkpG+EFIJheSzRZxEFywZjY/ve4sliQy2MwEUrkIXX5W8S0oSZCaIwJVgSCcQbyl/W/1qX/LDRMAEcHBUETbdjz5OKXe7eTHHyd9z7eo3voB4qU3kqj4Mcmkg7YObqKISEjVVFE0l5wszqpwnOMe7s+OrgRTKpQeD/2hd0szfrs0g8JGOYMx2CgoK90be5i5JhNJtI2jdeXUJNQEcWaREm3EykuRrS1HpKUgQxhO4AcFkg1NrFl8Bmcfez51VY0IQigZoccDSpnCI4CP/csBcP16JJuEtpaWRRfxtcv+X/PGF77lmOde+IJjFp56YUPzmZeraSuf7720dpX8MuAcLYIeee3WS8A+9/xT5z3vsivfk6qoMsHwf7ky/SncZBOy9vlElWcg48uIyb2o0TeK0p7nyDD7G7382BMbPvSh/3rf177xhU9XNiSdO+555Gvve997R9K9O8XUc19vwzmvZv9uQazXoIoKGRpsGGKjIkp4EDyJP/QrW13XwuozTzsTYMOGDb//IScBsLW5aYqJV/Bw1zBYF/xyMCYANx4jlaok0hxWbTHGHs5gfudAFBjN1PZGamqShPnxcnRbKkG+iCgJbKoKE08i3TgSBX6eU09cNBl9W8IoxFo9+TIIYVFS4XlxcsWQkh8gRYCNSiAsRihAEWlLKShH8H/cXQiiwPDc55wW/953P1z/69u/IL733Y8kp7VWCcKwPE7yDDPGgLXoKCSRTIjq2pTSxSzChAgdIGyIjEooXUS4EmQM5VZSLBlu/OVmtmUK5MdLRDpEy//5cEghENLw8lc+HzdusaUcojiOyg0SZdO4voOfh03bx1RSKHvS2hPPbJoyc6GUwjwDoMSaNWs0UHH8aWuvSaRihOPfFVIOYGU9OtqLZAJrFEILpDaYYg5KRVIl8Hf/UuCP27rq1viM2TMWA2wvj2P9Db640wAtoqr9RKdxOoRaiqgcoUgpMKPDLJsZY97cZvxAgzVoawliEqdYIvztVpJJSTHI0ecacqUiqlQeXg9zoxT7xhhauwRbVw1Fn1yUo3//PmRYKouNGPs/BauHUn+EEDjC4kiJkh5SOmXGp5MkFa+ksbKaKU21tDVWUpnykK4HUmHEZKnVluX2HClQyhASkhsPmFmf4ANvWABD+yEsAWGZKGVMeQ7RrSCMJELIlOM5TX875fZvCN4BfH+sN4zkbdlCWHzy0d+I5v477RLzQ1orHyOVNEjfmzyEYZk4Wg9F7ds1c0vuxScl3mItnt9EXSKSvVEpeiIsHrzBscOR44Xl+oqOEJjJWRYLwsHGFFolEKLuJOlRazw5TcWdRq1CosAKJT3iiQpiiQSphMPUGa2M2nH6g0GSyQqUdDFRgOcr6eYlthTu/SsiCdGxEdXZiamcZ1985hsrH+544/yrTlg9W5dMoPeMPmAe7X3M7ho6oKvmoBsXeKcCrZMbK45mgcCGDWukEMK+8CVXXT5/4UIRlrYbO/JN4co4VjaD/yTu8FeR/nYirxmRmorUd1Ds71DFvvfapJvVV7386vN+dNN3f3j5ZWddcc+d9+U/+uF3U8gXmHHGtQy3XMaBJwTBANiCAyWFiQQ6dFC+j+69X1hr8eLe9EPttN/Dv8l/VlSk4kJLIlMerxBGH3YYpUKBkaFMWUza8PTNDNYefh3689TmWtqbahGFcYT1sVEaEWWQhRBZtJAtQqlAlC8ghc+qpdMxmMle3dMHnq0tg1CkNYUIhoeGiTLDiCiLtAYlY+AkKQaCTK6EEM7hHuAzPxuU/3s6V2AinyVfDMjmIwolSRS5fzI21NrgxSQ1tckcfg6hA4iKKBMiwwIyymJjCiqr0SqJk2zl/rt38Kv7DrAj4zOcLaKD6PBKpyPWETwjiJAUS0WOP2kRp56wDD06iGNDKKUR2WEYyyFDh1v3+OwbLejlS5Zx7vnnrZ58O3lE8KWkFPYt73njGSced3ar8fdqO/FdKdwUkR3BCScQlCXAjA4hBBlEyLwhHJEE6QlkVLChH5HPjyX+DuyXsk9waubbqpmVpJqMDa1QurxhQSFgbJgzj5+K5wi0NpOzm+A6LkHvEMkD/Vjhk7EK7wefwJy+kmB4mGA4S66mDvXN/6D5+g30TK8h7B2nN5slWDWXEAfPqCMk9575XDyjL3uofzwJhIdeSiqUFAgpQAqEVAjpIJWDEuKZ44hHvL/EYBGxiKIfcfbKZhY3CnRuDCmi8nkyUbksgCf8ojFSujLhOq3/yAzQAoyPk/VD8fVMYK7bfnCYiuRBmpuhOJHE9mq0H2JkWF4mHChkMiKqkLImEdnzVpjzUqjVxjbm+3O5kWKxOCBKhUdNKT1mdVYIay3axxofDsnvSIkVUkIS6VbNpSZ5mqhyVlMfr0TZ8gwoFuMH+GN5SqMFihNpRvL9PJXtZldmmHwwjnGMscUIWZADOtC7/9LsV0jspnXoKaeIDRdf1fjt1R0zpkQJTz9x8AG1c/xh1Vf0ZdpGIu8bpZ1A1M6z1fHp7mlYoAN5FP4QsEYDXktLy4stEA18V5pgB6HjYIMeRPY+CHvRYR/KH0RoiUotodKpQGW+KPLdHSocu92sPvW5zpe+eePp165/17QtjzzGNz/5LiG8GHOe20mh4QJG90eUhi029FC+g0kLCgcEIzt3CwToSLYBOI5j/0AJVANKW7lICpCOK1Aaa0pgwjJ9PAjIZCdwnT98rH7HfrJIDO1tKc6/4FRj8xPWDXNQGsdMDGNG+rFdPTA6hgqz6PERVh07m1NPXEzJD39P5eOQEzFGE0Uaoy1aF2Bywam1DtoqpOswkR7jQPcw2SAiMuVM0Fhx+LM97TMKB6xHZEGjiYgwUv/ez5ZfgkOYr5F4cS+DnzMiLGB0gCkF6Gwam04jwgAnkcA6DiqeoDRS4lff/wW/fqqH0QJEkS0LexsxuZz1mZ9t0mkKiMUsL7zsLAhzZd1JEyBzY+ixPtyoRF+/4ZYDGVpr6jjh+BPWTGb4h5F+w4YNxlqSxy9c+d7qyhjFoc8jOIBU1Sg9gNICo12MLeuZoMEEhihrGdlpGMvUobwqOTY+bA/u3zv+tx+Hsvi1F28/XdXNRsdTxgZR+Xdbg/Z9PB1w5qmzwerJ0rNEIRCOInh8O146hzQKs3sAsW+Y1NtfRFdDCv+VF1F131eJnbSIHa99P/zkQYQWDDVWUbP6eKxxysdRG4wpVzaUmRym/yOLGP5YuVRIifwDLyHln4IRhFUYERJEDqlEigUtHuRzZZarsWAjrADrF7GhEQaLUKL4j8wAD3+D4eHhvaHxP72jK/ujO58QIpeTNiqGFLMWnQEblVN4RFkXLlGHUJ7Wp82LkhecwKnbR4Zzr16JC8IMT4TbTWlij4yGkAqDtqA1UpUZdFZapBMXQiXBq66hquldsfrElbbelWiLq8HmCjRbxTSvAieEyiDOqbG5eIVKDvo5jBpF2QiZs+gx/zfBePDEX3LNhMBaQ2X7Cd6Xz79y/voVZ0zR4/lR0zeyQ2WDCQJfEBQ0Vls0AUZivKkCd5p9XrnUf7QQunHjRimEsNe84rUXz1uwZK4ho8ndLqUSxK3Ajcax2mBROEikNhAegGIvVsRxK5qIs5dw7MUy2/sftjIm7Fve+hHxxetvoGd8jP/+2vsJ3BRNl3yCTOW5pJ/SsC+gtFsw9ts82x+wFJhrCQUjwxM9AFEUPfM8SKWUBWYbKxeEEvIoCaKc5DkuwvHATaBcMTlMbiYVVY6MpJlcGmpQUhIGAa965SVi8cp51t+zHeWXcIt5VG4AmdmHDNIEIxO4YZr3v2MdMVcQBGZS2s0eAX7lOEIIgRKSlKeIp8qqHEQhJvAxYRElQjKD/Wzbvp+xXEAQlLU/5SSAWUTZxxwR9R9iA0rKK5gw4vDPPvNlJtEq0IJQE8MGVtiwnFHk8zijg4jebji4FzsyBNonEOBUVjOyfRtb73+S0WwJPwqRxpR/HxJjOfw68rMp5RD4PmefeSwzZ7USZiYQ+Fg/j0kPE5WyYBx+vT2rQglzZ89eDVRMEl5EOfuTZt0Ln3PV6tPPXBWFT2mbu0XF3GqsmcAxFi0ny8zGYDWYUOBmEoT7AnIDHrEZl1ncSvHY4w9me3rSg1JK/jZlmDs1IGP1c9Y5rYuIrJaEEVaYstj7RIYFUxOsWDaFwC8Thg4xcY32Mbc/iNICaV1apEvu8zfgTmum5RfXUdv5Mka/9gN2HfdSmr9xBzMqqhjMpdGr5tE8pQ0d+RhpcRNxqEziKRffkYSyfN+FFX8W+P0Fff8jKiKHBvg10jg4BOXSfpCF0C///knulbUWWRwjJiNQAiuN86wAQEAMD+UHcyX/e7/tldnedK2IwtD6BQnjEjdXJtkKYbAGZExh4si2Os2quc5V2Pi0Lz9MRMfzFRB4lO6Ji2GQBTAORIIyEJYjMYTCKoWW1aiqppk2Jaut8AGEScbQSZfRYJwxO0FQpxjwCzRRT3u8mXy2Fz3RT3wkkM6IxeTCO4CxP5NJJNavB2tJTTnN+cG5r5z66unHKL1/cJcaLg7Kkowo4ZGLFHltCKUgBxR8I1XMUtHqrgSqef+kjMa/sTU2NgqA+UvmntnU0m6j3G6r83uRQqHDgCjQ5XtuNCaKsLrMWMSMo4NuTGkESZKkFyOe/4rw914gCiM/ZOmK1XR++Bs0VcLmH30OLSppveA6+hrW8eTDmgOPBOzsayZ1xruZdsk7zYGBfvurX9768GSGII8oqQhAvve973Ucx6mTQqQMEseNAw4SF+umQHkgBF7MY3Ipwx8sHf2u5CPQoaGxrkLctPGT8qLLTkflxgm7dhLt2EK0ZR96905m1QVs+sZbOHftInLFAkaVS09/uDwlQVjiKUl1dQXCGgjzEOQR2sc6MYx2ufvOR0mnQ7qHxwmtPEQiO+yE7OQuJWvt04bS/1g57NDxF5MRodYaixEIoay2ONpHFkcIuw8Qdm1B79uG7t+NNHmEk0AkG5GpJh69dTNP7T7IUCZEa0skIvThW/CH6NagA0NNYxVnnr4SOzGENBG2kMPms1AsgBfnsb6S2DMamKlT2+ouvPTKU6y1dHR0yHL2Z+WZa894VUt7my0N3YBjD6CUC7qE0BZ0mY2rAoXyJRQ0wT7L0AFDfOnzaTrh5banu4tf3/arPqD3aenMX+WHhY0Rm15KtM71q1oh1EKYMnFICgETE5xxbBUpL04QBeWVV1pjHYnfN4rZ3ksslaRkQtzGamK/3Unm4S14ImLXeW8guPojzBwrUdlSj1aWIVGkbs1KYskkWkQIx+Lfvw112+Po8TRJpaiIJ5CxZLmFNdnr/XO/4R96Tn9HvBJPG8V5WkAnYHwsw769A+B6CFMCo7HSAR1hCsMQTQihDVEgxv7G647z93JoBkQq4O7edLDr3oPxledWxkzLRKhwJDalsTGLUGAj0BhUjZU2L/S5K+WUXzxZ7BCCT3V0bFObQCtbfNAvjGO8vLA6hggTWFeCLm9CtiisVBhRiVfdZEtiXBgRokw5YdeepeiVKeJ4FqdCsd32MJhTuKUR4hN5G41GQoxERVVS2+HpK5r+aM+vA9nZiZ53ZvJrp1xefVbDjCjc37/XLVIiUvHJqFGQDwTSmUwVseWU3RrcuDPFiTtLoxOi+9lMxFHDqkiCEeRCRN5HuxKHiEP7pTlEJBEW7KQGriqiowBIY+IVyHgDsVIPxf6ryeXupn7KO+l49XU8du932P74z1mw6kxmPfej9E47C7+QZvr8U2zLguPtwMCw+uLnPyl+/evbnwLE9u3bpbVWKcfRGIvFRJPU9qmN9Q2OUo4VUpZrfpEFE2LDEnHX0tJYS2TtnxUuKiEwYZZ5s+r58U0f4LEn9/Hk1v0c7B7Bopg9q41z1xxDU2OKXKmElt4kC/qPl5GshURCUd9Qi40MTiyBUS7CdbHSxalvYvOv7+GMC9fSMKWG8XzIzNZ6KuMaR8nDBVph1WGyWbnc+Kdb1taU9R+11hQKBcZGR+M45QwumkgTUwGXX3oqq09dTDpT5OafPcqDD+9BNUzHJKqhbhqZ7i18779/SlXdK7HKY1ZzDGX/xNisLWe8GsMpJy3na9f/2JqwKESgEKUiwi8hheLghOKR/SPmecumOHMXzlsL/HLRokWulLJ02ppjzz151Zqlod9jbO4W5ah6Il0EHZb36tnydyMymLyldFAyuLdINP+FtF74IXI2std9qpOH77//MRA5a/6WEcAOAZuQqmFFWNUWoyqmyRcVpgzEJtJQKnHeybPL5VCjJ3NzQAqiok9hLI2yMVzf4quIeBRReN1nyWXTNPdOkJozB8KIkmPxiiGjTTFmHrcUFWis52C/9XPsV34OVRVETZX4C6ajlsxBLZqDnFKHSMbLgVEYlgVJJlc+2Mk4RfxdaloWz3V5YvdedvZmUUvqCM3khKJQ2LCIazLWESVhIzNe9Iv7ny0AeIhbNpDNh4//dEd++dJWR9Q1BXhFgx6zuBUCkuWhfYtBJQRRFWIRvn3+KTVvvfPJ9Fc2LurICzpxbCFjowxW+FIgIChgKj1E6IBWIGOgPIyowMQqhVUlHOFiFFirqXXraE40cKA4gm8ESZ1kNBxjLDI4JoMWkbF5q6KMvUuMmy7mEGMP/p/8hqtRmzYRta9VHzz++TVXVLVFUe/QoBuJAOtINBHGSEpRRABUuQIbhUhsOZgTwsq48ZwK0R5tPrpw95DlJvI7i34BN1ZLKVeFxwBUepiYRRGhrCyXFWX50FmjwDooYbAiwpRy6LCI41aRrHQo+deT37kD1f42jj3tRfT0bOWRe39JXVUz7fPOtk6qUoyODolffPWr4paf/Jgd27c9nEpV7U6ns3bTpk3BZHknDqSAhtlzT1194fPOe8+5559vt4xG7O7LQQFMmEXKErqgmdNSz7yZDUS+Ljf7n8HhOOTKxSEgERZwyOYDHBWyctksVi6b9bTrEkWGXL40SWW3SMQR2sbiGaoKAgeHKIw475SVfH3lMrP9iQEpprjl/ktMQIVHacTni5/+Ai9991sZLWrSmRwzmqqorkyRjLkoaVGOnqS7qzKgRyXiMQ/kHyHBiPI2gIKBkXSW/MR4Wiaka8KY21ht+c6X3s05Z604/ONXv/JCPv+VX9H50RuxphnjxnHrGnjsjvu4Z9l8GlouYEaDiyPVM1YyHZlFW5CWKNIsXb6IxqZKO5wZEaLSweo0+HmcIIcx8EB3Sa5bFSNVUXkR0FlVtRhrbVtHxyXrFy1bgt/zBesET2IT1Rjtl0uvwiIjEFoRBRH6YJyhbQVKs05m2pkfQXtxe/0XPip/ftsvjIxX3AUF7N+iSLJ6kWAziOr5ZzFlIShpRVS+DyYWYnNZZtb7HLdyCn6gkUojcACLCSIqp0+ha3EbpY230VLXRmW8kppUJYnBiTJzd2oLYRgQ05BIOGTH0+jjZlE9cypBqQgyxlg6S7hlD5X1FaS6Y1Ru64FfPU7UVIWZPgWWz8OumI6a2oisSpZD1MAiw2By71+ZbSwnL4E+BAp/oCLy+9UEWx4TMhLHsTz68B5yOoFKxEFbrFQIGccpduH4Q0bGXBUVxVbyg0O/+y3/4AzwkGUkn9rTp5c8tMecMKdJGi800imAykqchMKqyahGWEyNkG7eRpetkK2Prk2+RnR2flIIsKE77lIqKVGII6w1kRYIgVQKo0E4Cum5mFIFBeuhKyTSLS8BNaEmGPWplQ4FU0X32Cj1lbU0xB2Gw71YVUAXIshLyNoflij28kIctqPY9IdXIK1ejbN5M1HdEl6/+PTktYkZxag/l3FCVx5elKytwWiJXzTEkgproiO2cwuMkNZNKOEmzdQSc2Ks3qP/nbPAL3zhCxbgicd/+8ho3yCNzS1yeLyNGSN9OM0C7Wmk56DdCJQtPzcyKmfUwmCURRqBY035+po0WrnEVQ1aP0i4Zx3FhtcyteVDqOMl73/v29i7f1BU1Tfa0ZEJc/Bgz75CsXhnsrL6N91d+3qA6edefPEJS5Yee+mUabNWppJVdaER1VNnTFUnLmonUVXHJ38yyki+BkcPY3WmLPGVHubEtctoqK0gmyv9yf6IOdxfO9R9EGhtyWSLPHPF9qG3MWZyM8Iz1Ft+n5SgEManvS3FTTd8Sr7nvV/iljt24WdjoJLlfopqYt+Tu7luw0dY84LL2dXWSNNAkYaKOA2VMeoqYiTcsh8v+SXyBZ957fXMak0e7m3+kSIogZaMjk0YP58fUNqroTjqfvmb77fnnLVCFP0SWFUmuUifN73hPB55Yjc/3HQ3XtssjOMhEjXcfsutnLD6BEZqDa11Nf9jUcaYiKaWeubNapfDD+9GVjWgSwVEPo8pFCCZYktPTuZ8w/T2KQsTCe+sr3990y9XrJh18Tlrn3eS9EvGz9ygUm4CW16PUZ7h1AJtAsi5iN4kA1tzFOqPY+o530A01vCrG79mb9r0Q5nPRz+JjPnZHevXO7va2sS8efPk8PCwXbdu3V+yM1CweYNupzMxUFl3rqxvx/ihtLpcclRSosfHOH1lLXXVlUzkSjhSlv0KFieCwHFo7HwNTxRzbLt/B6mBIdqFpKWqklR1FclA4FmJ7wi8ouFgNot34jIS8SQEIQQRVS+6gN6aFN33PUr84d3E+/aQchzq+lPED3QRf2gborYWf3YbZtEUxJKZMLsV01CFkQrpW4gsYbkjjKI8/2rFn3cJLCCFpliEzQ/sgsp6hJqs+ikHGYWIbB/4I9ZxrfWt3VV2zmvU3+JH/+4AODYQ7IrVxe/57YB3wtklj2Q8g6sVOg2yFkRMYHV5VYb1QsIKZEuUtifOqXjzN+7g68bY9JSEGHRboyFhMtOM8a0IpcCPsEgOiZpbCdZWEMoExhXoMI9TSOLFExTTeUb1CH4yxKZyPJXdytSmeXiOgmyA8hGi6CH8EB9m0kkvEHR0oDZt+j3ak7zrLiJg+pTl8Q9XLzRmcCKrQiCSFkceKtVZgsji+4KqlCWY3IUljSU0lkBjVUzhxc2COD1NpRwD/86Z36ZNm6wUktvuuO3AQw8+WHze5VfGala+0275/tUi2T1CYwN4SYlKxHASIGMa4RqEB8YRWFccLgNJx2Klhkhj7RhSQlxBfs+HyWQ92peuZ/bCY823vv+hL1VVVTyhtZtNpVJj9VU1w0/t3Vs8/rQ173jd66/pWLV8ecO8aVMwsQQTfkRc54mM0VtyQt5677C4fUsBkXVQI8OEQQ5ZCnBshpesOwU72SIRh/TvJiPdP6Sm8XQJ6jJd3JojN3lPls4n2X6HxgIOzeFZa5+RAZZ/pyM8TFEzf2Y9N3/nPTzx1EGe3Lafnp4swyMTjIyOMzYwl8H+A2bbLT+0Fe1zVGVTKw0NtVRVpEi6LjELXlzS1FzDnPZK2tsaUFKgQ/00PDoyio8iS74Y0dPdF+XT6T1aV81+2WvO5XkXHEupWEA5DmGoy2uqwhhRKeJVL72Yn918J0FmFFXfhtcyg8EDT/CbW+9lxYwLaKnXCCOfdi2fScMWQuPFBdOmNXLvfY8gTYQ2EapQxAYRJBW704LRTM62trXLlvbpZ2zfvmnkve95x+vmz19mCwPfwA0fRbuVCJ1H2BClXUQRjB+DPkHfrhwTrUuZdu7HULXz+c0vvmH/+xtfl7m8f5DQ+1pvX1/P2mcowAghuPHGG//MhbwdEoROx9uPsw0zZ9lUo6HoS3RULvlri01nOPvExWXCiw0mWwHlqoBxwPVD2qbOIPbdT9C/7Sn67n6IJ+96hCee3Evlwf20GkVTMkVdZR2FbIl9nmDu6ScjjT080xdPJJl+xQU0XXYG2eFRxrbu4OBvH6Pr/u3Ifd3U5Q/Q7CaJ766m8p4aqKkkaK3DXTIHls/Bzp9C2FpDjBglYbBaI32NEbbMAD20feSI6O7Ie6qxJBzN/p40v31yEBrnYLQu970FUMhBtpeEnBBSG6F9/7G/hx/6ewKgLVcKEdt05ntPDSdPuGd/4tQrjnFMybcyWQAzHiKbFFaB0hLHWqJqI6O81GuWmLazFideKoT47MpaMn2R74tgDNAIE2KiAOt4k91GUd4jpWLYIAY6RFmJDDTScYjLCsZzJQKjmdc2jWwqRlpJ8IEoROeETEYJopR+beMxFa9xXdM1uLfwtU2buGVyzOVQeVJ0dCA2bcJrXO18vfXYeGUmyGltlESBUZpQmbITs5JiwRDz4lirMZEsDx1rQRSBDg0l30dDtXLdKooM/ptXP402WgghDt54880/Pv2stVc0LHl+WDxfuwfvvYGDu35LQo+SlEVSFVBVA6kqgVspUAmFSEisJ5CxCDxdnjsSFlSAjlL4jiFVFPTuuJ2ape9m5uylMgjUptHRwp11dVPaenq6h4DVL7jmzR+55qqXnXPyMcsYKEb6pz0+t+wYEI8PlERFKo4XE2rrqGDgiVEYzSLCHOHAbpwoIOjt5rLzj2Pt6Ysp+j5I8Xthv7V2csHrH458mRxF4BC4HUEIOPQY/jmphBUarEIKh1w2RDqGYxZM45gF0/5Qv16GpZBsukjBL4HjYKTCGIPCkkjGqayM4zgSE2jCIJwscR0BucIeLm8FOrSjGV90HejxtS5UVdTMTL761c/FWiuMcAgDPVm+teV9dlGeU05o57OffDX/sf7bZHoH0I6AnGD7I4/T2vgSYkoSmPBP5gzCGoSAxvrqAtqPEUVKWIstFcorgKRipCjoGi7Q3FBHY1vb87LpwaWnrD57qTV5EUx8TVQoh8iESGMR2qJDgyhqGJAM7QqZSCyh9YKv4LatZPfDN/OD679qR7N5fG369vcNDK1YMm/ZC664+OR4devyRCw5lu7te/BtnR+8Y926dRN/nkj2orKgSGr6ybZpgbWxpLH5iTIFVmiiUkBDzOekZdOIwhApQBiFUeVqiAFCpwyKldajatlypi9fSvCSdYz3DdK3bRcHf3M/Ox98EqdniKIHU191Kc0rl2C0QZZJzRhRHqqPG0GsoYm6M6YQrT6dwsQomX3djD++g/67H8N5Yi9V/X00GoeGWArvwe04LfVE05pwZrRg5s/CWzQNO70RW5XCCoEJDU5owEaEriB2qMd6xN0UVuB4gicf20PfaIg7t4ZIlJdbIyS2MIbNHrSezStdMukgyvwEgM2bzbMFAMufByIxwaOZXOHjN97j16xsTCyZ31owfgwpxixepYBKWW4wW1Axga2wYlpjya5dkXzb7duK3w6n4rthTiRVlowploVyTcVk5GDASITrgcpj8i62aLA1HjIm8FxFc6KepupqnpjYjh8FNJrp7M6MEIYFEpEmyBm8UJOYIZYnGiNmLKhZsVbNeu6Dv9z36d2bC++x1paEEOJQ3696oXzpzNXemclmHaWLxsEpXzjF5IymkRitiIKQ6gqLH9jJTEBijcAYgdVCYCSRsQNauTka/z4bjf+ZbTK7EUKI10tpFr3zne9edswpl+umVZfL/h33ibH9jzPcvZO+oR0ke3eTPDiAJ0tUJAx1lZCqBadOEFU42GQMXI0rLI4s4pY8xrpgIjGFqUgbhEWhlI5FkRVr1qwZG823XfGSV7zyK6+4/PmJ0Evozz48Kr+/o6i29pTIpzUEEsIiKAtBAZXOY8dHMYVx3EgT9Pcxtc3lo+tfWJ7Ds5NQdcT2bfs0etuRzvsIvcs/opF+aCj5UL/vyIj5D5VAyzP5GoRGCok2gnSu9LQoWyp5eLRBKUV1YxW1ovJ3g82TS3F1ZIiCiGKp/AyXwdkeUXo0GGlQVmCRjBWK9KRzdB3YPwBR88qVy93li6ZY3w+FxmKsPOJ7GbAxCDSvvepcjjtpMT+86W66uvpoaVnFFZevYVoDRL75g0zBw9fBGqyx1mgrHOmEYFwLCmMxOgA0rlQEoaFrXItF8xpYsPyY6acdt2z6KSefTjH9A2LhFvBARTmEkVjfw+QFsj+kb5umL7aIORd9lHjbYg48dTc3ffdrpDNDsugXbIXnLPjkx9773XPOv2jWvEXHypgqu9JcqchpF5/d89Wvf/Xazs7Ob1u7XgrxR0FQYDdoRGeMysarvKaZIjCRLAssCKQj0EOjnLggybQptRRKEzg45f2zlEUXEiKGg8JgCGSJyBRwDLgVSSoXzqVt6XyKl51LqXuYkf3dOBUJZiycW35M1eTQ+uRHcQHtgrQgbYiU4NbVU1PfyJSTVmFfdgWlrgG6tjxO7/1b6H90J05XL1X9PdTvqaCythJZVwM11diWeuSS2chjFyDmTsHUVqCVxPM1xkpCBY7WvyOGWUGE5O67t2Lj1chkrKymjCyTCXPdUOgxwg1VUAp/Ot7X1w3rD6nnPHsAcLLFLyqq6zbvHpn4yR37vCWza3xCNwQlkWMaNyGJJptn0ghIKmkmjD5naTDlpzPib7j/ydIH5ywsTMTIgMhhqIQoQHgaS3mUwqpyxK+oQodJhPXRnsT3SnSHQ0yU8jiVMB7mWJucSnZgnAPZEciWkMOaOBZda02uxmc0MWqXnVTBWdOnvqXk754lhHh+RwcsWoTp3Ext3aL4tbVzjcmVfBloByXLgymTOulIFPmcmRz6jIiC8ubmyAqEEUQGIi3AekBYUKWwRNNRAgxgRdlGb7jxhy/auv2p6875/+z9d5hlR3XvD39W1Q4ndU6Tcx6NcpZAI4kkBCKOyMGBYGzjhG18DZYGMM4J2xgwYBtM0iAyJkhCGpTDKGty7Amd08k7VNX7xz490xIjwf1dfK/9vJae0aPpPt3nnH1q16r1Xd/wws1XXHn1le6ssy8xGzZdiq+RuN6UmdFBpo7ukekjjzN6/Cn2Tg/ijx+hxCRdXp3e9oSwHeiAOAyJJho89KRjw1tf6hIr8vCOHdYYEt/3XZqmPX/6yc99+td/6S3hE2P19IM/HvF+cDCEER9vdBxdnYJGFW1MJgw2DaRZheYMfpISj5xg4fwc2/7lfaxa0U5UTxDrZTPKZ+qbeEaqwWn+/uySCX6SRg5PEwjMpZXPbiaWrDPKMjnlJ37etGza4jg5TTF1c0JTWx3oM15DhllpnDhipzg+GbPr8GH273x0FHILLr78XPI5RbUCRpksZoenW7BZBzOVOmdvmM8Ff/SGpz1/vRFjjA/8ZBE8eTBwgnEiTWuJjCmBKBGDqBhpWcWJTcDAdLkOfg/rN250l52xxpVcrCoj/0rgqkgaoEyKTRVpJOhRGNrnmCycx/KXfZRg6VUc2/sQX/viP3Bw8ABBWOKqzefIa97wS52XP++aToC0tjdNZr6J0wFB2zVy4XnPX1Qq9fxbrTo1otSHfvDscUxbFCLGy827KC3OX+UVux2NRInJEtW1UZjJE1z1mhV4OmOViBJSleKnPhIanqjcz4nqIAty81lUXEuXmodyjtRVsUkDIk2ooG3hAAPLFmYZlVEEAj7qaWvIOYcSdfJz0rNFwoJJHVGgKK1dxKa1S3CvvIbqzDQTuw8wfs8jTD62Fx7bS/uhQ3QGBUrtRYr3Pobq66Gxeh6yYSne+tV4m1bR7OogbBqMN3uYAa0d4yM17njwAAysx+qAzOhUIUkd1RwmVA2HU1jDo9nCvuP/WSDuT4NCZXJyspzrKn3vkWPx+/atzAdLVepKoiQtW7weC0UHKYgRyFmSkpV17c5deo5+832HuVUl8T5XmznP5ZLsFk1jRLLOyhmL8zRKCxIVcVGASzPH+VJ/iaBQojw2Ti2psd70MRrVKZtJdFQjqSaEaYEgHzAVlpUuaqJIePCp427D2rb42ndufOU3KrveuW1b+k8AbSv1b+bXxCvKRlmavjJBCg6McSjnwAoKR7Xs6O4PqKYR1vlgFFYMYixRAkmqqFdT0tR6ugiM/o8d2qk91YlS6oknntj1i0NH9//Fbd/7zqs3rN+g169bz5r1a9hw9nn0zF/O0steztrnvdylaepmZialPDosjeGjzBx9iLETT6JHD6CH9xGkVY5PCsGGt9Ox5sUcPnLI7dq5q97d0dExOTOj3/i2d/3x2167JTw0WU/fdVvFe2SfTzAyCoMHMbUZiCpoG+PQiEsR6zBJgp0axkwMcflFS/nEP/0GG9cOUG6azDlF2Wcl9tqnzfeY4xH6XPZQp2kWWto857K5ylxd1TN+CXbO1099++l/z5Ka1KkiKe5Z95OfeC6ncZIyMVXmwLEp2fnYLkb279oLnfNWrFrakkjIHGjXtfx8Zc78U1EpxxnLVbKCKuIyA2cXZ4L+010XB84qjLVUmhFDY2MGnFgTiXUBnjM4m2adYGJJawYXpaxbsUoWLV4tUflB9NgD+O0FbNrEGSFtCm5IM7wzZrT9Inpe9EEKyy/k6J6H+PxnPszQ0DFWbrqEF7zkei699EXkCrj6zPecTP6L0HzEs1QRFWNmPoXt+st0w9pr9Jte/4v/+KXPf3fDTTfdlJw+aitzf7G6+wI6Vrk46DCuGntiHAQO0zTkVMwLLl5BSpoxVK3FGYvyhB+NfIfPDX6MYhiTMz4LCuuZX1rH8uJqVuc30aMWkPN9rEmJbYxuxogDrdRpofpnQ2lSDcoJeSdgIMWQKqGtvZuuC3qILzqfOIoZ3X+Imft2MHb348hjB8kdOUDv4GF69vaQu2cXQX47lTWL8D7yi9j+vkznK4LD4nmaxx7dy97jFeTsRRinETQowTYreLXjhDR0mqbORvVHs2u5/f+4ifD+M3e2+XFU3jOSc7cfStwbC5pGzlFsQFp2qBaimVFoISgpZXKJe/W5atVtDwfvPDYzeVfoN1+mvVoJ3eGwieAyQaRzCeBjlQJpR5IeJB7FNi2VsTFcMIKnNfO7FlLPFfjR+EM04wlynkHhKAU5PElwKsbFjmbdUp2xsmf3qH/Jxj57wZYFf/btPYMPel4u33ZG+lt04MozIoF2eInLFoQSnFE4bamVHaI9dD6lmbQoDC7zNRTjSIyiETllahjdkMM2V5tlLv2PFKJ1/1lrRUQO9gxc8PbJ8rHP/vj+Ry+578HHzg5ycmZHe0d/b093sGjRIlm9bqOsWr1GFi9ZyrxFK92y9Wc6zbViQGoTI1SPP0VteD/tnUtZefZmJqYb7gv/9il17MQYVgeXXXblC9/6q+951ysLxZz99W+OeI/ss+ROnCA+sA9qFWxtHEZPYKKZllBcwBrI57ngrCX84puu4y3XP59iqKk2moj1MlRilpjiTs3IaMX4JMaglMNXmSOMlWzzd85DOQunJx9n1k+ZI2XmPKMhiRNM6ijkNUoZUjSpaPyn6eYk67jcTyKwJ1V9Mpd/535yNnmaTfHkzzqLIyJuwO69I25kvCJ7dtxzyJk01F5uUW93icQgjqz7e65Dumppyeyc36+UO6mKPimolrmHCYWIwpqI6dEmB/YdVeiiyj4BBcrPjAp0DqKY6ekmzldsWLqCUrGTyd330z40RaRKEAQQx6gxYWJXzHj+ecy/6g9xvRvYs+MWbv/Wp+jr6eGF1/4mZ537cnp7e4iqP6Z65EviNW8VCSuorsvw8y8iaT4E058jGf5jTxXON5df+oKVv//e975WRL54ww03eFu3bn0GW/EOA6Kkd/51DKwWixWXWJwotPIwlXEuXFxi5apemo2MYezEoRNI0oSbD3+ZGbuTNPKYEst4coRdMz+ize+iP1xJb2ENa3Pnsa64ie7SfNJEIRiUa9lqPodEYS5K0aIyZMiDgBJFIAIqQxOcFXQQsHDDOhacuQ7e/Fqmjg0x89Rehu9+mKP3Pkl4ZD89lRh78AiL3reFZGEfQepOwusiwr137iKiHa+9B4MG5TIBfGWC0E5YbYxKTfM7kxODd50aZ//XLIAOoFlL9teL+b9/YK+874qlygWlmDAS3JSj0KORwJ5kz+m8wrQnnLcY98qL8q/betPMnYtyQ0f9UrQ+9nCYREgTRAe4xGaMOE/jxEdsH665GxVDmHcYrTA6ZPW8lTScY2jyAPmiJkoz+ugSFCo1WN+hUkWcOGp1hfZ8OXRskMVnL26b9/zg66bsp/nlqq2ZNJzWiISCQmWJySddrT2qFcO8hQFxUsOZbM5hZ0/MBpxVLo2dmIarUZXHGyVmnkEH/J9/Wp3gnj33VIDvtv4w0BEuHx2tnLNn35GF9fo9uTCfW93R0XZmZ0fnqsUL5vecsXGjrF69mtXr1rt5S5a7+SsvoGPdZSI4HnrsMffxf/y4uuvOe2to9vm58KVvfsvb11963ib30R0T6uZ9KcHEDM3BvUijgpseRaIhXvqSM1jUHZLGEWFe0d1V4PLLz+H5l64n72siU6VW11nk4yxT87RvKCsmtWbCTLXG/L5uir7CYVoFM3nOBaBsyw5AUlCGJNXcsXMcaVa45uJ1pHjPKFbuZ7KpcnDSyFvEPuOuPfU/P8G8bEGXFk1qY3YdHXX7J6qyb9due+iBOx8Kw7ZCjIRo7VL7tFHnTyHBZzZxmcegnAR5Zzvlk+G78rRJIuWm49iJUYZOnLB4+Ww71B62Fd0kLoFGg6Tuk6QOtMYYRyMuEB2HbhMRFHL4NmXkUMpk+wUsfOmNJLlV7P7xNziy/2GueNEb2HDJtbSXBjD1h6kPvQ9d/w9ClUc6N2Zyp+Q4zfRbiKmSd/OpNR6hOX4fHUtf7pauX/LLwBdvvPFG+/S8wBsUiG1vn3de0r7i+bZniUtMqp3NGgJNgBkf4YpX9FAIAqbLTbTW4By+X2TXzD6OlndR6FY06xE2sTTqDZT4VP1JJr2j5Bs72Bt+nVvH+ljrvZBXrvpVPNPa8tXPvvvITxyg5NTXlOBlvmy4jNmG9T16li+he80K3MuvJj0xwvju/dQePkjHyiV4yxcg9QRac1NRQqVa486H9kHXUpSfw2S6CHTcxEwPQlIRrHHKmW8DcQuhNf+VC6AMQb2/kdx8YMp77YOj3tLF/calkZOgBmbK4c2fFboKaNA9SoJGxGvPN+Fwkv+HntKM/4m9ZZqSKozJRJdeHozFaUH5GotA3I/ECt8EdHT2MdYYpre9SHOmQlwq0Dmvi2hqnLhSp29CsUTFPGpTRDs8T7AWKrHD1WF0simq+7hbd1nbovpkF0PeoMMitpXrNnvBTGrRWkiqFlIPCWLqddBqdhNSmbO9cdnpPQWd6mYSJ5MdOfyZ/yl4z7puMvbtFvnqV79qRmaiQxAdEhFe+9otwWOPPdZeqVR6h08MLx8fHX3xrl17Xqw9b36pmO+YP9AjS5ctp72jk0Zs2fHw4zIyMjZiLbdNTU1OXXjJ5W+59poXu4OVhJuejGGqjj78JDJ+EKanGAgbfPpff4WXXnHGaT1XkiShWo2AkCy/Lp4DD/I02HF201Y4jk9UueW+pzhv0zp39vIe6SiGOOVaMS+mNXaTOcXJtuBJEKWxymemlrJ733Hu3rHfORezetl8WTLQCdahsTiZ20PJTyXNnP7E7+Ykvf9Ej45DSJVHlFqODs7w4N4RZiLLj7998zETu0Uq37HWmRxTlSZRSqarU7NEH54B//5k4Kp7xmPmPtbNumNLNvtvxiknJg1P7NofjY+Oxiq3OHA2k5RY3wMftOewTLFkYBniFMMTU3S3d5JbfBW7H3oeow/dSdElxBq8ZVew5EV/w6gLOPDEragg4sVv/QPmL16Diw9TG/9TktoXKcgMfnEjqT+fKJrCbzyK2ElwmjDowihBTB079T1lF18ry1asPrdYLPYrpUafjvi05lfe/EtoW49p7zSuUvOUE0RSrDFIWuHFl53ZYs/qk9dEArh/7EGm4xO4yKeSpoRK4ed9lGTHA6MiRqcr5GwR6RjlexOP0pHfyMuWXEcSVdG2dYB/LqLRM/5+ev1pa/7cmhsbRcbId9lUwOKjFy9i8fKl6GtfTFM7kmZE6DIPWWsdYeDz5J6D7Ng/hay8mMTGWYi19pHpEfzGUZfTDVG4NKrGD/48mwfvP3tH86LG1GSj+OX7D/jvv3pFwbUXqpjYR6ZidKfGBuBii6QOyQtR4FjRk3DDZX44Ntrku09MMOkZtE4wcQR5m60im2bts/bA9eKSMHNHD0romiap1jCFkIgcM+NTeI0qZlLx0sDnfRdW+cSThi+e8JjJKdpNinWGuijqRZ9qoybFhUVbsQ2a1ViFNvNvTJWQKLAKjDV4VlErW4rteZpJDYef+dbNjkmMIk2hYcRFdSdp003WkmCEZUmVI/9T7Z6rQdm2bRtzdnPnnHPbtm2LgfHWn93A9weWdCzzsYujmeamqcrIZfsOj60PPN2fOBOkib3TGHOLGNk706hd8PwrrgoH+nvkd28fd4/tifHHp2hMjaKiCqp+nH/8y9/gZVecQaPeAAVWdEtbprBobKvzV6QoSVvdyqkCKE9jgCoQS6WZsPPQCfaNNl3l8aMyMjrmls8bkP6+NkqFzMDaRxCdzQMVgpHMbS0yhkq1yeDxafYcGOLIVIRCZLop3LVrmBf4Hv0dRRCLsbMEhkyu4MSdJOLok/3bMzopN2cfkUySYSGTk2BxLoNfsy5UsNbRrCXsPzbKQ48ddfWwID/+7pePHd/10H7lD1zswu4Cqcf+E+MyXo/pwOBLC8ptPddcN5u5BVfmFO9TaO6cAulkjiBEGBqfYv/xCvfc94CxcaK8tjypVeich87nsJ6HMRHdnY7VK0pU4wbf+d4PmDlrHedfdpVb8dI/kakd36Q8OYLu6qH/4tdxZHqMqfFB1q08l4Hlm/D0GGbkT3C1r6FJKPjdpKqXKCkTVHcSusns4CEaD41JqqQ6JQg0jZkfSVI5Yc/YeEHH6173ygs++9kvfPemm25SJ7WBV2yG7dsh33+27VuD8QWXZNC4KEirM6ybX+CsjQupN+PMD7S1+pom4qGxOyHnGK8qVNROJV+l4ClKBMyoSZjyWZW/kCPJELYywvh0mZ3793DdMsE4m5EP1c+fhjBLrFGAUw48h+cESQxGIjwn+Hiknmq57Fm0J9xz904qSSdBbx8xSQvGVrjyGGE84vKBSFJPd83MmL3/XQpgRszu4pjftA89sqe685YlwYY3nquci52U6ho74bCLMgaQGIdSGroVJrH4zcQ9cXtdwplhCJoo6zBBlN2nnsq6YNGgNI4uvLSLRmWII09O0DGvEys59o0Mk+/uQjciXD3GcymbB3Ks72zw0Rd0svlwxHvviihroVi0xOKoRgkdRqNKsZrUo5kJcepQ4rACkafxlMs8+BIPJ45cV0Itdmhrs5nm7Ikp9akZodYUF1U0cTm5F9IRNqPY/j+V7mcthj8xnJrz/ZHBwUPAIeDHwD/Covz8+aaPICjUp6eHOzs7m0eOHmkuPPvcKy+++NLwyERkvr1jXFNxmPIE2hnMjOEFm8/j1a+8mGYjxorK/BcxpEq3aobN6M2z8NzT5ienioq1NrMvdYo4jXls13EOD0cMPrFThl1E+8uukwPDhyn4hvm9bSzu7aC9kCNfCNFeBnsmxlGLYsYnqxwaHOP46AyJhASlPA/c+h/VA089Xm7/td+cnzojl6/tZ1F/JzmtT4noBawzLYKByyRlc2IonTuFf6lWZzH7VrQIkM5JtcjeS5QaZipNBgeneezQqIvbe+WxO74f3/XVm6wX9J3jvGJBwtCR1uWJvQcYHJpkw0CRAMkIO9a2xnpuDptzTn/nZrdNddoswGykmmARpmaaPHl4gsHjU+x88EEj+bY2o0OU8rEFhVat9x7HeNNThNowUY64/777uf3b23jDG/bIy156rVv+st91PomqzEyyd/8R/NDj/MteRVu+g3jy09ixrxAEg9jCQkSVSJrD2PQYylZbZt0qy4AEXMuMRFJBB4rAHsU29tr5869Sl13y/E2f/ewXvjtrAA8IP/5QCoRxrvsK07cYl6aK2fmwFpiYYPNlXXR2tTFdnsZrwbq+9jnWnOCYeZL27iLNqR4+c+nn+czeT/PZIx+naIWFLOG3LvwjXrPiF3n/w+/jm8c+RuNYgQWLlxJFzcxV9pnd93Pk/z2z+5uLGjwbeca2GMgyG7mlM6GFtHBLcbP2aVBvRNz50B7oXIbzQ5QxWM9CEuHKx/B1w4aep2Li22CkxpYtmtOyav8LdoAjI8QrV7oHJob44i1PydarVpb04rYZooLAjCPsEdAqm5lZg18ISYKUrgElixaFuKNjkMxg6YY0RmGxns5uYteax9V9TBQQdHtIyafaqNMe+JQ684yaQVRQgYqhvwwzj9eYCoTcedO86qJ2+vo0r/5hjbLWFFJHrWaolzzyymFSi0nAhtkJFCdYYzHWkvN9GmVHoeDRiAxRmsU6GjI5hIjCWUOSgm0qkWkHZfsEADv/hwH6f3KoOk1BnNPTHGsMDTE4+4Dp6WkRETau2LB23kAvOycSNzLtISaFRoImh0liXnLVOQiQ2tmNQD2dQXKaDeDZN4IM+hsdb7D34KSdmKypvY/e8fHxPT/4ZKM2/u/rL7lyU2//gD00jjo8Oop28UmGn2BbxroOrMLhE3T0MHbiOA9u+8zI7vtu/SKMPXLHt5b8mnrTL11YeXifPWvRPLV2yQAdbSGhb9CiUOKfKmJiT+kNZxkncyDXUxfRIc5kzh3Ox9iUKEkpV2OOjYyx98g4kxXrgo5uuf+eW+wPPvvZKNDti+OgXci147ycQJ0T+45w+PAEOZuyamkvAXp2gsgs3eW08OzJLnGOE8Xs95XFKpiqRjz01CF3ZNzy6D13TY8f3T/hd61rS5U4GyghVyQNAyiFUIuZpx3z+3vZc2iQydHJdHr4xH3/+I8fX37rD3+wcMO6ZdKWA5vEXH3tdZxz4WvQ9YcpD/4RQfNJ/GJIGvYi9SlIjiA2xncOh9e6hNmr1K7lUEVGFnGpoGsR8fRh8vMciXHrATZv3txaJFsUbpvxvO6zTWnxSgp5J81YObHZ3Cu12Po4V196Iaf8jrL15vs+T0zfx1R8nH40Y+Wj7Brfz3vP/F/c+tj3uXTF89j6vL/GGPjNbb/K18a+iHQrOmQpZy47A0sWr2SxJ6F3QZ6R0OBa5Ct+ghBzugI5lyX8bIXxdPCpI8H3cxw+MMEDTw4jfWdgMhdRsIJt1ND1E/iqKVpZlLVPAbBt9Oe2f/5nF0BxkMqBph0ocunla3zd25XYWsNTfsXifHAVh+pQsyg/VqV4BY0rR6w/Q1F6YGKM2PTgGYVJEGsQL8SlMWiF+BpHEZJOkupRpMNgVETY73H+mjPYMbqH0doEFkPHlHJP7krlyaUel18KFW24/AzDLx4q8uc7q+R9TTOy1BqOwM/CIdNUMCmIdtjYYbVDVGZCW5uG9k6PajPFKI12gnIK5WXDapskeLHGryplpixpWbLk+W3/Q375ORfEZ3aJ8kzi4sL+JQt7e9r58o6K1JMCvhkmrU7gkgb4TZYt7KZpMrmKFnsyHNa2wsgUCtsyb3jmzWytnSMPyAgaYzMNHtp5iAklsnPH3YzveSQXlM581f3fvaXz0e0Ps/KMDbL+rLNc55KlThfale/5gMaqFJdGeAJJs2qrEyPxnod3NB+/7z4bVyYTrbsuccHClz956/bugl9MrnrLW7wdByfYf2iKeX0lFg0UaSsE+EGA52l83ydQ4GmFKI0W8Dil9zoZ9pBZOVK3iqiZUq3UmZipMllpMjrVZGy67BLtCSqUh3/49Z3f/ddPjYjkzzZ+h2hdcuiSWK8T6enj8NEaB4cjRivHaZqEdQt6CcIwm4tjstmnPDdHxjInA04p0tQxU2/yxN5hBodjjhw+Lrd/7aYZ7XcGTorZ43IeUuhA8r24Yh6GjrGwV5PvaHNP7D8qw9NTQwXSm+JUju14+OEzHnvkwRcWPHveH33gD/OXXLhZmsf+kkbzrynlcqjOPtK0jJreg7YzCH4WIDwLb7e8OAVBuVMkJJs4vHpAczghGrB0ICRRFAHccccdrbecbeBSmLeCnvWkYd6oyUkvk7cIabnOgoLjgrP6iKIEjToJ/zrruOfQnUwlk5RG8iSqwp898sd8dfEP+Nobb2NJaRlf3vNltm7/A47WDrNofgdjQxEXFc9mWftiUgzaKXzlZZ+5SXGqdeiSWeawmvOMPxtR/bm6wdMXP4e1CZ5X4InHDnBiWgjX9NMUhxaVTc/rVbxomFInSllr02h2/rfd/rcogFs24MtOksuXBR9492uDl75oU2yaTxo9Pu7TvTaGmiadsvhtDue1GJPGQF6RanHdfcjlG6rm9gNTsSoUci6OSU0TKXjQNFjnga8RQiRYhPX3UCgpil39TFZq/ODh25CcQppN1EyCV7bSiUehWyFdjkAauNTx0l6fv69Y6jmhzVfENYMNFW0FxWTZkaYZ5Vdari86dNQqmlzekuqENHIo3TrhClmhNJn4PY5x6YwVKetRqeqjXFH32I75n9r17P/ccMMNauPGjbJly5bZu2/ugpc77rjjuUyHnwabejpLee9pLxZ0rsCjg4NC6uPqM7jGBCQxYurUo5hmnFmKzTEuaWnSWqbULWbKKcmDOjnDcig8MkboVLXJ3Y/u4cCxGoPjk/LALbeggoW/mOpOgnafxNTZ+dBDsvPBu6xXyEfF9l6vvXvA93NFRCxJcyZNo/Lh8sTY4erk5HwsS9DFUOUGuvHCRegA7XfywPd/ZKfHyvKSLa8inLeUJwfL3LP7GJ5S5JVHIafI5zSFXEipEFAqBISeJgx8gtBDa0fqNKlxxLGh2TTUqzHlWpVKo06jngCaINeOLvbIkQOP2ztvvmnfvkfvGfODgY1Gh+3Wb3P4OUGHELYjXp6pof3cdfttvPjVL+XHD59gbKzChqXzae/08UONFoUn2bUzs1uskOlqcTjdmnc5SAxUajWOjkywc9coEzOGalqT73/+M9W4Kcu80jzQIcrzRLV14Ao5bJBDJw5z9ATLzlhBkmL3HZ3QU5Xa9hXJyL89sOmKurvjjm8GQfCtl7/weV952avfuTaNn7Rp9W9Ue87HpTnS6Ek8E6OMa41ZWmQlyEJajWrpER1JmiKR4BogTWFmrM7R8V6W9pzJVKXhxsZO7Hv6At9s2bod3TXw6mTRwmzAmnqIsyjlMFMznLO8g0XzuqiXM7Y6YsmnecaicZ6qP0xHISSOE7pLvRwZ2sU3dt/Ea9a8ntd9aQt3jH6DjmWKDX4f1sBwI2TzuktQ2kKi0UHIsWiQAgW6c734zpEQk1iLdSqzW5OM8+CZ1vxV5upKf7Lr+2lkq9MdXVMEa1Ju+fEuXDCALeYzlM3L4p5cdRRF1RZyOSXNaO/Y2PEn55yP/msXwBtAfWgX8UAxvOpd7wjf/qbnJXbykVRVhgs88FiDQn+BpfkaZsahywrV7WGUzaLWAofOidgpw8vOsZ0f23OwVol7cxI0HPGkYLJBsUsFdBHnJYjMQyggMk1XsZsiHQxFw6S1GYKJMma/bh5/0D5RXO5dsO5FvktykTgXIrUGJWICLVQjQxpokibUKil538f3EtLkFEVbrEM5ha1aSvM1zTjJsG6bUcSNNTiXedkmKNKqszJmtZ1kR73uH1t1HL2f/8kCPN1B8aabblJbtmxx8jRu/mm7PpvNrxTGGN16vDs9ApFVqO6eUjDVcIxXLURNVJQFjTrl4WyRweFqFujq0mxgwSyL87kYlKfQV02KsYaRcsQju45waHCGih9wx9dvcsnMDKrU6SziEu0rp7tEhe0oMcqYOD8zVWNmfA8Z1GBoZcMsVTpYonP9gXh5jFWZ+5HnW5TGOE95PZ1q76NPcXj3U5xx3tnR8jPPdrnegTAslcRqRSPS0BACEyGmBi7KEFClTtrp+p7OJEVWcNahlSBa4QUhYWeRuFnl+OEnq089sePgXT/8fmzrcZ8qLLnCSABeHpVrw+gcqtQBGKQxiWpT3Pmtb7CwI2TNZZey4+AIEzMNli/sZaCvnY62kJyf4mvBJ2jNGd1JXZoxlihNaUaGcjXh+PFJ9g4edxNGUa/X5NYvfeb+4UOPGa99+aVI3ooXKheGSFsXttCBLbajqhGqWmbdql7qaZPhwQOYcuXuBxuUN4yNBUqpNO953guue+3SUl8bzce/LDmZwSQ5nDmaAeBGY1KHOJf1Q6kgMdgITAxEkNQdSdkQVzPnPIlhpOmTe9476FpxnrrttrvkXz/3+YfhZAKKYutWW/Q7z7SlVa9R7YucacbaYUBSxAUwM8nVly1HCxiXZKHgzmI9YWhqnGo8QqlLSFSKBTrmwxcP/D3/ct/H2V/dzYrFbajEop2j4if0Bou4fN2llLwCJhC+fuS7fOnYv9PT2c6aYCNnlTaxKr+cgVI/Ba0hhRiHshbfWZxojJKfr2hLQOuA8dEydz18GOlfj9XZDNxpH2k0oD5EoI3NaS2RiXcA5tlddf6LFcAbHW6rIC+6IPyLl13u5VJbNbmSqH2TTe49ZHEPpbz+qoBiGiFTgioEoFOMSTJJRA7qzmNhoRKsCfcfe7C2osf3OsRENWjmcSoHolFBERdOIeUQNxm7ZKAmVWJUXuOpBlE9cemMSFtZyu++Nt/4pbem5JaDNQG66WAE0kmXhYKKI44dzabCF0uYdxSUUE3A2mz+JwL1GR/tUsgJUZyJ4tPW1uysylwqTMvpZtwofzxnG1P2m1Ct789yBzOYbsszdtdtJ7uX/7+BSF1GpVRKKTPLkDv//PMXv+Md77h44cKFF7W1ta0stbUtC3M5VymXZWJiYrRWrT/wyIM77v7Tv/zTO0WkJiL86Ec/8q688sr0dFAL0I1neo+O1zgxWhNynRmMrjSiPXB5HtxxgJe+9EJ6SpAThXEZ29ib06zPLXjMEmJa87o4tRweKbPjyUFGxsr4bX1s//LnGd6/Gy9fwrpAIQG0daCdxiUJaZwgyiBh0nKcSTJTa1GCEx/nYVDZTC7QGbHDC5WTjIpsAN01QFov8/D2H7mHt98WFft6o+7++YXueYv8/gVL6OoZoNCeT73QUyrwUaKUFoXvh2gvxAUKLQ7PWKxLaZiIWnmaybFxd+LQntq+xx9Nhg4emsFWGtrr6vNKS5emXh6lcPg5sSqEQieurQuJHbYRgVdEFRbw5X/7GleX61z+ohcw0rAce3SQnGdpa8vR1V6gp7NIe0njeR6e55EmQjNyVOoxE1NlxiZnaMQpqVOEpU6ZPHKQr//zJ+sThw/0qnxfZyoeKiwo/BDa2knzHUjQheflMXt2sWm+z3lnLXHHRqt66OCuiMbw3XN8VcX3ZHlHZ0cujmM7fWxK9YYRfpuPS0JcIpiGw0aQ1g1uJsE0Hc0mxFWIa4ZaDM0YmjrEhe3EqkTYPkD/ZS9j0RW/bKZnqnLzzV8+Njh44hGlFNu2bXOt8FuJ/O7rdO8mId9lmJnWrTwgTDOlIyhz1UWLSYwD7fCsh1UJiUsYKAxQHe/kwNgRlvS1UdIeBRcwZU9Q7UxZMNBOZFI85eE8YWI05hzvLJb1riCJI5wf8MP7b+E7R7/P4hUreKhnNz/K38aA18eKwkrOLp7F2uIaFhZ6afPasSrMZAkmnsPJ5n8DHD3tPY9xhiAs8eMdj7F/qIk+dwmGNAtkdjlUfQypHyfvauKiRKJa9QcAo6OjP1f+xH9WAVSisEX8jRee3dzUGWpXd3kVrmjQf56H96jizrubbOhp59IzDVIxmKkIrygkqUOKPi6wpEq7gmfUOf3j+sFj0zXf2aKNjMM2hTAAG+NFDpEmqdW4qpN4uMFI5wSuw8M2p9ngefKaTZrrX6v716/x+7UJSaIZUWWIBgVzwhJVs/mHsmBTIU6gqUDpFOUgjUFUa2isFVHT0telqbkkM7pO7Smqt8nql0Hjys75MyKqrseadTkaLg37rvuL65pfff1XDRbntp2muclW1X9Vhxi56aabVF9fn2zevPnkjO2OO+5gbGzMbdmyxYr8zOGUcvvtt2sRSVvEsPa//Js/u/aM9ZvetGz56s3LFi0phoXg2X72RZtfeCWvet1rD+148OF/e8973vmxK6+8cqplrM1pYVGt0qlayvRUA+YtQmo1nHjZje1rHntkD4/tG2L14jaW93e3RN9ZpNXTGTetlHTJPuU4gZlKlcPHJ3niwAQT5Sb5sMgPv31zvPO2HwWqkBdDDiGHBAVcEOJEo4IA/BRJmrjU4Vxm6uCcQZTDKYcSH4XGCijPw6kQ5wc45SFxgojFSDuiC6h8T86l9VytXqW2Z9AdfepAi9apwEum/Zync8VirP2g4IX5XD7XprT2tXgKnDVJs5Yk9abXrDe9Wrni0noTaCjwQh20LVNe9zIjeYwqOvFCwUOs+KhiF6rUicm3ozs7Sf0OXGUS21bEz3Vwy7YfsnfHg5z/ghfQv2IdKg0ZLkeYQ3U8Gcf3HFpns0pDTGqdS50idQrRvigtTE0O2f23PTz2yHd+EKaNtE2V5q+05FD5LmwQIvkiXmc/SVhA5YqoapX04C5e+LZz6ejosF/+yt368MGDD54Hu3ds2aJ3bttmRMTNNOLhvU/sIPeq10mz7SXsvucrrOwqkzYtjQokTUjSrMjV0jyRasMGXaiOhbj++fhtveR7FtDZtZz2vsWoUq8L2jtxot2e/Uf0V77wWW6+edvXgEljrbToRwFgbK7vfPqXZFKB1IDzMmesyQnOXJJjw8oBmg2HVhqxBicpYoRev4v3b/o9/vimP2bvU/uI22KKPXkK/QFhsUTVgfNics5HUsfMiZTzll9I6GkqtkKu0cbbz30zfio8NPwkR44dZSgcoth9jEe69nN7eC+9QQfLc8vY1LmajW3rWZxbSKffhSd5TGpITYIRm42tnEafREyeXU/4TLKTy8Iu+PFdT5B6ffjFNpzJZsPKCbY6RZiMulxodaMy1ZgYHfsRwPbt2+1/+QJ4BajtDtvhJxctLHT6pBXj59s1Occl16Ws3Jjne9/y2T3oGCho2segMCKUui06UJnWrwDtfkqjoXnBEtP+6cPTM/XUFClHmXg4cFCdxlQnIT4CcSXJt+UrC0rSdUbPuJw5oHjekhznDQjdXQGoHKYeWzPVUHockgmDG9LEdc1IZKk0LZ7OZhHGGgweqWRdQBoDWtDKoRoK5Rw6p6g1DGJ1xhBtfcjGGXCWOFZE05bSdGBdxX1VrB9zxGfb9dsCMiX1WX4fSzL6H0mSEjPDThw7/6sVvxtuuEHdeOONMrdLe47Tnd62bRvP9bibbrpJv+51rzNXXnllunjx4gU3/MkN7z733Ivfvnb5msWFnD/7MAOJm6hGMjNTFWshn8/R3Ra6fJh3/V09qv/8nuXnn3/ejZc977K33fKjO/9BRP5GRNxrX/vaWZjEZQozNxknarJers631YrD+eJKHhLksfUqKiccOXiI++56BH31hWjKLOktZBApGQkjuzEzFmXiIEoTZmpVBo/XGRyeYGh8hkSKGM/jW1/7wswjP/jOiCr1rHTO1+gCLighhRJIgAuKGRFERxmj2fiITRBnT5JPackGRPnZDEqy1+vyObTyIYqxcT1be3nBJTEu9pzSoUjQIc4lkCY4m+CIe5NmTFIrZzj9ydOao4XG64z2qgUdIr4nulBCpK1gncOIOKtD0HnR2hOHxaLx2jqwxS6MziEqh8l3g59HxMBUgsFDz1vCkWPDHPnEZ+hfOq+59tzz9dJVa/2O3l6CXAFRIQ6IrMXpAkqc+DbGNhqMHD7MrofuMQeefKgcTY1MKN2xRAod2rrAeqUucV5B0CF+9wCm2Av5HlQYkh7YR6HNcOmLzqFcq7s7tt9LY7J8y0OQylNP+UDcst578Nbbtn/j1a++7xUrNm42jzz1On3vw98g1AVs90rCrgFyPQsJuxbQ338G+a6F5Lrmk2vvQ3shOHFJEtFoVpiZmZGxEyNy/MFHeeCBB+Wuu+5qHDly5BtaB381BzcQOOi6oKPet/Y807UE22goXGb8rZRgp06w+YWL8UIP05xBa40Tg0KDgsjWuW7Tyzh7/tnctfte7tv9AA8PPcLe4b2Mto2gSpqwM0epXRHXm+RrXVy14XLyngJTwLmUcxecwfmv/DNGZ8Z5cOgJ7jh4L08MPcrBA4cZLI5T6s6zr/Mo91V3sDzsZb7fz5LSas4pnMmq4kJK+T5yKoeOhdQYUmWwyuCURVvvaWqlpxm1z5lhaKWYmZhm+0P7oeeMDI2xPgSZ+bWbOUTgJqzYpq7F1a9PTh4/xg03KLZu/a9fAPtnuUS+L5VpSzLqMG1NZIGHCYr0nxfxtosVjVFD9XhKPOkRm4iqAy8BiSBognUiQ7F1nTLds7n9gaOPuY5qd6FUKnT7FIsx7YumWdZzlFVLJlgxEMu6FRP5eT0d0tEboqQN0oik7mhMGPypCdR0Q6UzDsogDSGNLZ5SHKkYTNPhBZk3aZIoEl/wHWjfQ2yMjTOdYhRbAl/TSA2JBVHZBulwWTyM1aSxw04YF5xAmsfDQ/FwPFnoL/+2Wu3CxfPbg4EFXfP7+/IrS+2QphaTelRmEsYPVOpDexvfGTle/5NkJnmU//deofLJT37Se9e73pW0bJzaP/jBD162bt26S7u7eweiKCr5vj5y7NixmWPHjj324Q9/+BERGQbQWvOBD3zgaXloW7Zs0TfddJMTEQP0fuELn/+1c845/1fXr1/X29r1DVie2Dekbnn4mL5r9wQ7h2PKVUuaaHJBjr4enwtWF7juksVctrHXdgS+PfOMDcs3rFv7VxtWL3v+S1/6kl/etm3b+E033aSvv/56Y4wREXFTk5P1FVGdoDFFzVRJfI3LF2DKAT7Ob+dr225jwbq1VJtVyrV2Bjo7CMJZV5JMphMllnIlZWy8zNGxMicmqmgUYVcnJw7ud7d96d+TY7ueEF3oWmhdUeN14YICUizh/DzkiqDziKeAFBfHmS2fiXFpcup47LLEE6cUon3QPs4PsogtL0RKPqQpVCrQjMDzEfGFtNkyeI7A87IEEgmz+Zw1WZGdY3Ump3pbmc1eAzCzR3QVIKooojVKpRjxkKCA196J5NpwEuCCHPgBuAQ/XyRpGwAjmJkYTBPdOQ8dlxgdHvVGb75J7gkC2rsH6Ojro9DT4cIwZwUnKSaKa5XyzOh4UpmYaKtOljswsWjf7/CL87tS5+F0HpUrKeMFuLCA6poPpU5srh2V70TKU9gjj3DJKzazcEEP+3btURP7H3U5W7tPwLFzo4GdSJYuHN19345/+KdPffqVH77xBnfOa/7Kjpz3JpVrK9KxYB1evg2jfJdYjTbi4kaFiYnjDO/ZyfjomBw/flwOHjzEieEhhoaHmZyaalbKtalaPXkySZLPhWH49ZGRkdqpff8KD7Yn9fbVb6VnwyLJtRuaqcaaLNA58gjsFFddfgHWxq1l0MpdbDE0RSli22B+Xx/X972KV1xwLSPT4zx5/Cke2PcQ9x/awa6DO6mWKuA0bz/jTWxauZHUZDFZgiO1KcZaOoptvGjN5bxw9eXU6nUOTBzi/tGHuefAvTxx6EkG9VF29R2kp7dAT+dj/KBwD4sL81mVX8La0krWF1ezMFhIXgqkzpCaNIMxOUUYeza/0SCneXzPIE8dqaA39OJctta1CFIZQVcOU3B1UWlM1Iyz7L+tO3/u8rH/VBZoqovpeFkwo5pkMkbVE+ix2PYQ5ZUIB0oEyzwcZcSGYP0s1TtJIY0QmiwyyIK6z1dFLyiH97tCAG1BicBPULoBuRyodnBNj7jbs1FMOjaBrVSR+gyq1kSaKVEEQU2gKdhIoKlo4OhKoZFkLbyyYBNLEllqCnQhO5ELAinYWGMaKV5eqCcpyimMbum+yEgE1jiiukPGEX9Gk1tUW7z6mvwH+hYPMH9RP/PndxEEjjSxxEnVRFFMHDkJmw2WX9hdOL6ncf39X03M8OPJ20RI3P8jOHS2S3vXu96VXP+qV531hre//R0rlq945aJFixd2d3X8BBmkXK7wute9fvrYiePf+PEdt9700Y/++fe2bt1qnXP6xhtvdDfeeKOIiBERPnTDDa9/+ate9adnn3XW0tmlEkeJ/t4Dh/S/fespbn3oAJXYA68LaLRCFzOW7dETnTx8oJdP/rjKBcu1et8rV6pXnz/feoK55poXv+Kee+5b96EP3Xj99ddf//hNN910EpuZGJ0Y8k1Mm224qeoUUmzDmzeAnRnCRU1UWx8jJ4bZ9q9f4+VvfQV7Dx5HNwZpK4Hv+ygRosRSqTUo12o0mzG6UETa2pBGjYPf/k5613dvPhFXpwOd65unaAcvj9E+qtiBDfOQL6HybTjjkWoHvoMgW1uYGEyCzKZgz/ZlXjYOFN/HKYUyggsCrB+CEbygiK1XcNUZXJwingdpHtIg0/TZNHPOtCk4kxnJ22Q2rykLbT6ZSqFA+4gISgSLB8oDncGwzi9CvgOCNkw+j/N8cBrJl6AVBG08H+ko4uIC2vThakBzhoQ2VDH0VL4LF9WYGq8wNTSWpT5kXFCBRCC1IKkoL/L8IuQKyopHqgS8ENElnA4hCFHdfdi2HmyxCyl2om2DZM/DLJnXzttecT6N6dj+x937FNNDhxfnj967py7ANjtXabFixYqHvvsf37+tp6f36je84RdoX3QmqTXuwL5DDA8eYGRkWEZHRxidnpShoRNMjAwzPjVDPTEkceyiqHmi0eQuJWpQaz2Fr/fm852PjI7uPdQaB5y6f7f0O7aBl5u3udm53BnRjmaUyShCQzpRZkNvyLkb5tNsRCdlCbP2eCrLJyHSjsQkeMagfGFgoIflfS/gpWe+mKl6mb3Hd7H72AG627u5cP3F+KmPlQiFD5JJdjxP45RgjMU6S1jIcU5+I+ct3MhbN21hcOI4jwzu5v7B+9nx5CM8ZY+Qtu+jv7efeYvn0RW20xt2sKq4lA2ldawtrmZ5fikFXcBaS5Imz2qfBlkzcd+OgzTiAfxiL8Yq8BRiUtKZMXKu7MJAq2bkoumZ+KEWScL99yqAYpvjzZBapCWsJRAr1HQN215DimVczsMWipD3wO9G/N7spirksCpAJCVQmTt6wRndZRTOWIypYhqTJM0KLiljo2lsVEWilCCpolIHEdhYIFb4BjynIVWY1JKkjtQanHVMJnm2T6UQqkxsa8DEghJLoyyITjHicErhNRyeBdEW28iG1k5blJfBStYqTFXTPO4oeCkrrwlYuXHA7xgo4mxiVbPqDo8cJ4rrktiGANpmQcnYJkz4mGhBG0lf8jxggXMc+Tl3gXLDDTfI1q1bn5No45zTrS6t4/s//I/3rV93xvuWLF6cm7Nx2GzTSoAcItDR0SYdHRs6N27c8PYLz7vg7S+66iX3feXm7/yOiNwDsHXrVn7l937v0je+5mW/v2Hduuu62/sA0mbU0N+8/5D38a8/xo8fmIAI8BVeUkFNHsfFUdZ9OZv1KH4R3bkA5i3mwQOdvO5vdvKWK0fUR9+ySS3K2fSSSy5a+6E//sgdbV1tL3nd6173wFNPPRUA8eDw8aMzjQq9oXVHx4+h2tZjOgtIWy+MlTGujm7v4vE7H6IydIjzrnoJumMRbiLC2kmUaHwvwPM9lFdEtZWYHB9n7/bbOfzI/dSHjjTFC7tVrjsUlcOpEIuXFTzlQdiG5NoRL+vklGqJ8DLNOaQBpCniWgXQWkQpRCucVqBmyTA+syQYBIwfQqeHFAu4uI5N6kizicQxpDHOGsRanElRzuJME+dOucbgFCIZAjqbPy+zCKlo8AKcn4MgBL+AUyHoPIgHygcvh4SlrDvNstrAy0NbJ9am2ZwyzCONMtTrpDbIpEs6QJHijBFs1gXhXA5hPi37NKs8rAoyWFXrlvGKj+S6UF09uHwH5NtxbT2ZMf7xg7jhQd78B2/i3EUFvvXgcXf7936IlpnH9kxQwVnh1IzaAXLw4MGZ7u7ut33+37/yoXvuvOvarq7OAWeMVCoVKpUK9VrNpWnSjKwdT43b7ywHnFO7lecdERtW0eFIvsChC49cWNnGthZ0Pzy78c+9d4VtXzU90FYvzruErkWi4kRbl+KcxreaeGKMq168kPZSiZmZWpZMK4J1irw4EmU4Fhl6cwF9YQCpo54mpClYDHGQUAgLXNJ+AReuP5sYi048RAxK6Za73OznDsqoTN+qbGan5yyJEcQLWdm/kjUDa9hy7osZrUywa3g3dx65iztHHuPg8UM0dYzXk6On/1EWFLczX/WzsnMZ53WczYrSWhYVFtIubUTSRLeeLyuICq2FRiXi7nsPQ9+izN/ZgWBwaQrlEYph0wZa60aDh6Py0cPZihD736IAbpu1QUujmaNjPiNRSearJioVdKKQusPYFFVLceUmxgffH8k0dBrQXpa2IIJFMpkMgjiLuBRrLSqyeLGAbRHdTXZ5HFnGoESgjMu8WRxgDC4xpEmm30pwtMU+f30g4Y5xi9eRidcVgomytivWgJdp+sQpkpqh1OlhrIVUsDpzUXDGxxhHs6aQpmHlBli2tkRffx5Ng4mhSdI0VsYlWYCAcljtZ9E4NhPZB6FgtVGjEw2JhB7fpyNJ/s9nd5s3b1abN292nucZY4zbunWrExGstQLobdu2PY28cvvtt3sikv7Gb/zGK9/xS7/0lxs3bVpps2KXxvVUP7hvRO14alwdONGgllhyoc/i/gLrVrZx8bp5bqArb7u6O+WKq6+8eMXaVXedf/5Zn/nrv/7Yv77/I7//5isuvuzdi+ctyDYJY+UbP97t/dm39nHfk0egEaPjGl5zmqSSxaxkG2GKsU0QhfZyWFPHjO6H+jTewALcwrP4/B0V9g7fzz//2kXeho6p9IJzz+t676/93rceuOeBs2+88cbRrVu3yt79+w+NjAxxzoaFPHzPcbxl60nzeWTBUux0BW9oHKcb6K5eDu3c74b2/XWy5pwL/J5V6yl2tzkdtqlmNE2jPMHk0DCjhw65kYMH07hW9bXy8MKOktEeVoU4CbJOqtiezfvCIl6hDeMXINBIkG+ZGwvGZDNjcWSQps1gUDULTUo2mkOpTLfg+YjyEOuQJMXaFLC4XBEJ2hDTRHIRJDE2jXFpBCbBmSRjWJsCuIST4KfLcvucy+ac6CxrUGkP0bksmFQFiPZQWmfvTQU4TyFBgMuVoFDMXp/JGLHWKVSxM5tdej5UsicSrfCiCJsmOKMwNmlpZ1PQBpwBJU5EZXCd8gUVYHWYeUPmfOhowxV6MF4blHrQnf2I75CRI6T7n+K6127mjS9bz2Tk+NZXt0vj2IMNHVc+1xpIKZ6eIDCbXXp8cnLylwYHjy7La87OF4pLcvl8u6d1YnETVmTYObU/jpPjExMTldPda0dOmfvK6fSosEXBNpN2LLnIdS6bL4VOa6NU4VrRaZFDp1NcfdklWGexTlDOkjrIS8reCnzkqYSnYp8+HXNxb8TlPYqN3R7zih5eqgnTlLq1VHWKcj6BUaBPkc6fFusgp+R00pptg6CUIyeZUXVqIpx29HT1c3XnfK5efTnjcZlD48Pcf+IB7hq+m0d37WWHO0yu/TD39jzKHcV7WVRYzLKOBVy/6LVsaN+AcckpNxssgRewe9cgD+08jlq29mQ0kxIw9Rl0c5wgjJyIcwpuBcwVV2z2tm//+cvH/lM7wFii40eGOxq7R/x894A4nSDKCspkmVbi6Yxq7hzGaqwniDGIstmfzAripDA5k0gpUudlcI62qFZKQ6ZjauFxpmUqbMnonWmry7LZzZ4mHqaRMlhT3DwspJ7Dj2PQ4IkQJdlzuqQV85FksUmkFhUKcWRxLV2MTjUm1TSbMbm2hNXnBixaEFJrwrGJCbBZOrzWrQBTk3WKKYrUpCCOnK+IgSiFyUkHqVJhyWtP3psqtv7vd3+zpBURMVufPjQu5PP5zkajMSEiEXP0iM45DSgRST72sY+95/rrX/ePAwP9gEnrzVR/9ntPep///i4eO1wjSSSjzKYRRAGYHPgeyxf58qrN8/Q7X3EWaxd02MWLFqu3vf2tv3zBhRf98qYz1s7uB+ahXUf11i/dx3cemYGpGoX6NHG9jkkNRhy+i4kaFdLJCXBCvidHmhiS6QR6OvDyPrZusMdrkASEay/k/gNN3vRX9/OV37/AW1tI08svPX/gQx/+6L+JyIu1UgwfPTZ5ePdOFm28XHlTJzBDJ2CgHZPPoZauxkYV3NRhXNCDWliSZnU0ePyBJ+HeO40K3LT2go40wXNRBEQG3Iz4vtHFYp8lyDoyNKgc5EqosAPj55FSJ6rUhlEh6ABbyEFQwOmss8GmSBrjUpsd0kz0dPu12QKoW763ngcqyBazTZEkxsZNZtMlRTusp3CSBx1DkDXs2fyvVWRcK7/QWcTGLVKMwonOWKMITgmWoNXpZcbJVoHDR3QOF2oIQ8iXMnhXAUmCTWKwYJ2g8+0Q5MEPcOUJjFOI80FHOKvBJtk9bdPMAk65lo33bFaqwnk5CPJI0I6UCphiHpfrRPkd2LAItXE4doh0cJA1Gxfz7rddjs4FfO4r97g993xPeenYZyaGG7c+h4A6cyjNHGcONwyHG5UaVGrPyXI/ze843f/PYQaOCtuhGfRfk/asx3l565p1hdFolZJWqyzuSbj0rIXEUdS6CpIVpzDHR289xFeG29HFmCfTgNsPK4phzLou2NwXc26/5sIOxfJcQEEiatRxXohqmTVYazkZMfKc9P1WsoMDT3sIQqJiIiKIFW1hkTMXr+CsJWv4xeTNnBgfZMeJHdw5/DD3H3ucR8r7ebhtH4mqolaEfOglm4iSBr7yETTWxWgv5J57dzNZzxG09RIbiyhBrEBthsBOEepUSeokSpJ7MvZn/3/KGOg/NQ9Qa46PTsvuhw9G55zd67uSNlkDbhwuJYsOmTXccRYxKpu3KXDataJP1Ek5s2R3IEKadX7mpOqgJY92YFx2IS1IFl7WgicFE0G96qhUMzjooUbqDs8EeB2Is1lxEr9FVjaCSVzLoV8hdYXkIMGQJhYngmhNmirSpMm8RT7zl/vkCzA8FhG7BPE0WgWt19KCopSPQaNMiqfBD3ycsaRG0Uw1zWkhbaSpFpdj60lHqJ8Z4nTOqVbh4+KLr1r4h3/43s2dnT0v0Z4+p6urqyOOkw5j4qlKeXpoejx+ZP/Bw9s/eMP77miRV8zWrR9595ve/OZ/7O7qMAA/eGTQ+6O/+z4PPDYBOQ8tCV5kkaiO2BRLLiMmGJ9D+/P89ZFpPveDQ3zkly9V73rpWudsajedsVpBao+MRvrPv3C3/rfv7qHWcGg3g0xN0YwTBIcmJa3USCtluvsCrn3TZq695gI2nrmKKIq4edt2Pvbxm6jNBOiO+RBHmJG9GC2EKzbwxBHHL3/sCbb99rneApWkL7/uuhe95k1v+vDNX/jCHytRtf37dsbnXPY8f0W35/bu2yl+99mY0Me1tcGaDaijOezoIWyaoHKdiC7iGjOaZKrHRRFKEmwYoJSfOuc8h9dprQeiEZ0HL0AKBQiKWF3MbLkKnTjfR1QIuSI2n0f8HE6HSFjMoNA0AWMQYxHTxLYikhyCKA+8DAJFa9CZD24WwpsiSQJxiERNXOwyJyUEUQJasjXnvBb702Ri+1bKPc5hddJaYQqlvJMeodIysT6Jh2qNCwJEh6iggAu8TNKRyyNhLiumrXw3l9YgSjDig+ehi+0ZRJkvQrMGcSN7n3EDTJTNJ0kR7SPS+h0i2e/zczg/xAbt2bULi+iwHYdCKuMwtZv0+CC9Sxbwm791PauXdvOlW/bZb375Gyq0ex+fqsbfgcnyTxklODk5BD1tIXtmV/e/D8XdcYdBBBt2X2I6F2djV9MyJNdgpqe48Nxe+nsLzFTqiCcoIygPjozV+fGeGBVq9MwM2pZIc5pmGPDYhOPhYZ+2MGJ+h8eZ3SlvWRJyVZ8mMeYkqallP/60d3XaGCQydxs5JXclNAGIkPitK2ETrHF4vmL5/OWsnL+CV/FqxqcneOrEbrYfuIs9I7u5fMklNOLmnGBmi2hHVGty6/bHoHMBNihk6195iLFQHSGg4oqhr6KoMlluVh9r4Yr2v1MBBKBcZrJTot2PHLbnDK7OUSiWKQUeSimU59DGMnvmU3Y2Abhl3CuccqNz2YnEzaIXYhGTQZ1uFl82DjECqcoKYJpZkiWRI2pAs+Fw9ayoJc4RlhTDM4FUXEyIh2ntDeI7REOaOJzfknxpBXWD6nTEcYqzmQuJTRRGUlasDumZB5FzlCstiFYJGIV1FqUMThTGecRRpvPqCC2+FtIkxRpF7CzVmnPNsi80vEHXTCf/d/Ieb7jhBvXhD3/Yioj5rd/6rbNe+crXvHfpsqWvXrx4oFOJ/8yHtwFLgIuiqP7u6171wqknntz1bwf3Hxh/05ve8JHurpK1OPV3X71Tfv9vbyVp+vhSx0xVMKbZCgVWrc+libVTpFVBvDxe1zzGp3O8+6/u4tHjk/J377xEQ8JX7jmsf/9vt3NkfxnxInSjgokqiFhEJZipaahPmFXr5qm3vn6LvGHLC1i1fN7TXvR5Z6ziupdeyqvf8hGGqzGqLQRVxY4fxfYtJt/TwT27Ez7wld3889s26K62kn3jW9/2/u233LOoXJ/89rGhI08p0zjn5S861/7Vp+4RPbaMtLMfigFKdSJ2Hr5ukA4dxjVqWVfmIpzODi44LysaQohSYdYd6WzjDjsg9LP0EK+EFPtwYT4jq4iGMMC1FSHflhVEL/uTFTQfUpvN6whPShSEVlcmks1wtJcVNjLLQDEp4qcQ5iAstOZ+CZLEuCTOXNxtmnWnLfKnSyOcaSCtA6LDzw6aKoNZZ6FR61y2d6oWEcYLkFwh6+aCEPwQfA/CEBcEWaBt6sAv4bwczs7g6g1IGlgB0T6u2An5NrApKknQaYwzDZxpAnFmO4efjTe1RkmA8ULEz0OugPgByjhMo4rUy+j6NOn4CRauW8Jv/9YbuXzTYm598Ij91N//izLDDx6Iq+O/EJU7n4Kxn3WObmfvpY0bN6o56Q2tGnYHgP1pM/TTdowiNghK61XHsnNt34BzJlZOXGYz5hTUZrjm8jNAFMYFiDTACTrweODANEM1QfKQ6q4WXFzH1QOsElSSUFM+e8qKPUOW+x85yldfM8DGzhyxNRlE3vIvPV3j+kyyylzeioicTLjxZjV84qO9bI+2zmFdxoCf19XLgr7NvHDTFa01lT2zr/xs/3YGP/A4sucE9z85gizdgFGZx6QALqog0SB5PzGBp71Ix9+tjw8O/bzdX/5vdYAKsIlKbz8+6V55aDLM9ztxtchIW5uj1AZ+AXSoMxaUdqdOKdb9hJuHm/PBqNkb2graZECeiV1Gbqtr0sjiEkuUOOIUTJpZkwmGVjgaga8YbUrssJ7VTjknOJMR8X3t0YhTSB2e00idbHPyVZZGjyJJFV7OsWJtSE+nUG82aFqH0q3XpiDQMdoJIpo0hWZsKYUexTCDPxuRwznBWEfDQmMC7Jh1rqEeydeTffX/DcZmS3dXvPnmm//i/AsueOeSxYv1KT0d7vhYWY1O1rDGSldH3s3rzrtC3ndhWJBVK1d1rVq56jfT1OFs4iyi/nTbA/zhP9yLkm68ZIy03kCsQTmDnRrHNuvZ6dJ50N6OLpawaY20OoZ2jrC7m0984xCOGLEen7h5FzQNARGmchxjDb4VkulRXGWCs85dYX7n137BvPLlm1Vbex6ARhRlsHYL2bYm4uKL1vOpT/4B1295P3HkEN9HpxXS0QMk+dWo9n4+f/cw15zdK1vO7OTaF7zQe8FLrn3blz/3z8fL09X68eMjXHPVy/j6N+/k4GPbKZ3zQuphAeNitEuwhRL0zENVpqGZgqdwNmixfFuQfIuO7sTL8ihVgA18nK9A+Ui+GxfmcV4IQQ7CPBTbkGIJcnlc4J+SNrQKmliXdWViM+utTCyFKD0n0kid8kjw/Qy5tGl2cjMOkuRkAZQkm/tl309akCm4NPvMnM3CmrOL28qK0D6I31IpZzAoOiOsSBDifD+TO/gheFk3ihdkhVCycYNoi/XBeRoJ6kijjo0auCTNSA5KgwpxYQ58g6NwkqFqLThRiKdxWki1QlSISKYVpF4mrY7iNct4jSbNJOaMyy/gt971QjauWsht9+x1f/vXn6R56GHr6uP/a2Zm/GEY/5mK35x5ufkpVny0Zug/Ve86B/9UsN15Heuvcws3hSpoS9OZmufEoghw1Zi+fMzzz19GmjRR4sAoUmsQK9y+p4b1ApRpIBN1TK6IzuUQqWPpw4yXwUwgQYjfXmDwwCT3rHKc/YIVRM0kgxdni9f/Zz6dO4UOtMxbM5aqbY0YBesciW2xPxG005lErLWenQVfhTzw8EHGaiFB5wCRs4jSrVSfEfx0HE1VXOphouQ/APl5u7/8X+sAM2yhelcl6t0/OK02XbZEO9NIpVkTiMDLOfy8RQUa3wflu2wGobITgVIZ/OIkyzijdRExgkvBJY4oAZNkSQ1p7DA2Rixom3WHnjg8z2FbdmW2VTBjZdlfNSloXyUG63lYazDGoXXLe6+V7eaqoD3BGIdNMq2UylkWrsoRFB0TU00cQpxRqzKHeAU2VGiliWuCTWM6OzxU4DFeb2brRhTOaqxzxMZRm3D45UBcwiMTLerAT7t5b7jhBu/6669Pz3/e+Yv/fOuff+3KK688f1bhvO/omP7WHXv1jx49ypNHphmbyOjvhbzIot5Ozj17Ob9wzWqet2EgowkZQxgG3qe/8xAf/Lvb8GnDTB4jNU08EtKpCWjWufTi1bzk6nPo6+1mz4FjbPvGXRwfPo7X3UPaMBgDcbOGPzDAJ7/VgHKCVKeR5gQ2qaC1wcSOZGSEFatK/O6v/RpvefO1uljI6dRaas0GCm8OW7HFz1A+lWqVF195Bu/+hVfwN3/7efSipVhbxo3tw2gPr8+R6JA//togm9d3SF8e99a3X8/3v/utc1Njvccee5Irn3c5b3vtZm748D8Qkyc490KauRA6ekmdg6SJSrL5rHg5sIUWvB63vELJioPysrme0llRCHQ2q/I7cQHgh0hYwJU6oFiEXB5yQVa8vMzR5ZQ1hsymwLTs1U4p9ITZdHQ1ZzFkjvlIAmJwngadImmC8zNzHWeSrDimCZjMrDZzFTFZwW2NDazJ2sOsqKsWGUIyQprSOB3gdAuK9QOcF4CXpa+L8kGrFmsz0w6qFExRcJ6PBAFSU7ioikuyOLPsgNsiuimdXcdZM4lW0UVApRYaVVw0hIsbkNTR8TjpxBBprpNlV17BL779xSzrb+fm7zzmvvC5L0t0/FHx7cSnx6eOfrN1CHc/7fDYIoHZ2Xn5WWvXLtv8khcsW7Jo2YZ8obBKiRTqcXN8YnJiz6Fdh3Z+cdsX94pIZVbv+qUvfUk/ZyG84Q7LVnFerufCWu8abKpFkmxf0wLx1DEu2VhkxaJO6rUpQCMmGxGVKw12jAjk2vGPHePTb1/Ibfum+df7LHQ7GD7Mmy/M8evXLOZXvjDIoyN5guNjzLMlUpflOio7R+riHE9Tf54GDn02U+vZx8wmiUCGhM1+72QUrpz+9yjlk8SG7936EK64BBe2QwumtSaB2ihBOupCv6EbdTs9Vj50C+C2b99u/jsWQAcQGoaqcfq9/cNukzk3J135KoSgTSbKNInDmRQbu5MM3dkdT2ahUJcVItsy7FWzmWZztwOX2SVaj5PdoXLZydkYO6stxijwNUSpZs+MBGgnLgWUxVmbef/lErRpQRNxZnBrOh0utUhTQ97QM1+REjExJojTGUNHa8TLiqASTdIUbJwSiqa9PUecplQbTSzgkdHcDQ6nDPEMLhnSKpikLHX76JzZg3uu4rd169b0/e9//0VvePObbj5z4xkLgXRipu793U33e5/4+v2MjVQz9yXFyU22UYeJqYTH9lb4yg/28qIL58v733q+d9GaDu7ZOcT7/vT7UDeY2lEwFbSNSIfGWbWmw/71n7xXrr3meTI3TPq979nCta/6DXbtPY7uWYSNJnHSgZv08ArtuPIENp7BuQaIJR6bwdcR7/2dl/P7v/EG+nrbSE1KvZmZNaMko9BDNr+awyDzxCduNrj+zdfyr//+VaarU0hBo2IPO3EUKRTwexbz2P6I7z85wVsuKHDZZRfKZc+/dPk9d9/nHT5ygrsfekLe8poXM3/gfbznN/+Z+C6Hf/YGbFsPum0+WbJBB7ZWw9YrLSJVhFivdRBzGSNSZyQRUV4mE8gVEK8Efi7T9wV5JGyDfAGXC5EgRPwA8cIMbmyRXISfzOY7KSCbXQFqNjn9VEcMgugA1+ruEAWehzs558vIMio12czc2lYHYE5OssQYdAvGms14ReTkjHuWfep0awbpe6dmkUrPQfjUSXu42Y3ReiHWD1H5EBW3QbOZQaJJjEsym0FQLb2ixZqMBevSCImT7Jqnk2AiJGoi9QQjhr5zz+Wya65lzYY+psszfOjLP3A77r1XvPL+OB8P/cXQ9MjH4YYEnt01pOVBKy25D+95z2+cfdFF579y9ZL5L2zr7T+3u3derqejizDvtSBhqNZqjI2O8p7f+Y3jE1OTt93/wI4vf/SGD3zv+uuvNy3p0OlM2YWtygLzGvlFm2kfANNQzinEOqzXgJkpXnjJKpSCxCiUBisexVzEvlHLoWYOry0gbRhqU3U+ev1yvnbHQwTDDf7inWt400VLuGPHYaoTEXa8xtr2iPPOHCBuJBiXEouHUhC0oCmRVp5qdmT/iWHn3BxG9xOlksymbnZZShYWTitXUM3NBUROEk+dA89TnDg6zD1PDCIDmzE2PVkwXaOOVxtFxxUjgfHiZv2WyonKxM8z/Pb/SQGkk+boyPTH9050vHQ8bT+jx6vaFKdU4DKbQi/7wDMGWKvrm0XuZDZnKkNwsOCczDkHZ0UyE6oLmMyxw1oyM2oLymXQlVPZz6fWoTUcq/vm+EziJHCkVhDj0FplG0XqWuM3h6k7XCoo7WEbMWhD1wIfyVmmKw7PedkcqxV1LEZQ2qfZAJskdHR4tHX5GCxJotCisnhQZ7Gpw1pHYjwmB2OnRvJOTemv2ig++JyMslmh+vXXp3/4+3/4/He9553fXrx4STtE5t4nhr13/uX3eXL3JMpFeGmMa0zi0lla/Szd2YMgRyMq8o1vDnL7XcP87UdewBe/9ggzM4JWSTab1QXSE/vt5Reu58tf+WO1cF4HzSjJZkSkuFRYvLSLf/jkn/LeX/sjdu0fQ9r6saaWafqiMtgm4iJoOtKxQ1x++Vr+/CO/ziUXrsPamHojQimdnSwdp0mndnPWhBCnKW29HZxx9hnc+aO7UUEbVuWgWSOZnsLvGgDn+Mrto7zm3B4p+gWufNFL1t15z0PEacrw8LAU/Ih3bNlMUOjhDz7wGYbu/SH5NeuI+lfg2jsQL48UE6iVISmh4ySj72cXEqcUaA9RAcrzsUEeFxZwXojzQyT0Wxq6TPqgfI3zQ5zno5SXJTtIq+Kc5sSt5gxjbMsNQeYMabKEdZd1bC2kBCuZZZpVGaHMtnbucDZLzuKcRc2yx0zGJHWtxPjZw4eIat2HWQF0ihYL1WtJMrIUjQwCb5XqVgeH1jg8MIISHxeE2FyATotIkmDjFBdHWdp3HIEx2NbfMRFEDaReQ0VVXHMUE41lKbNBF8GSpSy46GIuv/oyFrYnHNixm/t/cIerDO2TfHOwlswc+cOh6aHPAFXY+pxdX6vwud/+7d9+4ctfft2H16xZe9H8BfPmbvX2FNklQQm0l4q0l5brlSuWLwTe+vxLLnnrtdde/dC3vvGtvxGRLyql+OAHP6iezry+QsP2VLWv3uwt2NCdhnljqqmeNSJIm3XagogrLlpDagwimlkFoecF3L1vnEqU4OcqpN19fPTbx3j5ZQv58nsWsGZxH07gtR+6k2/tqKAHlsDoPs47v52OniJJnOL5Obr9TBJWcz6xMyiSTA7pvOxcPOdee7ZMv6cVQZuejLFCZYel01qfuVNfc1j8wHH3fbs5OqHxl/aRmATws0ZnZgw3fQwvrQopxI3m1wHhPxH+/L8CgRaLWJocPTYV/OjITHjGmgXK0ZRWsKzFaIVoAW2zw6aSkzY6InKyIDqXdcu0Iolcy55q9iQ7izO3aDEol1Gxrc0ufqaj9jDOoD1h17g0K3XX8D3da6xCpXF2MhKLxJmmyXkpNLJ4GEk0zgiFboXRhqQCTjSJm4WPbMtN0SOuGUKlWbq8ExUYqkmEtYZsuWXvJ1YexkSI8amPiWMorxjnNh27u22YI6sezz6v2LJli3v/mWf2v+Z1r9uWFT9rvvbjQf0LN95MOQ0JbZW4XMYag7aGJKpCswGexgsClNPYpo8XhOj8AmaSMu/4o/vRbhyRBqZRwadBMjzBRRcsT7/1jb/wurpCqrXGKVxfBO0FjE5OUuzM89rrX86Hb/hzdLGLJPUQ1cCh0S7GTIygk6r54O+/Xn3g939Bgpym2axhld/6ffZnOFEJFk1qhXojZeGKlfDDWzNo0lo8Y7C1Bq4RI/kcd+6cYt9Yk7MGclz9gqsZGh6ls6ObV7zsRbQX26lUKlx+zgrOPGs9E4PjdF95LqO1PEklxXkxxC6j+jcCTGxwtiUjQHA6ixSykmnznJ+HfAECH9EeIgFOK5zvIZ7QovzitM4Kh5JW8nu2uWREhKcNmk5uIErkGXtQRlpxTk6J1i1ZcRJpzSY1YjKYM1XpqWP47OHCWMRkrp6z/ebcUN9sNqlwrQI4q82zSlpdpM5ioySLCxI5RaaYLY4irU5Be1jfQJjgYpcJ/pMkM9k12YxSbJq9/1QhcYSLxmhvjFJIhxCvxJKLr8EsWIT1Hcd3HeT2H9/O+MFDdPtDdLmxuDJ1Yuv09NDfsWhRnmPH1LMxNW+//XbvyiuvTM8555ylf/Ynf/anZ55z9usH+vtaFzFKDZ4cHWmoA6N1tXO4qUZmmniiKJY0q3oKnDkvx9J5Oed51nYWfbn0vIvPX7dywxfO2rjpBW98wxt/fevWrbU5M3m4YjNs347rWPS8tH2Zs0Y7iZJMkqIVdqLBuSsV61b00mjUW8XC4VlLpaa4dV8MQYCtGrTvMThR4gf3j/ELL17Ox767hz+6aR8zsgRZtQqJp/GjEV54/pkoY0EZ6sbj5r3jdJXauHRBju6cRlyASVISYzCt9aA4vUTCcYqpnwHXQi4MML7CpSlpZFp7sW0xWtUpT//Wf2xrfBjHllvuOogrLoVCW3awEQdREypDtHkzruClOo5Mdbxcuwtw/JzNr/+vF8CxMYK1PYTD5cqxI+N57NJQTDMTvzqVCWSdtBhnmpNO+4g6CcVwEqLJzsGu1RUijtl/5RmHlJOUGpd1hNbNdoeZPvDJ0QiQdm2y+SD42cxDHCayaE/hiXJJ5EQCi7URfiHTWUXTDvE0aIMRhVMWz9fYGGq1hK6OgKWLizRcg0Y5xvO8TEjvTPaqHBgJQHskTWw8hgqH2ReNR59NwrBphMpzXdNZjd+Xt339E+ecs6kfSL/9wGHvbR+4iYYp4pWHiWtjiNLYRgM7OU7Q7rklS3ukXK4zeuw4FNrRpQ6MhTQaQcpllDdNbAwqqqLTOml5lIU94r70bx8JOjsD6s0o65I5dUhJLXhekcGjRxmdrljSauyaYzmVnw+xRvkKM1Fm3ZJ+PvZ3H5QXPv88MZGh2UwQFSBWYZ3hp2VpWmuyzx0hsY5yo0H/koVOhRjSyJNAMpJOHJNOz+DlQsqVSf79h0Oc9dYu1izu5f3/63cJkwaeL9hUMC5iuFqG8y8jPKfIeD5PIhHoOjptIHGKaRQhziOxgEmzuZptdfwyKxj30UphbYJNo6xMexpRDgkC8ANSUS3CjNda93KSWOBOEhROnZpnSV9ztcunLExOEQ/mYFZP6x8zoDMLlZU5ZLLs/socaNBZ6sTcU/7J7LuWA0mWjkrrnmv9PWuBTzqKPAO0bXWlGcTbwhuy+aJREKRZl6kzxra1rtWFWkQScD5eoYc2r8S7zr+C687vA9MgJeTA8Sm+9eMD/HD7Q+Qmd9Nhh5yuV6WalEds4HbCFR7HtkfPUvyklRaS/t4NH3jt217/xn/YsG79wOxjxypN9YOdZe/L9xzhvkNNpho28ySwfos4lyFMnfmIs1bn5RVn9epXn7+Qpd1N29mWc294/Rt+Yd7Chef/w5996JXXX3/9wdnxBHfcaJCtvs51bXZt88UlVs1qt7QS7MQUl7xgAb4vVGsGrTXWgac15brh8GSCDnrQlSo2qaNyHn9+2yg33XmQ7z9WhxUb8Ao5tI2IJ2HjvC42X7AUTyAo5fjb7w7ykSdyFBalrMuPs64v5LL5Pud3+azKK3IajLU0XZLNiCWT9XiYVjNhScVDrBAGjkSFPDoacbhZp9eFnLOwiHGNDG3D4Wzr8KQ0gs26TQsqCBkdqXHfYyNI3/ps9OOyuTONKhJPoMOG9bSvmw37ZHPqxHH+L3gh/2cUwKe96LENNAvTS0uVfWZicMIlylg/0SYjCp28H2XOzdNyjTjp2DNbEO3Jexc0tpXXBoKzcjKlxuCw0jLzbd0GtoWQWhxKFMZqdpVViOd0qrLWMtUpDofvBNv0SToM4UwormyQXosWh7WKRt0SBoKdDRa1WTpEs25RRrN4cRuFzoSxWhmbqqy7sTbD9VsmsZkA2dJoeJSPGsIjOStHzd+LJD/uKy0d279/f/RsEOisTdnHPvaxd11zzUteBUn60OER7y0f+ir1SCGVIUx9KkuWHh2imIvdr/zOq+TNr3sxy1b0US03+d73HuSPPvxxNzR6BN27WIxxSGwzTN4FWInRYnDNmL/6599n+bJ5VGuNjPrsTqVBS5YRmum0A5+accaa2ji2ssiZdrSCdHiYqzafyZc/8wH6+tpUM66jdAhWWqfGU8VvFn5x7hTgZ1VLE5c5AuNsQqNp2H9wmN7FC1iwpG/sxNHpfpUb0IkFZSKoTWAaJTAhN995kJeft5iNCzza22KSUKHiBjNJgSeqjvvLHYwuzFMZbOJVFH6Qz65FpYKbnkLVY5AEER+CIuTzWVfUWqdEMa7ZxNSbuMYMxBGSKkQDhRBb7EP1D6C7ilitcKiTtHKZC3+2DnryEySyuTfWHErsLJw9J5dwjpq5pd2TVnq9N+fnWs+hWodKTpGMZHbYRcZORs+aY2ePs0r9pDDupHe3PHOKRMsXBpFZlqluFV7BGg880/I+DVpM2BRrIW1apstNvvij/RyaGuOqixezedkAa+Z5XL52Hr987QYK2vGNb3+L27ff4Q7snSqUxyaXnXdeW7BjB43TbJyzxc9+/FP/8tFXvuKlfzC/vx+I0/G68f75Rwf513um2VvNQSNBNyNUZQavWkUajWzt+T5IQDkssL3SyfY9mk/eOcVvX9unfuHiBWCS9MrnPX9Tf/8/3tPd//e/vHXr1u9sueGGYJtI3JbruyDqWL3BdXQ7aqlyZLNYiSI8O8mVl5+Pw7bQ5eyCJjallA9YYw+x++Ej2Hnz0W0dyLyQ3fWY3dU83oZ85j8cV8ELcaNDXHFpju7eNqJqDScwenQM7pyhvqSHhzsLPDxQ5CvtAQvaNWd1B2wegIt7PFaVfHp8QQk0SImNboWGaIwzFLTP42Mpf/Kjo0R9XTw6rSnfuYd/eU3A61+wljRKUApSlZH6kjQmsh5W5fElIufD44/u4eBogndGPzb2wYsyCLY8TUCZUsl3OdtB0hy7DbBXXHGFt3379vS/cgGUZ3NWYMMWv6O2t9Bx3+GuRnSk3pWj73hlqT9q2lwP49IUj7xkXTBy8qD5tF/rHD+1M5iLXbvZ+ZGVk+377NeydaVQpEzEbRx3V3vSuQz8NINFGQZGMNWjzlZHZiDujOuNR1RKRVmeb5s4Y7QoX2UtvRE8BUhCc1qRDzQLV+YxQUy1HiOSw/MyyqlIJu3QVjIWqtOkTmgOmzR3vODJGLdOj5S/wQ2c2L91v/0p19tecMEFPVdeffWftBdzrhzF6j1/eyszw1P41QppvYanIZmY4KxVPe6fP/2HcsG5qwErsYko5tv55V+8hssvPYstb3mfefLAtOf1zMeaKJs/OAcuIh4/5K6+4iz7mlds1vVGhPZ0S5Jwal/J8vKybkgphZ/zHVqN29gsUG2pSiujXH7hOr767x+gvS2g3mygVR5rHM6Zn5g5nCqAp4bw1pya9IIjiiOmRuqURxturDwjcVR/zNryOkmnliF552xTMLVs4fh5Gik8tGuCcr3AlLGcvaYL6wr82+GIbxxtcmhvE8SiPB81M4EbHiOdnEKVJ1GNGmLqpKaBdR7iFaDUie5fiCuVsJMnsFOTqGYD14hwcS0zaUh1dpl8AX8CMz6EXjCAN7AI29aZEUpEMlu801Dsn2sW8+wzmtM+eM7vdK2C1GreOCW/eNrsRs2Zv7pZk2w5WXDdbMX7GfwZsudtEWlOvh4Nyma0d2XBM6dY9hjEgEsTXFsXhyYbHP7+Ab774CAvPHcp7331Wawu+Vxx7gCegQvX/pIMv/MN9r4HH+35zCc/8c5b/mPbl7TW9csvv3zuxnmy+H32c5/7p7e8+S3v9lpuAT88UPH+1zcOseOABttGfuowycgQdmoKG9UwNkWb1Fky1qzGEx36hB19sGwTe9qX8K6v1Lll5xH+9tULvYX52Gxcu3bgt3/3N7ZNVCeu27Z16y0iQlJY+WbbuREbthlbmfCy/U5jKtOsXaA5e8Mims34JPyZee8bQh3xe6/YCBN3cv/ho4wcyUHXEqR/IUFHJ6mkWO3A+JAIOpnkkjPXkKZVktQjLaf86jWrWCZ7uP3xQzy6L2Bsl8L09HC0fx5H53Xxw2GPhW0+a9sSzulxPL/LY1ObT3cx40PEUYxNI6LQ568+/RDf3l9i0dWdJMfqNIcq/PsjmuYyw5GplFhp+gPDhg44uzukN0ypxAkNp9HGcvudO7FeNyrXgU01In6WTtKs4DNJQEPlMFit7rzpppv0jTduU//ZXaD3/7HoCSeltXO+LFBYvHa+qo52+ju3qSbkJ7t7XycrX3h+fsHqlQ/3ncEPolvkzcHXMZncPeMlyWzhcplmpeX88jReXOsmftqsoYVfnyp8s7NCd5I0Y02LPWocxmQktrFKF0ebmxDpJBWN5HOgNiF+iOSborvGS0724hqjVecd6UgrUzg3hepLEC+zU9NOcE1LXIdil6JrYZ6ppElUTwmUJtAtmAyNSIbHOxzWalKjiMYw6kTe84a8w+Z4/f3AUbY+M3P5J+YXWkTSL37x31+/Yf36LiD93Pef9B68a5Bc05DUGmgdk06Mug1L+/nON/+CRYu7iBq1jAkqfubqaRusW7dAPvWpv/Be9epfYbwyDrkSJjWIzqNbway/8rZXiKcsTZeijJ9F8bj06Rtsq9kIwpB8W5sopZvgnKulzOsM7Of++X+prraAZpKipYAxacaYdfKcm/ns5zoL5wlQi2OOj5fZe2iUxCU06zUmh8dTrYuBtQI2G/CjY5yOEfEpNyyTdcOP99X42/sneN7ZEY3eTu49YsHzMneNSh03Mog9fhR38DA2KUNSxaZR5lCoDILvnCuLLY9jJsdQhQ5cs4aLK5BWnI4jUS7OgkudTyoKl6QOb0ZUPA2VKdLxOmrJCtS8PvDlpA/dqaL3sx30njahkdNcx1nyQcvJRcem5QTjsF5r9igKaen/nvaj6hSsKVae9blPFckWjPXMr885uWZs0dlYg9ZsUWd3v7SkIM46DOlJcpC4GL+g8EwHMxOGr/54ih3772VJqcim8+Zz6cYOrlycZ+n8DrX0uqvslZdfeOY//sN5n/jQDe9/3/bt2wdbczhp7RXp5z7/+U+94Y1veIdn0yQG7y9uOyR//L0RGmkRPTOCHN2NnZjAmggnkRMihEicspnXosvMvtNEOTPdFP1kBX9yAllzFl+9K2b/wcf5/G+cqdd11Mz69atzv/bu93zjobvuf8nRoUOPSvuS16uO1ZikcZL8ItqD8jSXPm8efZ0eMzM1tMquQ7ZraBJrOWtdP5/+o1fy1L4D3P3IIe7asZvHHn+AodiH0kKYt5igvY14pMxCPcRZKy+i2YhAB2hnmd8V8q7Xn8UbX7GGo1MVHnlijLufarBj30EOPBETF9s4ND/Pod5uftTdyadLTRYV4ap5mnP6A87qEhbkSvi+EI81UCcmGH44jx4YwL96E99TAd/9en0O/b6JFzdY25vysrPbeMemAku9lMFRw20PT0DfJqwotI2wxmBqFXRtkLZuS1dnt+h6zCP3P1hpzVCNiDAn3/P/WQGUlpmrZa7Ja2leX1gMSmHDqdXlo4NPhd4lZmj3mqTQuzJZecliteiMZfG8sy71iqtlWvURRwH3zezjjf1eFp2CZGO/WYiFTFiZmbbP6QJnn1IyONO1yC9i5TRZU6c2Aetci+yWMUEThIKDfbU2GraD0PdIUDirMH4p83EsdSLhKk/lNiP9leeJbkA6ikv2CdEd2PQRJPRIKpA2YrwOjRfC1GQ5E/96CgPEJK2UZ2l1uAqrs+iRZMTa9ITW3gnZH4+bt1dn6k/+LCedzZs3G0AtW7X+HUrEDZfr6h+/eCcq1qSNJugEopiSF5t//5cbZNHiPt2Iamidy2YtLWc1UYpypcr69fP53fe/2/3ub/2pKC/Ethx5rG3gh4EsWb5IrEsRdAuSzvwNTh48ELQVEgy+WPzUWOfcgjBs082qdTd+9D1q+fI+omYdlE9qZtln7mkw51xHilmgTwFKLMYqosRSq0dMlqscGBzn8MiMo1SSwwcfG06bM+1hoX9ebECCRJyXzZNoNpDQUG86PrX9BM3AJ8kX+dHeBE7MoArt0EhRUYQ5uA+O74PKFLoyCa6JtdO4mhVMJiFReRGRAEE7XFVUPcG6OiotY1Irpl4D03Aok2C8TC9R1Epbg00rqLiGOI3VeVSgce3tqJyPaIfTumV/ffpCOPcwKK3rzzOCRpVpBUSoTNhOHKMajcyNpdHERRHESTbPKgRIqQ1b6oR8DoeHshYthkR5c+aQzxyqt8IUnD3l0qRUS6JBy9TbIi4jwJzyDJstfqeKoxN5epEUlx0UhUwo73skhXbS3gG0DrEq5FAac6jm2H5PxMfvPcx5fZbrz+/h9RcuUH3dJfu7v/OrW3oXzL/gU5/4xK9df/313/X9LNrpn/7pn/789W94wzvEuKQp4v/21w/yT7eNo1SAHnwSN3QI15whNQ2CzKZRkvo0NMp1SMt4orF5z6jONtobntBGmlr8g4+SxjG5FWfy6Alhy98/zrd+a4NeRGSvuup5hQ9++IOf+/XfuuEhr3NFV9rR5ohiUWmWvqBdE1Ov8MLLz8p8UK3NXH9OguOZqXhqE7zQcfaZyzlz02Le+MoKhw+M89ATx7n/qRM8fuQIR/YFdJgq7/6FC5jXW8S5FK0zxyktQmoUhTDHmj7N2qu7eNXmhKGJGk/uneb+p07wwMFRdu0/TFPlGOvqYqyri0e6cnS2KZZ25HjRfOHiVT5ceA5qOaiFnURRAI0IlcRZZmodJG6CMSRJjqcqhqcGa/zHvoivv6KP4T072XO8jlrTia4bjK3inIczMamz5ObN58yzF1No1li0rO+LYxPjdx3YNfi9wf0P3rRt27bktAe9Z3Hd2bJliwBs27bBPZcU5qcVwOyotmULmQ4jq8ClUqlPt+UWI8XNqGCLs4lxYf3Ek4vWllzn/DX+kgt6VO+6zrj7DBKvF1tvEjeNIakqMVU5NLaUif6QInU8pzDOoV2WpycyC3XJM2WaJ0kumfyp9aiTFmk/OYI8NZuYJcCAcZZYPJ6Y6QBrMcIpIa4OkCCHBCXwA4zvQVunJRcIQUOYOht/YiDTtM0MYgVyHR4mNNTqhnzgZ2YYNsV6Ahq0jVsCbofzNHGqicdS4x0NtTqh767sm34zEYfZQMDOny7YFRHzvg9+8OKVK1aeBdgf/Hif2vPk/4+x84626yqv/fzWWrucfnvRVe/FXZbl3htgqrEpppjQQ14CCSmPEEwNaSQhjxYgdBJi02wcA8GAe6+ybPV+ezt917XW9/7Y517JxpBoDI2hIVuW7z17rzK/OX9zGkqFSDmCq1wkk8f4r/76PeL0M9eLIEwgpQ9t0gWH0aKBQQmFIA3wildeTj+57de4+9cPQfWPwKQRlEyRRDGmZucgaA2sjUHy+MbF/PzcGkmCIwicpmBrW3GrgVPP2EA3vOkypHEMQQ5SY05YsMXzPl9+gY2C2EIbC2Msmtpivh5jYqKO0ckqJmttdotlmpw5hvtvv/WwkF1rtFCCKWUhQOwQIBWEkYB0gN4yZtxuUKEEUfEBmc05tA6grAGmJsFHDwAzE2AbAyqAnUs0rImGhyeSJT1Brh3KcP/RstBRX0l0kaSkD44YhaEmkgBWmdb0NZceLV56Vugv66vpuaMQT+zunvvOw8Oq0Rrolbl8ZhQIp0GzEqwMxMgKmN6uzm3suOmLQIsqB/MLvjPPkx7peN7OWrDKYkXUDoD5KkSzCWq3YJsNsE5goxBIk+zmJyiLapT6QUMViIFhmFwXUgiQscc3vkUIQWc+yVlPBXNm8FkM7PMJJhvYTr1O5h+kE3b036CQLFpYO0UN5GRfpis7m70G5QhsDIRNQTkH1nNAAjCxxKOzKR79wRTu3Bvib64ZFptGKuYP3vGWlWdvPfX2j3/y01+7/Yf/+e83/N77rn3961/3XkeSboCcD96+D1+5uw5JHnBwB0x1Note2JQdqymp1jTM/KGzTpv0rj7XJNvWse0uzTtjLVc99Kjf+PIPh5y2HVxCOR9MdWA6QpLLw92wGbtnDN7/H/txy7tOEbrd5BtufMvKJ/fWV37p5xFLt0AIwgxAIAHdaqCvZLDt5KUIwxgLF+8FNUt0olXUIfIYm2Viy8UunHxaAZtPWYbXxikmpurYtWsKfb1d2H7KMpDQEEJl1B2ILB8tsiYObTwYYyEYWNZXwdr+El5y3jBmqsD+w1U8tmsMDz03i537xjBtHNTyFdT8Hjzt5OCscmGXdMMMF4EWY6UfIr8kjwMtgTjMVheLNOPEIwJZA48JzzyV4gZ3HBseP4A0ApRMMsxkbxn+2n50LxGojy5BLdHY7aW0fjDA6VvOWdGPYMXs3NgNh/Zd+ZEnHnvoPx598JefuOmmm/hjH/sY33TTTXTXXXeJiy+++HmP03PPPce33HKLueWWWxZ/77rrbpa33PLbIQUvtgGKiy66SHQ0dINbbkE+3z+U66m8hoTYLohXgMVmY7QVqU50ob+UnrT1PGfVBYh7NiNxe2GjlDkMLDVqZLUjYK3MLLIW+1ur8Fy4DGcVd8PYrOZIMCAtL0qhJ7wXmRxywuWIOWNgLDwc6LjWFje8zm0va/DOJFA2gIYAGWDOeniqPpKhl4zOaPMyl3WYuQVY388Cza4HqaRgy6Bpgq4a2DbBTgJEDGeAoIUGWwFBBG0ZwggwKxi2IJt1CioSECwQRoyoAeNM5qQ3m28n0/xBxMFhABLPIfmfjjULp5rtZ5x5+UBvBQDsT371rOAggXXnIQQhrbaw5aQR/b73vNZJdAQhFbROF3vejnP/svXTlS66CoR3veta+9D992gdVF04ZQipgNRiYmxuEaZx4nzuhXYnIoLjOrAER0oFE821XveqswvFnKJmFEBZ93eOjCwyqzQDMFojTTXCWGC2GmD34TEcGZ1ibV1S+S6wV6Dxw7uDH333688Gs7Wi9AZGbEYPIlI+LCSEcjPyPAhwFSjnglyZmZCQmfCEsRAzU9AHdwHVCQgdQ3KEZMYEr7js/sk/efN0ZcsmUap4ZSeKImf//jT+wi2l8a/cusZHKd+fKod10+czVu47/OVP7ahs3VwqwF1JwHIFTODtYXXwA88m0e//w+zBXzy6dkR25z1rCbKRZIgz6QO+lzE8F2Y/oBO+z/w7Z2u86I7NgArCJLCzs5BzNTjVKnRtFmmrDgSt7GZG2Q3PCgFLGaAPQR1oeDDT4xCrT4Et90LAwoisjX5xY0Inp+tkm5rQFjYOO8zRDOINKQE/B/JyIMjF/sbfbhV4McO9gLAMSiLYdhvUbABRAMRBdriCgM3lIYolOJVByN5u6IFu/HwywdPfreNrr9byJeuKdtvpp4pP/fWnfi9O8Xtvffs70NXVbZtpqj7001F85RGGUj3g/U+DpseApAWyLSA1lNbmaldftnfy4+9p5U9bVx92Kv0O5ObsgNx8AtdfPoFrr2xNXvve6NHpaOXp7HVJ0hHZmYOw5SG4K4Zxx44UX7jzMD541Uoyhvidb38jf/uxW0XQzm5LYAthATM3j7O3+Fg+WEK7FUF0bjhCCEgpIJ8nK1Nm6lv4bto82BjknBSVnIs1y7qRkANmtThCesH5YnGurpSEUgoMIDWATQN0lRKcfVovzjptGDcEjCNj83hy5zjufPgAHpmpwp56CaJBD+AC5JzBUA/j8mV51IXFlJWII14EV8ByBo6IDCKO4Uc+Hn5Y4clwAGL5WnAKoOTAKZQghQJBIL9kNVoE3Fur494D8ygnAa8pF+0pxSGcefrA+v7Bvps0TP7jH//4n53QVWrvvvvuF3uQllx69cu2+7l8+Ms7fr7vlluuP8DM4vrrr6dbbrnlN0AF6oVXx1tuucXcnWUvioUVK84sqvx1jnReTlIsQ5QgTlIEuYLRS9ZLu3QbMHQGqHedTbVgDpokak1CpoRIKwQgkky3NNk3p2Ed7J7fjLOKexATQcDAcmbXzmSAjsRJJ9rBn++Os53TKLE9vtEt3PKMzcDWBjAmw5fBMGKd1Y6NpoIPtJfAVYK0VIDyss1P+WA3a+0m1wFpA663YZsh0KwCehaMAii3ARBjgAIYMqPHECNNbfbyLhSdqiwTk5KE1oR4zlhn1pNe1WnbWf0Pzen6ngVe6v/e08Dy13fdew4ATMy36cldo4CrwbEPITV0OM9vvv5Gkc87CKLMwrxwC14op17MS3aIRZIjnHPOKeLlr7wi/f63byU1nHesYUAbHh2dOj7c/Z1SQWduIwE2tuj5Tv2yi89yrLWesQoS3JFgTwQdnDh3yoqOW602ao0WJuZa2HesxoeOVW0z0DKfz5HlEEd3PpPueOjeqUM7H3scqU6F6rrISh+wzII6bZmkIJwcWFB2ODEKnFqwF2cGH5OChQsZayTHRiFrNVgdAmgjmRmPPvmeA+mf/UF7teOfCYMVsKlCEc+q07Y8q768oVW48vR9h2/8eDsN2l3DpyyZ2nP7F6ZWDK8/P58GL4G1EZDuA4USFBpeu+aA//1PFQeveXe0/94jmzeqAgkikA6qQHUO1DUI9h3YojpuFHlRT9mCM9Mel0GIwbZTkhvGsHMzEPU5mMkxJHNTQNoAmYQlEiJjkWoLqzVADoRjyBESsQ6gTDcQxzAxwVl5EnRvCXA7gOyFSAQEJERWtFufAarzoGoVHEYQOnNyMgjWy0OUKkDvEGRXD0zeh5YvfHqeb6BZpIZYho3bEK0mqNEE6nXYoAEETSCJAd3uzJ8LYFGAqeRBS4bBw6vg9vdh0gBv/M9pfOblLN52ksRJa5ab737na9JzHAOO5fcem8Hn746gnCLo2C6YxjEgDSFNABO14bVH5//xL46Zd75Rr3e6VgidnIUk6We2KRA/BROmEHHC550SDH3/E6Ph5X/hTmknP8LGYwQ1Mkf2A04dsrgEf33bKC4+ZRBbBxw6eV0/3fDq7fjX/56F4/kwmqGcFCZK8NJz18F1FEKh4DicRQcoCw8IBbiiowz8RvuSgdYC1rqwNoeYU6jUghLO+K/CgkjCPq//F89zWxMYjrJQMgdjczDWwGqNvMfYtLoLW09dguVnbcPTt9VRkzmoVghIB9oJQb6DZxseJlODRsRAYMCxARIDji0oBZAyZJtg7BwoAjC0DM5JfdBHm5Ccg52fQbtt0d4tgdwMZDkHp7sL1FNAi9r0ZFvLJx+q47HhwLxj20Y+75zZ9z/54F1fJKJDS5duPGnD2rUbKv19w6FulyUr8qSa2HfgGF12+Xl/u3Xrab1SKVx+wUXhT39x74eJ6B8X1JIXggo6G+BNAviYveWWW1BZsfm0rv7BNwhrXic5WkFsEMcW7dSkcc9qTtdsd8SKrcJWNrKmMihJYdpakE0gWMG4TkaYiJMFvTLrxLMKwsYwSQmPtJfi9caBhYUSBMcKWM7Aw6LDFFxops6kF+qckE4wXnToE9ktjxdQh8cBF1ZkmRQLxFYi0gIuUvx47yA1Iw9Oyc2aiL0yRL4bouDD+rmMmNJswzZbQBBkcxNbB4VtcBIAxQLg5WBNDJNk4GJrF8xtFo5AlgFLARsyQhPDtKXNzReEmJH3mrnoX9IG3Y+L0MTd/7vN7+abb5ZSSm2txb33PbwJAPYenRLjY9UsNyQY1jCkX6JLLtwmNTPYZEH1xRP8ggV+wV3ZWYykVMi5Eq985UtzP7n1ZyaNGtl8TEianJr+DcnyhZGFhRuJyUwWqU2DZMWKzf2r1y3ztAEcLEhlsnNj4eeFvpkZcarRarYwOtPEE88cw75j86Yea0lWySCY4qMPPts88OQTrerEsSYAh1ThHHJUnxB5YUFg6ZJwC9Ayhcp1w8pC9nc6PtjPgV3ZYRYSLDoOxLkWqB6CwyY7aUzp+Hjwp297+uhfvj/cqMV1nNB5oOROQmsXouQgRBoDFvzaa+orp8acY3/0j+GzX/767JLhVevy7eRq9vQx4vhRqGgXRBLACE1hE1wuh4UvfrDadfYftA8k1l+fwjB0g2CbEEEEPcuQMg/jLxTSqsWCUHTiMoIzE4slefzabTJ/DkUJaHoMIqzDHDkMW5sA2TakNdBhSLoZpBBGloutoK/clErL8NBMXsSyUBTdrEwsmIUk1IF0D0GtWg07MAjjy05ukSHTEGK+Cq5NgltzQC0At5pgHcGAs1A3CMwKesYDTY6C+4ZAS9dCdHXB+gtRDX6+6N1JSAvDoNk60JgFBzXY2hxsow4Rh7AcgBBlc0VBACKGbQJzedKNKXC1BV6xHnKgCzW/jPfcMgFjGe88vUtWfJ8VaTnaJPzzfdWswHdsBnbyELg9A2FCRhRRhcaP/fAr+9SlF9KwNi+D0ZcyCUMi2UMUPwWOHgJ4EsJRFNVDPvcUXnXZplr9jl0tq3JC2LgK2x6HnRIQ+SFUGxJ/c9th/Oe7NwI6xZ+/bhN+/MgDmGkmEK6PZDqAk8zgnG0XQQNwPTdTlRRBygyUaKzFxFwLB6YiTNcisNGQiuDnHSztK2CwJ4/uvAcXEr5VYIoR+xZaAyY20J2mnIWxYiYxP9/Ckf2+hRCZ5OopB9pKEDEOVzU++oOjmK/3QxRCmJwLdjQYHuYahMDTiFQ2EpHGZC0jzFnhgEkhtAYbC5MQyDY5PRqS7O8GFxTE3BHoyaehcgImPwiRGwSKPdBzDXAhB1XwoNoN6FTjuf2JfLq/yRecexG9l8XtbrEYDw72nL68rx/FrlLWEiYkhCvRrLXQW+nFo2OBOTxexctOPTM3snLTZ87adsbFdz3+2Nfv/69bbvvYxz5mbrrppsVNUC1sfr3LNpw5NNDzrrzrvEX4Ja+VNhA2PK6Jio3WnURm/XmOHVwDkiNZOakmUGoh2AIKICuzE2mH0kLKyaAZgjPOJjGsdSFtCw/NrMCx4WEszx+BaeeQ5AxYAY4FtKDOTJ0X802LKLQFCc528hM2m/cv/mR0ZlQd52cKxCk4NkxdSPGriQp+dPgMeJUiYqcIypczQr/nwqYpOAhBkQEnSVbMazWs6Zw+oxakacGGAbNh2EQTfGSsRZn1hkJlZjGbAiYxQCghtGu707LgWfvA9LPz1wGYAgDc/b+79Z1AlSh9/vOf/8Dy5UtHrAXPzTUoakdQjgEhhU1DDPaXsGz5IDTSLH+1UH3xO63qAhIGp5y2UZx78fb2r2+/l5xCSWklcPjoGBsLeuGt7TdRZZ0NkYQE4tbmLWuTru58JQljJjoRY3Lccn/cyQvUGzF27hnDrXfvQIAuFBxHBjMHxsf2Pnf/jofuk1EQrIMorhJudx9n7DGwkNAQgJOHyA/AqBxEqQeUL3byZi6km8vqVjrkGmiTUX3adZipCaBdB+kINopx8qqpIx96b21NwqdBmH6yzc/ADfZC2ASSYlhyYRxNtg1ce83MkmbU8s460/ZYPo2d9oOE2u0QMsro/sIHYKAkUxIa3rIiHnnXRbvG/vHXWyIlPd/yHHhegZ08BC0Hii6Ey2BlwEZDmcxcYiU6JbTyuPGLF8RsCaE1qDYKqh2DHh8F1WtwOIVJI+haVQ8Mzc/c8Kopc+lZzYH1G1pOJZcqaYUzOlpof/Y/Bme+8d9LizJvSyABowiwDsxRAeV7mSnMFRCtKnjqKLhWBddasGETHAYgE7MQliTZTtoPMFYy2CcEEcxkmN0YR1YBw11gx4UQWaGc7RihYBlOGsPOT0I12+BGHen8NCioQyVtJpESrIVNm1mzvfaglEcyHyFFBBE7MOMHswOasx5ysBe6Zwn+6Bct5HMOrl9bJCKDL91XxXOzeXhsoGsTsFENhBgqjShtH6vd8tkn/EsvyPVH9j2M4qkk2k+RrP8UxhwGiQACZUj0glCHUSkEGb7hgtHWzx7qIS7YstVdTEiIW1WIqA7Vuxw/eWYG9x+s4exVZazoB647s4TP3d6CbWmcsVTjUzddjfVr+5FGMXK+C0Ci0Yxx945j+OWTR/H0gVkcmo4w1SogigmwzYzuIwS68j6WVIDNywu46IwVuOLMJVg/5MGHh5ABkc+oSFEYQRsLKcTzboIvcFZ0RkkEaxnaaBRyCt97eBoHxlz4oooIlQxDmCpAK8QsYD2GFgaWdUYCApjJsVCKSRIRazJhKESrCkpmCSaAbeZBA6uhTQtuFIObh0yX9+OJhj1rKZdWQjk52EI/uNIPqxPIdgNp7RAOHC3Ty85bzte+4urNxXwRKSzmuWimtMNNFnDSBIOOwtqNHrXaofjX7z4kD81GaNYC/uQN5/G201a9/LwLz3r5fdu27vjhD25528c+9rEnFiqWFPAxu3rdKa/vHVz6bc93VKNdw1wC3ezfKszpW4Xu3yKpOARr80hNAtI1MLIPgpSBzhLhnbJFBpPMKPHSgFzR6VSTWSRBJ1CuxnxjOb66byv+/NQJlFSMRBNYELNkEsSQzNlQlY5LZgufX0aO6LA6O03vbABtOtVnGfyerbGkyYFvNc01FX402sVf3XsSaj2nkhpYD1HMA8IBEgEbtAEdZgBe1p1EvQanKUScQCR1CN0GRAhONUmWEEawIQDQ5LiZzdtawMYEJBIUK1Ao4UWSEIkH4gn+CIApXAeJW2B/i+OTbrrpJnruuecIAC6//HJx/fXXp+9///uvvOGGGz535plnrosTzUKASrkckDBYhICJAB0AXITRDJMKEEsw9G+10Z/4l3tkUam4uOY1V7l3//TX8yYJBqAUpmZrNohSIYnohbMpOqGhI6NaSHiOJwHT7h8oQ4LB1vJvgAFfwAwkAXSXfZy8eQ0fnGnhjl/eWz82s//jD9329VuB7reQ6HuN8rpXWiGL1ioI4YGVAksJocpgrwzr5EHFCqjUAy0UoDLOqYHKcGFKAEpksrkloF4Dzc4ArTokRZQ2o8Yb3nm03dXluFG8nol/Rmg9AsMFWCKA/eN8FQZ6cy35xzfOD+hmL1N6kETrHhACCKs6TV5xJ+phwKTAToDXn2XkP/1s7ign/nqWeQs9JbjeBVHug52fh0ibsHEEtEOotoZNU5ArIfIFUFc3uFyC9fKd258FSYINpuDUJ2BnZsGtOgSa0K0GRFTXH3jDWPwX7z1cGVjWlQedDOgBwEpEdh9Oq+yvfP3DY5XhcrDr099Jlnm93UWrLQspycY5pFMTkJVVoOo4aPwoqDqDdG4GCBIAhiUFZGJNppXCaG1BSCGgUMhJmYtgrQOZ1mB1BDYCHjGS/grYoSxQ3jkPCSFg5+bgNMZg5ueRzjVAaQCHI2gdkm7ULXQaLO+Zp1JfWmAK2zN1tzEzNeyi6PaSl2cYQzyVHUKZNsF1HYTUjQ/9eBIX/4GP7ryDm59pZ/nGsRnY6cNAUocQMZK5ufDD79hVveJiuypM3shu12lkmreD67eCbRUOlcDWARDCUgSwhhBMrA3O2ZJ0D3aN75qIKluFZ7P1o21h6zNQlSFEscV3H53ChWv6EHCE6y5cis999Xa87dqN+Ls/24q+nAerAeH72H1oFt/+xW7c+tBBPDumAZPLzAsmBnEdIgk7BcbZSbvqF1Cd8fHscwlu+WkNfb078NIzluD1r1yLc0/vR0E4SGNGuZRHECVI4rjj2MXzVKAT3+lMbLNwpMB43eL2h+chUhepcDIJWriAsoDO+ktjdkCeZEfmrW22QJNVyc1AImyCmhNAbRSyOQpE09rGtTY4KpLqkzK4EmQdpDlG75qr5baVxSV3zZ8JU9qI9P4fg/f/HChUAO4DpICfj/Gac8/H2sEyjbUS+5NdAR6YDMVRaDlnK9DSAcUxCrqJkRzh0tUVdBd7cGh6AnsPTdEPHzlAB9wl5qzBYbzxTW8+pbuv986vfOmz537/+7fsvummm4QaWL58df+SJf/WXcip3XWdjq18icKasxT3boJ1crDaZi4prkGwyjiDonMStXIRIbGAVCIhMnmGM4o8CQ+ctdeCpAUrwCUfPxy7ALK+n9+48Tms7AUJ4ZPkCBoEIgWHdXaSkAISYGFtJ9m+AKzuFFx3Zn3WEIwBbMpIY6J6BEzPJ2bXBDVvHl3nPkxX+rzqDHK6u6FdP5M6oySD8OqMBiN0ArCGtSmQxhBJCC+JUYpaUEnKs3KOrDc1Z/1Yex4GpSIISGi2kAHBcPa1kwGKuRJ3uUWKamHb1vDDnnKleeVbLs11b+zWVVRxwkCWbr75ZnHddddBSmk6ZZvIbLy3mL/+679+3Rvf8Lrvrli5WgLQymX1yHOj+M9fHAXlugGkYG5BComZqUk8s2cMZ/dUwDaBOlH+YHr+NnSCc48lII3G9q1neGtP3uTt3XnIUqFHBEFrPgpaPcVSUVr9omypjilJwHU4I8WguGJ+vjmlmWDZ0oK9n37D1HGcM+87hKEuD++9/gKsKJrgj97z7X1A1/lubvmHU2OkgULWWC6zQ4tXBOWLgChmjQylLlCpF9bJg5UPciqAU4KAAEdBFlDvyOkWADVbQBICaQskAiCpumu6zAbWLVCygyg9CodLgIhgeQHnpSFsZvGXSoMtsY7qJNJfgDiGhZe1GiDJyCc2czgLpISU0Cu40OfMV2fNAKAUQalMaWhUwY1ZGEpBaQwKY9iYYdlAwEJIB0muCBTLwNIRiMGl4JwH1iFEtQY7MQUzX4UwTZiohi41HX7773e711zdLIDWI9KvZpZLybU1ULQDbqIRhZolT9FfvCrc8PNf0MyTLRRdJShuz0NxDnZOQRwyMFwHZqvAfB1sZiEBmNiQqddbuWK7een5VXHG+ma5nI9nD476XQ893R8/ub9QRHnIJ19DBYzU5pBwAqE2w3TnICXDKJkt6PUa0KrCzlaRVqdAaQKh24inZxLfbxx9x8umxWtfdmTw5NVtp+gTpOBcs9mPux8Yr77/C8unx1orB0S+zjYypI8ZEAmkxkAWCjjKGp++vwYlPRyYJ8jUQtea4LAOYWM2JqH+wemp978OQ6mzEaKwibh+G2j+VjhIoFUZhnS21lC7swEJCCuQWMFLlyJ/1SkNfOP+ViwHKp7WERgKPD8NUZ6A9HK4/ZFZHLoqxtKSh7VLCTf/7XZce/U66CRzZc9HTfzD957BV/7rEOabWS2QjC1UMAYEbeg0BNsQJHQHm6kycqQQJEQO5BeAnIvaTA7fuq2Bb/36MF5yQRc+8vazcfaaPiQ6hFvMQbgu4nYDbDKo/2LO8wRFmplgjUTB1dg52cCBacBJ20jcLlDaBpGFpQJIUVY8HsRWTNUFHT0mMXkQZv5QKNO5HYJrvxbNccvtqXJizApr9RE4zjCKS1/BDoSpzpERBhTPY0X3Qcx7p4n0lJdCwAee+DVOXStx/WvPwi8f3oe4EeHal1+OV125HvftS/H3d8yIHfU84C8DfAXhuHAdidQpoCVT7GnE2PN4gEqagzQBbNRELd+Pn811ye88PoV3bY70deee3d2aH//Zxz4/c9ZHP/rRGdXfO3Rjd1clf6xBZmzdqx33wmsRkwXHMTgKICzDSgLD65wYFtBIGTGeOeMJPv9m0ckpWZEtUNKCHQM2Hmyah3DbYH87/n3Mx69/+gt7dt/DyXkrx5INg1Ra0W1Fj+sg8QUJZkjLncJqAcEWbBlaA9oI6JSQphZhZBEGhFbb2skqwuem/OjhyUGxo74cY4XTGEtP8WT/EsGUg0k0qJ2CF0C8ncEhpRrGxIDNboIiStCVROgKI4Cq8KIYayjkdbq7fjgZePKe3OgaHekBz3OXyBxgYWAg4JsCKsUudOUriGfbaDTDpDVWL4Mn00P/tC888QZkrZVSSnNCl1jhoosuWjc8PLx8amqqde6552664S1v/dzIyBIA1jy4d1L93TcfxU/v3o+4FYPyBqadFbIKx0Gqq/jpnQ/waWdsJEMpCnBAgiDoN3mSJ/6GJYInBAZ6unDRZZdU9j7+NFS5gvlaldvtVtzVVcnrNO2gu/jFRBRIaSEkMwm3sePpZ8bGxudP7+kpCqMz1NnvFGOzzZl0q8XXvvziJb09t9z8zhvf+q0D++d2yULXJoOcgPCIlYDIlSH9CljlYJUHUagAha4MUybcTAL1cxBCg8JWJnNGIdikGXptQRKNGwCHbLQk6UTB8ECiKNZAOAqWdRC1ILSDTi1I1tQNyvrsDMCWyRECjASGBASnGVAYnXosNgALSGOBdgo0RG7Iaxya0dEa4WnXkgeyMez8OBQRrA7AJoS1cUciBBsmkPCIbTtbhOI2bDuEXLEM1qTZ/KvWgNIBKEngt5rxDz67W1x61ZwM9bVwCq+Gn+wkW/sudDwO2KkMFsApQUuUu2Pxx68I8m/6imiZHhSlTaHjBsj3wHULjgNwYwJkHLjwkVQnTKUYVv/0vYfNW19zILd0yKvAZQI5y2AMgtqY+6/f7Eo//OW5+RCbe5RMQek0uGqBsS5I5QPWgyjksvVlZhp2dhp2pgphAijbRFKfM294zdHgU+8c61m1wumB6gWbk2BsAVLMC7drtPDaN9cLy5cdCK/442Q0CFYuhecw2TqZiaOA3w2nT4ELLj7/YBsQMYT0IdotGF0HIYQQhuxsYl961Zzb093KBZFiV46Rrd8FQU1YyoOgYUySEVVZQHaMd2ALkoadIuiaC1LvG7+en4AtrIT2mIUihHOwYQMi34fxqsEv90zhHduXoasocd1LtiCOLDxf4baH9+FP/+1p7B1rA8bCD+tIW22YNIAxMUsbgIizwkC2cLQGKAIIZLWCQA1IiU27Qlb5kPkuSAzgp/c18MCeO/HRG0/B/3n5Zrg2RSoFVKEbrVYLRpus73RhxLRgc7MZ1DqVCk9PtqFDA8DvdF86ICJWUZNRnQfPHSWaOiBsdX9bt+Z/Dp760fLCw788ehQTALoB9AKb3w3iNF9ujJaGCl0oVSx7SxC3JjhuhIhCwkzbp7FgOYxbQG7PDqSN53D+a07G5RefgpO3rsBg70rkK0vwuZ9P4Wu/nETVG4LoKWSz74IHKuaQ5LLoDFIDWfBhbQktHoaXr2B0732441kPk4YRN4r4zM1PKrqqK73ikqtWvOXI6EeI6A9ULle8iA3zXOCQ9tZBH67CKRnISglcLMESQwkBpBap1tBpCtYCVlMHcovjQzjRsXx1aoWsFdnwTtLCMAOwCjbnQsQWTu5cmhhZK380fr17685Dac/Tz0Xr8rtphT+uNhbmplyJnrKTcjlnYschISzJVDOFKYlWTE6UKtTarj3aKooj6XA8HvXHc0lf3Cws9zG4qoRThpXMFSC0hAkj2LAOJBqkOUPwwGa3VW1ASQi2LQjdRqkdwYtCSEQwcYxyYrBWCDpPdOEqVVxdUCOrJ1S7caeYnvynYMdYVSWDft5Tg/39cHwfzXqEMGzRisEV2H7SuaW1S9e+t6fSd2Ffb/d942Njew4e2rfnK1/8yl4iqgPIf+yTH7virK3bb+jt7T2nWCotrZTLiKIQuUIRAz0lWB3w3/9wh/z41x9GONsApRpunMKkQZbR67SwiUIF3/r6d+ILzz/DPe30LcL1AdddGH4/P8Jw4gxPMEFQRq+58KJz8O9f/fp4GNcHEvJMnHJCRPlO+QPx8/BaJ8KqAUfmUKoUdu/b/9ATjz7x7BmXX3nB0lRH7Ckixov/uRPT/0K5VGtGdvs5J+W+/b3vXn/9a9784NhMul4WKtLAAeULYL8MzS6EWwEVK7CeByg/I194RQjhIw2q4DQAxyGo2QYHLZAJIRYOaSQBoQHBRMbCGvIabRcwCYSehkACNgRzgkdpgW5PlqFrAhwpqJHs6xYdhi0fDzN0eK8CZFykDcNpm9XSfLjjmZnG6eRXhil1mJw2sU7ZsCFBMUyigRAAIkD6pFwJISOYNMNRybgBHczBBDXIngHoZh2UtEGORlqN+IPv2Z9eevVUsdV6E3J95yAO7gDP3QUnnYMrFAw5WeCeIwACVjAuOWncW+YtjY6lAi7KMNQGRT40p6A4yig3himptusvu2D/zOc/fKB/xcZCH9KrYNKViMEgO8tOdIhc2uN94D01r8A88e4vlts8tLQA3QC0Bc+4EH4BPNAHKQmmXgWqs0CzCrJtODZGXJ0LPvXuZ/SH/nC2C+pkGHMlmFaA3BjCHIONdiEJJmFmW3zWpnru/742l/+//6+YqqWxQ3oQ3J4Dz48i6cqDdS9klIf0LFITwgQ1oD0LTjUgYiDg+NLNDZ9kFQimQfwrkJnI8GxswDrJQBuUrRUd4SnrgmQi6Dw2DCfLKk443kwiSDeCThXIKpBudxy7Odz2eB1vOnsY0IQojOH7Cp/87tP4yM17wCaF056EqYbQcbapCY7BnJAOLRBGFmlowVobqzVIA7aQgl3P5GUeZY8c1QalEZt6SLY1D69rEI32KnzgC7twz44Z/MN7zsSqXgXNBoVSAe1GHUanEFK+CL0nQiIqODxngTTK3Pkmho0BtOqE+YNkakeB5m74rdH/KLr7//Ylynnn4aT7VffMbUrX9073XXWxWXHumfkllcL4WcuXtJxSt7i4UKqKiGdUrJ8knSYIa4InZhSenV6Ou8IUexs+9u7dacChPvXMM7xGowEKGZXlPn5yz1585ttHgMG1GXA+jEE93UAlB10QKLsGa4oetFA42BZoNxkmFEi612N+eQFTv3gKMl8EqRJ4qoo77p2RF23ZbkeGBs8BAEVEvmWQ0Ck7czUkSQmJowGvCXI8COVD5hRknuHlPUgvlav/eAAA+BlJREFUB1sELNvMaBIbIM7qgxYNRsRZdEF06mI6GQVhDGCz9mr2FDRLCC5BLFktjTm5PBu+FLP1Bh5szFoEE3m0JwWSZgvglmASQsAlkLBCKANHADkHxRFgoFeh2OUgVyrClxBOHkKH4LAO22qzbUZECUPYFJZtx0ijM7vogmM1jQBuwQ/qyLeq8NImBqMESw1hhXRxluNgS5ePwR5izy1hZbG7fE5ubfmqaLn+ZON+O1MswyWF/dOTuOjMy3Hj1W/AGZtOR29Pv+MJtx/AxQAuTtIE01MzuPFt75nate/Ze5cNj5y0beu2jd3l0vN9zsf3BvGRbz9Af/3lRyGCNpz2PEySZHRMY8DBPNi0AZmD57ioz0fuTR/5dPWfP/f3lRXDvbKnt0CKj9N2XixfRrzAGLG8bs0KOv2cM+v3/fxO1tQzPDff0OvXUFYgSvxb8lsLCCcS0lENwMv/y+f+9fDaTZuW9JZz8ISi407uE7oJOoaO45siQ0oS7XaDTz9jY/cXvvz/zr/2Ne+K2aQuuZlRQDhdMLkybL4E8kog6YCUArsq6+JrRJDtKmzcgAmakLrJEjEZnZXGCkVQkEjIwArDLAxZXcD+ff48tjkFo0MW7BBR1m6+8J3LxpkaQjPScR9H9qTYeA2BvQ7O74SmbQvO9AANUAjU58BBLKjg2imk7SmOW0OwLtipQjhEpiFgW+3Y72qlfX0JlyppqdHUjbGJcoy0WEap4CmnDZ04QOqAJwQ4ZSBoQ7LmNLW0ZGhi+g9fMtETN3NwCj1Aawe8mZ+AEMEofxEKT2wWC0y1AHeVyT1vZOex7+3ZkKA31wcbMuKAiBPAWLhcpKR6oPEXb9vT+Pgf1lc5+fUyjF/LUg0D6gDJ9tNQ6RRptMAyhq0HeMMlZvBrd+zf9/CM2qDyvbBQoHAOtlWD9b1MMarXQK0aOGpBOAniWqjfd/2x5of+uDGQNi+BLb+apRwnHfwIXmsvjA1hqAWPWzBCUmwY7zx/svSV7+f2HWz3bFaFNoMVcXMKarYMy1nLCC/UWMVh9pwbN2vUFrq+vGgcRA5EdABCHwUxI4UDhgFxkjVBdGoBeZFXmnWhGGpj1ZAon7K0ufveMc2q1xIMg7SGSZqgoAbh5nDPzgj7JiJsKhUQuxLv/Kdf46s/G4fIuZDzM+C6hjIJtK0zUZ1MrWXR1NWlK+fr518cyLNWTJWW97WVXzKRhqBGU7QPHCoe++Wj/bh/T3F1qosVlLqLrhMgTSWnswFRuw41sBw/+nmEnbun8bWPXIbz11UQxwalcgX1Rh2w9oSsIcOwA2s1nDRGGAkI5UO16uD6UXDtGY3m/qO2NbtPpUFLcBiFMb7kB8WzV65V79u+sYb3nVm94oyTqbhmY0FQTwFw8gAvA6zs1F7ZTg2YC4iITpUBrm4dxp/E/4jJusCODWW7/0ApPqnnoKfVANyezcgVCzh26DFgbhK5kVUIgQxBWMzBOgJwJbpKEstzCm1YHLECiA1EO4RuG4hcCbm1ZyDe/wx4/BH0yGM4Z8kpzIZlomkaAFQch4dJ2G1uMs8Yfxw07EL4eSD1Mr4S2oiYs5OjIwDXgcgpUM4B+U6Gc/IFhPCy4LXRWbNzqmFTC2jbyfExQBJQMqOrkwGTAFkJk0mmLLqZaGkZRMsEzKk9bBhkhC/Y9i2WcAoJWgjOg8CKJCQgtIaJY3CjzVyfgWnGhDgG65iQZsFESx23jAaABCJKwVoDaQsyDkDRFMrBBDYFMdaRwumOh43lPJZUClhWysPrVtBFJhJAZAwojHmbGlRf6Hsp/nPvo3hyax/e9yd/iZdeeA2Kfn5xi2glMdvYWCEU5wouLV06IpYuHRk8d9sZr124QDXDgJ/cOy12H6nR5Ewgg3Yba5b1YLJt8elvPAUn0TDtKqzWEJwinhkFkjb3DlWot7dox6YCas+n5PasF8/t3FP65Cc+3frzj3y4a6WjebCrmIE7iH+bFRQgCVdY6i0LnHHW9hX3/dcdzyTtRr5ebZey/en53MiFMlYBAzISDgElXyLR6pVQywr3/fc9M1/8wr+1b3z7W0pBzuG+3hxJECRlqoE9IQt2ojwqmJETDrUaLb7o4rPL7/vjP7T//Ml/1s7IWpWyhk0SiJ5u2HIFUA6EdDOajxSwYQRqz8I2ZyGS2Yz202yTaYcxvEhAwLGWQm2UQL7sOX5MSAWMG3mPP0I2OU9BdCeUbXz2+Ey7U9xnjUI0l2LsqRQPPmx4eKmDyhmGjKMgOYLtYPUyOriEk1jExwiN/SzGqg4/PJnfAnL6iDULCaHDCGYirW7ZNBG+/43ThQu3p35fjxCeYxDFBf/gaM3efo+c++y3lhTr9e6iKPkCOg+O6jBVmSHJFBEaCbZuankDPVbFDYaSj0CHKTyroaULtikIDEkiqyGjThBUGs51ga44jea/93SiLJk+Ygu2Edg6kEojmZxJ3nX90ejT768uM+JUxPIGdvVRstVvQSd74Zp5kAXIsVAWSITg0nBLfOS1VL7mn6aOCi+33JDP1sQkmtOgvA92RDZ/j9ogrWF1DYOF8eafvflQj4nWEpUvhJPuIt24A6QPg5MoY5qKThsJE9gw9w5HzmtPblT+7p5mTHntWetAtObA9d5MBpc+DMlM7TERGBoCJkuAyybEXAzMJfB8AS2zoL2yunMok9l6sdBab8zxyI+wIMm20EfistONufdgNE+21QtBQArYoAlRDKBy3ahXI+w42MbJ55Xwtr99EN+5YwxuzkE6ehAmrENoBaYANgwJtWqw7dTp1kfeeyw4/8z2UFdPPg/XA+wwYFUZSABO+pG0Vn6ovlMfPFKY/dHdw/s++x9NPTVb3iR7ckXWseV2JNKxKtyBU7BvTOK6v7oDP/rU1Th7TQk6BvxKEXGtlekVYiHJa5DAQwEpSl4KO7oX6fw+cOM5oH00RRpXXS+YTyLsApzGhWvrb3nny5JXXHqB1EvW5QndThmyDMsFo8MQuh4RpVVC2oaxKQDTQcYWQKIrU3AcH5QT6C/VcOXQjHPl9kln5thfohWMIC6/Akn7dXj3216Ghx//Ah5+9nHICy6HLOeRFgVKZYnegouysJgKY8xYRrutQbEFbOfzagYIpURu7SZAjOKPr12LC09Zxwdma9i9Z+8uAFBh0PxxmiTX95ck16uPIAqqsKqMWPVmIfFyD1DsBdwipHWAVAOhBds0awcQIqPe5wgyLyDyLtyCB+spIE+QDBhjYFMNY1JYDUArEDtgisHSdhYMl5iyBYcEwRIzrCCyku2Cq852ugClBFkmmxpQFEM0U5hWBNMKgCgkRAkoyVx4i3A1w4BJAJ1m3xyTAmHmnpTxHEQ4jbXNOs42Glf4ZWzpqmCkq4BKyYXoySHtcZFCQ0QaNkohWwYcphSmjEojwqvOfgXe9sl3omfVCABgqtrGLx7Yj189fRi7xhpUr2npujkMDudxyvp+vHTbMF+yaaWdbUf05V/sED/85T48e3AOUeQCic2yFJwCCpBpCN1oQZgWYBrQk3VcfNHJeO87r8DZZ56E3u6yGJ2aw999/lZ869u3W6/S5d7z858fHhrpn/w//+edG31HcHexQLD2d9ZrKOVA6hQnn7Qp1zU8WKxNPPnPgwPFVwDYusAtf/Hqj0xC9Twfni8OtWtJQeV7N3z9X/89KfUN2cuuuEi0dchL+nvIk2kGEof4DTn0xB+OciiKAn7Pu68Xd//yzvpTT4+VZN9yZXQLXJ8F5UpgV8C4BAgFSjSoVgc354CoBmVjxI3R9oqh5ti73j7jbD+ZB6XXVmlDxg895VW//rMBdWi0UpEFvyz8SP33Tt8cfTYJ1m7gHPdJYtfCCAtpsgYRNgyqKkw9qnDw2YRHGx498QjhwqJld4kkKsqsFJktOJHwmkBzTODI08a6VUUHJ8XOY41ytyp6SyF7jGZCl5p47h8+sdd59cvV8p6hXg/JCmh4EClQKFbd3p4Jd9spo10vPWcyfOOfjtQO1pf3CF+AdQDEMgNJZ4Yt3ee0GsKGXYqIbTxHxAJGZBs5dTJCTDb7ydxp/QBRnrFmBZYK4iprA6iUoSOSFMPU2nb7GUfm/+n9B/oTexao8nKI8BnS9f+C1JNQArDCy+g7HIFhoISgxEqce2pt4MxS9fCj0TLIXIuMVrBRE9RuAMoFB20gaUNKDV2N4+tftq+xbLjdHbVjzplHKW3dD8E1QBikjpuxYTPUE7Knx4CVwJVntuK/u3P2gE2HNkNG1pqWEGkbHDUBtwzyCiDbYW1adNYEABR6U2Ou0qMWdh3BMYCW9rjozfQ7mDUZ2xcO4bwtaRE/aO21tnwO2LecGiG0zTZtHQPGwa+ense+Yy1857+rcPwS0tljoCAC65QhpiidbUd95andf/vp/YNvuIoGc71LBWgDDFYiNQ6Y6uzYFqxugG0ThkL4hbrauGFm6P9uGR1652umZz/5leLTn/32YJfsHt5CyodJW0hmd0EuORWTNQdv/MQv8KO/fzVO7QnhswPr5hCFTTiuAwLB4RhEObRSwrvO7sGh/57CroefQ+I3UBxZmUvKm7dO79m35uKlv9R/+Cbeeuk2vbGysizY60aSGOjGPENX4SCRwmr4qe4UlS90txKyZrMQTLMd46SEdsogv4zU7YeUTe4ZalK+cQiIPovk0E+ge16Fm//5erz2D36ER597HHLbS6wYUGJ5wccq00AzlThCEuPVBLbF4ESDAw0KLNgaOO0ERhDMlktxvwJOUwZoHMTU5OwEAMh5b/pAnzdw/YrlS/srBSd1WkcE4gnqFpPYUpiDM3MMdvoozMxumNlxcKMBjltgjiCEhQRD6kxG5EYEPRdAz7RgpluwtQAmCEE6a0p3PA+O7yJX8CE8gNyMI7lQjUNKQcgMKM2upMxFKjMWsxAEOERWEAWGuBqA5gPwfBO21gS3E1CctUyT5awcmy1sqsGpASeZsxNpCIrbQNyEiuqgYBK9taM4p9XCtbKAa7q7sX2oH0M9BfjdHtDnQ3RJCEcCKcDtFCLS4CTrLkumatDnn4KeL3wQpaECWq0In/nGw3jf3/0YX7v9WTy1ew6j0wlmZ5uYmq3jwJEUDzwyi+/81z66f/8R8Y1f7KRvfW8nJqYa0EEAN65BxXUIHUAgAZIAtlWHTNoQ8Sz01DH88R9fi2//21/g5C1rqNLlw5ES5b4yLr3ibIxPTKSP33ufdMuldMdDdx0sdy/tOfm0031fMUvKzGziBe3BHVkHDEKiU5Dj48knnxsYO/TU0Rve8JaBFSuXLomilIV4/o7FHWelIIlGlNqp+RY98fBd35ufHJuDVz7NpkY+8cA9R4tdlaDYs7QsoFDKexmzkhbEJIB+IyKR3RAZhGLBo65ihW/94W0a+YILAGQk4HaDXB/wFZTrAc0AXJsDonkIFSCt1/TrLpms/+RLu/uuvCo/sHrLJc7K1RfQmvVz/kVnHe1+0yVzbs6dn3ngyS4pVJ/XaFvZzXF8eqWeD+aMdUiS1ASZAFw3CI4KjD5jcGyXMcbNiR8f8h+YT52JrSVemsyHWmpXqNBCNBnRmMDMcxZ7d2iuT7GZNgV524H047vmCjnKudtAvhgpT+2945tTQy97yZKRnHeRSs0lsLwMKsmWd5tMIowOc1pLsWo4dda42t5yv5/AL7tswMSGhLUQiGCjlDf0j8fXnl8rMhsiiQx7hgjEJpsQE4Oztszj/E22JLVAcyJ2v3dvgUPpFUjkSFgDtjGpaLZ588eOqVUr4pzx38Rk5sk0vglXNyGQB7GE6Bh+LCUdv69BaphL5Iipg2n8611dRpR9Pzs++ZDkQSoX3K4BjXkoRDDtevT2q4/KMzfU80nMkDIi0qPZbY1Fpw+EF8sHs6wxk7QSKgjE139RaIZU6iepQEaSyBWAfA4gCXLc7OgWNkFBAxzOExHDtiO1xJlrnTvcKjj9Fta3RMjyygS76IxcbJ85sQaMMmQbiMlrmPx37nWfaNncZlI5AlyiQi/YKcBYBjkBnj1qcd/jTcCNYKozoHAa0AE7IiI9ORVeeeaxQz//9u6BC8/vGiLvPErkhQwqEqL9EO27IJv3kg6fIYr2kEwOkYinyBqG4QLHNodKMSxcfW51+bbNZvSHd0RPGptbRcol0pps2IYq9WG+LvHMwRm8+tKV8FnCUQpRFMIYCyJCagjCRIi1Rk4kuOCs1Thz2wacdMoWbDn5FAz6k/bVp/8i90+/H556+nmq3xmoUDtUjOYYyXACTtQmFVpSNQHMWqQTDHsMwFEA4wDGGOkMQ88BqAMi8iEMQZl2FjOL5sAmIXhlULkb7EsUaRrJzgcwfc992LRyHR55/Gk0ApdMoYcToSjv+6hawuhMirhpgSi7nFErAYVxtubrGCZqgmOLfbMaHE1h20iJgjAsPvbI/V+XaEArL3+/66jTKl2l5V1FSa5KsWakG6+/+mRsX6OwfbXC9hXAhp4QS9QEiq1xYGI/9Og+JJMHYauj4HoNHGqACQIik0USA2qEsLMhzFSAZC6AboTQrRBILCRcCN+D6C7AKbiwNslkUi0AayAtIE0n0xZZcCMG5trg6RbQjCDaCSjVGYsww79kzs4OC43SCBQnQJyAdAiRxFBJDKObcGrTKDansLwxhtdYi3dWenDFUBdW9fvw+xTcoRxktw+TE+AkBVVjyIYGBQZplEAbC2qGiJcNw//s7yM/XMDkhMYb/uDf8ZXvPoaaFvC0BgVtqOY0nNY8ZBRB6AASATQBBw4kGB1tweEGRGMWaFUhghCi3QTCGmy7leGFWENaDT07zh/5yzfZT3/8PSJJ20hTi0QDqWFEsUa7GWDJsjXygYefxfxso+gUelY8cu9DYmhkqVi6aqVwFMMVBAsnmwO94FzLzLDWAI5Dh49M4skHfx287KUv7dq8ZUNfnKSdUPuJsHKxWMDaaic8PteiBx647/7ZsWMJvL6zySuw1awe+fXPx2Znm1HfkuFKrlymQi7HjmQishnQnH4TriaIIEmQ0Rp9/YPOvQ89xhNHxpVT6M7mmLICcjwg50JYgpmbhmjOQNgWm/a0PXft6Oj3/u7pkUppqRvTy9iEXWTiCXAoWcc5lLy2c/G56D516HDwg1+WmqSKPU/sd6MNpcmWG4jixAFwMCNQn7KoHiBMHSDMj4FJevKxifi5rz6zcurJidzsmUMRF2IamjmUoHaE7PxhweNHwdVJsnlrRapK8vZ9/K2v7+g9plz/z9jtdm07OfKfn52gC893h+P0LRbuUhKthyCa/wWKHgMnz4GSSbg2IQkmbkToiVj99+NycqI9UBaKhLTUIcakYJOIHjnHb7hw3lM+AZTFebLCpc57sdjjt2jkyPCDhpBMWXXHI96+ycjrJbeoyHHIBpavOmeq9edvGuuJxClw/GGytR9D6nam0KBTZswxkFlhOqEaC7IxJBSVKdXfvMudTlVPn2TJIEGsCmDXA+sAImxAUgITVcUl66bUOZvaypAmFsnxxjWmxRvscSRcpyjUSriB5935gDd9tO0PuG6eLIsMaejlsgiDU4CQlEVh4hCI6oBJmbWVc0Gr/qplc3552EhZyQQOykjDOKGAplPPxs9jExOYrCaUBbwHdzizuydLS13flWw9wCtl1WoqDymLSF2bGatqM6DmQVAUsZABpdPz0295yfj4v312//r+7lPKkb2cBfWSaD9OVP8p0H4KrKcBm0JwCMFZLyFxCtgGhJ4jZQIyLNloi00b4yWvPb/R/OYP6WCE3AopIstpSpS24RW7cOhoAO0oXL11BJHVcFyFdjuEYAENhkAKZkIz1Kg2Z5GkLnQco7t5M2487WZ69csacIf6OU4SlvPz5EU1EiYFAkI6KRDt0mg/qzGx2+LIHh/HJoZxtLoSh+aW4cDcSuyf7MHBgwUc28uY3hvDTqZwW4AgBeQ7BbxJDGUiSK8XNlfKDN7VMX7olgdp577Rpyda4ajA4Eikhu1MyaHZxCCZiyFSALEBhRYcJUCagmKThcKjEE6jBauAyUaNNvdY7srZkWMTcz+XAKhenZ04cujA17RNdyVRulUyd/UNLcGVl19Ew73dWDLcj5ElJaxd0YuT1vRg23ofZ65zsG2VxOaeNpbQNLrSI/Dqu2Brh5BWj8I2JsHNBjjmbKaACDKNQFEM205gawnMbCbtURIjXynCLeUQNyOIkIAgAQcGthnDzrWB+TaoEYFacRYEtgZkU7A1YN0JBGoDshakTQbqTWIgSsFJCJgmOGnCtg/Dae7D8uZhXKFbeL8q4vrefqxdM4TysiJosAAxWAEVvGzdCCyoFYGjNDthtBLEaQq/lqLuAPl/fT/cLcsxP9HE9e/9N/z6sQNQXXlQMAuT1AAbwuoYhpNM8jVt2LgB6AhSphBxFaZVyyzxUQOm1oRuBTBxCywtBDOEbcPUa9h+xlr61r99WCRxCmvVIvwbDEjK7nDC9TE9X7eP3fcAU7Fb2DSSTz5y//7Ttp+bXzLc53iKsiJKsi+KpQYDKTNHmumO7//wV6+77uW5zVs2LYvjEzfABfPM8Q2w2Q752EyDHn3ooUenju5vC2fwQusUmR3fU25+8NDOx4I9e3ePr1y7qjjYN+Aoh1gKJgnxoqjRbKEBGAbSU0hTJL/82Z1G5LuUQQqQB3bygKvAcQjMz0HEk8xJSH58rP6ff3u0uHql52n1KnZMm3Trv4DoGchkhoRuUWgiIGqZzcNpPu/MPffTe1Si3ULfL/e4T27sr7bWKTFoGyklM5KSWjaxJk/S46P5A5+4p3JHK+ct1Vbg1qdzk32VcLpYwLC0cBCBVKLIFyTG41z7e8/JH3zpiZ556Rbez65fsYz0nDMn7/urd1fPELZfwCsKU/0pED8Cpqhz781uahkXl4DEMs+w2L9bjz4yWnGl7+dYE6xYaJLWUMGcvvasKdnTy8KIbOb3YgWDtFiqlOU4LTOrhqD7n8bjz013LSW/6JHrgRut6I/eNG23nRrkLPcxmQaZaA9ILMinJosIIKMuLUiTnXExkdVcETn/sZ3Yv2+62C+9ggIR2C2ClQuYFJQGkBTBRPO4aOiQuOCUlrCughAmQ2plmmWGRTxhR2JYEAPWas6xQzt3JUcePFLJS6+YsySYlU+UK2atF24F8LLiVY4TUJAhDZVIabZp7Fk9NbthuO26PQ5YqsVYz8LTt3jkO6F+Si6YvyxZpQQdPSRad+6osMr7JWtdhuMTPB/kFcF+MXOV1ifB81NAO4SgGdITE8Fbr5nY8+XPHNtUdNe5ibqGlW6Qad4BET8B4rBDkhRZhnrxbz0BcUgEyylgIiIw6Ti1gyP+kks31fjbt9MBVl0jUJKRBmSEC1XswsPPjuKcU5dg3XA2HzVxiiCIIATDUFbYTTqBSHOIzDw28pdwyapbMbi+HyktRdKYISdokEgNUCPEhyxajzLGn87h2cZq7MldgZnBaxBsuAHhSdchOfnl0FtehmTDFRAbrwStfwmC5ZdgrOdMHEgGMTNeQHAggJpvocwGypcwTgybNADpQBR95IdBG5cJdqrN0uTO53aNz7dYwO0zTp+1TonIMhDEQCsBohRI0yy8H8eZKphmUBNCghCMXq7abRsGZBAERi1I2jfffDNdf/31/7lm1YYtfr7wV/NzVe0oqfqHupHGBsRlJIYRa43EWIxoDRMnMEmMNI4QJhZBbBE3W5ipBjg8PYPR+VGMNSympgmNOI9IFQC/G8gPAfkeSN8HtAfbtKhPH0VhZQ+Kvo9mvQq0NWAzFiI6P20HSykSnVW86LjDGV0AgHI249NJRtWIgyzQnjZB6SxQPYLlrSM4AxEuUt24Kj+M9fkuRGu6IIZzsPnO32EtbJhAtDVkaDNdOU6BkGHiGNIyGhPzkB9+Pdyta2HmQrz5j/4D9+wYh8pJ6Po4JDfAkYVttDrldp1bKvkQlV5IW4eJm5BsoJIA6ewE5/uL2HruFuoq96LWnMPjTz6lg8nD5PT2SdOs4U3XvQVSEEJjFunxC9VERARHSuQ9he3bTjVfy2NWp61hJ1+m6tx4///7+78f3/yVz632+/MoSk32RdsGCFJKOMLaVStXyMrQhhZJkfxvkG1ExEo5KJVLIrNbZkYQiDys9Nnpzy3Z/+yR8k0f+NCBj//NJ1ZeduUFBSXAjhTEL4JEXTxxCwKbFFu3n+JW+ivT9VZ9CUoVJl0jGQ1ABy5gIlASQ4iY0mY1/r2Xt+rbNldXtnEl56lBtnUvFNc6JJcwgwTYFkhbwSHjVetoy98U60fmjevWMXzee/5L7Hjt+toDr9ww1e2LdCBhD3NzsnrnAW/0tt36o/ALb3KTwkVauUnU5fofvqvnV6dU6k9fvWnWXd/fsKYl5O6q2vONPcU7q43+dykf12s4Uno5RkDpS7fHp+RV6sZpiVXjQVBwAEIKaCFhOUEGu++QZBgQwrCUgtb1hBGS6gTpYreFtcQk2GQS4VirYI5OltKVG+Yls/ifS7Qp2wCJYH1fyPXdiYPEjElOyiaNQIijU5ZXNSURLB+CMkchyWbKDqeAyGxRbDNAt1gopSbbmdMzFwYS8abzq/4du+Z3UKVnG4y0ZEOBJAbYwnZKdABlm3U34LZbliUGc9LxCDz/MIRFN25mXRaCLXKhPG19ro5f035bMdsAy5TGxHE7yyLrGBRnwXsSDtjxwcon5ghQ5coPDudnr5ykor/KAN7/suW+U1uohSHlMs5Yk3bDNhpGdw1ZmUDEAZCEGTuYU1DYhKjNw0RjIDis59v6olMPHvh/Hx07zRHrPCuuZ5E8Qrb5SwhbhdJFGLIgihebbrBQXtyRY/mE5kDRYcMSQUStutl+em7ll/9k/9xbP9oz4S7l4dS4zI1Jcv0SIpXDx/7jSVz4icshjUG5XMJctQ4DF1IARicIrAHcCFvdL2Jgze2QhQ1ITBu2uRteHINjQnqM0XoGGJ3sx9H+U1E99RL0rNiGFUv6kOuqwCsW4QoBFwwlsoNRIhU8juBLF4H2MFmfxuTEHA4c3o1j+36Frkd+jfUDx7DkJAYGPESoQhsHKt+F8pl1enc+X+iGeclf33/7Pc/uhie0XCE3ng5bqMAGKSgMwcaCkgRYuADpBEInsFZDtiWM5+LZ6Zheyi6WLV1y7kIbhL3++s+r6667Tj7x6FPHwAaTExPUDgJsWrkU7UYIskBqU2g2EHAgSCLWGqkx0CZFHMVIowQwBqvTBCcFLURhCJ1YtGLGfCPE2EwD0/U6JqqHMdNWmKr6aKIELi2F6lqGdtBGccMInEIRabWe3eY4KzjNHKEWZCxsEmeGFquzB8NYkGGw0YBJwIkGohhIAsioBQRjMO19vCWY5nfLojjLH8KqYh8q/UUES3JwhooQeQ8aCdBIIVsJRJwAsQXHBjbObpKIGVYboBagtbwHvW+5Eg4I//i9B/HzB4/BKwnErTkotKHrdfgU2zfe+BJx2aVb4bsKE2OzuPOBXbjtZ49BJwLS90FgpPMTuPHNV+CDH3wrNm9Y3pGYGAcOjNJnPvvd5MvfvF1BWdpy0ioJ5gVP7SLoetFBKQhSWF62fFidtGX14089+tQKU1pxsupe1v3Y/Q/F3/j6d+f+9IPv7tNJzNJ1j4MgTpR3KItt9vZ2YctpWwZyuZz8nW3llEViBAGOoyCU7AOEEkLAUsbqZBaUWpedbq84W53e+Gcf/KvZf/ri36uXXLrdc8EQ8rc35hAcsLHoHxxSG9avLz9y716IUh8hSUFxCAodsAkgdY2NtSRsOP2u6/ZLWB9EXUDjUbCeglAuLGtYEUOZzJwlDVOaWHbqnD93YH72xwfLbVUuF+AMnvH93ZXG93fmH5MU3KMofTrW/kWA2kyu+y1QvjtVUrAjfYUCc7nn0h3JAHY82DcFHewDbA5kT4Okk5XvbtLQTI7LpMoEa2npsC9ADaR2HDJdQMoZEIeZ29baDsbu+OfiuoSuMvkwcQ06yJyc7AHsQMEiTvzivqOuvvB/TYFd5FGTVIyhvO4GW00mBRBb5Zpu2ciUGHJniYwLkh3mL8xib521HRmbRdY+kgFLYUkQ5zS2neoM+bn0oSSNt0G5gE0AE3eMb9QJUubFM8e8WquhyoVBDcMGbEUnk/dizRid/3cjBYRCIaeWw5o5wGT/DyYFonZGDWrOw8bN7OamU5DKcqPWuizdHN012h/sH69Fve3IR29WYg36n4pXF0DTTGCDNcNJf28hPjgfmwGnaLqNSZiTkDhqQwQtoFGDCeZAbBhpkyr5w7v+7VPTS0u5ZV4ir2LSD5Go3w6BFNa40BRnOUJmMHGHA3vcwJZFjo6TlKhzUhBMICbZtAm/7kLvjB9dsve+Hz+6rtft6nbSaB5RbQbe0Brc98hB3HL/Ydxw4WpoQxCOxMx8DZWch1ikkFEDI8mn0ZP7L8j8CHRcA6IZOFpCzPiI90U4dqCEw+UrkF7zGgys24YN3RUUigzl++hysxEYI1sDLAswEfJpCCdfwXfvm8Z9jzyDP3jtRpy5pYjZFUtR33ouqodej2ee/glmHvkhNq2fgb/Og7Eaia6CykNwNtf4uhtDHArdM//6gbtus/H4dBpfe5pce6VipwwkKVGqwToFJQlIZ/sEp9lGSAmApIjxMBG1ZhvlYmH5CXVId/Mtt8CMjKwYlanDvhcKI3PI54uA9CCVAphhrAVHMWyq4eqsbdhaCeM5MAUN0xlZG50i1Sksd14Iq2Eii6AdodUKUGvWMT0fYHq+hgcOT+KRw5PAyOloH5iGHBgEJGebmLWLMz5inTHy0hTEOpM1TNqRQAmkU8CEoDaAtAGER2Hqh3VvMMav1Ebd2DVCp1aGkM/lYbt9iCVFOH0eDCewSRMiZtimhW6nEHEKijQQJeDEwKYpTGqQWoNmtQrnNeciv6wLY0fn8C/fuReUs9BJE1JY6Po8Vg/18Le/9lc497xNz3t13vf7wL/9+3344J/+LYJYIwma+PhH34W/+os3EwDESQqTWoAMVq1aKv/lX/4i5+T8sc/93YemDh2dWHUxndGt2bKkhcK245uYIIJSlrt6KmLzaduWPPXQAwdJeicbkkaVVw597Yvfmb/6yovTs7ZtcmBNpyEBz2MDMgECTI4kLFu5dL1D+Z7jb72EPVE6Xfi1ZfgOUz7nANJZDbgtEioTN4nATgEwijQpll2ObNbG+j7yV389tXHjVwZOXT2srO6U7hAdL/9ZJAsZSDCU42Dl+tXikbvuj4Ue8LTIQXAbpGUmcXNINmrhtFXzuZVDcY/BEvimRUk6C8cSYGIIzmTbjNtgwKlFOmdtdTKQa724ibj1AFPuCoZrZDlfZhq61MTBpUa3Y3IdTzISy8q1Mg/yFMjNwSBHnARWOKkQlcIgJ84g2RjMCQw7MJIsKY/YKRIcH6BQKKPzYIYT1QlKgygFUwcCv/hTZt0VVoOtQ8q16PNkWch0EroNqFK2TpMDIywAl/dNFULAcRkZ/IABsDBZOfDzJNDsh5YEYZhJWKws2xqQjFvWJxMk6UQ3w6Nti82yIiqGrbRkLUFQJyZgMyhAVuLO2TxwQT5kCxaGrFG8dIkevGRDvfdnz7Ui2eX7WkcghAApkLRIrcdQvnh2tui0qpNxXliPocDCZNzWEw9oi+KkBKwFkwaIMFSKfDhxCToFCUFWMmSSgEUCjkazg6J0YIUEKAWpHFh7RF4e9UZf9yPHDk6cV8eqKBXsCyIrGJb4RV3K3NmUiAHFApoMDw1Z5/w1ycytu6MccQVkUuIkApI2uDoNDqpA2mCJhHT12NhnPjLqr1kvetrmQs7bcdKN2zskFgHmNJM8j78InU1O/FZHqqbs3Sdk0STJMbyKQ598W2vtzx+betakpdMFkTXRtEC4BJA5fP5Hz+BVZ69GDgn87hIO755AV4WhKMBG+7eo5G+HLA3CBE2YqAVlBOgYMP9khIPNdZjf/FZUtl+JkeFeFAtFVAo9eMe/P4UD08Bt71sNR3hZIS8yghRbC0cV8Ox0hPffOona0zM4e1MvTr1mM5SsobdUQNxXwdyaNRjfcTZqT38BJ889jMoZEiafQtYnYQsDpE4yePtbdV62k9el4uDEFw/d8uREmj/LWb6NjVtkaEtsUnBqs/3ARoAOM9e/YSCSCJRGM4iQ9/2KeiGcUQg5w9aaJEmU1oaZQUabxeJTQQQqFEAEONwB8xqbRR2sRaJTaK3BlrOOKQaUkhn8PWWkqUaaJIjSCCsiDcQxLksNvvqLcdx6eB6U2whTq0IIF1abLKdnTUfiTDsBdgM2BmzTzj8zgNagNIUII5h0Bhzs5UJ957HrG2HPVejJndozSCv6B5AMV9D2HPiOgm0GEEELoqIyclVbw7Y1RGxAkQZHKThOoLVBqnW2mccpGkWFgdddACLCL365C+NjdbgFH6lNgCTE8v5h3PaDj9OWk5ZRELUhhAAbBbYaKWu87JXn43Cthk/+4Ydw6eXn2w/96ZtFFCedoDogSAICiOIEM9WEX/G665Z87+bvHX7gngeeeMPrX3YZscgGAc8D+gHMAopAriMxuHx1L6CqglM2JEj4JQ5n5ktf+eq3ps/c+ndLiFM6ca6x+HIDgNGi1U4xsmrFlpGVy4Q2FkSCfpcs5HkuhvtLqJTzrhDQUA5Y+UyOT+Tks5oMLUknhNzAcjm+d1f/Q3c9zOeddD0azeg4lumF7cyGoSyDUsaSwQEGmZSs9gCT4cB02omMKCBI7UVnxFQuKpFwGdJUM4o+pdmNYmExZQZ35MW4mXHEuyvJHJgTMjlA+rBCgY2y5EqC9DxYyQbCZSlBbp7JzZF1coB0QUlBII1gdMykAmYrYYVPEIqhXEHCAQmXSSqCateX9LEFXIBCZgvKsHidudJvNA4DVliCZ6Bc7iqq8HDDWJA0tNCbSVCA7BITs9641aiQ60FIhrEBhKX/oYYWlN3WuQdIJ7IHUBKTZ+5/gpoXnywq0tMwuRQE5wWNICcsHPx8WY5hoQWzXzHibWfPiJ/uWL0fwp5ESctyWhJwPShhs+47yZhte+lsW6RDIE/zi7QXLBhfXkhwYIaALgppZq1lkMyO4JwGYDYsyGawKghYUmzJgySHLJwMLp33C9/b0zf51vm66WoqaSoLnwP9riTE4ubEAOe6pbj6FFu4dWc4BvAay5o5TSg7kLeApAXJEXS9hq2bJuded3VtQxyfyX4+R0n1lxCmAWuKYEo7z+fx1/r45k+/S83u9H5mu6YrBCVpizduyA3/3oX1+c//aj6RPf2uCOpI5o9CLtmEh58aw91PHcFLt61AX6GCA+NNPPX0GN635m4sW3sb2OuBbrdB7RYoVZCHLCYeVXiGLod7yXsxcsoGdJdLKHsVCJnNrKvax7176tg5L3HOUhdJwllBDLICA5WTeHZXE63UR7Enhy2resDIwPWekXAcAUd0wdt2MUZ71+GJB76I9c/8B5adBHAxRhq3wKUKhrY28ftvaeAH3wqXXJDuDH649/s/t1H9Kgxvg3WLDGuIklbWIGJSkE4zj4VNAePATRmsDSxZVi9825SSOSGkiuIoqdaqLiOTOWTnA2AiaGMgpOj4HwRIeXCcTJLzRDa4NsZCpyl0ksB0QqRWWDiOgCz6YCoj1S4MDCyH+JO+FXjuy4ewtz0N6ZTAHi+SWsgYkEnBJgEb0zHBaLDpEAa0BukISEPoaAKoP2fPmdnDr0Z+6JrLX+OOvOYi2C0jML15uDkPwjBsM0R0ZBzm/qfhPrQLbiOCVy4CxsCG2W3PpClMqmF01h6fJAmC+XmguwvumkFYy7jrvoOdPrwqJBLo1iT/1Sf/L7actIzaQRNS5rNeQrKAcGCNxYEjY/DLBcBG5port1spWQShXryRZfjvDrEmtTydxqK4bJl3/1337ZyarV3WXSrQ8bJLe2KzLBwwOYrhlcv9kH4daUjk50iTx7J72Ln9Rz+nJ9/x1uCC804qxHEMIRbyeFmcITUJmqnFXC3AJRdtV+vXLUMYJYt28N+GNFNSYmSggisuPU/f/o2/3y2svsoRC7nlrOyToWBSgbDZBqzQ65aNKGbbEe3EYnnviUufJYCF4FhHVCyXEhBZNmmRoBk6JXQecrABkijeunmasjLGMnNylKTVsJI6TMeOsUFk8hKRgtaawoRwYLZUANkR5gjgvIT0AKkE6xwgEiZ2iEUGgoCbJ/byyG50LuAm4LgF6Ihs4hGZJAO/kyJWDqTwwCxhbQRytTPQF3TuTTaTFIU93u7+PLdhBwskNChHXCyjtDrf1k+FMhDEecu0WI0EZWl0ltdEWsJRBVikADegrNMRU/l5SsHzNzELKTgH6Ons3xQW+VLXHftG9I3792O4XxI5DKjjphBj7eKB4jeWZktgKWAFE3uMzcuxpaBmd0Zxr4HHJGzUeWqz24EjErTjvDfbEm0SoihIcTZm0x257zc1eD7e9IxSjrUn+UBs7RlMmtlakiaEQUwmsDCJSCAdgg9HeHUY7WR1U7AsHV88NlnpevRQsX3VqlY5LhELsiThwC5wYF+0nLrzfoIAJ8XZq80QdPNONnoNO2CwIaQJSDCgA1YmJRPMHv7Ue+KuYrnspc5JbFtPQCR7IdmDpfQFDQ0nzBz5+ejChUrh40axEym/NoOWCEBSjDdfWe37yp09E2yKyzVy4KhGIqojNR5+8sBRvPSslSh5DlLpxebZ7/DWl93rWyoDSQiRhJCJAI1qHHnKxd7i61G++t0Y2bgElUIRnswBwiIiCekI3HDuAH58dxu/eLaB81ZUYJFkdXmLMi3h4Wfr0IdnsSLXxKblJYRBCrPQYs+A6+fQSxLO5l6MjXwYx341CH/H5zBwZgohatBRAC72oHxBQhfMaXvwW3bt+eb+Y3cfqf0LR1PvUn3bfKvKTLBkdNrxhMSdcRkDUiMvInhSIIlSUs+HcLBduXKlVk4O7WYq6rN1OE4ZUiSLRdRghhIy+1AsQ9sUgnUGXRYyw6CJjP7vSAW/5C72xzED1pjOLSOFjA0CbZFaiaEeiwtOEtjz62nAz8Eg6zaiNAEZDWuyLyb7QtJsE9QWbDQoDQHThgxrULPP4g21Y/Tusy8Qm951nSxcexF02YP/ImOm3BlrkVxzLoLH96H1vbsQ/ewxoN0ACh5kxIjJAmEMnmsiEA7CkTLsOetRvmQ7bF8BE5MNPPDEIbCMwaYFGxr0dBXsxRdsEkmqQSIHa7KFrvOuQqeEJBSctA2Bk11DS/u7mGmptcwLa56FzejsIDAZpGGCUr7kPnPg9tH9e44E519waj4M4460wIul7cwGBAfEKXK5kp8rdsskCurweyosAOmVkNZk/7996VvB2Wd/BhYGAgKwAmGsMd8MUA0T3PvkYTSnpvGBd18NbeLM5feC2+YLFyMhhZA2wTVXXLz18bf9CX3rm79oAmkJNGcBRVAuQRi4OYUVI5Xw/X/zbnrJS85T7TD43TcUAWgBqicRYos8iNrWWmRpep1B4yzD2hDkEK8diXzAgYAhttWMFsTUsewvoO9P+O8rYD4iHK7RHkhxKkMwpAYrEDkFsBEADBFnlUrs50BuMQtzkwSRA8ECyJVgTQSRhiATZzM8zoxArD1IU0cSeFg13KgND7vLsw7ZiJglCFmm9DcXuozQI8gCecvLlkKsLod9OwIzLynxs3ckFlaAhRNR28iIPdclZxAmGYeE6BRHP984wR2wc9bokkWOOom3tDODZFIKT86W8NgzqF6+Ad35smUShqwUnV7VEwH4i/7PxcdEsICQglKhedlKp+ulm+rT3987VRMe9yAqMElFhjVgLFkJgGXl8CxieAVY40Olswsly3ihUrEQ49AZxRk5V8KBbkdsIbSBUCF0rAEdjV561lhywaYgDiOtbr17sGvP2KBP+UJJWLD1XfLIQ4hS8Vc73cnLTuey6WdIyR0cGk74rr1AgiTRCX2AoBjdfeGqnpL3QNXGNWLTxSZmJBFZkcKzAZLWLJ9/UqQvOufYysSeDaVrpMOHoUhkyDVKOm0TnYutyBZcWrzBm+MyM4vFYhx0NsjjG2GnsYQcSjVj8/qk+8yR6qMPjpdXoMcF6RAczAPeCO578ijm2yF6/DxeuT3HN5TuQoUjRDYLxjO54LqD6nMx9g6/CQMXvwN9y1agUiwhR4zQTTOp2PpI4hiXrsrjyvVAhTsHHNJZiVhndGZ1gnUVQm/1ObzhytNRKRfQbGlIkYVPGC4Ex8gVfSizBF1OhLFL/gB77k4gdn4JvacCaEcQuTZ0uYC1l9XEq444du4X9hKRPJt/+Ejja22N66n7lD6WLis2xJo7YwSTod/IoiJb7KuEJtrto+qETzclImzeuOX1hUIJ0ga0dqQPcZJAGwMpJZRSEEJASdFpGRCwNpM/FwbisAyrbXZLJALrrMZGSgGWEtJZsBr7oAJQ1BppqmEowaVnrsQ375+FQQphOZM4kzBzmhmdnfQXCCmGs0JeGwM6YhGME2oPRn9Ua8gPvPsdTvcn3w70FeEAcBKLI+MzeHpPHeMT0zCa0T9cwklbhrF5ZT/cszchPXsTwscPoP35nyD6wV1IRAqnkSAdKsF/03koXHkJes4/GWp5D5ys+xb1Y+OYarYAB1lIPkzQu7wiBwZ6MyMDZxb1bAGSADO01tBsOIpjAtoHCl2lDUQLhhY6YdQvYEGwZJEnB3nlayCKjxwcnbj8klPXRMTZk87H6/ZYWAh2IAhcyBdFudIjpppHpsnaSsZ+dCG6lzm/vO9xf2J8yqxY1ScbtTammxoTc01MzbWxY9dR7Nm1Cx/5P69Eb95DO0x+Iyv4Yo3wAMEFodxVEl/98j+ceePbntSPPvYcrEm1MVaqQlEuG+rHulVLsHHD8lypmEOcGLCVvxGEf6HKpbVBO4oRxKmTaakEEGW36iwrwIyE8iWaXz1si4DIA222Ju0oafYEskcHpQUBKwnFHo/AsT085w7C9ddC5InIZZAHknmQqxalN3IdkJsDKx8sPUA4IKHAVsCi3CF/xGATZ4P3TLJnliElcUwIx47+45/VnN6RARk1mkyodm45x2c9CxsJMzp1SpnPzwiLZadanHOSPfWH+zxNPVJ4ANhakAwoHk2ii66Zmy0sW1kOw1Us4kNE1oFZvGE/X0SjBZnNZkB4JWUMcJsyqC9JMFLVW/nq4yMz52471p3vdwAnw4ML6sziTtwETzRkdfKdwhJS46C8xODG17TPuOUveEYUTS8jZpUSMwpgjlkIIThM5rpGRBPlgYpp5CHTSUhSsC/mEO4sWNnhzQCpBFuThzUQpCkNQ7NhoF79+t8ecrefmx8WTp9Eaxz/9x37ks9+bXbiY99YYlEqVZBWYKUC8t3er3f3JbPTTdu/KhTI0WLskE74PF4oPNqFq40QtnfELV+40dgf747GpKu7rIkB0waxgIYhbrcbH7huwvVzXSqmHk7bj5I0ARg5WKRZc05nY6dO5ykTOrfQbIMAO5nBiTPWsumcqumEg0FmRsp+baS2pVLOfc15gXngm9WHne6u7RoJm6RNskA4cLiKZ49UccF6Fyet7vNN2gfTOgjlOWAmqFnGzFMxDosrUbrkvehbMYjeUgGB0mBRgLISjmWANIyQKBDh1r/cAgEHJjRwhQNDGYOXJKEZa7zrpavwkrPegiVdLqLEQCruHDQyV7vvOtjfknjnF5/C9mV5fPTalYiit+PAPTPIH/oe8mtcxEkbQnWB+3yc8cpQTFZhaafY7uSODe2c+dEvxpPgGtG9usTCZ6sVMTirc/J8QAdY2u1ZcCLGpyaeUJ1nyQ5WBlcNLV/xD739/a+BBee8nBwZ7gObGMrPd2C/QKotojDKcj+CoBwH0skILq50soQRd+Z/2gAme0mSxMBysngNE0KCHAlBAspz4UsXq5YW0F2ewzQRhNUgNrAmOY4uM2lGtrCmgzRLgCSCCuZIzz9S+1gUOX/0qY/43p9dB6kMgnqAr/7kQdx81x48cTDC3EwCRBE6gzaUuws4/6RevPk1p+HlF5+M8tY1cL72PoSXnITJL98G75LT0H/9xShuXg0hsk0PSFAfC7HjmTH88K4DCIQEwWRh3TRAT6UHvu8hRTYzFCc8nMwMzQah1VRPQgCGy16eXqxlnRcrpwRICCjH8QHQ+MT4PIA1WLxVc+f7udD6oEHCwsu7yHeVQhy1DpkM0UWK4JSKaEzPyocfetL2r3iJfPrQNHZOJnh690HMjB7B+pEBfOljv4elwyW02iGs9UDQLw7RfqEMSg50GoPAfMkFp6tLLjgdANwX/rk4DdFs1zszJfkbM8jnu1MFojBFHGlEYZzCRk0iW2ToztdrQGSIIVDMN3odoZU1EswxwSSZIcMu3JD5+NIlBFgKFAYkrV4PS1CnC+GuZ0qsoFKmIUHCSheQXgbddhWy2aYHSA8Q7sIimJlBhATrTlYsNSDbBictMrMzcYEb8//0hUn5qitzI3FbsaU2ueyAOVl8+U+sx1i4pS0u9iSFzRPf+N7C6qfsvv/+7s82BFBqCaSTA83XrrpsdOp972ptYHExhD1CQrcAozLmqnj+rffEjmLJDJsKOBB1AHMLRhZriSnnOHfO9/Gze47OXroWfVyibIWWnaYLohO8iMfngMcjCxbSIUo55isudlb8yVsOPviZb4lx9BeWAEkWWxLzZOaa6dq14TNnvax/O/MykJhFyoBL9kXSHFlAPmvmyMqn01TCwO0V0NBRgrUD1V0/+/rO5StPu6yM9isQJbvZ6ofRpZ5zb7rx2IpD++nYN+8pFZxSSybWJXI88fT88ModY/PmyigRaUVAsOx0rPwPc0AwNAkUu4Gtq8OtP34irIhiDIYDayJINmzCkDYtmZu57Jwjy43eBoEpMmYPwD6M1TjeI9J5B+wJHFoQwAYyBsg60F6G6BMsnvdMP08WxoKQTQSy2LYxWgpu/SMlejuUAadtCNFGGAg8tXsWF2zuhbEDIOdMWHMQUjNsXaHxVIpD86fAvuwDWD7SDyldTLeB5f0+okTAiM56zHLRIClYwpCFVTGoc6PN1gZGQTmoRQJrhitoR63MuEjUef4FhNA41lZ40788hYd3t/BnFw3DcYDeVcvQoD9H9dEj8OYfgRp0YNMQxnUglgmcd74R7aqw7jRWFDDXf3/zvh1T8cxmFIbKTm4QqSbAVYDyUOYZrOsrIEg0jY+N36kA2I0bTzpncGjgJ5V8T6+JrK3GRlTRhVbqg5gRpxZKeVCSIF0BNycBY2DSzLKdxgmszi4kUASpKONKOi7gO535ETIUmckMJcZ0DC5EsJbheS5s2IQSUbYAmKzaHTqLNsBkmLNsoGrBOoBJQpZpSEnz8fnfb0zY99306S7/Q6+FgsXBnfN4+yf+E3c9shfwcwArSA4AkUkqFozGXIw7/msGd/z0MVx0wXp88o9ehbPPXQH/zZfDef3FKDnHFeLR/TO496H9+Pl9u/HI0+PYPz2LlDxIXwFhmo39WWN4qMe4npBBaCBYZOInY5FkYcAwStBMdYaJEl3wHP+3jbattZBSQDkKjlKB67qJ1rH4jTkAnbgA2YwbTkRSZYRDAQEdhUC9kXWcxTX5qb//ahIVKzg230Z1toGN3Qrvv+al2Lp5JcCMoKGRZPcAOP+TK7zzI6VOp1gKCpKgIz+esOkstMhbkaG0hP2teTXmbAEVQqHZbHMUaarWa21wPAk2g8xaZGH+jh3RCqrkEDrEXdbkQVJDQIMMw7LIXMUnFPkCAlAMm2O7+ryCPHtr+4kD9+myW1ZrDMVgVgy4RKoMuHmwzGWN5koBws/4o5Rl4tgmTDolkYZA3ALSGDoMgNm6AU/VL942OftPH0i6Tzu7tz9t9LMMnyTBc4DJd65hJxiR7Ikt3bS4mEkBGAHqXZXIr326eNUfvW3f6KO7nKla5PedvsXSReeMnJyvXERRXcNt7IS1GmRdsPgdrn4ChFUctizaTUoBMZytqpaYBDlQSFDq/sojS6a3nj7aV+7PzFkszPMAevw8Xwgfd0oKCYEU2i2RkhqfeH9wztr1Rw5+97Zw97Gan9N63nWkrZ/zcuP8xbvTi0eGtvhpuwscP0we+LdHbxYOhwwgYrSbRhiGS9KBiOtj//rR6fLK1SPldnyWzfEBYRs/JCeZQ5uJfYfpY2+rlm57rH2sbfxVTNL6RohIhvKeI254Zeo62mi4ZP434dfsSMwg5cU4ZYXYAJPOgROGSTuOU0GYm6y/9U1HW5XeLichjzk+TI5ZKKm2v+U/nrWJiMBFOAtUxwx8QSitYJh+Brud54YtLL/YgZRBrMBksXYpVfJluiSMYlDBJzYRbFoHbBkPP3EE73vVegAlkFqbzeFTFzQWYmxyGHzZX6Jv00kYGS7jG78ax4du3omP//6puPGMPjhBiJjchbtwtplZgQWQYfa1ESwDnqvw+Yfn8LkfHsQNp+bwh9duBmwCKVVHxTXw/Tz++T+fwMOPT+Prf7wJLzl3AM26xgAsaGQp6rUPwt3/TvSXayAmWEfAFFwU1rdx2slCyL1sn5zSeSknTh6+7PzJ7/73s9NztfEl3sDGHHndFJkGThkEn7o0L/Yem6zu3L3/VgXA7xno++qy3uHeWquS7ulb60w4yxFrB49VPawICNIl5GQMSxLGSHDqZPqwAkgy3M7BEIZhTYpUa4RRmClVMpNAhRCQQsBxXPieDyaCJZndioyBYkbJrcN1CWhluCXmTPrkRfnTAqmFsCnYNFhGIZn4CDbMPXPk91/3J6eWPvQalkjortv348a/+jGOmBZUpQjbmAbFEYhkR5M2ACeQJEFeAZAe7n7wCC55/Ev407echU/82StQ8hVajRB33v8cfvDfz+D+R6dxaCbOtHoYkO9Cmhi2NQs2IUiG4GDabt64NnPTJgn+P2f/HW1ZVpYL488751xp55Mrh67c1bm7OjfQdJNBJDQgKEEQMVy5gp/hd1XkermKV1FUQMwEFW0aEAQEuqFzjtWV86k6Oeyz815hzvl+f6y1z9mnuhrv76sxenSNqlM7rjXf8CRIL7WryoggghmekEwkaX7y3CJz+4FSpfhKzhi2nOEdPZ2fACPvu7Rt4yCU4uE4jr3bX76vwLziRsHUv9pTYGjoSMC0EyihFoHoiO62Lx8aHeNXvfE62rCmgqGBPK/fOCIu3rEWrxkuYbhSQCHwAACdTgexThmlRCm+ps+XSvQRNYQQ59HUsRy7ZHmF2GP7i7UgWDYvIi5Ml1tEDCEEYpNgYbHNUcfQwsy5c4CrmByRshBIEAhkiaw1kDaN/WCOhLRRmkcpIhC54J6AGqmFGGXAiRaW/FGPP/Zb9nXjvzv3yINPFxgltZlKyhHQINvJJqnMXD32QEip6ix06tqiu8QdDd1qAq0FRty2lUorecXt1fiDb2/Ym65bszMoboKuxmzCx0iZJQAOLOk05dvyCxKLM7ut5e84fc0WYUhw8oNi38u3b9r3qsFMiBnDtoDu/ClQ5xmwbaSEI4ozgTotx071hNWE9H6N2SJpMI7MOhagIWY3TetwJYz1mQKT+/b4QHzs2FRz38WmKIwPUjoNAc6wbbbZhgES4LRpSiOiTGq7B4OEIjiFHH3oQ6VtP/tua9pdY+KoLFxhhgfWeg5oPZJ6wrrzMDmmAcmpkRvxSjNAveeCgLYK0sQQ2iJqOUuJFjXbjpN3vnLpzEuv6d7ctjdy3sbCVr8GNzwFIg+O1BQlijdvbVfe97IzZz/19Y1Nf61TtKRYOsPqifFGNawtFOQGh2DzIFrK8O8LRYn1tHcShkCWLG660nc3j3VOnosa2+F4LFTXGmaRCzoLb7gp3gp3J9hKcDKdFQadsk25jz/LqcUgWwkRGtROxHzqGWOb8xCe1DyyBLFhnwcxFAFQEGQyj3uxmuNAAhKgWMRwC4X8GtduPNXRkJywZU2ILOAkOH50Ft2ugXQsyN8AbQCnyqie9hBe+nMYuuYlGCr6SBKD265ch6ufX8LPffpxHHnzbnzytRthk9R3eaUn0OnVawQSIUHchRQuTi9G+MTdVUyPW3z6sWdxx0s2YtOaXOq2hfR8tEmMV182gpftHcUbrlmLVqihHAFhFQoAxNZr0Ji7A8HS51BY58CYLiB9yDUSYzsNOJHC9y0Pn+nkS+L4tpd88mean/qbB9v7jxzIdXgbb15XoNsv3agLlbIz/9Sz/zp54vkJtWfPpTcPVioX5yPPHo52OSc2vRaouHDA+I1H6/irx+exuySwe8zBrlGFHSMKmwcVyqUAUhDYIk1lZwMtCa50oKQL5WfLCrbpWQXAJKmI3dr0cBNKLa9DhcMoDFYAbwZoxiAZZA1OKmhkHUOYBGw64KTFXtdSzEc7cvGx7//Khr2v2PJn7xHSFTjwyATe+VtfwbRbhpvMIqk3IBgwUQdo1lMwWflAoQDpCWgbAmQh/BLYKeIPPncfJhebuPWGnfj0P92HZ48tAtIBVADlRkDcgI1jgA0EWQiOwWDESw2URip4+9teKSKTpHEqvU4+0+iAAM9zsXW0BIq6zXfc8cErt160odgNu5aIxPlrRiEEBFm6aCTAb/zye4Z/5ade9a4bbti3q92NOa1QK8Um/YxTYF4zs7Ua+ZxaBGYP7d1x7eI/f+VPBi/bu4X7TDxFT8MXxglq9fZy6iv38DWTdeHUXwBXk1+s7Q+NpWW7qtWWUqvNt7kfS+w79IWgVRMgA6g3IswuNanTinHq+QMEyq9nA2QG6enjZMLxdscWwtCooNgEG79PtGyWpytGmlO5/IqVIR23sOOi0ppvfr7zum8+8Pj+v/ry2trjp3ZtMc2yC5EE8EIHXq/J8LIdZQgkMaC7CUg0HK+Ru2i4TdddNxHeen3be8m+nLvj4pIPdS1ss4hu9TQjPEJOUgdnXTHhwgHF6JEvmDPBXdYUsILUbZjGEej2AlunAgEJYzsgXSXYJgSblCqx3KjwsmECcV/6VW9V1tXodiS6wo4DPMkkYUkwhCJQnqTbRrs1uu5rz1Wj6145BZFPOOELx3ik6zte7mOs7Rmvpwe9jiOE8zF7ubIcKJclyAFsBNOQ0MlpcHiCBNdghIS1DgQnqyfjZSkEgyhOecMx01TdFZa7T1LEwU+/sbpN5hRcnQO3HgRHZ0EiD0saUnuQ0iJxI/7ozy5se/w5Mf3g0aSNgcE16KjoxCRNtnJiw0Bpl9RhFaqzeF5Y14oTDa1c5PCQIKS8Hdoc53/lNUuFj34heMxbk7uOiSlesvadt03J3Xu8ksFa5vg4kTHL7wOg9L3Rak9cwRLRDHDu6ZhOjedlxISNTkTzxxIU1xsMD6JvQUsXlEaAGGyAoi+dbeuc8VNHwisZOQc6AeIO4AWYrzbRbEUYHCnA5rZAdl2Ex7uYTK6FvOoOjHgW0hWIrcZI0cFXP3wlPvO94zi7uIA2NsGhaDWM0QN9sobNQMJ3HOyfaWOhGULoeawd0/By7vL7TjFOByZp4xVXlsHw0OnEUCINJOYMavPKJUQXfwD6wHcR2XOQFiAZQxQECpsEKjWDTYqpKAVmJh/nUu2y4v/zC68vPvTIszg6vUh7dg/oPVuHnKefOzj31BPP/++PfexjQhUKuYuLbsC1yUVe0k04R2ZBAwSuVGBKa3HEEzgSx8CJBHimibLpYqygsbOyhKtHFS4ddXHROg9rB3IYCATgakRsoW3PvEBCCAUpJaQnloFznSQwcQKd6Qb9wMXZ+RaqHQJ5hfTwDSNQtw1hNKyJQLoNa1osOUESn+t4naf+7CNR541v+NDP5d01I7x0cpHe/1v/gmnpw9MziNttOEYhXpjD8JjES15xAwYG8nzy+DQ9/tw4OtUmnPIQrGVYUwMbCzFQxhe/ewxf/M4RQEn4Ckh0AzZaAJkEki200dDdDmy7DcQEuMD2bcP2M5/+DXHZ3k2od9og6fZRGlaaeymItg56+F+/9oF1mwbL7ybHIRPZ5bBZ5hVjsN4BJqIQt990eQG4/NJuV4NTDUQ2ZdnlqSz1hgQ0W8GKUGs3bhQ0sunTf/q73mV7t1C92UxplSyWKdyUFU0iubxX5Wxty+j7/TL5xb5APL8at+wPDu1rAOiFrjPM5/tVpoeCzf7cGoOJ6SoakaG5manWzPhZlt7QoE1tUIiylWoWTUjtdrlNGlrCFowNmWGIe2smEnih8w3DwoH1NKzp8kBlk/uedw9dc8ebm+bgidONJ59zmvuPd7tTU7mlqWm1sZtYhyRxvkCt8oAMB/JYe/FFUevKPWF37agqbtnmq+HRzT6cjUBYRlKvI46fY6tPk5O0yCHAkJfKebKmkHpShPOwnF4CgehhgrCZgTXBUgTYcyTjaRApSBFDWAlr/Yw5G2eyjwwf7m9SKKOc24zE0mQ0lyRONjAHR22BdAFSKUYqJJhKTIEqfO/c8PRHF2qDwyMRWRaQ1sLQyjXa34jZzGibSIBFSkCQVoC4C8ecJCRnEENlh6WEtAIONQFhYCFTUhFb2GViUGZZ008TswAngpMGY76pZ6G9c5du7R68eJO5PQmHIJ0l0slBSEoF5gQCRAyGIG1crNtUzN/15eb6L3+jc/reJxan834n+eC7sbF0/W5B+ioWyb8T04U29Jw1ZzYrggJWCDhsSbsRv+MNzhX/ct/i3z95urANKsZwcfHMr7+/uVvkr+YkLBDFZ+GCYbUEk+nzOs22E5xtKtoRz58i/PBo0PnBSfGnJ7rBwo1D8tXvuDh6tanGTAkRKZvxBOjCuDxZgAV7HMs15aYCB10i45C14KgOkS9isRFjsdbAmrEhtNUauDWF2VmJ5Or3orRuDJ4iJCxB5MEahsMxPvK6bUhYQIcxFFskpDLf1tXPL61BxA6IBJ4Y7yCJPGB+DjfcOoDBUgFGt7PXztCyC8se4raThjbL3vtJGa+KGKQIdu3FaJ17K9zqn0Cty8FyBJYuaMgiP5agzEBOEcptTRPHv8W1jsBlu7fRJRevZSihnnriqbnvfP/u1x08eODcW9/6OqFMnMwIEpRzPSpUZ5CoU0BnAKg2oZxZOLkiEAQsfcG25FMjp9CAomONBP+xkADPxhiUTWwsVHHRAOGyYYE9awPsXONjw6CDwGMIRyFhiyg2MBkpRhLgeA5E4ENBwlMuaCmGUAVAW8ikC3TqQLeeMqK4C6NblgwE4gVG/cmvvCqcv/m1u9+wd90dL7OimYjP/59v4/Ez83CLElE4DZdjxEs1vPXNN+FPPvlL2LRxNIOADPY/P4k/+fRX8KUv/DuoMAYKAlhUwYihggogFExcQ9RtQBmCTRIk7QhJtwO4BhvWl7H35stx03WX4orLd+KG6/eK4aEimt0uAJEe4ufH/CA9fKQ1uPnqvZ41jEYnStlsbPq6Xdu3siJoZlRrLWYiFiSWr3ebEQ36w2TBAmEYUzvuYG5pHnv3XO5eue/SQjtsM4RKcz17I0BGmsnEdssSAb4ALreiexIZ6V2AwT/Wc7J3rhMY1vIq3IResPZEtvpJfQ8NDOYXGzh+eooTN6Ann3xiQcedxCmuhYVOzQKUkwWXWggKEGq31e0qQcZA2wgqwyB6zQWdTxQgQCCGggSTpSSegakVrZ/bKfddWxzYd2M0gFgDcTTaDuuURAxJDhyXXd8H4FUIzvAASAwgsUDkwNS6SOIpcPIoKDkDX0cEcgE4KR2cohSOtNzn7ZhOFv1FkNA3JCyvxhmWFQxEWlTQYxc7MJSCfcQ9YkJqWoHsufrpnxYyDTKOgc6iEFPzxM9NiTNQwQ1sM2ao8MGOBCV5ODmDI42cPb3gVEdkMgS2bImIeuJ3i2VfWu69N+ofOVNZHAnKzJ0JknTqG9qTulg3DTLNMjwl6xVsa5XuPc31k5ZgupK684wj0+4ioF59/b5mftN6iViXWIoJMqYBsipjYvds+1xIMkh4AaPDW4OPfGT44g8bnyWVCL4HEzqwrQegwiqMkCsr/R6PAfQCRx0rFFyOKWbidduj/Jf/pPy+z9917iDJcOnt73Av33H5pYXErGOd3AvFMZjF8nW4XPxSGzMIk33pTfDJs4H4whP0u880S4fhqDcenct9Y7gyMbdLq3dbig0kpNVOymvAC++rlAPDDDI0VkoSGG4SuMQ2YWk7JLRGpxuj2uxkW1MXehFo5a6Bd9nLMBhoWFWGTA9dsGC0hQ8RJvBZg5GHJpWZt1/g/qf0TIrDCI+cbgMdDZl0ceMVV8KFRtL3aj2d8S0ohgAhofQqhVUwsPCthZEK8FqYWfs66MN/DWcohnUIJC2EZ6EqhFxEiIkgcoSLClU6cu5Z1F3JrW4TR0+dvueJRw59aL4xf+JjH/uY+PjHP27VmXNnHl4/ur46unHD4CVikb3WvTQ7H+BcM9barXQoN5Yjf0hZt0JwAkgvD1FSEAWfreeD/TzqnkRVEj3Xtvj6QgL32QgVNLBWMTb7Efauk7hqU4BNYxKjI3mUigquSpUNWhsYY5GXwKkZhU63BegAJklg4xbYhlDaQmhrwFoinNT+0pHnb6XuK2/B2IYdv/xua3eOiiPfOYLP3XcYoiwRt6qQmhEvLeHaa/biS//wMfieQDdKBd1EhMsv24Av/t2v47JLt+ETn/hbNJMYRHlwJKFtSq6QZGC6IZLFWXglhauv2Wpf/tJXiVtuvhqXXbIVa0YHlr9AbSwarS6YRHYYmGXq/crEkXZrCQi1Rnd5nWLOY5v1Sw3SAAYCSPYoJH3n2eoWVXAKlbY6sa3VlkRz+tw//eRHfpHyRe+6qKstWyFFX7RL+nAy60Ff3JC6n33XS4ZPLUz+C4JcDzdhvGBZs7rIZttYm54yQgC1Voz9RyYw3w7Rri3hkQfueZREYUtKsjSA64MdH2TdLH7AR6cbF8anFW/c3IGxIZxshfLCVp76XiTBZhg2mS5E5xmhO0fA1REmNQx2KpBugXy5EbmC6E0ApCMN7lhYs8gaU4CukdBtCK6mZCtWYEgYcrNCZlLPVMPo+RcQ9R+ovEpUviyE55W/Y5H6VEqYlQmdTYoW2lQnZjMqvLgAM3DVmootuCW5Na1poobF/VUKqeBuIBIQBLD0Uws72yVBCmFc2vjgARFf95JsiUAEae0yU7V3gKcSE+5XMmavD+CMIUi965plX0NkM/Pv7Eq0acLJ8jTMK7QbA04v9shwbUHixDzOAEtfecUt7q+Q34KImtZ2E6ls6lG7spkQEJTKesgAUWscphux662nWHTY1NqgcJocPQ8rALZqeeK0tNJsUt9yv5e6YYigBJG2GrsunS986pqLroNXAoL10A3AtB8hmcyC4MKyARH3afz6OloGrNGWrBDff9Y8/0x56HO5OPc3ETm3sRSv+KcDY8/9/B2LMZVGHVACYZswdJ7JebYCN1nqB8MCMSVgldCyNCsCR3HqpkSpw49DHpbqFcQ7Xo3B0RE4lBZXAbUMVfjGACRhSKVB0XxhY4z07Qj4DmO8GuHofAK0q6gUJXbv2ZD6tfbDIoQ+SX9myWgIUln4rgPDEZZCiTLy8Cs7EGEPvOZjkGUFFhGkK2FzjEKJYIRAFDNGhiwG2xM4PF7mZpSI+++772OtECc+ePXVzsc//vEEAFS1Wp3oNlv79Rb3ZRdfPGrvWGhJ3j/P9048E5/S9VNnlFsd98qqKUdHEIy5yK8pobh+APkxRd4AyClC+B5k4IB8xaIgQOU8Fnyf5qTAc4nGN8e7oJMJymywOajisgGNS8c87BxxsLniY2wIeGahjU9+Yw6xlpBGwoQWCENQEllrQ8EcSu6cPeU1nv73a6l7y8Um2LDj4ivNwJtulKpl8bf/8hTOJhZKZOQKq+GRiz/7o1+G7zEa7QhSZKJgAlo6hCMFPvrf3wIO8vj1D/8Oy8IQjIgJlqCkA11tYnAkwAd+6534qTtux2UXbxJCpJ2KMRbdboRE27RhFpk2je0qSvPqQmKXQfUenPGCYnehNeF5f/ZiUgQmRqfLmF1sULVaBbrzyZoNmyAE+jRb57+mF7Lt+p+3fyoFGCwYXSOgoOFLAYb8r5MHXrSonsf8AIMkUO/EOHxsFpNzDasKZfHEN757vD558LQKLrnKsAMWHuD4ICcHGB+IBQkCjHW9Y2dLjZv3tUHGpCu88z63/s+5H1+ylK60LAkICkH2FFF4EjZKjXwNyZR6viypSBXLBEGuMJDQqdsL+WDOZ1OY7RPgZ+xTXsFV+YUf/Hmr0OwzEam0aPkAJur7fzpdr75OsiJy3gS1jBVz6g/ammLbmpfiXOg/Y1HaKYW7yzAsSUdApLRx1gzDbcApBM9PDs0ijCq2HJJreRnjXgGK+9a3y+OrWNaPZuhkdvDzMmLUez+2//qg80zae++DGSQFoAGuQRyfEZ0Dc+KHgLokpzrbU6vERULmsMOQqxqLlccnSMSQyRmi8DQUpaYtqROul+Zi9hIYsjAXWt5oZO5Gq8mgWfEmdDuWqdsEucym3iSKJ8nRTQhSabPLK3gmYcVhiYVZzhuUIx523eKF+CPz4cgtvV0GOWUVoRV2553NSLi426WwCo4PQJC72qi7x8SFhWALqx3UOpQHrN+DMNLrQMMmGt1M60vaRc29HNj9MgSuhFSp1MVmgHXPq5f6GrYXTcwAAGPheA6emGljsQmgvoDLtpSxcbQEbbLvscf4zq4ZIQBLBrA+QBbjocG3nprF1x8KceToc/jab96AK9eswfzgK1FsPgFZtjCZ4YR0LayykAHDCxiOn+C67V388OgEWzuM3bu273zyuROPHC0Ull+42rF167XF4YEbc0t17JlP5DVJBSKJ6aVj+3KdTvuKetzGYtTonrFz9WONU42TCM/sl96pc96QaOZG13Cw1rG5NQpuqQRvwBXuIKSXhwzycHIFcLnINBzAVFzU3Ryei5ieW0qAyRBoNjAcT2FtOUI9GMDZMA/PetCmDrSqTJ2aVVFNcncx0frM329uPnb2Ggz896vdysiV1rV73nOHFOsGcO7BI7jz4QMQLsF063DYIl6o4qfeeTtuuG47Os0YwlFga5bdU6x10Y0SHDxzDnLtILZfegmdOHIalM9BQkHPzuG2267AZ//yo9i5bUPKkIxjmDhMxa1kwYIgIdPCuhzU2Y+Z0aoV5YsXgAv/3YV+9kV/JkW8MD27xEu1Ds3NTMdAWFus1wesxTKnkP4/vI7sck8fgxWOnZlF2SdsWzeUYiFEL5hGf/xzrDZw6nFeCcDiUhPPHTqHU2fm2K3kxcHn9+t7v/6NGSG3/Yyl0gZYwSKXJ3Z8QPkQyoftCIAiwEfwxAGuvfc1CsJlutDrOV9v2V/wl4uIELAiD5IZfkaAEAwyAstwiyAYSrKW3YMmL51ErU3F2b0g1z5MtFfc7P/Fd3D+604p5qsYSFkuHKXNyY8Zx3vPkx5kDLIGumOxOGFQa7l0rpXcCQzsERzAgCxICSaZah0VwxoH8BycWvKcJNKwQoLMC6+RZR3g+c4tq92GlyO8ALt6k0ArOkI+X3zO/fOrAtXZNs8m4uBZjI+3hisu9Pt8ijbBKMA2ieCCrUl1kGyXUbaesF4QgVhlHu8mZWubnlH6yne2XIT7vkPuI5+d/z6FFZAck6VzYM2khIVjJRgSWmRNEdvzpZlZA5u+TqmkMG6X3/4OZx9ctr/wx9Of69RGXwk40dteN/7Y4LaxfSa/2SKczHKtl8WjK76sNs1sJEukI6DWhAuCx9YCIg2+liIt8p1OCADohjFalR3IF9ci7ysI5YPYwnMlYCyiSKcJL/9lwghn9Y8QW4P7T9aQhAQ0lvDS1+3FYNFBHOtlv1fXUXAVIUk0dCKRVkEAeeDjnz+EL37rJIaGA7zyqkFsKAEhNWCHroc96YNMJ3XNEQRyJEgxkADSIVhN2JDrwvdCrte7kMK5GsA/9Nv6qMLo8BsHKgV38Klz5pJoSJY35yB3VOAIB2XDvCHRhCgOXtLpBHGruabdqGGms4i5sBOeWpzojvOJ6imEi4fI6570CvlaqTJq/TVFuBcp5Nb4cEuOyJUh/DKUH4ByLlDJgYsum/UVLNE6WmgzUKtDxC0gDpkbVZbzpwS1x2USnn1ENU/888ttbd8lGPn9S1VRXMbDdoM7KEpXXQIB4KFnz2Ci2YYcUrCmAw0NVwr8/M/+RGopRgCxQR89EQYGtW4XxydmeWKhQUNrS+Mnnp4hWRzZpBeb/Krbr8LXv/aHFPgC7U6YAd/ZlAebZl7YFY+NZcyPVxq8Xrd1/kG2mlVmf3z2GC4gdu1bHRKp1IYGhLhrMX5uHklkUB0/swSgMTl+VrebHSgHBJOSZtIPQb14ke37naHePOsgCSOMz87haz94CusGPX7Pm14KXxApQYhTxmovZPUFa06xik2XqYSolz5hEceM+YUW9h85gfHpGhfyFZo8dy751hf/6mtsoxBO+UpIYigJypVgKQeSPowrgUUFwx2QKsgHDw4U6tNVLm01ZLWT+mxSRprg1LijB0/ZrLj1qlpKqskOYZuKrQ2ZdOdnRMa94GW/S0rpDGAkq9bdbFPCSu8AXfHsPM9Uq084LlgBNo2YTRnDZgUbygw4Fb9wYl79+9UHdu9oTP1bZGaLRvCNxfwUuDpD4vi8qv3dY6LluNFNlhQIQsArpgxtUmApwZAMV9HSkgzqZHUZvmJO0impJ9Zgm4mZBWBTyU+q1TsPJ86w7uVrO70slzkbKjtg2fLKZ51NjSxTxxk3kqhPaJ46K3FgFl8FYY8S0aNjAW9lnYB7InaWWaqC6CNmrPCTLdm08C0fCiYrdH2G1Mv95cq6klZBqisrX+oVsczaCwRY60BDZKxqkz2/WFVc+83sqWeFaIikqvG7f7py3ctf6m/89qNLE6Ikgp98xTXvL6zbJ0zjDNvuDCAkhLYZM3aFqU0GEJagmShqMc804AAin6ItlpgNhM2E9ipjCQsFs/EmVMouTsx18ZEv7YceHsU1W1zctn0Qt24UGeP6wu5Nqb5WIZEWQkdQykNkGI+dbAPtDnzdwXWXr0vvHUGQMGhC4sxkF2cWNS7bFGBbPjULcVnDaIFfft02vPeWddizrYI1ZQ+6VcWiZTjFMbT1WvjJSZAjYcmAHQOSnK6vMyxa+l2sdes03i1DSXsFANx7772m91mpHOReU29BNSOUwgTJoTPQQoDyHriSJzuQh1iXgyoUWWINBuKIB6pdsWcx8l/aSHzT6gw02o1tC2EXi2ErPD6/kBzFue5J+eTsUUHdM6Kiav5QQec3ALmhCoLhIgoblMyNkMzlAVdCGoaJbRpk25gizO4nW332EIfnvnxxeCi6jiq/cb3atOFSncdGFNkVJPjWy+FftQ0wjLsfOgwSaSKEZBemvogbb96tr923R7U7YSretT2mI2cTYIQw6aLRYttdTMTiuZOPk+2QbcxvWjPmtT/7ud/M+S6o3YkBqMysdWVqWRYs48KkkRftjqx90Z35/9dfTATDClNzS5ittxHGCSZOnjwC+EPf+e59e37lv/8KNm4aIGsN/m+fdmWVlRbNMEwwOTWDB545yZoCPnR0XDy+/yj2XXkJAIZCBMtOKjo/71BOX6Pp006lNnrMhDjRaNZDTEzO49zkPJptbcsja8TpM0f5rs/95b8vTk5LcisvgQzyLASJoAh2C+n6M8gDilJZS7fO0vHoyPxQdeL0qeTSDc5ILMGusUQWMGKFadefXLAKh+hLOEDPhaT3fsicbyPah9PRC9isq1bbL0JV758syGafC1IJiuH0YemFXcl/kVRHvQF1hQXKEkQGki1gBdqzPqrPhda2HPnUNH035JGblcrtY2ILxxVwfcBx0kBjIgjSZDXBy8URcoHQbh5SZ+S0898XZ9MV0SrEt//99utpVq2oOV0t9hpFwf3mzylBRlhGuKi5dcKIZyeUvuuE/FfP1R/QWlQcdgzpuG/EfmGR6U9Z4PTFrjQLtk/qAIJl+393n3Lf5EN2xZ3QYtmtaNlMmflFv87VVnUO2IKSbtdu2GjX/fzukXUY3gXYCuLZw0DtMRIcwbICs34hNJI9ldBAo+4kM006DEUvZRbL2D9IgUSMwVIu5TGoHER5PZx8Ga3TNTxy7350/DW4Tyr8wxjhiT+8HVsKGpERF7ycmRhMMZzYRaAcdITAXY9M4tR4BExNY886wuV7hiEFECkPB6oJvn6whQfPWhyei3BTaQGfedcIiijBSAskCa7aWgJUEbHW6HQjkMghEAQubYT2NoH1yeWVrpCU6aJXuj9PCawbSER8vAlm7CqXMUBES72PSCGxXjeJ0RQJJUiQi9OoCNNsAdMLcEiAXAe26FJS9kADAQnPhxzOARsUs7cOA23mgWabdtQ7/vX12LeduBiG8Wg9DnHONsLjnYXwbPP44mG2Zw8Lxxv3C7klf9RPcls1/GIRTrkA8hlJw6I1fhzVZ57b0z12bB+Kb9glN91wjRjAZlk2g24gg4ESiU6M5OVXgAZz6Jyt44nnF8COBusOHBiYdhtvev3LlOsKhBEv04T7qfwmStCoJ6hVI9GZr9Lk0ZMNJ1e5JG438eHfea970eYR0W3WwcJ/gVvDhaa2HwcG///zi5YLKv2XP9cjGSRMWKi3cPDEOYTk4dT48eTciecfVLnRYOLs/OuPHJ3ERdvHEHbamSZsZV1yoQmwR86RREgYqNa7ODk+g2NnprghAlvMxfKH933/t7l1vCmdD356ZKBi1w85ohi4mSF6XwHoTSaUYh5sDTraoNUJUa21MT9fx/xinVudiIXjkz88JJ5+4qHaV/7uz+9pztUc4ZavYVFeT6IEFgrsFcHCB/lFWCeAUICQASwpkOoigRr8+uPFs5furY+IgQhWaijrLK8jewD7BbVrvaJmUpu/VadbX/FbxqysXTEDzyaGldSMFeYs8WorZdt/PbKFsJk8yJp0QpUi7WJXEYZWnEJ7X5lYXkf1FfSVr7dPP0cQsBBaQdcY5450OayBDje95tdPdP5MOOoPjCqCiBiOB3YcsJQgRwEaEJSAohA7d7TNwEBORKICUGPlCqWVWZT6sEnKSJ89OGAlwHV1xl9/3FF/4yB60UC9a90y0BBYOqzt3KyQJxri00vJ8CY3779dJphZWog96HT1TCIVP5jzMe7zmLapvGL1a6ELTdS4ME6+vEXoo/0sJ5sw90lQeIXswT/eUjD9HnUvW1F0O2023VPsLNRBaBFsNe27rEjTRHrENpvZp2XYsWVmJ3aoVrWtc3VxSDowbGW6zxeKIB3klUU5SCVbkbYQjo847uLSXWU8+bm34fixGTx38iz8coB1LiHRThbGfIHNUeZp67oGJ+YN3vcXj+PBKZ2ev91FDFw0igXt4MkzCR6dD/HsgsVz413UF7twmnVICkFmFOylOmqCRBh3gWjFEN2SA4fbSLwyyB9JV9a9RnL5vsx0qJAIEmD9SAwhujBxbrASrFlTr8+sFEBr7Tgcxefylk93m9hsHERkMAgXPgt0hIHQDLGQQM43IZlhHAHrSMicRyj76OYdQj5IdRkbfZDjsGOA0Y6mtV3yr20kvq1HlahdxaJpYTxqmTONuejU0smFcUPNcenYGnGLOKxuMNUz60lccyltfceVchRjbsHmpKKgIKUqesBwCcl8G2r7RhADB54ax8npKmjAAXQMbSPkhkr21pdcTcaYVCvWFyXGWT/W1cBSQ3MjTmhm8uh0t3vkm6Jw6eV+Ba23vuUVpBPrMtxVNy/6Drfzi+HKelP0oRhmVY4ZryJPr14HEjEkETqhRjeMMFDKZ5ZSYtXKhXsSBsvZDl2j3Ulw5Mg4lqpdKwcr4snHHzzKpllzZGVY22TwO9+5O7z9Fdd4VqcSLyuo71yn9KChFXSKpERiGbVGC+PnZnF6oorJ2YbVjiuaeknuv/d7f3zyqW/84cmncMXCTHTgp973i5ecm1YYLDBXSnnyHJkdhGL5oGhpi043RKfVRaPdRr3V5nY74TgRDDcnyS9QbX4WT3zrrmP3/tu/PC3gVoQ/8FKG9Mj12QqHKFcEVAFw8kBQAtwALBjCz4NbOTIsWAZU+Zv7R5Y+cP1CPLaP3VD1HEt6q0GxUpAv1HvblW/q/D6Ez2c99IQgdqXQ9QqBJaC/0nKf8p1NeuhKK0FWAkJDsEVj0kBIRmFDatYtlh8oZd9a6ls8EVYZRacRWqkrXFqsTcrtJZGRd4B4kTF9TGFpIrJMgbz7pPjcRGPjm1UgL9KCACWFcDwYUmnMk06AsAM2Gtypt266tq1kcRDclsycUE+3hqwGSEqJF4YYyq7oTSWnK0BLNtX1960W+wkky+kGPY/pTCtnejhXbFA/Lbh6BmL/AtX/8invbun4N7IsrtUyPrR0LlqPLkAugazI5AGrCw6tYqniPLu+bE3aW9H3pSxQz3+U5fKk+sKiSivONdRLOOhjZ664g10Yc1g1AmY6Q0uQrEhRSERnAbhgOCn7l1NoZ7nGEoEsZa5F2UUeSRo/ayciHS+6voBOY3wgyYM2jDXDFQwMFAFOoKyF73twHRdJDFy0MYc9O3biJ7AbBoS424TupZ/0S1MAGJGxkZHyI3710/fjwcfauPINuzCyTuLuxOLe8RZ+6R9Oo14axuHTc8hHdWwJqnjDuhxedtMorty9CSVRARClDFNIsJDLLoYpRqpB1sJIASuLy9der+in9yOlK2Cy0AlhtMJUDoRNYohSUY1gBod7n7aqt1v3jXXCn5+qKP7X6hR2W4lCwthIeYxZFx4TiuQCUKkvJQQEW1BioBsJxFILUhOMArSrIHIKNJAjWc5D5HPQQwF4Q46NJ0C8AWNdi/WNUN7Y6OS4EW5KqjW02y20El3uWrOeCJfmlYu8m7Oe40EERogBAaow4DngpkZiYngjFQgCHnn0FNqmA4kiAILpdnHx3i20Y+c6SkNmxWrWJQiJJYRsUQ9DbuqQ5uZPPw1U9to2rrnqxt0zmzavGQ1jDYh0J2+4f6WStrX9LMrV90FqIbYyJfaZWvWnOp/nfsVI6euzS00cOH4a11+xC8NlD4bNC34WnLKloiRBra1x5vQ8JiZqLEsFcfzQk/P7H/zmnwo1PBglzttEvuz821e+ad90x1vpyss3g7ibCoNFFisDghU2tdvSQBRqLCzVMTm3iInZKuaXOswUcLE8JCamjuvv3/Xlr5965gf/Ip1tn4LKv+fub91tF+fr7be862fk1MCIr5MlWE7gCMtKWAghwVliiE4Y1hBb4ZD086R8RY5KsDBztv3Uc48ffvR73z3XWZgm6Yxca4VzEeBCuDkYqUD5IigYBLsFiGIFyBdAuULKdywNQjUWYHQTMshhYn5k8O9+NDX3O+ubG2idYVZMoCTTX9H5Z9YyWbw/2LUXAXW+jyb1H9qEFS9Me94ivGcl178eyqKrREZFt0hTxUVsEM0xph4BEmLe+UoiLipAJBCw/RUvw2roBRirhslk5Wnnm6qoNBRLiDhBZ5owd8Bibk7rvFLq3075D3xpv/qmdL1/0qq8GYItO4FgtwQIL82JaicQeolNN6J1A43qG1+Rq7DdBUHPkOA4fcZM+kDo4VBp0aVMCJ2G0WfyFiuWI6lWHILsqhUoBGU6HwYLC4KBNKm1X/NYAbPHumahq9Q9p9SfLXX89Y7LtxG5HLuOE9UKTczXR7E+dc4x2fpZrCIPiRcUoZXEh/OcmPqmVksG3Hc/049hM1M/o7snXuK+BA7+8Zh/uiVYBrKQet6mBDSQARnOLO7ShqPX1BEo1c6xgbUEJ2aOlwT2n1FHgIFrrfQDkGEQk1ABEkMYXTeIgYECYiMQhV0kEBBKQrJFlBhEic70y4CUHmQfpksAEsGQFghiAWsETFni9JklPPTEAlShgursNGbqGgIukABP3PMwbrpxM27bncPNewZxxeaLMFIchFIMnQY9gyD7Qqg4ZYWuILcw8MACqQ98r6mwGc5vGaxlasItDeJEIRAxKh5xx3fR7Ko1AHDHHXfgzjvvhDp0/MhdxXzumeFy+cpDI368P99xRqBoTbuJkdiiCIN1NYu1nEORApRcH45yoEjAJQFHqDTklgSE1qA6g2pNMJowimBdBgKPVCkPKuXApTzinAsaGQa5LisDlJsdqixEsF0NjruWtCYoJWTAiDbVEY9EENbAbSaI50LEsUAwWASaFvufPg64CmSj9CtpdXD53u3wfQ+NRjsL7qVVaQNEQBwbNOtthK0WFmdmTpEsrmGjeev2zQOuI0W3G6dWb1gdTtnPVL8QWxLLom9eZkwt+/Tx+e3eyu8NA/NLdRw+M4n7nz+OZhzxrVfvQbmQI1eJZcq0BCPRFq0oxrmpRZw8V8fsXJWVn+eFhQn+xpf/4YvooMxu/g7I8lYZlLhZq3t/9ud/jT/+9O9CcheB48KCoLVGHMVoxRFaXY2lxTYWF5poNNocJRrS8ahUWUON5iIdePrB/Xd/65++MDc+aR110e8k1n891KhSQy6eeeLZ7snjB8avf9ltxb1XX1tes2lj3g3yJGzqEA8wfJlau2mTUKtWR3V6tjYze+7suXOn7nvyB998rFGbWy9ozfXKHdun4a6HcJikTwY+KDcMCoZgnRxQrACFClAYgMjnUtF8UITwy6DGAhnSTOXR8p8+umnpTbuf72zfp3NY40AJB4aQOumfR2ToCfoJ/RN+DxBaOfZY9KYBWlnJUTZBn7/B6p9ylklRPWcWBQgLIwiIGOEkYeIA4ewRw2QlDZUlr7kkIjHAgC9hevIMtiuDOq1kCBClYdMr1TklIzkhw9Zj1Mc9zByLUa9b7blQ/3kmd+AT96k/V+7A7xunMgzpWci8EH4ZrFI3GUpa4KRhJTdEPMOLH/3t550Nmy4uJZ0yq3CWiOXyXrhH3V9+f0YASCDYQiYOtGNBll7YTGRGD/2CCVjukwVYyEjAVAmLxxkzB2PTcUh9db86/qWDo3ml+M1sg00sBIHLlxyabyy+6mwb/iBxktPEEJAsVsC9ZSbsheK8+mGM3uKGsmY2fZVKO0iEgVEGrpUrgcCUsr1XSZL6/XGX98P0Y6VNq8ludlVdpT7rtOU1A+MFHqU2m/yFlkDb0onTwIOnkofgFD7E7KRXplQE1weMwIaRPAqei9BodGefh8jtBFGa58i0ssW5EBDd424Ly9BKIMm5yCUh+PBJeJ0Z1GSAc882YWUeCh2YWhVXbevir3/uaqyvSLBSiDmCNiGsUZCSUo/dPmSZAEAEKTxg4tTIgVN3IdfLJI29zUi6EEv/kyvDgmctijlw3uThNrobAWBubi6dAAHEM0uL74LFPw8MjF6BIMRS0jX1ipCTgYOLrtiK6nQVJ88uQSy04NUayMWMQsQY1RJDyKHg5uArB65QEMqFywKSCZYITgJQmMAstdI3IwnWkRCOA+H7FA3kID0XKp8D1hQhKiPCkgG0RWiqaK87DTFkQNMJ1JIHW+1A5MZAo0V0T9Vx8vQ84ArApg4CsOBL9myzAKTlF8RYLl9oSWKRJFaEzSY3l2aOuV7u9qhD5HmqDcCz1oJ6fjzn6/nOo81fkLLOFgaEZrOFOI4xOjyUreJWSAogsez2UWu0cPTkOA6fnGYnN0T3PbyfFmca2LlzBwqu5WKxRI5SsHGMbpRgutrE7GKdI204V6mIerNGd/313z49eezEsFRr3gJV2mKVtBoQsjKAu7/5nfjPNgzxq9/yJm9+ppq+TkEcRzG3QsOJJhhrSRCR6+XJcQmdVgvHHvnh8cce+Pa/HH/uvgXQ5tdItXZLQt524RUUXMVG+lCju4JG1N71/bu+2/jBv393/qLtG8Y3bt3SUl5QFlLkwRR3o64xJl5stmsnpsfPLC2cncmBwzzgjkGWflM52zcyIaeV64B8hvAIwoPMDQB+BUbmIXJlcKECzpVAhTKs46Q3S7EEzg2Du/PgZImUVFhKRtb97gNrzv3VyMy2XJhwbpMkUlkxslkRzNbj/Scz963kiLEc58L9GM6yHZdNWY/8wtX4aoNrWrE8o3Q56SUKsiGwdDrGucOEqXG2LTjikSkvnn5cui/hJkqjZEvrpZBFAtxkxcO0Z6BMnElw0tWcYAJpAxExdIOxNC+xMEFYnNXWiSxEEKgfnpUHfuce+euOk3stZP5SloU8pMfkl0FuAKtjwBgoaEAviXi82nrXOw9N/MI7Ry5J7F6m+AliHUOTl+Z1QqxoAXtRZz2Dh9BBd4IRFAmqLGD8JNuqpNZkJPr1imkxTRsHCxsBqDmozQGzpw13561ml5y7TwQHP/eM/W+usu9LRPEqcnJrpGTAWVt+dHquNXVSo+y7YmCvAxZxOr3JF1l39xcbvhCVaIXdLdoCZslCDSiYon5R/PxCJKdV0pWeldrylEj/F49BWHbV74NNVppouwqSsSn5hXULdOS0mf/PM4NC5cSgsAStFEE5YDcAWoQ929alea3dReiz98HdsyNdRVvqW/NmjQpzGi9GK6tk10okgYQwHfjPHET70Sew5f5TeGV1Fl/sAF5pBBYhOO6CJx7FG957B9aMFBGGbWgSgAjgwoJEfwORPp+UAEOi3glR8BwU8y440Wh3dWqbx9HyPcFgWJPmpVudxpOlTQzDJ0agNKRSUJ6T6/9sFQAxPj5+eBzjL7384kt/v+R478h5udGC52LQ83H5ur1Itgl0kwjddg21ZhWzS3WYmSWI2QbUQhPFehWVpsUaVighQJF8lJWPQCk4QkIZASMdSGJ4LKA0AZ0YSb2LZGY+S6aREK4LUfThlkvgsSKcfT68oWFwOQJP14ATIeKpCO0rCxgOXMwtTOFMXAeUhUEIshqQRm/dOpzaJWcLJD5v6JJMkERwfQVqt6LaTG2f6w6/FAQcP3HWhmH6ZRgYWCuXl5jL3px4oe4tjViyYMPQoUXIBt04wslzNUzOTvPVl2oeGyjDkUoIYmgw4oTRCQ1mZhYxfm4eZ6frlmVAOp7Dvd/6t/9zqDQw+Oq3vee9GzZvlvpsHVpr2CTls2pB5Pg5kq6m00cO1r/9r1966MyR56elHNxnlLeFlGNJ5gWkD1gDpzDo/OPn/r65WG3Za172qsAJ3FTH7XjkuR6kBuIoRK22iOnjJ7tnjxxsnXh+/8nF6efvAfyO8re9yRhxrZFentwySOSZcyPELGCiJoTrQ43tKZmwUTp5fC46efh0C9AmvXNN9n3QWkCWANEUIudBVXaCVI7AsKTAjp8xDx0irwLyK4DyYR0FypcgiyPQuRJQHEnxP5mNQ/k8MDiQWvjFdcBE7BYG3a8f3sBvPNg5+pawvasRtm1xmyeEJ8GcpB6OWS5kvyRhueDxC63bhD1vfy0y3VjPAqx/TdozJ+fMZs4SBHRKzOgCrekYtZMCs1OMRtOaXCEnHz2L0396sHXba6PiTaJU/sdr6225OBXZ0oikQpFJFCQ4MHCkgIAASQtmiSTW4K6B7hLiFtCpEdpLxJ0Gs2GG5wsx383j6RP0hd/+kX8n3NJ7rPDfCOn6QjHDdQlCMCWAkhGx6iJpxUAjmviFnznc+sPfji72C7fJsNWG6pxIcUtLECxhmdJGoA/jlFaDQYhjgZOPRRAgO7ZdifwI4BcActINK1TKrmWbpszYWIMjQlJXCJcMGgua2zW21ghpRM6554x84JP3+X9mndIdgLoZjj9qlcNEOcDz5LPTXmd8weHB/QmE41J5KyNyCVIziEzmB0p9cUGE/shB0XNF4jRAOfsXcEKB+SOE2hnGtpsNpJfaqwkhlrFW8SLkN0uri2GaJCUz/aGFsNnKl1YT60Rm70IZXr9KUdW3R02ZBpTiZEywEBBGwCTatidc+dhR8ZBF8R2ukGORkpYdCAT5dNJ3lnDZ3nVgNjDtKdDC4TR+2RhociB7pglQkMSIZAAXHUgAmlxI0gB14ZyYgf32g4h++Dj0xDzaEw28PHBwP0mcObsAyC7QreHlt23Dz77lBoRRCE/qNBOWRfrZkVg2VBAw0HChjMV7P/8s7lsqYMf6PHaVDd53XQFXDucRmQQUz8O4WCaSsbZZXjrDipTspsBwFCBlup4X57F3VNY+CACN5w49/+EgCD65cf36Xywp9dGBbTu89es3wHpEnGiwHkUcttCONDp7E0TEaEZNtJvzmJhZwvHJecQzNYi5eZRrMcZiB+uti1EOMAgPrkgzAoXjQZCAaywkCTisIJghwhgiSWCqHdiJRfCCA6oYiFEAQRHtcAlLURNiMAdqxlhsN9ERBqQIMAQ2DCiyxVJB9S7ylNFIL5jS8oGLgq/guy5DqI2GqSRyHp595iAfPTHd3bhlOEjCDgt4ZLJIH2NSTMtxBLKwlgzry4SfxNCCsNgKcfD4DGYWFjGx2OZ6FFPT+rR1TReBI1nBIgljarQ6qDc6vNTsctco8oolUZ0+g3vu+se/XTjx0L8sIH/zudPnjt3+5rf52/desjaoDPuFAV+wSRC22hg/cbx+9PH7Dj3yn3fPAnJAyZGbtHA2Q/hg4ZByfbB0YeMuEFRIKq/0rX/9hn7k4ceTiy/fYwcqxarj0hzYTtXrjYnJc+faZ0+dNq35qTUAD4GKW6S34SetZddYdxM5vkvkwYoApjhIVBlKSQENAY6asNZAuHnQYN6DjT2OO1mMlQEjXKG0M4NZWCYJCGmlEJQGzDokVB4yKMIoF9ZJMUAqDMDm1iIpDAOFPMjzU/mDEIBUKSGoMgg01wFxHbrVJSmkFaXRi37jG+ax0Z85OnN1rNcsVBNb3KWEWyGQ0OkK0mJ5GvyvevEXcBfsStajoNVJFhYKBJ0yEpE2XdSWSJYMlk5HWDhNWGyTJQWhZSCfOhXf88knK1+R3tZPfOc0J3Pdyf/9m6+ovO0SNHe16iFmrQcX1socID0NQWnCojWW49DCdgnaWI4ZIKOkI0HWAXVCD+Pj5ul/fF7+/b1n1+4ml38dQt7EsiDJyTHcCqTjwpIlrZeAmgNEneZFm081fv+3ziXveENhp5A/IeJuFbL+fUgbQlsns5ej1Z8Nr0jVBQFyKYLpCCzOQbQWEi6VYd2iJTdHkB6RUilqqTUQRRpJmznuWGhtOGQh8opJ2kAeqfnVJ+fMp//kwdxBeAN/KllugvTB5AFOHix9FgI42xzMPbIwcOAducalE/u7loQU5XUaxs9YgczLdWbZJ7XvXRhKUlcnTskkyiSwDcLMEYePP6btZAMitwm0LohgA8CSBUsHgl8813I1V0bCWJl6axoLTjTgpES31BbOvoih7v/FlGnTpgtkoTqWkxOWHnkGzX8+HPyrcvmPDDwwOUSuC/LzMAljuCJw5aWV1Ju5NQVdPwkVpXImxUDBZcApICIBL2mCTReWXJC2kK6BmJ0CP/wE7DcfhXp6ErXJeTwLYGbfJqy74xX45Lrt+P7DR3Fipop4cBNufMmVKOVduEojEgXIjMHC6H0v1LfS1TDsoH5uGhPPNTHh5/GjpRgLrx7Anb95O+z8BISeBgdZc2okTMSwMWea3TTNBkQwNr0fL/RL9SHRdPXVV6unnnpq6tiJE7+9aWzk2pre9IrymmFbLuaIWcMkCZIoRjOO0e10EDVasMkAooFNiDczQjbQcQut+hLmZ+ewf34BjywsArNVFKpVu3VR0/rIpfVRCYPkgxxCQD589iEJUJLSSZAE2CTwZj3IRYIcj2D8GKiFOGNrLIcstrChE6aDOmJI4cAYAWYJz/FUPucT2xUfzVWElWxvHrgSAwUfYyPDys/ly2FMLJVFc6kafOITf978vT/4H0E76lIUtdkawyndWQhmwmDFw/qxPEQil90M0g5SQBFQGSyg2uzi6ZPzgKeovjQXH3nqkWcu2TpWuOyq6/fC9aHDOLVj8stUzg2RnZ/FoafvO/qfd351sjY3mSh/1x+zyF/VaVnv63/3+YNerhgPrx2loZHSGSn4xPz0jJ44fYoAtZdU5RoBudYKV0J4gPBBXom4MJDq5dp1mE4DcEqQoyW1sLCI+7/1IwvuuECrC7RPAGYW8EuAn1NOZT2T2mZJrrNCSQgXECkRih0fojQMWxwBiwDkOBBBDiKMYDp1cNgGxzGIiVkiE3RbCPbTZoHT7AkIIYgkmAQMEeAGEF4ecAJoFYDdAJQrAn4R7A0DuQGQ54DiTpboPgTr58Ayc0EZINj2MFS8ETbpwHbrgtwKZlX+qp//l+lv/9Xbk6suq2PL7IwxwUVWlkcduAMM9jVYMkSGadlVNmMvXIotSymMTb0qexuGvhUgmCFZgIwCJQzbtWhXGfVzFtUZwmJT2FJoMFgQ4lTb1Xcd8/7qC8+WzwpFb4al14hgAE9Wc8ff8YWFx991DT32mj3JpWt9c0XZJeF1CNSUiC2gdZIBIApMgBQSDhzUE4OZplk8VnWe+MER/9BD04PrgWSto+wbNRU2spIMlQe5BYKNkSy268iJ9uhwrK+6fNr+9Gub/qtv4eGh0Yu9CLcgiY7AW/qPNP+SBThjpi5LSPqm5VRXntqPiYbCk5OOOTrDM/u2Oeu360RSSyNupas0sAbblLYuUycPCthCCwe1ROHMohh/9oz90V8f9A404/w24aoPETtrBYQ2MpDk5ImdAqz0SdiEqbh2w188Vz9x1cZ2bWMkKiefBm+al1TarODkNeARtJNp5nrwA/WxuLPtlEjSpPnOnMS5QzFPndZ0bMmVFY6w8CxzQTlU2CIg8nG6YSJk58ALsbye40vq2KMhOIHoEGqnGE4gkN+uEMkoNWR/0bUqnWdbmEq7VkwXUsYwGwNpge4s28nnA/nN5/1vTDQK+9xcYWPCDguOycoShJsDOiGuu3Idto4Oo5soqOZ+VORZdE0bTBoQjPuqDr773Dnc/cwE3n/DWnzopnVohC1EuQDl548g/IdvwD02he7JWZxudTFx4zb4b34Vrr71WgyvryCnXdxw015MLXXwjYMNnGloPDAZ4RXbA2ibhjzzC6BFC4aXxnqpCP/4P2/HsaMzOHhsDk8dXcBbbt2JrtGQ4QwkHwNcmU7HMWC7BBsLIElNE9LKKJAwI0oI1hpoa5ILFUAA4KeeeioBIK7G1XI8PvUPkwtzL2+0W3JooMhMIDcfwBcCZcuwVqPd6aLb6SAOQ4Tt9P9GOLBOBTuGt4Itoxl3MRPXMFdfpBPTE9g/MQUx14C3tIS1zQSjHR8bkgLWUg5l4cIXCkoQFCwcnUNLMKqmgQM8Z+4Zrovv7W6an72xYl+ydsD1RwZhheohpQATlCvDYqmojGVvGWDvB7ezH/WVxLqxAQyNDSg/VypFUSSsFXCLGwp3fuU/VDdJ6q9+25uLs1qIestQ3Olicnycc6bJH//ou4QUaiW6JAPyJEsoy0g4wWA5sGUVi4d+9LU/PHf24GeqJ56ffBjYeN0tb/uTLRdffdPQ2NhgkHNZczI9dfbsicfu/v6Js8efGCeMvlypkfdpKvoQOVAgoXIj18S6jcnxhWTy5FQO4N0AHKHGChCyaG0qbWAhGY5HojAIeEUYNwfySoBbgBAubBjCWAMVDIC9kiAdDiFpDbGNr0dPS8Sp8W+6isxuYXLBTo4QFCFypZSJ6RchnTys48NIgP0YnC+CwgZEuwrb7RC0B5gEbDRsv7qKskRf4YCkAoQESycNJ3YdsOuD3IGU+OKX4aogTVlvzoKSDuAWQcMOlO8hUUg9Hx0BlIuwtUGI8kboOAInCauC8c61r3/DW7+4//6/eNVk++axaG9rv0aznNjCeojyOoJfsqCcgZaqb+spMgzEZFyY1ZFCkFiObVpGZUwaBApN4I5BUpPoLhnUqgK1eYt2g621CoMuiVnPxfEZ//7PP8b37K9WhhxP/bZhJ2el7EKxq2R5hxTBji882znzhf0bDtw4Ojl13fowv30o8YaDLksSQRj7FdcTLYGkOd9M7FzDW+iQ+8RT8870D0/pyCbllyEQJTdnt2qTf61BwREOGXh5SW6BtXbI46XDv/+bE/Erbuyu3bzGKQwMjRSQ3yaQbEYUg1XzuyQ7T8NYmYqubaquo0xQTX3CbsqCdomB0JDpVpU803a//WcHnY+/rKFvuXaTuHpzxayv5DCcGLkt7ziqKExsrbUaIiSD2W4o6gfn8zP3nXNP3ntSPAeMvlP54S96PpctuYOGckaLgqLABTkByMulyRVhE1JAzHQ2XPeJH9Yf/9jN4XV5ZXMTz1ubm2WRW8sYHAZUOXV4kw6DJcMSAyxhtQVFDN0mhHXC3JTG0kmjm0tCHQ69pW+exv+8cV3hd7Zxe/DUQW03tIUY2SbBJYAdAyiARWq0Qbzi95Oasae+mDIRsEsCk8ctH3nY0uh6YM8ggQZT84OUzakBomU3pRfqg1N8OZUfiNSjlLNIMyMQV6VdPG7l/YfU+D8fkX8rXf9fNOdSTI0AdgKQKgPmXPLGW7eS60jVjZtQzQeQz8XoNI6BaC9OTkR4/e/fh643hKuG29gSpJpg4fooVmto/NU3IX90AIeZcXK0DPu2m7Htp16NNRs2oMAeCAZGCJQ8gdJoDldWE5xrNnHPyRa2DfnYUAGMNhlJ8Tz/Y2Eg2EAbFwUWuO7yDbjhyo14PyuYdgsNnUB1DkHIJQAehEmAGIhqjLhpQQnDQaYrFYxWwmh3GFGSwMQ6fLECuFwIn+QnNRF9dSdt+cV8IX9zYaBktU6k1gZJEqeIDgmUCmUMVAZBAjDWII4TtBstRJ0QSZKg2+lAthwU4wA7g1EKh3agvTtEhzqoJU0s1Ko4NDmPh89NQ04tYGxRY0NbYL3xeBAuutyiJ71F+6PBpc6pSx0Sr9ucm8KsuuiWayEg4anUsBdkso6OYGFFYjJDqb4omX5PRilSOvTgQIEvv2I3bdq20dn/wOM1d3DrgIFr1cCI/x93fbP98L0PHZaDQ8V6qzEZL86cetlNV2/69d//jeu2bxxz6s1OGjDfO/4sZ84RAKxAlDAXiwNAK0yqJ57Xfm7bz0SRvuqxBx7d+tgDT0hIpwFKJqDn7wE654CxfUJt/oAld7tWLoT0LQmHrLCkwZaUJ6R0HcBugDVpYYGGZcOQCoAi8vMkCkOwKpdOUF4BlBsEQwGyANlZgm3OwXQ7YBMCJuaUsq1WbOKIickyCwlIh0g5JIIC2C+BnQKsCsB+GaI4DOPmYZUPCAesO6CoBTg+4PqgfAgkGqQTCKtTzRplET2CUr9NCDBJkFCA46UsTzcA3ADk5CBkAGINvXQGXFuAMAmMjgCtgGodorsZcuMYTL4A6zgQhTLkYAzNCQRp8MI4sbbs5lyn61x62wf+w/vu/7jm1Nk3XixvcWNbmD8UYukEbG5QiuIgIVexUCUGfAIphlBZC38Br1MCgWMGEgETE3TMiNsWumkRt4CwzmgtMVpGWGbDAbMs5h1RSxw8MOsc/foRfOOe00NtKPl26WFrIoMcOQGEzCnreDDwLaCE4PoW2+huefjc+iMPn0uOAY3nAQVIbzPQCgHXgxnwgWQOqn0xdG4dEF0NoAvYAXTzN8eeKik/MWBHwi3DOpKBgApq8vj3/noquPHm0T1wbwJigom64FqbjX6CqHWKjFkErIAwKVpirE6nzUxO0AvHsr0oVIv0upyzPD/lohubb0tZWn/vFI/dO1G0YDoKRE8CIYDuYQlnWy7wr9WxmO0a7zBgHUBvhpP/AHlimKPwqA7zZQ1Zg0s55AuBCgy0zAEqAHk+iByw9skmTXZyXv7BhU3bfv378YO/e2v9hh1rTLHeSdA9xjY87ZAqGHLzBBUAUjEcYmjNiEKg2QXadcNJ01hEkEL4an/HOfvnT3p/Ot4c/GGLTh7YvTH373sDnTt7OrLNJonBUYtgRMAtKiAwsMouSyWsBaQ2QEgIlxiNquHmaW3nZyFPTgkbhiwGn48wultCDlqwTFlApodPLhPwzhPq9/I8s7Bx4nRq1bPEzUOaDx3z4785KP5XWwy8Q8hgnWDNrFwyfgnSLcCIAMWgZV+yrUWJsXAbJ2EXnwPKBL95BDoERoba+OsPXozdm4Zw8QYfnnHRDJsoLDYRfuk7aH/1CSxsHkDtHTdj50uvRbBpBKV8AR5klo+rQJKgmMDSwZ5NI3hgGji5mOCHBxbwzn0jEEour4jPD8YwEBBkkJBB3AGsMQBF6NnvU/OeFEvWFtAWHFqgQ6AkbUy1BTgBlGNRCxUaTaaYLKLY1v7LAvi2t71NAkiSJL5HeM7NQb7AURwhkBJa61QDGCdIkgQ20RCuhKMcBJ6PfL6QRRwZREmMZqsF3e5ChAmanQglnYCMhgLBDFu0toeomxbmWlXMLs7hwEIVDy0u2nO1aZqmWZ7ZEsNuLuQrowXatN1Drh5AZaaIrkr1cAkEQBIkXeiQ/Ga9vWxQfWGWVYof5aTAJRetw//83V8tv+stH5hqV2d85EYDgAE1NFRdnPaweOyh19x+26kPf/jjV77qVS+7Eo50l5rRMjht7fJSLNOeArHVCONIyFwBhtw3AANDiXXfTCq/RgU5MLlgG8GacECq0t7MtUEweQrkgoQCi0AgKMDxXVhjhY0jWB0BNuJewQc7gPSIpAtyXMArg7082FGAnwPnR8G5YQjhAX4b1g3SCKGwCoqqoCQkJN3sY5IpDiYkWHkpU4wkWDmwygMrHyR9wC+D8oOw3iDgeZCKAOnBmCLgFgEdQdgEMCE4CYE4gtUJmHV2s2LFf5MUIDPLLSeN3yEnAIQEJV3YxgK4Ow1qh1A6RLI0gTVjZbz9vT+B6SWLf/v2fjjJDqjt25GUirCeAJULoKgI5gFg0MDMnSSKOlBOkXnkktd84pmRY18ZP3ff7904t37foL1ECqPaZw1qJ4lNgeEXgHxA5PoWng+IwKYyHykysku6+jPawoZA0pWI20DYAeIIbCLAGtgEBMkscz6EER5OLYlkvOnff99x+/S/n3AeA234hPTtLuY4MqLowfGZpUfseIAMIKQVuhlGymkff/vrO+7Lb1zqFj29aWbGK3z5O27w5LPeTllYN8RUh8MKcZKDI+TEO15d2/Wm26q0e5etNSI07vnhwIHP/FvJTs4MXyuHAmm5wsIJydSWwt/66DxuvFltiezrrGxooub3ySQnIXSVHC1hFcMilTCAbUYiyLRWfakNaVMpQJZTUkgMmHGSU7XAfu8cjRuOLnaCLb+VxHmQ6Bx72fXh6dfcGB7v1rxrvvWI237y2YDh+3d4getrRJBUQtzuzDCir952o91w2bZZpZWInz9WOvHAYVnU8dY1ThG+kQ5bERCTArmANTGRYfZK6zY90y6O/vIPDn3v//ey6o5r1zh7cm4smomCmU3SZKply7ZUEGs0kzQMK4SwwpHTibCHqurfPvmA+0DLjnxIefS/H53b9jf2sfCbf/Ta2k9s9pLc4pQ19SkSuQGm4oBBcUgjyBEkpYb7cagRNgmNeYv6nLBx24gYRfnImWTBZz3sEfHceELEhIGNBG/EQgSpC1BPgbN6Fc8ZOS+dsgWnxgLclmhNWCweMaY6XVDfPmX++NHG2pe4bvFnDEljhCsRFMBBEeQWgW4bl24U3tb1OcS6A3fiPnAyi+JmF8nMQVBikC+M4qdudGE1o9VN0JFNFGt1NH70BEyk4f3eT6N87TYMbF2PvBvAdV04vU0UpS5FlPnBaguUPGBDXmFuOgR1U9tK4blZysyFj+melloQgWTv3nPgdg8hiR+GcBU0a5AhcAuwnRXXHzYZPOEBc3UH9QTESkObeAIARu+7j1+sAC5rJLpJPN0JuzBgYkhAKLi+B5nruX0bsLGwSYwwDNENQxiT0qqU46CUL6BcLKU/qzXiJIbWGmGcII4jxN0WvHaIUreEdblRhGM7oa0BdxM53V7CVLyAQ+Fx/LD6FCLRxhQ0jIoQmi4AIHAdOI6CtgSrEwjlIo4JS0stTqV3L1YAU32EApOwIV57+/WVu+/7Z/WZP/vi1PFjs7nEGDkwPFC58rId7utfd8sNN1xzxatcX6KVWHQbbahs5bBa+5NNNsQI4xhRErMUTMbES4BUQjijCSlYygLlpEuQrrI9kiQxGA5IuEDgAkEZyBWhHQmCShmuJgbihGwcAzYBMUOSghUK7HkQngfr5AGvDHJzIC+d2CDdlGHpFUBeAG7nQMkgYGNAd1Oj8J55NxGYJCz1lugOyPGBQgD2A5AcgHB8sBKgxhKoU4Mol8HlMdhiKTMOMGCtgSQGRyGg4/S5eqG6Aqkvq0ibFkgXAgwBA447sJ0GbKcNYRNwFMG2O7B6Fi95yVZ89g8+jL071qAVSVS7Ddz9n48Ak6egrrsRqIzCBC4wPAiyXbB0IZQLMz8OiiISQrEzvHnnyVZx2898feDQTZtP3/XTl7S2bSsn2weCuCKMRHuR0TQGipEa5joiS6dmsrYv2BfEhgjSWAiTcvqkBElHwnWUNNpiquvFc4vewYNz/PhXnxdHxuuVdZDBG4Vrf54pKcEiEaoiWOXB0iPh5WAdBQnBpjbdvfXyxaOf+4OlgV27k03wL0rb/u45/PJPR92v/mdj/8981H+CA++VcRKGO9Yufu8rf17fd+VNagz+NRIcrUU4g2svXsKH3hTVf+1PaPLvvz+yVpWbvg0V3NzSsbfeOL3RNnaz9c6SnP0SEbpw2AULCevadKWrMxu5NFkgi3TCSgQS96W4cSpcDuccMz9D4thC87Gj85uMm5fvidu2+tqXzzz4fz7e2rV9U+Hlrj/6KrDBR2tRdP+P4skP/YH74Nk570aV41xcxfg73jD3hf/1a/yWzWuTXWqgrABCstjWR8ar8//jk+3j33ps3XY1PBCwcBlOieAGEJzAhiCjiWWZ/Knu1W/4pW9MPnvjlok/ueOy1q7dxejaQU+N5nwSDmwWcUTZWcaoxQpHakHtaI2+/f3jyVefmh4ZgFv6NLmJb5g7rhz7lcfn24d/8z9an/u1W4uvvzTf3RXDoL1k0Vowdva0YCKQQBqRZi0YaVyaEFBiJnLsw7PuZz/5RO5Tv7Kr/luXVfjnrIaZOGlFa8nS8JhAfh2gKgQOLIQ6L9CEUqNxaS2kEbBdic4iUD0leGEqsp2ooH446X3xz58tL3qe/SUtRGKtclh6gOMBuRLIK4JbTbz3p14DCiy8uAozfT/Y0bAlATn1LNr1Yyjkd6HWjSClhHJcyC4hOTIFDJaB6/ciWlNGIB3k2YFUKsVyBfUpWrgvHUSg5Fi8drPA9Yhx0boKBASMMX3ksexg4CzeiyizQ7N9xGsDEiXY5r3w+DSsdIFYgOMYumGQtABje7rY1HSBSWChITmEI3TYjdut9mkAuDN7RPXj2EWh1m1tDAQDNkmgTYqHCJl2xEJKCKkgpYLyAmhjYBINrdOf1dpAsklvDCmRC3IgJVG0DG00WGskiUYUxYjDEO1uF5FOELW72OrmMVwrYI8ZxVjbxZei+5EMChgjoaEBALliAN8roNNNAG6BhQM24InpBe51EOI8cepylhoIBmlqsu6EfP0VlxWu/8c/LoRhYsGAHzg91ZXbDROuNUI2zEJCrNb7ZSkHPSGvYUat0Ua7EZKJGX7efglQVxhyCcKxwq8IcguwYToqQAkGWbAkIumD3ADwc2kWGylAKrBMs7GYLSiXFhaYZBmfQpaOnq4QC4A3ALh5CG4Ds8dBQREYXAPk8mDPBXIlcNgGxSHQacLoNiBSlC41K3FAygULByQUhO8DQR5WOWArwVEdWFwAOiFs1IKuA6KyAbI0BBSLsI4PIZ1UwOq4aTpAjwDDKTGGOd0EkNagTgibtGG7TVDShbAxkMQwzTqEMrj9tTfgJ179Lrzymh3YsaaCTqsJR+XxhT94Nx5/58248+5D+OcfHYJ3SRGmmAM7Km1O5qugOIYYWgNbnYPuNInikIUXSOFtvPShmdyOh8bbR0fz9bteedHMmhtHOxfvHqS8ctRoII10s6RrnRhomxJlHEmplaIgWBAMMRIAbUtoa6rNNb2FyZo5Od3gH3z7pO+fruVDILgBrvv7TqAKsAydbiAMU+BwNr0LP21WpHDZdJu4/drWxNf+snpJcWSPk9irQZ3E6vgsTGsCbjwVvP31+ety9uRTP/GRtePDa8Xif3wpvmbHFes3JO07ODERi+4pFp0W0DxLAz6XP/Pbi2WqtWf+7olNBamSwsWbu6W1o8hT8zDJ1lEAUZqzCErxPp1R9gFYTv0tU8aH6G3K+8y+s0Bl64PbEosnE0xNS/rRIXsflHdN3HHo/W9beuRT/1u9tjT6EgWzEzpastoe4rwz6b3mdWcuundzmHv9L8dfOzRVuOZ1L5+f+Pwf2F8rrV2fg96HOIk4JT8dVZduOb72zk/URz748e6zX3xw23Y1airCgONcmVAYAXsSulUnFTlwpBJmZO1VD8+5Fz38rdZzObf2w0tHk8KekXhwZ9DMl93ECsFtEnLyudlgYC6y37n7mJiqm/JOyNz/dDznUkMuWAQMSfmEfCMdZ8+j1d1jb71r4bsfuWLmidu3JC8ZypkNfo6FNAxOCIllGLYAOTCuwFIbfHTJf+jrJ5K/vO+Ux47jvO/Pj8p/pKGG+8bd4j3DOsTiItlWk0VlFigMM7xhhuMDSnHagIlUIKA1w3QkdNOgUWXMzpIxHS2XrC+/d0L8458+zt+WgfMpjbwDIySEhCwWYQpluPkRJNrDxXuLeP1r34i48yC82jMwtYfhlh1IOPAL04im7oYY3QHIAI4xsI4FLbVg8znwxWsh/BxK7KQrTpIpmzpzvBEXMAkRSBv8zaM5bFeDiKIYUZTAcZ0Uj2KbhuwCKEsCcj7iKEEUG2iXIAzgsEXIEoVwAu3Gd+AFACIBthGoJWGWGKxXLOqsMSArYG2ChbpkKfLUSppPn52rn8lADftfFkAWHJAgOK6bOrNJmR4sNp3otNbZgQlIKSGEgOO5cAN/mXGptYY16eFtrIXRZsW4lSQ8TyGXyy+bCCdJgiSOEXVCtNtttNttrN+xDWeea+Gh5n7Eo4xm2AQADFRyKJcCLLa7EFLCmrRNOnb8nDUXytvqC+tcLoZpRA7VGx0WIs3iIiI02yGM1mBmZlK9HKS+ZeeFGFqMWFtMTFVZG1C7UesefuaJkGT5NhYuQfpMfgnkDwJ5k64FQSQoJdNY6YKFCwEPUG5arLwAEEEmEiaw7QIm0zyyhREKYBck8mA3vSglM0xzHtyagazNIWnEwKbdcDfuhM0VwcUBmNwgoCNwEoKSLpBpt6jHZxci0yulXRknIdBpQIRtSB2Bkibieg1I2iiMVtCaOQoslECDw5BuACYH1nGX+ZPE6WMbk6pVKYnASVrogC6ENLBJDNuKgHYTqhDilpt34eff8ybcetOlWFtQIBBCA3Q5gE+MtbkEP3nDFvzkDTuwc/SH+L3Pfg/e9bciKQ+DB9OoKCtCoN6AKI9AugFss0ZWtwBhWZWHfMLg5XPRyOVfPryx+uXn6jXPrf/w0rHWicsGG0MbAju6vsIcOH4usbTW9yyBWGgj2eVkXkfJ0qm6Gx2rurXD9Vx8YsnVjbY7DAQlOOItUPIyUZB5YgtrAA1hWCpBUgLSl6x8wA8gvCA1+raaWUdUMDOn/+Jj42PF4RFH21ut6J4Uuvk1IU0ttYJiF7wIfv2r7NVvvm5p7up9sbfjkvK6sPVGluY5cmvfhUnqJK2EIEZkLXtcov/9CxMDT50u1Z5dCHIbN3abnoBrkohJgIgVODHp5M9x5ikq+qj49KJ8/NR6jRHYEI2zjrVTho4vFea+PxHcCRXevHMjP/u7/73zjlJ5lzKdDVZ3HhEInxXCVhFbCZHEdutOXvO3vyNe8rbfCP/p079d/YXS2EU5bd9gbfSEMPV7yUksIDQiE7PjO+ovfmNy1/4J/dRzU5e/lAcaQKRAuQHAL6Va3HgJMu4CkqzMj1QoGHhpJxnBY/N1/dh00oLlJZhkFty5J31j+feA7PshaYPjOoNMClo6DKFA0iE4nrLCBScJ+7lgMOGRd33qmU1HP/Xkwqmrx6oHb93e7F41FOYDwhotXdmMKKk1zNy5hO779wPO0qkl34L8VwvHeVPCsiQ98auffmz0uWPNqS/90hWFn9hVqpdbsUFzwZjmEojOCJKSSCqCVCk2yGwRx0ASaktdaRmkyCd5ouV2vvyMc+d3x0dikfP+3rAqpgAZQQ4MgIsVIF+C9YrgqIZffudbMFLxYeXlMM9/HKI9AzkskVgBZ72CN/F1mPY7wBUFZRIkUR4Y8SFH1sITBOXnkSAHEzdhOcWG6QWSj5Vhoxekq5UEF3IwnpMyunvDCQmwYeQDge/sn8e/PVXFL7x+B/aNabTb6WYsrT956OrfI4gegxQ+tEkgY0ayRAhbFsaml2zP10ARsBg5mI886yhFxprHAdiXvfSlCvfdp1+0ALZarZRAylSK4xg60WyNhSABKSSEI+D43rIbutUa1loYrWGytaCUMh2fXQdCZAQVY2GNyQphmkastYZONJQjoZSCoxSQz8MOAMMMdKMQcT3C++xb8PQTx9DNL6DZrQMAykUXGzZWcGpyElICNmHACXDgwEnqRKkz+qqg0wuEya5MhIKYCUm8rIQGQYIEkclwn14yOq/KM1sxFmQCqrU2ZmdbHOQrOHbkuamwMT0gvfU7DBxAOGTgA1QASQtivey7lHZJPkjlUqzO80C5AsjJNFfSBZMLMhGgo/TfWgMmAQmVxafEMN06bNiG0jF0bQmmO4urrr8Uh06fRvj8FDCyEaoyCOkWQSKLD1EuwM7KVsvqtMDqLjhOYJIIwkYQFMMkGnapAYglXLJzCB9633tw43V78cOHDuAf77wPB46fgm47gJcD8g6klJlVlEnxFuasS7PgJAZ3u0CoAQ4Bx2Lb+gHcevPNePWrbsC+q3ZgrKAgTQfgAo6O1/DHn/sqBtZsxvt/+jYszJzEzg3rUQg0/scHX46J8Un87Td/BP/GW2GGBqDFIMiVYC+AWaqB3BqcoADTrsJ2mqSTGODEkvKISv6gY9xBGxcuenIm6jw5JcdhTR260QabJSB+BrBVQJQALgBCZeyYtRB0NYTaAqkCGQgQpQYM0iZgLayFCwhF6ZJUAa4H9vMgP5eydckBdAiJkEx7LrzjFbOLu0ebW8LurezQEWHr/wzHEmDzkJSkcUlOmygK8Xv/LRotFQ3sfIWhHqS4eR9yGmDHh5EJNAChPYrDDo+Oed4v3TTJP/fPo5Mu2KgohqE0OJhNipuAdPY9rZjgUn/KA/UwQNsXLZXKPvS8QfVYYqttVz09H3++PlY6ilnvwx/5YPvqTeuNq6ONVnS+Jah7CK4EYNxUCkGOMPWYr9y6tOkf/iD4xa2Domy6a9jw/cIs/gg5zti4RkKyS2GsbKlExd/4iXjtT/3J9CyV164RusEQLrFfBPxhkApgGvNA2EnpvFYxkQ/pSkVOVCEOK8xqK8O5HtaANC9bzmkYCycAO6U090coIAggvQJMu01hHDJJgiq5u0gP7HqqmrdPPVA/BBM9CtBTQOcBAAHg3gbAgRKvFy5dTnA8pqAEAbaqXHAD96bvnkyG90/V//JX9nm37BszVw0GoiA5BMcGWlvEnDmjZnigFFK4UKLrsDjRUeHJc+pbn31U3zWlx35V5dzrWDiJ4ACWJURlAByUwDKACgahuyGu2VPEG2/ZChN30OBBPXX/M7hkiJSGAIUd2OE8coUDMNX/AA9+ENZGcDWBlQSTgvQL+OQPZzB14iA+9b6LoflFWBb9m7esCEoA1lMQjoBUMm36s/xFyzEEFVBfYnzha2fx7wdCfPa9O/H2S310O21E5MBrHwZXPwdXRkgiBWENRJPQWWQkIaVG3zZzXmYB4QLjzQDzyQBJATJRvD99Rfe9KAlGArBPP/10TyvhmUQj7HQQx3FKepAKxpGQKtXrEQDHdVdNWL0VaBJFkKB0ZSpkmr1FBCUlXMeBCNLMLWsZxmgYY5YLKmeMQc/zgIrE9Xuuxm0n9uHOhW9ivj0PGMBVAju3jOL+B58DeQrWalC+gGefP05nzs5j06YKdBRfII+NVsWdcC+8U9B5YSi9QZZWIm5WnCCXzXWZUueIThTj5PgU6h0Dtwg6evDZB4BcESRdsIAQLrGbA/sFsJtR5ij9XAwoJYR4Qcpuk5lhdbsFDjugwmAq+iSVaoBslPLukgTWNgETQUQhVJzAtNvQcxMolBJ84o9+Ae971+vx9MHT+OY9T+Nfv/4gJo+cAEQFKOSAnA8hCdkWI/PhS1PDYS04MTBJDNttAp0GyE9w6w2X4Fd+7v3Yd/lODBcdwLZx+btfhve+8UY8dfgUHnz8GB5+8hSOnZrEYnUBnUY7wznFCjFJEPKBi9HhCrbvugj7rt2Day+/CJft2IjhSgAlGK5kJLGDMzMJ7vzud/jzX/gOjx+tggbX8WPPHIcTn6M7XvNy+uC7X0VRtIDP/P47UWv9E776g7vh77sOYmAEcVAEKgRiD+wIJM1UfEtuDtRuAO2aQNiEJeIYFiQdFjknJ0B7yGqQVbAm07tZm+EQKe8RVmRkHgHLCSybtPlkZghJ1smRkYEgK0Ek0qbGy0G5HowTwHo5QJVBWoPDNhQETJKP3vCy+hCkIK2fZafdgYgZiRSA6EBYQFgJISxMSNi7pwsrJCedCXIwCccCrAykQUqSYkqdPiSDdYSrd7AjnMLhhdP2krhBLIpMwmRC5F5GXuYjRXb1IZaaf9Ny6oGlNLRWsIZcEpjcL227odXj8/nJv30q/jdyh77lFET5J25JyqZjkcgnyO+egkSAxKYuMAIMKxJAe6Rcw7dfUS8nbIHWYaJwHp7VYPKhRRrrRDaGRERG+3zLzs5YMR8daDeSNfC7zGGbyCsBTtZAunmgOQ8O60RJRAhjsE5S7gIkkzXMkARySQAgIa2QLrHyBCsnZZa7OcigAO25MDKVXqBVI0RdmIQYnGfluoJcdQkn+hIYBtsQhKgrGJ6FELDRScOOZ2VuhIS05LqCWXBChkVhza7J7shHf+M/5+9dU1n67HsviYZuGLM7Sr7dE3g84gsrBKem07El1DsUNhLz+DPjzv5/OEyHZlpDm+DKD4mA12q4VhilQIAoDADFAcAJIPxBkHWg4gX82vt/FpUcw/OLuOur94SP3Xmw9Q+/5K5JYo991aI4ZDiDEsnM34KH3gYuB2ATA4mBKA/i0/dP43f+4nm84eoylBJIomTFNjw1Z+jLwFi9NVCWYBwCs0SqXRWQ3IUmCYg8Gt0Qb3npEL7kX4z/9n+ex7s/chR7/uaV2L0+Dycy0DOfRdEcQyzyMNSBHwF2gZHUAZOkrjwkAE0C1gAOMc40PGa3LHWtUV9s174HAPfdt+Idp86rCgYABgcHi80o2ig87+UUeFC+J4gESBASnaCnJRRCQCm1POEJSg8E6ThQrrts3GutyRijdrmQCBJQrpOyx5SA4yg4WWSDtQbWpoU0iiJok85ZLxnYi7tmv4uz9Yk0QDcgXLVrPQAJqfJIqAHle1iYPG0euP8h/d4P/KQXhhEU9Yx4ZZ+1p13toUd2JSSz3+kji3sFZF/GXf/3asFkEBvGmYlFnJioscgH4vTpZ+vPPHjXj6Qau90iYbKalOcj8V2IbCohQRAsUkJIWiPTTVPcBsctcNSBSNqw3RbspACKJQjPz8xqTVqkNGB1F1Z3YMIEaHYQ5IC3vuNG/NKHfhLXXbkF7W4TL71yG1565Tb8wrtuxw/vP4Af3P8UHnvmNKbmmjDdNmzSTd0oIADK8EVrAcnIFR3s2jaCl978arzuFdfi+uu2oKDSBPPYEha6Ptb4wFDZwyuv34NXXr8HoY4wV21gfrGFqZkqGo0QcZzA6DRyZaBSwNhoGWtGBjBYySHnOtnNk4AAdLXDP3rkOP/9V77HDzz0FE2cmRIUFKiypgAhlvDUww/DdzuYOjMFWG0+8L7XURJ2xGc+8TZE9BV869v3wN17DcTaTUA+gBUjQM4BPB/UqYPjTjalVkBRDSppkO3E4CQh1hHYJpxaC1mQASsIGEEwoi+eSmQiUCZiCCIlCNIlkhJCGBiZGggI4YAcD+zlwMqFFT7IK0B4pdTNpLWYmfYlgKyXnCQswWjIxhkiC1iSUFb3XX86vXSVhYkI1olIQGcNBoGtWMaM0cvGs0SUWLgclQbdDp2cVAeb5/RNw7uNo03abPayBtna89vAlb/j1HCCYMBsII2ErBOmnye0zho7GefFvWfijxg1ciuzc+uGwfjxnNJDHNUh0STmlChG1sIwZ5OyzLYZhnRHsnATsuYcpBUAOenBZgQsp1aDwoIYGnkZFrf6i439zQoLLxCku2COgWAABAlQF1QhIMlDRmFq0hClzGRpDRFr4mx9xyCwckTqTqRASoJcDxxUYNwCSPpI2dYRWPmwnTqo2yGKumSsBhvFAFsSCRGUMFYGKUOWGU5uG4QD4ToMNy+UU4SxIZmoQzCKlcc+3PWvnokGbv/Dh7qPgONnCl63uXds6fi1GzrHGq1gM1TciZJo+genh/cutvJzgHQgnV+VvtqRNiIOAAdWKshiJcX5HQ9UWguZX4N47gze/cbL8aqbdoF1DfNLIT7z13cVpqavlPtPPWsvqYRCBwLUaQOlPFTuEKKJ34c38KdI0EVQyOELj57Gr//R07h6s4O//e9XpUQ3yBU7eWZoYjg2RrrpUpCIV4YPmdpICskQNkFk03vKEkMghgCj3dZ4x/Vrsf2TJTz81DhG8h4IeThLfw/b/kpKyEvacBIBUSeEsxZJi6FjAyGQajvT9SWqHGAiGTWOdFSnG39/crI7cccdd8g777zT9BfAXpnmdZvGXu973k8LSXvGbGX9xovWDVUG87DGCnJVutLMipdlC200kjgBGbtcEIWjQFJASZniSCJl87g9wWMGUBqdMkhjnToz9IopMacROgpQroQKPARWwHZ8XH7xFdgUrsfpxVOomiUM2wHsu3ITvAKgmSCEgjUa8PLiy//8HXnH294IgtOXAogXDbLFjzO3XWYz0QtFm2SQMGNivoYDJ2bQjqTNBYl88t7v32MTZ7fwgtuYHIKQbDyf0gRXB0LkQGENemEScH2ofCEFhIlBJtX52bALszQHmCrWbFqPlq6jNT8HJCZ9O0kM6DoADacUYOumDbj15pvw7rfeihuv2QlBCbqtJhLycPzkFLZsHMP2tSVsf/t1eP/bb8HZmSpOn1vE2XOzOHLkNOZmauh2DSAtCgUXm9aPYPuW9di1fRMu2jqGUsGBYIZmjcQqnJmr4zPfehb3P3kGt+ws4dUv2YtLd23mdSUHvlLYNDpCm0aHcfWerRdwk6c+o3GNSGtutg1OnJvBY88cph/c+zjd/+gBCms1lAPCutGkATszzlGnbRgLvpJ5Ze1o2C7s/dPPfU424yZ++WffipKK+V8+9W769fXfwme/dD/QbcEd2wQUC7AyLTjkVYCwDvg1IOrAdvPguAi4MaBjEMcgownWpDEdNoG2qaWb6GcWS7W81QARSEoYSFgSqQGz8tMpRCoYEinJRPmwbh5wPLDKpa5H3RospRFGsJK09oF4ERR5qa6MUxst0Mo1bMCQkQPZMeA8g9xew2az1IEVpqY1aSYiEkA2NBcUuWcafnNm3J8b2dJeb6VhkkRIxUkvmjQvM5IU29QswU0UuCpRO5Fg9ix0oqT6zgH+1p2HR7coP/iINdIWHGM9SkgYk656YZbF88KuGFELK5FoBkcgN3OSYcGr2KbEAmTTn7dIGEbJ0Vw8h6VOCGsDtqnpAgkn9bqUDqAlmDwYGQJuDpy0U4JVEgNaL0eVITM3gHJBjgdSHlgGYOmC3AAk82kOJTM48tN7VSmIwAHrPFhrgokljAaMhkBfepKQzEIByiNWPrRyQHIQwm/DtmtkTAQiYSlXUtIr3kKJvaWTtPDYdOH0YxP6FFgMg6kDCk9C2THp+R8mcmFSJoclcoiFm0qiChnW55ZBuUEofwhxdQ6X7xrE7/3q2+CigVyhgo//4Zdx4MhpwNno/uWjM7XP7jw5yHkLOEAcxXAGR6FmPg89eQNo07vBIsIGV+D9N+Tx/3zgZgzlDOLQQAg3bciyRNycZMDJw6XUW7g3dIAAAwPPemhGEk3Txaiv0UUBro0hkMCShJRAs2lwxWaFfTt2oxs6MEt3wc7/FgoyRJjEcGKCbEpEM4xWnZEkmXF5ds2TZVgp8fhMAadqOTFXD+1ktfVpAHTnnXe+wAqNAKgtF235VL6U+2UhCUoJOKMCZqNGx0mgVIBOWF82D3akhCMVHOXAc7z0zRkDYyxYG+g4REIEoSTYkcs4UC8aCErCUQoqy9VLtIbRGlEUwRiTrkmVghQijdARgFGE4eIgNvmj2N84g6nOLEbcIfy/7b13mF1Xfe/9WWXvs0+dXtQly3KRZeOKKza992BCkstLQg0kNySBSwgJGJubwoWQAAESSkInYHozuGLAxgUby7Ykq3dp+szpZ5e1fu8f+8gNU5Lw3pfc6/U88zya0ZwzM3vvtX5rfX/fcsrxE5y0fhmb750n0AFp3EYPjKnbfrTFXnPVzfKs516okm4nF7//Eknrj1gYf06BzDLFgakF7tp6hOnFTIpDFXPr9d9u3XH91TPaTl7qVbgcQUyppLw1SBCglEHiFuV0molJz75D+0mPOggtWA0qAuMZGLac+cQTedVvPZWLzjuJucUuW3YcZve+wxyemSfzQqlYYPnEMCeeeBwb1y1n5USJ0Aq9uEc30ezY2eVTX/k2V37+yzz/eU/jj1/7HE5eP4YB1k0Os26yCuccD1x0vyde5gXTT4Q/ttwec2g/0oi5dfN++fYNd8lVN9wuh49mQjSofvKjWfWhz1yjT1m/XF3y2E085qSVrFk+4CfGBhgcKIlVhftjc1LXI3Upc4tddWRqXu3ad0Rt27JD7d6xn/179zEzdRDvu81CpI4MRv42ibt3d5dmvzc/39gGxP3AE4DayMSKs22hsuntf/HG35g6eN/Fb/vLN6rQd/17/sez9fo1g7zlb79CfGQf4aq1qKFRJKrhbBmsBVuEoIeKeui0Br0U0g4+7ebxK3g8GiVxnxjicqjwmL2ef1AqSF8+oozNdZyBQQVFxBZxJmfpoqJc5hKYPHZVm362cW6YnS/4oWzfXk24pFgQF6O0IN48ILh7QGaNaUJzj1BYVoBlWe4mgur7Pcv9eYSpKLRXxAuGowezXpLJbjI//fUb1YoT1oQrCiu9OB0rMVnfYJxHlg75Y+xPwcYGN+uZ3ZkyNSVZSWv7hV3RXe+9c+ALodGvzFRpgrBEs9ux8XxGNKHzsq1c3zItT24XL/38PI9ZMCwccIydaFDV5P78zLxIGpRTuShfQMcF1Zr2frFhJlGqgDjwKbgU7RNEAiS3GsSF1Zw4Rv7/ksT55jGNEXH3r0tiQpQNUTbA6wBsAWUDdF8T64NyfsoONMoWQc+SdRdzuqxxKElRzqEyhxfJW1EGMFZpGyK2iJgAsYLSVXR5BBUNQK+OdJuaLCET79FKdBgoE5TXgVuHdyhReBWcj8twgkdrUSbUaKvFhBAU0JUaKqzgbQVVnkQXayT1WUYrCe/7y5cxWe5QLFS4/vZ9vP+friYYWi5OZs0n71mZ/NaWI40nDCS1NEoxnRRvYsx4DTn4ZkxxGenIxTz51FGeduZT6PR61OMYbYO8D9dn3BfCgNv3dXjrp37Cbz9pDS9/3BjNjsMajYjGZwZT9bz7Uzv42k+WuOZtpzMa9WhjCfshzgCBLtCKY0yvRKn5HdyBNxKGC6SxIkgFFYObcfSmhKQLaaL60XU5P8Mbw9GkxOa5qmukJdNaOvLjPQeO3iQiSinlfsoMe/K48VfVypU/zIKOb4w0hWVFFZwcqKO6qb6++/vU9Bij1RLVcgU8ZD5DkgxPSqY9RjyhiSjoCClp8lgnD17InOv3UHKjVpSgVH7ac33Y0agcNs31ODlRhtThyMhESJVCeaFQrLFscCU/aGzjvvpWHjO8kaKNePK5J7L5jutRxQqKMOfihhXe+Tf/mJ559il2aDjUDzWsVbmo+SFhSQ8zzH7QacXdHwIoGJ+7l4v2dHqegzOz7Nx5lLmlRPTQgNqzc4tc/aVPflLr2jJ0uFL7QEQXcizeFiEoowJLtjTPBWeewGf/8RV878Yfc8vtW1hoNwlKVUZGhth00ipO2bCStcvGqQQa51JWjdU444TlwDn3lyXf32MdS1ZzxBxuCt+9fh/f+PoPuemWO1iYr0N5iI/9203y+au38YSLzpZnP2G9POaUVTI5XlPDNUMpVMqA0mRYLaRe00mg04tpdlPZuWdBvnvdHVx3yx1qx44DOmmlKqiUGK6ElEwXazOy3hJ777gv3vmjqyQMgmhkcFiPj48yMFDDRgE2sDjv6bViOo0u9dYC9foinfYcLkmxxqaByfYPho2vul66zS219x2s13+QY4MPvke+T7iWxvz04euB69eNj3/+Pe9+5581640//J9X/FUwUsrcn/7mRebU41fzxis+zd3bfgKjawiGR5HSMIRlVGkAXygDHXxSRvVSlO+hsi4kCT7O2bZKCohL+snvx3rHKtdn9k+A0rePExvmpIkoBFNAqSD/XAPiEJ9ApwdO0ENDOCnkXbUsxkhMFgbcsc1mbkEVbGgR5/sWYzmE70lzx/9M0V0Q7v4eMnmGkuOH0M56RGm8CvLCiSBkGMmQhpW5rVptm7HxQqLvplh6+Ve2cPWTbvInb7zQqvJkShZ6dB/hUWi8PpY6rvIFWBQm9fiOJjmaMbVPaM6SlYKC/d6BYN/7bkjeaILK5U5xnJjAY4yebgWjcwdUWhmsRMp0RLRXGptvRb3BKI/HYXqGuZ2e7bd5GRg2Kog0qVVo5UEs2gdAhmhIMBQWhIN7ffe+xWhUB9I1mS9nqiMq6yjvY5SuoNoNvGSo2ggUB/MYCpehsjg/6WdJbkh9LHVBW5Qx+clOm37BT8gFZhlGGXxxALE1CEOIAlRcRXW6SNKFpIP47Fieb74ZCkwuaTIBqLD//gYt5bzlEUaYIMLYCq7bRdKWVlkX70oIXjSZ5Bl5KneRN6JtrkPDaQ1G5QW6PICPqlCooYpDGFPE1RepyRIf/KvXcsaJo7i4xb65Fn/yFx+iZ2vYckHpriYOK+N/+d3jOt9adZ9UrEbKWkmngVQHicaaLO19NUX9z3QGnkYczxMai1UBXtK8l4fHeYUPLZ+6bZ4bbmiwprKbVz5hLeLreAWisjykWUKGxyK27Stx/Z4WLz2jRqslJNZhncklNb5HZAvQ/BZ+/5socZism0fB4RTZvJAcEtoN6PR5hEoEnSlSrTEW7p0vciQdVK1Gw8/M1/+8j9jph0OBFojKYenlfsBJ64SGrHncmHGVmE4ZgkbM5/Z/lH+770o2DB7HpqGTeOyKM9k4sYkVgxOUwhDrwHdjei6hLfW82UpAaAxWG6IgvN81xfmENE1IkzQnyPSlE8dOiFprjNYE1iJRvuP1zqOdJ40TMCZPC9aO6/bexG+sfwEmg+c+7Tze9/FrcGisNaQZBEOT3LN1h/6bv3l/713vfkspyToExvRLxrF4ePVTpsePNIxPH4BJrCIRx8JSl/0H5tl74CiNthddrakD+7b5r3z4PR/pLCwsqHDyhWJKkSISXRpQPqyiS2OIKaNNiAnKvPqVT2WoKjz3yRfwnKefi7XqfuVM3oPL89PAcHAuZs/Rg6yaHGTFcIVSoDE+IfWepdgx3+hy38GjXPvD3Xzv5kOyZdsBaCdCuSZ2+RhOnDIm0B2v+cb1W9Q3rrmLYi1hcrTM6pVjLF82wvBgLmTvJj2azR4Liw1mphsszNXV7MwMcaNOpOcph3TGBsN9Rs/s963Oj0h7u12aNK1aODBSkE6hVqPZk8HW7P6x+aNpJUt9pHyw0lo9hJaSQkde+brRbpvR2ZGiDrUJTdJJOo12I56u1+uHc3vbY+Z1oh/kZH6McP2gi3Upe2e+OH3eeef+xYf/8f275qbn3vqud/7t5HHrlrvHP2aV+fYn/gcf/txV/ONHrmFh8z4YXU4wOoEvVlGFEioqQrGCq+ZwJ1n/I81QaYpkKeJTdJrkcpFjNlTaIjnnIHf0NzYvdsagrO1nD2pwPUhaufay10J32yhVgOo4vlSDKELQZN6KUqm665DePXNfesL4WhWpWoAixauMTGuMV9jU4qbgwD0pP96HWq+cWrtSYScCXCnDqRTTT1+XzJDVYfYe8YfujfVCYu7s9YJOVAlPvmPuBHXj3qMHjx86ujaNQz8y6bQUHc4qMiM54UYUyhtUBr7tac1C46gwNyViYuWDoGJv3Rff+aar3Vua+ri/wdhzxIZgi94UynQ6Pdm6QzXXlnsVVmdkxWNK2j5b3HtMN2Jxt2br7R3u263Ush2JrBwIlSkLyuab5kylaDyBs7i69zPbMrXjYGF/O+1+3hTS1ztHWaygrc2hy+IguteAhZmcFx8NQlSGwOaORoWw32rI5Vk5bNx35k4dKm2gsxa+18HVFyBwmMoiVMdR1YE8pSQaw/kxqKYQ50VQSZq/R987VpRC2fy5UGi0uPw5MVU8DsgtAL1ZQoJFVAwSCyQ9xKfKS86flGNtHOVxKswtIEODKkRIWMHbASgMooNijpotTFNKF/jwe/+Q5z9uDb7XpsUgr3j9W7n7ngPYNSfjbIBIGasX9c2NTaV3Xd/jr54zpbor24RW4etLUC1THThAuu330Cf9A4XRSyFN0LSIMo+nQGIcxhia3ZRtRxzW9Hj8hsnci0ypnLRHrkuQFJ5x9iR/8dEpPvSlbTz/MZegdZMwBfFBXtDDHmrqY5ipt+PKLXodi0ljTKrI5hTxLqE7q+jEeQKPVXlVy7yijOPWxTI/mh90ooxptOo37Dwyc+1ll12mL7/88p/C9+34yvENgQlOkVCr9mio727OMJxqlqVlxmzE+EkhPZPSi+/l2sW7+eq9X6Ryd5GV0RrOHD6PcybO4KSJdUxWRxlUNbyBOEuI04S4HxOjdQ6DGoQgCAjDMJdQ9FmfaZbmkTbHeoFBkPvE9XVpxhhcsUDFaIoqgFbG1Ttv4Oh5R5koTnDOpnWcd85x/OC2Biqqorqe1GfYZWvtpz7xpfSkE9YsvPSVvz2cxQlRFCA6y3+eqEfu+x1rO4j0XbvydPdeplioNzlwZJFDhxZZXGrgXCBRdUDt2n5380sf+4fPLh05VDeFyZc7XZxERaLCqvKFMlSGcCrCokhn57jorFU84ZxVpJ2YVpoye2iBanWEgSGLtRqvFK2u4b4dh7n+pnu4+qat3HHfPmrVIuvWrJDjVk7gnchCI2Zqri5HZheZn+9C1ypCp03QIqg6ZVQb3+tR8R0CicWhFgOr2kpld3WXmgdmpzrrp+8pDouxA0abgUxcUZTyWrSyxniFS0TSQ1Xj54ZK6SEV12/PFpduO1yfvfdBUOTDxhy/uiHqIWwlfgqZdnAlgLrlllu6WqsPfvnKT926b8/e91z2jrde/NxnPNWtKKXq7a99nn7+U87jn/7laq78+q0sbtkLgyvRg6PoaogvFCHIITCtA3QQIhZcmPdjtWT5gukfSIrPreMelGrufd8o2uPjDj7pQZqiXIx2PVSa4OMOrjMNPYHxVZjxFWg/gVuaguYsNiyxc264dMs9o/OP7xxdwQgyOKqVLgrWOnRX05ty7L3bycJekTlfmb3v3mzfaSuzc8urtausLppC1aFsCl1PPKc5skexsMP7o65ibj3qr0Z3m84nLVUaOemDd0dfu2B1uTqStkd6084PLFO6MCDYqD8JnCLpOLqLnuaMYnEaydqZD4vGeIy5emf6zT+9dvA9hEMvCXzhHC9Z15koIqgpUyjj0nTo25uH9pxfnlneXBA/vjJQwWCMMYJklrgecGS74+C9Pb/9UFndseTaFx9NK+2tiRSXKVUYAkoei4GeJV2wzG5t+5mZyN5wqHY7WJSKlnttIDTKBAXQFmcCfNZGDm+H0gwMTxBWB/FhKTevUP14ajmmYesXmCx3L3K9Nq65ANJizaphjuyfIV2I0ctDjHO4QgvCEsoWclP3qIQqFHJNd+bQkqB9moNyPodHyWLoNBCv8LURKA+jgn5vsTAA6SAkbWzWAZfg0wTJYsRl+e+FI4dpckSJoIjY3EJQ2xBUgEVIZvYzXm7z93/1ap514Vri1iI2GuPP/vKfuf57W7ArT8EFUX5aTANcEmPLqX7P5tPkwtJs8sznBGE6nKADjcta2HIVxhsEB/8bqrmXbMXLicMRYlOn4LooLNYa6vUed+1okyUdjj9+GanXeRtF8qQcxNFyTY4fKPH6Z5ZZXJxHJEWrlNRatAoI091w4L1ki59AlzKipiFNEkyikNmA7u6M3rShHeeEGyv5/Mv6c3LKRdw4N0TdjEqv1WW+0fprQF1++eWPeNJRq1Yte1ypWvmur2TR7BlNltamqthN0cZD2VItGpZVigxUIkrVIjYydEWYarSYXViiW48ZUCNsqJ7EKaOnc9bgYzhh9DiWVyaomTKIJ057JD7LVfsiBMpijcUYRRhEKNFkyuPEkSYp3rl899mXT4jVxMpB4njrte/gE0e/QZbAZ576EX7zgt9Eacfnr72H3/7TL6JtCbV4GEnqiHKi44Zy8zt3vO1/vjF8wYt+Y22xqKRUVCqyIYjpa9LkfmcL1Vd0+vy5JcscnThlsdHlyFydA0fmmZrr4nQgtdGqUt0ON1137dx3P/+J21TmD0sw+FJvoggViFJVRbGCDA5jBibwuopFCJMlvvjB1/C0C9YQd4Ubf7KVrTsa/OCHP6E6VqUSFZmda8jWPTN+x95Z0nYi1EZVMFgljbsmh9Cy3F4sqYMBYxQFFWNpoKQjKktaJuvss8rtcll8h3HdXaTdfWl3+hBdmgvQACjDxMAQ4UQFN5UNrhcJxpS1orxzWjBBurRl9Vyy58YHsiOT++HIy96m+d738g39jeMCVz5sN3FpflEv7X+6caNw+RX+AevbF+t+8fqpdusvTkH7mZF9Smvtvfdj46vXve/1f/jHL3nN772SodGSy3yqtQ7Ult1TfPQz3+Jr37yZgwdbeQrUwAi6OJjD1Crvz4k2OGtzGzAliLa5bEUA71HHmJlewCUoyfP/8AlKdVFpgkp7ZD2Fb8eQNiD0bNwwxuNO38RV93Y4VDoO6OH3biOY2QW2SNpr8pSxzTs/9NSZDVk6jxqwvjrgNZmwuKBYOiLSaXqvbNl8bqv91JX7s6s+/Xz7yeMqLSsV70vjVheVp9f2LC0o6TSVD7U1X90tP/zrH6640xTKL3PB+IANA8kSWThnaOfm//n4hfOGw3Yp895Xq4qo6pVVSrlY02576fUQk4lE2hhdiDjUMlPf3p288+9vGetEkX1OQvWZXkcoFWmJIgiraFsUfKyG4633fvGFB5ZNhPFI6L2EE0IYKtVOYG7GSzrlXFeX7Ge3hVd9ZZf/xCcuLX7k5MH5aifNXGlE60pVKauh3RVJ5rXTbW2vOmSW/uSalXt9GG3QdrKSBUVUFKAGV6JH1pJFoyxz+3nOWYPsPjDNTT/eRq+Xn7wIIvLYMN2HpsllOkkPkiaYjLGJCueevo5Ln3MRj7/wVG798Q7+6WNf5fof7wGpQWUYVSpgbAA2L6h5H9jmyJLLTeCdz92xaPegXYf2PJSL6PFJqK5AKkPooIRPff4Mpb28D52l/aKc8yrwWW4RrST30NUh2AAxNj9JiyftNGDmAKeeuoy/f9vvcu7J47nDU1iVN739I/KhD3+JQm2Z9MJRpWrD2tYGIVWk9Rlsb0Fcd5HRbPv8lS+8Mzj3/GxAVbVo65UPNGE5wg9U6XWX8JxLNP7nJKNPwmEhbaJMSjvVvOyKH1FN63z8r1/QDwvO8raXN30NcEaUgYsCPEFuhmGKhEkT1/gmsvh3FJLNaEpkcYLugso8bkbo7tU5AtHJGcTGkLODgcx7ClHIja2V3B5Puk5mzL37p9+7+e4df/xw5udDFoyJiYm1taHqj1zoJjprYlqbYuXCBGNCvHYiKlVeg7eGyDqqRcvIQIWBoSqmZNEhdHsdms2U+lKXzmJGuTfAumg9p46fzhkrzuLk8TWsKY1SsDU8HudauDTOm/ta443Gakto8o+c/CV9O7UM5xOStIdkwl/c9D/5t8b38GguMedwzWu/lpvHKsuTXvsv3PTDA1i6+OYCpN38oUmbZAt75p/3Wy8oPvelLy4NDZaoWCNDtQrVSqgKgcL7/oeDxCV04ph2M2Vpsc3CUpvFVk8aXeedsSqMQu19yp6d21s//NqVB/dtvSc1weDxirDksIgJRAUlpYMqMlhFDUzm4vegSjY7zetecQYfeMtLSLoJW44u8LI/+le2b9lJ0mx6bOixocGEiqhAUAyIdA7BKe/Q0kW7OA7IeqGWJUmaaZb1ZrzJZqWzWHfdpZudY4/12eGF1sIeoPeIdeJY8brx+9lP15+flUfmFbxdweX/2SLFf/C1v+zQSikvIuVicfjtFz3u8b/zilf97rJnP/vpFKLA9aN01YH5Bj+4eQtf+86P+P7N9zJztA6ZzuURxcGcWGByVELrY696MHs11wV6ycApfObyU1+vA70mxC1QCdXxUTZt2sCF55/KRedv4tzT1zFZq/Lq//UdPvLdOYKhgZwNvOducLEoI8rX9x595cnbDr/ysa0zhrtdU48NXfGoTJGlmoUk5PtH+Mx77wg+oEz1ZeescIW3XFR/+onlZLLjMyRTuQ2hsdTRXLcvuu5vbyh/E1N9rQurJ0hYk7xIBcp3lxY3Fbff9BcX1U/fNNJbqZzQcxCjCCXNdz46IPaW6W5w+O6j4Y3vvd1cs9AZOl4XgzcIOkAVDLaMqCKqZCGqgg9FS4xrtZbOqdy3+a+ffvC01YV0uNdzuCTAZxDgmcsCrj5ornvPzcHnUzP6lLMmZu9+8yXuD0+oykSWdfBeIViqJPgg5AfTsv9d36v83d7O8ndI0UTKrCygFKoygh9dhx1dSdqDF59b4/PvuhTn4J6te7n5rgPcce8edu0+yMxcg3qzg+8jTMODA6yYqHHyhlWceeo6zjj9eI5bMURBZbS6GeViEaU8N962nc9/8yfccNNWdu2fRToub0db3S+C/XDbPmsYayhULSeuHePiczeydnKQL3z9R9x2x2EYGicYGEIKVXwQIkajVYgnQWcJ9E3HpS/CVH3PHa/zzoAoh5IM12zBzBSlQo/fedHjecNrn8fEMNggotfJ5L3v+7j6/Be/Q6lUZambMh8P0JFh8ZUKqjSidKeOdObAxXixfmjpngOffu69K595wZJtDSuJSl556/ClkKA2hKeHa4ILnw+jL0JVToNgFS4A45O+jC3Na7Z4jAUlBVApohViQpxXmEyI0r1krWvIlr5KIbsVq0DiEpLOI5lg2gp3VGjsU7QXFZ1EyFLBmlxz6L3BZBmuEHJXo8hWfYJvFZfpbXsO7L7uprtOveyyy+LLL7/8Z65VCtDrT1r3/WKlcn43afj24JKdm8iQYSGsGagIOqJPWkEycSqWFK2FKLSUCwWGylUqtQLFokWFQruXsrQUs7DYxrWEURljbWkdm8Y3csbyTZw8dDyrSysoh4N4UhLXI0vzG64BawxiTB87VljxZHHMUq/OH9/+Fq5yd1OIiiT3TvOll1zJ8099LmnS5jt3TvPCV70fb4fw3RaqNYtOE5QF0i7Z7Da39qTjk+e97LfUhpNPikphgZAMg5PYZcSpJ+l5kjQj8S5nnilLYAJlowLOaObmptm1+a725h/eOLX97jsOQrjeFAdXOaXAK1E6gmJFSRDlGvjaGBIM5wneSwucdsJKvvrRVzJa0XQ6Ke/41xv5wMevk6AzJ+WC1SbMm8BZ3JlBsj2S9aaypD6rXbI5FLfX0JquBb1ZfNJrT7fb0w9lRT4SnVWhXtxn+1wpDztlPZIP+4NjNOTnQI+/7kMppUQp8F7WVQYmXv+0pz315S9/+SuqF118PpVi6Lx3WitRifPs2b/A3ffu5a67t/Dje3ay82CXuXpCt9tBkgwSly9oD8Se963iEnBxzgIMoFIusXL5BBtWreCkE1ZzyqZ1nHraelYsH6EWGgLxdFJPKSrw6Rv38LvvvhU7vBqaTdzB+2BpL/hpUVmg/NzC1Dkr777xNWfUj1sWupNLRoXWu/Y988H0l3eUrrl2b/kWovLbtC6c6J3bOhLNXPsn5/TOuXh1++RaqMJGHOiZJZn67NbCli9vL31DFWqXaWVqzlZLFAYVQQVDJhijXG+pbbpHd//mxvrB52+cG53ArRcjhUS0tHrBwoFZN3XnrLnuk9tHjxAXLlSBfqa2hUEvJocAgzJiS4gtomoDqEIV30vRSQ+lLa4z31nmt9z6B5tm1p5/fKtcC7Oij43sWogOfnZz4cZv7Skt2aBwnrOVJwqlXWPh1E/+/ILFFReuaqwVJaOJF9OIi/ObZ0vfffsNyVWpW/mqwLgnZNGIiB5UKiigRo/HD01iS2Nki4d49xsu5E9edB6ddo9KLeqHrQZ0Yker0yNJc/MNQVEplyhFBaz2eVSYCNbmvdk0dlIqW8X9mjbFzGKTO+8+zO137WPn3kMcOnyEVqdFHHsKhRLDIyXWrV/Baaes4+R1yzn1+FWMVAugM2bnMz525Y18/Es3s33nDBRGUIND2KIBUwYjCHnQq3jJa6rk7kzKZ32DigTXbUKrRbGkee6TT+IPfu8pPPbk9WRpB1Mqyr1b98o73vG3+vvXXre3VirdEMfxTmd0kNrqpWF51amtYCVdCXM0QxWww8vwhVFkdpq1U99IP/SM2/1TL0oKDOKzIlrZNO9vV0r4WgC9GNfWZOGJMPAsVOXxqPA4fFAhthEQob3KXa8AJQbrl1DJNHR34bvfxsdXEybzaLooH+DbSW5o4iBoaDoHHO29nkZd0Un7sVsml6B5AcmEciHkjlaJaxZGJZjY4KeXuvG9W7dftGv/kZ9cdhn68ssfsYXywOK35viVr6sODX1Ai5FGqz7Xcd1yJ+q6rJq5rOYKalhZO2IDU7P4oke0RhTidEYmXuWUa0chUlRLVWrVKrVqmUolQuFodmMWWi1mW3VcE4azUVaXVnPa8MmcPrqJ00dOYXltknKpjBHBZ47Upbk8QjxaCcYb5twCv3vba7nbH6UUR7S2HeY8cxHXv+Ma0iwmLFW44oNX8Tfv/x7B2Arc0mH84hRIF7SRyHmVLB52Rpqtsy46o33e45+gxybWTAbRAEgGOsMYD1qjTIjRhixLaTUW4+bc0SPzRw99//qrvtPav2vniRCdqMOBUbQpenIau+7HBklURFVqqPIk3tQwQYhrd5gcyPjMh17LBSdNEHdSvnrbTl7/5n8RV9+takGC79TvSVznSklb1/nZA1vrsPTL98nuL3K/Cijx/5SRR9tqJf0Uh3OHx1b+4UUXXfjc5z//N2uPu/h8li8b8qVCIPldzwUEqYe5pRazCw3m620OHF3g4NQ8C/U23U6XJM5deIqFMmPDRcYHiixfNsjIUI3hwQFGh2sMV8Jc18pD3VSSVEiyjEglHGzAE/78mxxciDBeQWcef/A+VOMoTimxdFTWa7ZoJAfGogONkVJ2aKYb2IVWOITRVW3iDZhqVUzV66Csne6kNGXnYDDXWTYU3yrSuOm+Q7XnokpnBUESOWUDb0uTKiyLhANKhbUcZnOxaKWU9w6/NLtA1vt+VKqbERPP97ppfT4OR5HiSnBtQr/JmuJqpzQK57AlLbamtC7gghK6OoQv5QVQJylusYlSXdGhUr7lkKUd80U9e/eqcmtLIxWm5m0ZpQumWHmJkpr2ofEUBrTPHLQbW4vR3D0nVOvTPpZ1Oxb1YpwVi7oQrobgXB8Egh1WKI8ZmESqy9C1El6XiaTOD/7l1Zxx3CTzrQ7Ndo+V48MS2AcR4R68//Mej1HOe8mc0Ol1ZefBWfnWNbforZvvUeecdoq/4PGPlY0nrFaDRa208WgClZuHq/vZ6847lFUE1uT8B/LoLHxuJeYlRdPBhhGzdce3rt3Mp77yA265fQvdegNUBUqFPFrMRg9kUTpyiDZLIIkhzFi7dpCnXXIWv/PsizjjMasIyQi1FWe0fO4r1+m/+9u/Z8+ue49Y6z+wMHPwI8Bs/48eqY4d96fFodW/3zLLhzpmFYUV56isUiRYPUFYn5HG9df4gaVrjv7zU/bxovNlpR7L8NUMAsmZxgWFGxjClKsoqUPSQfUqtN0IKlxDUDoZb4bQJkIbcFJH3AIq24fOtmP9VF//GSJZhurEpN6jXICNQRYT4gOweNjQaHiaaW6TEWiPmFyNK95TKhS4r1Pm64eKxKMnpc5LcN+u/a+6577dH73kkkvsjX3Pz5+3QGhAr9mw5q+icvGPorAYWVF0k6zTSXpx13XjVKXttOQKvVJc8DUZsUNeqwGNDBmkBFp7lNIiKGKTgBEV6ICoEFIqFahGRWqlMlGoESO00g4LrSUajQ5uSRGlZVZEK9g4fBJnDZ3OaeObWD26nLHiINoW6IlQEsdX936FP7rzCrwOyJZA9reItzX4h//+AV7/otfSaXewYYnnv/ETXHX9NKWhiN7CEXzjCDqNERMSOBEfL6hscft9sPTjydUn1zaccEoQVSpnDIwM6nCglPR6cak+u6R79aXZuekjc4cP7b+lNX+wDcE4lJcHYel0R7gy72QpUSZShENooxFjkNoyVKmG6CLKhtDrEfoOH/771/KiJ62j2+ywb6rB6//603L7D29Vy+zebrdR/0Jn8fBfNZNk50MK26Uv1nlNm1HwkD6b/Bc8lf3/NbSIiDFG+hljjy3XJl998imnPO/8C88bffJTn8KZjzmVsZFhVzDH5kWqkEzl8EHukPNwFenPV5U6cc4w14hlZn5e5heW1I/v2qG2bNvBm//4ZWxYWVPaBFzx5S1c9tHtFIzBSSffsB3di3TqKK3EIgoXk8R16C7lJxPViwUWvS2MKRMpMSUtyohRJaW8Jssa0FsC15myhlHRvuFMZRiinDJfqEJ5AFUeQpIU6bZyxqtORatYqcSR9ZqQxuBjjEpitC6I0oj3LdFhUalI68Aob6uIKaMii66OI9EQPiihbBFrIWvNIwvTBM7jpSeSzirfbOVSEJWgQ9WHxzLvgyKENY0piBKFQVSadKG94JFEoZMkQBUyojxpNqgaTQlKVRgcw5eqhKOTxAttXvrCU/mXNz8Pq4SPfu7b8t5//jfOO+cMddIJx7Fq9Qpqg2VqpSKlMMQYQ5JmHJifZ+rwUXZvv4/9O3exY+dOjs7MYhUSmECNLV/JaWefwyUXXcDpm05gcqzmB8qhRIF9WJxrfuDInCeOlXQTJ/sPH+HWO+5SpXJJnvXE8xmqhFrEK2MLtOKU+3Ye4Ae33sOWbYfYc2CGw9Ntltoxjjw4uhhGTI6UWbtqnE0njHPGaes55eRVTAyXCV2KsoEIVu7bdVB/4lOf4Ytf/Fw37bZvC0Rf02jVv9w6cd0u7rgjg0sM3JgBI7WRdd/MahvP6654rtdrz9EyFGIqEemu/QQ7t0g6dZvY+VtuuPzcPbUXnRecvWp9JsEIWpUc3lhEC9Z6VFDGlStIZDFZ1vd3dXl6DX1DFIkRPFoseItPPK7XgzTG+L5Tl3PQhHQKmkegNauk2TDScl4Z41VOONP9pA3BFgN2tmr8YLrCXGFZasIo2Hfo8Advu3fnH/wyxe+n4K9ly0ZOKg5UXxxF0TOd4VylcwPrfvL1VCvtHOj6VKeF7rArpjWqqiRDJkxGRAcDaCoOU7CowCJGS6Yz8dLTx9wcCoGhUi1THRykWqtSLgY45Wh3WywuLtBaiunUhSAtsTxcxoahdZw7spGzx06mQYv3bv4Yd7CDkJBkyeP2tGAhYVyWyY3vv15tGDuOxCcs9uCFr/sUP9o8RTBQJqsfhfmDiG+ALqC0wvgY6bVx3U6duN2GuJBvseJ94LpgJyCMIBo3phgqa4uiTd7UFYWXAIzD6CIqLOFsCEGEqYwj5TE8Cm01ru2J9CLv/ZuX89JnnErcXmJ6MeV9//It+dfPfUbKrt5kcfo9cwsH/h5owiUWbpSHbVMfHb/C3iDAmWdKcMdme74x5WeMjkxesGbN+tM2nHjq4IZTjmfDCcexbs1qJsdGXLUYUowirDG5usE8MG9cf86mSUIryWh2E2nUGxydmmfPoXm9Y/tOdmzfzuHDB2ktNUh7eYD0S//bs/nrK94oOKdmEsMT3vAVdux12ILHa1ALB/DT+6FZR9IumtQrlyiyWPks8aK91jpAqRAJirmrjHe5xs170eLwPlbiXK491AZsKMpGoCOloiqqMoSPyrkYP24jzTl8pwFpIsr3vPGpEhHlxatcoOxFixJ0qJU2eUyX1YguoUqjSHUoD1sNq4jWKFOEsIDSCXr+EOnUbkzaA+/Eu67gekpJqkQMorRXyuYC4qiK6Ci3KxPvte/hXUdLlvTTXgSllVe2oL2J0KUB9OA4WaGKLg2CjqgFPW786MvZtLrCXCPlNa95I7fc8mOMSmecCW0YRFFgw6INi16FYVfE45xTadoox+1WkvW6iwGyX6tsq3Lx1V75GWOiU5UpnJuq4IwwLI4NDI0MTyxfzso1a1m3apLR4WFGR0cICkWazR5LS3XmF+bZf3SGA/sPcGj/PpZmFwnQbNx0Es9+zjN4ytPPl3WrJyUiU3l/PfdU7sUpC60e9Vabbi/FC5RLRQYrBWolSxQEoDUZOldzOfyWbbv0Jz/9Wa666rvxkYOHflLQ2Se1Tq+ZnZ09AnQeOg0u03C5Ko2dfGU2+OQXpCc/16mBEaOMx7WWUNOzyMJBdHMPtr1PkvriT9581n3L/+CM1mQwpqU66VU4AqaYs1JznV9/wTIh2uQ6Sm/A9WPWxIPJyIujpDgRlBhCl6e409KkCxmdI16WpjXzdaWaXSHzuRTG6X6bFUUhAG8L3HwENreGhbH1LlWRPXhg/2d/tGXHf7v00kv1lVde+Uutnw8ugPrBdPNlq0fPUsqcqtDLMuVWZrhJRKdaGadUOJThSj3fdSqwx6tCVM3C9qJU0iQbTobVkBrQQ6agKybv5wUgoUhGngSB0cpYS1QIKBYtpXJAWCxTsEUq2iIuY7HXpL7UYWG2TiWpEhQDesUYp8n7cwue5ECbMNHEs22ecsLT+Oq7vg4pPtKZ3rUovPC1H2PLliOEg1Vccwq/eBTSBINFTChOoTR5b0cR524RrkceeaCMKKu8KJTvIMojGocKlDI1jSog2qF0P2w2KmHKQ3hdQUyINZA165Qiz1//5W/zyheeTdZeYCnWfOW7d/l3vetDulff0UzrB36rubh4bd/hRD1a9P63wKIKlH+AzyIAx0Hlibpce2alWjtjZGRkxdjk8mBwdILR0VEqlQqFYkS5XEFrTbfbIe4mJHHM4tISS3NL1BcWabTqtJp1et2mz3qdqVD5oypUu5XxewpKWngfpV4982Mf/+iZT3rc4wWfqm/feYCXXHEDUhzDKQuuizQPwsIhaCxCr424BJXl+yKlcxm+6EhJsYhE5dxZJu7Rt8bIqfM+FaUEjEZsQRGW+gkUZQiq/cDkENIeJm5Bp4506kivnfc15ZglhBN9v8l+v/gFBSgW0EENomF8VOm70BhcdwGCKsHIWjIB01tCFvbimzMcM6SGPNQZNJj8PXWhiCkP4pRC2nXodpEsQYk75tgi9+uZbQFVHUJqw6hCBcIqxljSqT28562X8t9/4wziNJNPfeka/vqyt9V9p/FhG3S+kyEdiXXSdarknKxC+w1KVKC11iYIYqPYaW22L45b++fmOkcf/vAMwGBYq42mqT451eEGj3lMZu2JUbG4vFAIi0opycRlCl9AaW2dbmRJ7y4tye3FQmFWlFnVjJNTlQ3PWr/m+BWXXHwxT3riE9l48no/NlqSwCpttEfpQu4Z0g+p7rtNi08dsRdpdHocPDLD1m079I9uupnvXXetP3hg/50ZyYeHivbqqamp/T97Clym4XIfTZzyVT/0zOdlqy52FCIjaYyKO7CwiI/nIJ5C944QmQWWhUdmnrOqHT5nfG5wqNCjMgRjE4ripMEMaLT1SODzdVIeUPAqdX/gTd87tx+zlmTorse3NcmS0F6A1rSwsKg50tDsbNC6daG0MO3CXePGnfaktd3RFVFPyoFVXUKuPhLK7e0JPzg6rLQN9PRi4yO33XHXq/t6v1+69fNwBEdfcskl+pGOjpXJylhBFUZEywCY1QrWa0AV7Nm6GD3LO/FxL71Xe6ayMK3EpZ71w67mhmW9HbQVhoxSZSBQSAheiShxeIdSXuFDwYQ6T5EfHmC4UmRlUGZfZ56CreDrHXZPH6HhDcoJ+nBCeqRL0LMo7SSe6smrnvs6/U9/9gFa7TYqSNl+MOB1b/4Yt99+ED05jiHBdadgqY70EiBBiRflPV4rwCIYlDilXZLns/m03/w2KFPIU9+1QYggUFCpoIojiK2Rwzb9zMPFKVYfv4y3v/U3eda5ayl5T8PBt27YLH//3k/7hYObxTWmP5vMzf1Jg8bCwzcgj47/Pf3BPlnm/thpBaxcNTC00AxPAXthKnpEITWj1YSyhZO10tXcjUFFRpTvZ515o30rsKqDkv3i3Vbjsm1eZVuSJInTtLlAPV5KisXKwPh4dWr//mXPeP5vfOYTH/7YpLXGDw1V9GX/tpkrPnA7wdA43meQtfHdaejOoXptpNNG9ZIcVlIeZS1SKOOL/YLmI7RPIW4hnUYupHYpRoGEua0XURkJi2CiXMhtCoitIc4haQuSFqSdvPjFTXTcyz1pyfJCqC0EIYQFCAZRhQLYCkoXUSqDLMXNTVMqJoip0a2sxAyPId2E0DXI4cx5pDGXJ5y4FAksOoyQMEQXavigihiTmyjHLbJGHdXrAWmeVKIUJizgywOoQhmxBWxQhLBKMrWX1730fN73pueTes/hg4v+Fa96lb7nnh9/2naSN87UTLO4pIe73clpuCOFy/RY6ePjAG2g2Gm155lvPnxNfOB56WNvD2FawZNPnSjvakoljv1Az3urlY4CghLWKturH5FC48ihQ3TvL6IDDJVKy47rdXiOM+Yp1aGx09edtLF04saTWLtqNWtWrmZgcIBKuUSlGEohtLR7ber1lpqdXWLH7j1s27qVXfdtZ256SpJOfUcaJ/9UC/U3jtt43P7++q1+Rovk2CY7KE9svDkONpzlq2d5M3i8yZRGkjakHWy2hG/uxiQHGAtbEmmv4iRtnVGZjS5d17UbKx1KQUy5rKgMG+ygolh2qJLCBLovGxLyBzC3SiPTSAKuKyQNiOvQbiraDUW9nVFvaXa0y/WrDyY/+V59vemE608mGglwveiNJ9xcuHj0IHfVh7l9NuKQGmQgys3P6p3eezZv2/OGf2/x4xcYY+oH/f8jaSgKlUqlSsVuDKx5elgonG2M3pApUxIxBu/mcTREU+2E7VJacRWppT1VoapqumKGNVL1/dOhFsSL9yhnlBIrEGQMmAilNYE2xOJpJQniNKrj0Xt7uHlEUiMm9jrMDN3D7eY7//jdd/zRK/77xb04Vk4r1YoD3vG+q/nXr9+LL9awlRKmu4AsHCJrLSFJJw9n9Z0HZb70d6X3ezza3CtQ5zZJqhBBWIZCCRsaJItQEuJ8im/VKRZSLn3uubz6Fc/k5FUlTNYlcRHfuvEnvON/fSBLF6astA79zaFD2y/L2Tfq0T7erwE8musWv/CQRU49aKFbt2z5qsz7ihMxxpiqgMpAyDJSMUaStJNIUm80GnNA/Wf+IK3ROnjN29/+V+9/y1+8Iei0mqLKRXX5P9/C//roTzDlIUxRkbg2dNsQ11FJC+U9XgSlNdoavA6QoIQKihhdwOkMSWNU0oGkk9utofBBbsCulM29SJVGSUbWakFxEDuyAo9Ckg4SN6HXQGdtlE8RyfJ9mVb5ps8GoIM85cLmZlLKWbLWInRmeNz5G3jnm36bI7NtXvn2L7JkVhFULN7FeMnQaQ/ptZCknVuSaQ0mQLRFY0GV8LaEMoJyPXzSzHVmLo9IQytUWMSbMloZrDL4tEU2e4TfvvRiPvS2F1OwnlSU/PnbrlCf+eS//niwzCv27j18Nw+o/o7dWv8fkOo8kJnGZcDb5eFF8ZFf8rZ+IX3IAq1XrBhenvWCMxI4RxWKFwZB6eSCrYwGxaIpFCMdBiGI0Ot2aLVaJEmS+qx5yGfd+wSzMwjVPaNGfXPr/v1Tj1Dkfu4oja35h6C6/vXtbNJ5Jo0ZWIFYQVwdt3Av1i1KZLt+SHdUraB1oC29WGRQd9SL109z0bIekU7p9TJMpigrhY2EMOq7/2n1gIeTCOIUWQpxL/fw7MXQTqDR0cy3YHPDNj45s+aORbXmJLP63GXR2WfTOzyHX0o53dzMCcl32d4ZxVkj4pJeFsc3dJP03fsPH77hP1L8flEB/Dk3/qfYhSHVanWoaJd749cDY2K1tpjIKlvLPMp7Slniu6lJNWVOo8oqP+onGfbDbtgXbcVjIkNWsIjWohFxeO21AytQsBgVYntesiNdcUcTpdsFpXoaGlmTpvy4nFS3pwvFFa95zcuf8Y63v0UZpQzSJCpU+er1O3nD+69mz/YMygUKJY/LBMlaiOsgaQfiLiaLc7d7eaAAamWQILccIuwLaJVFicJmKUkvg1YdCimXXHIKf/j/PIWnPnYNBRfjtaHRU3zh69+Xf/joZ93SzF5bzBY/cXjvva/NU2AfLX6/vjDpZQ/60hX+33mb9M9aREUErbUMjU688B/f9/5P/tZLXlTqNKcpVCbU+z53G2/54A301ADB8ABeNJL1ch/EtJM3Hftmk3n6WB5FpsIIH4V4Y1GZRyUJPnM5jR7XF++Ddj1cZxbmpjjxlA00Us3RmQQmj8eWI7zrIL0uKs5Pm3n/z+Uu+2L6UY4aLbldXNruQqfFxKoSf/yKp/CalzyOmngkUnzlpoP88du/xZGFDD0+iSkEeQxSkuDTOIc3fcoxa0ItKcoJKqxAqYyIwmcJkiV59I7LxeDKarQyqCwlazTQdPmzVz6Bv3zVU0lcl2q1Jv/4j/8sf/nWt95WKkZvmzl68Jqfg7Co/6TMR/0S66k8winspwqwgBodGVkGxRWQifcuwlJGjFGeklV6UbTtGZMccs7Nz87Oth72vP2yBUADvjQ0+kwbTXzUh6PLXK/oEx+howikh5EmBRvrAm0KNLdXIhVWiqV1Lk5pdHVTxfX0pFpv6HFrUs4Zi9WYTohFo5IMI6C9ymUc/d8ot0LLVVnegXOK1AuxwGJdpJFo9a2Z2pEvLp5XDkZOGWDDWT567oWqtf2gYm8X1TwkI42vqtHu9vm41765025/aGpu7iqAXyR1+FUVwJ/3WvkZFzliiFE8OtBBJQxqExgzIVbOVaj1gQoLic6MC13HD6UTvpZN6JofUVVKqmJxVYMKvajAIMaK7nkliz2VzqWYRYOdY6erm+/oTikrhtULK4XiYytRgaV2kxc883m8/c3/Q8YnRn1raUHbakUdmu/xr1/4AR//8u0cOdTLT3GlImGhgLOCON/v5vr7XeJz5oTN7a6UzZu4rovvJtDqAI7B8TJPOn8Vlz7nXB531okUTI9QhFJYZsuBef75U9/2X//a15VPZpTvLP5gav/W3wSOPgp7/teETH/OIqd+SfmJuuyyy9Tll1/uV64+7k0f/uin/vYZT7nAzc8vmOJQSd22eYY3/d23uf3eaYgiKJYxQYjWDpV6VJIhLsNlXdzSXL750gFMTKJHlmGDKN9xZ7m3pfYZEndJ221ozmPCJq984YVc/icvYSnu8r6PX8cnv3gbraUMylUoldFhhDEhCo/4DBGHSh0u7eG7Hei1waesXDPAbzzvfF71oieyYUWFNGtjbZm020JHBfbN9nj7+77Lld+8F6SMrgXoQh6mDSC+H7jc60CrAd0emBDGlqEGKlgboZRFUofKYlzawcUdaCxBOsMpm1bw1j95Gc9/4kaSTp1qacB//qvf1f/jDa/fUZ+bef0ZZ5x27Y033uh+TdnSD3+m/H/iPeTf+RqpVkc3qKDwGmsLT7fR4CmxFEmdolIMiawi7S12te9uE9f8uvedLZWo+rulIHgWxOCjbpwpnblm67hqNvD4icw+dqjH6ECCVYLJPC7JpbPCsT2bwfs8AcR7Teqh4zytLiKpUne3i/HfzVyUdZY9vaRqq1BnrVKiDO7AIqqdSFD/oRo5eOU+65JvzHXlnd2FQ0f6FO3sV1HE/r++kRYQJoiqUj3VhMHZ3qgNBjuIV47M6kxLITOJcaWErJaezqg5Tk9qI2WH7wlmUSPz2aws6v26Z3cUOgPlggojpbKO1kFFkJvI2t+MypVye775e+effcHv/tmb/pLHPe4M2klXxDkVlUvsO9LmK9fey5evvY277zlMd8lDZPJeiinlfQ6rH/RYqZwg2mlCuwG+TVQJOOXEVTz1qafxgiedxaY1Yxg8cdomKkV0e5avXnen/6ePfobdO3fogtTFNQ//y/zcwt/GcWP3r+mEfHT8b1z8LhNRlytV3njG2d9797v/7synPvFi1221dDEM1WIKn/3mbVz5jdu4e+dRGkspfc+7fh5kC6xjw6oxXvSc80mSmB/de5Af31cn6Ug+21KXRzxlbZA25aEiF59/Mq/7f57G0847Eddr5l7rUYm77pvma9++hRtu2saWfQs02gZcH0lzx05fGUTCsrEKm05ZwdOfeDpPv/hU1i8bxCQOG4Yy14j9PVu2qzNP3aQGIqW8i0lsxFeuv4uPffp6br1zL61mF1wfSsVB4BkaqXLOaWt5/pNOZ8/Bab550w52HpjDdTLwhXyvmDlQXYoDwuknjvPiZ5/Ls55wDiuHi3g8Kir5z336C/rv3vkujhw9+Oaxoeo/7Nq1678SuUz9glOl/JxT5X9o1Gorh8Owt0bZ6u96E5zt0V5D2/rulLjkrjRt3g7BvYuLi3VAr5hY8fhCWf9eWasXB1qHLtN4r1Eq8cNBotfXMo4b8KwptJgoKMoBFK1gcDkEmknfa15IRdNwmmYC0z24tzvI11tnM7fyxehoEpkMUSPDyEITWWwTJgekuvdzhI09NyRJ63Xz8/Pb/7OHCPW/6YY+0mKvo6FohQnMkLa6opVeLtoeL8oMGmwYSGFZ13ZPTErZIIFb8qnbT9vfoeqyU+toyIbhsrBYWqFwP4jb+65qTzP34AtxySVrojvvbL9m+fIVT37hbzzvgt/7vVcObzh+let2e8a7hKAQ0U48u/fNcOfdu7j57kNs23mUQ0eXaLQSunGMiGBtQBiE1MoBK5YPcuK6Ec7YtIrTTlnPCesnGSmG6KyHF00xKpG5TL5/zx4++JlvqluuuRrXXqJgsn2dxvQH52cPfYCckvwo2/PRcYyAI9YWz1y1eu0/vOJVr37c77/uVQxXSz7uxboQGeJuxs5Di9y17QDb9s2xVG8RhiGrVw5y0voJTt2whuUjIRpFzym2bJ/i+7fv5Y4dR1moL6Iyz+SQ5dSNaznn7I2csn45FZ1vmL2xfe56jDYKq0K63YT9R+fZd2iBHYeXODo9T5o6yqWQifEqx6+ZZO2aUSaGh3M6etzGaC09yeT66+7Qn/nMN9m27T4uufix/NkbXsualWM+7i7ooBgQpxF7DtTZsmM/O/dO0U1SKhXL2lUTbDxxDSesGiUyOTN0uq3Ytusgm+/Zyf4DMySZplKtcvyacc48bQ0nrBunYBRJp0lUqMn0zCLv/ccPqE9/5jNp2ml9oFQyl+/fv3/p0bn2i0+Cx/49MMCA1ohzGN+o6BatNjk73T+80IwvH39yxYQvM8qfHBpzYjGMKj4TIc5E4ZVWSkVBNxuOumbCKDViBWVjvCiyGJqpoi4hrVT3GjHdOTsctexgNJcM01n+NGVGz8BVNGqghukqmN4HvinR7HWqMv29nzjnXj47e+SuX/cC+O85smvAUqUaFsLhwAQrlA1PFK+XWbGB0so6FaeZuMMo+xMROdw7snjwoW9xme77VCoeStz5/TPPvPCdL33ZS2sveMFvsGrVqE/TRGdpgjZCEBqUGBqdjLlGl3orZqnexHuhWIwoF0rUahEDQ0XKYYD1kKW5S3toLKmNmG90/O2bt6kvf/N69aPvf4/m4pTYtHeXpI2PLizMXJM8IHB/dEI+Oh5WBBERRoKw/I4nPfPZv/fmN/1pdOH5j3Xae52lPSVaYWyQ5z06j9YKq22OL7kMlEW0wrkMawBtSMTT8ikWTRGD1Spnl3qFMgXZeWBGvvyVr5L5VD3nmc+STSesxRqUF6dEMowWwOTaOwVa97Ozsz4cagBdkJn5lvz4rnv1v33hq1z17a9Md3v175RLA6t9Ko858aTjh1/3+6/mWU9/qh8oF5SkqVLGQxAAwQNXwLsczsWgdQEvIh6nIqXABLnllXi0SlBa8nQsJUDk5xot+f4PbjEf/tBHuPWWm7ZYoz/W0+mnW1NTs4/OtV96PVa/oIg82B7xIZl6pVJp2WCleE4pjN5YCILHWZODZ4bMu55kaWZUapx2SnwEOu9Z5ybkXhudSBB7HfiiUZGEJXW0V1KLo5fgSmegwgLOCKqXoeYPgo0lat5MdfGWmzLlXjV/9Oh9/xUL4CNd/EeCTQ0TRHQpFKLCYGBKy5TKvEubezuzTD3o9Q++AA9vNGuRPJgrKBYviKq1P3/Mqec967nPfT4XX3QuJ5+wwQ9UA5yHLEuViFOQ9jUrtp8VKFjJY2elnzeotJFeCvNLS3LPjt1y/Y8269tu+Ynace+ddJpLzZItiPKtra3G/NsajYVr/hNY/aPj/46hlVL+Va96VfDhD3/4WcefdNq7nv7s5xz/9Kc+izMfc7ofHS2Suz95vPcKEZxoUu9lbqGutty7j4JCHvOYjWpotIQlX6IydT+Sr5xHWq1Edu7ey9e/e5355lXXMH1oD0p7RkZXcMEF53HJJefzmE2n+FWTkxJaC8aDQmmdv4lzSC92qtFscfDIIW6/7W594/dvZvPmW7O5o4f+zYh8Lgj8oTiuN8qDI8sa8+2NhXLl0vMuvORpL/2dl3LRRRe44ZEKodG5mkODyWOypdNL1L59h7j11ntYvWqVPv0xG/zQQMkra9Sx3ax3icoykU7Hq/1Hj6gbb7hVXX/dtdx9962H6otznx0sFz558ODBLY9uNH+lteBnXcOHFJ4BGBqYnHx2aPVvFsPw3KgYjVojiHeI5AHLCoU2OTvUZY4s9fQy751nQZQphZVSqRlrfzjYqNPSBQg1CBRWUtK4R5DukYGl65XN5q+qJ81XdObmjv5n77P6Nb4J8kt8r/yS7ykA5523snjvtvbvVIqDfz48uvy4Ezeeytlnn8kpp2xk1cqVjI2PUKuVKBa0px/ak7iMTurIMpFGvaOmZ+bYvfuAvnvbDrbt3MOe7VtYmj2CxJ19ocq+bUzyg243qSeJPtxuz2zpPyS/aIf16Hh05Lm6SlEs1s60xvz+yMTKSzdsfMzgaaduYt26dUxMTBCEIb1el7n5JXbs2sfmu+7i8OGjKO1YuXI5p512KieesIHJiXGCICDLUubm5zl0+DBbt2xj533bmT5y0DuX7jJW7vZeFr3Pat6744vlwVOWLVsXHbf+OFasWMH45DiDQ0NYY+l28595+PAh9u3bz/SBQ8xMH+6mWed2pbMvDZbd53btmprtOxndT0oYHR1dlnl1xfjEqhevO35j7YQTT+C4dWsZGxsjCCztdoMDBw+za+cu9uw7wOzcPEYb1q1bw4Zjv8fYGMpo6s0GBw8eYdfO3ezavYvDe3fdnXZaXy5o+fxCa/4+ebTw/VqcIIeHWVkuLz8jCMxKvIwoEYf3eG0G+mTV2GX+sKR+b+bT+bjtpwuVwinlwer7dVA9Ya5lXUuvNJldk4cLIIjpSDHdKrXenrsk6X5FGfn7o0eP/qfbSeq/wMX99+xKfu4u+9hNWj60fFVbu+Pj2J1vTXBBqVQ7sTowMjIyOjI0Pj7GyNgEtYFhxMBio8nCYpt6vUG90aDVqNNtLuKT3rzVMoUkm7VLrk2Sxg/n5uYOPQgzf3Q8Ov7D7QGlYHBs/NRenJ0kyKpKqXqCCWqnKExZxEPmSJPOUUeyuVYpzKGUa7U6k96pTTaqrNalstZKWe+ckjgecC5eQGdbC9ZO6UTfmbjGTXP5DjoGWLdu3VAcu/XdLD0lzdJx0IOFYPB0a8MBpVWIZF3vOrNZljZQaslqM6UD+U5B63v379/fewSo7NiHUwqGJiZPTlN/ls+CDWFQGA6CwCilxjOXTsa95q7Mx/dUy+W5QiFqJN1Ws9VKlumgeo42umiNQaHXolwxSTubM5/utCrYNTwQ/bDf53sUYfn1eHYfAo/+e8fExMSmQnnkSquCkxq9pNP1tRJOobIYFSoC09oSZI2vOad/NDd35Ju/is2O+r/wJj1kt7JmzZpoaWlpWUpn2KfRJu/dKmvLp5VKAyeLoeTEiXFuHsVebThktDpsHdsMzf3x0kJnqsehR7jpj07GR8d/ChLlkVl+wQhEPo9DzR4pCmvjxo2hm54uLMzPSwyhVFFBMDkuotpaJ4vz8z/ldPKLRsBKLAZhP7JmDWr/fpKHbfJ+kXD8582DklJ05BfPFDvBRGGa6fYjXCse3XT+2j2/6pJL8udi/MYH3f9+OPaVV/7UYUYD2fD4ivMqQfG9ypiJGGygDChdSJP4iEuT20Sy243JPjM9Pd35Vayx6v/SG9TfrVwmcLk/9oUXXXqpueemewa7QTcIXdMoHYSZtTaO6R6ePDzNHchDF5z75/aDRc+PFr1Hx69wIblUXXopbNy4Ua644govP4WDvE3DVgUb5SEuI0o96El8sLHNZar/fY9UmBRcqrhso1wGXHHFFR76fhD3f/Oxl9xPOPvlxdeXXKIvAcbHxwXgC1/4gldKyQNOKVv769GVwKUc+7vp/y6CgD+Wb3nlsaL36Hz7P6tw+nK5PFGsVk/U1q8QkUywy7S4rb1W785Go7Hwq/yB/y+wjXpktqFqgwAAAABJRU5ErkJggg==',
                    alt: title || 'دفتر مدیریت کلاسی'
                }),
                React.createElement('div', { className: 'flex items-center gap-8', style: { gap: '6px' } },
                    React.createElement('button', {
                        onClick: onWeekly,
                        className: 'header-btn weekly-header-btn',
                        title: 'برنامه هفتگی',
                        'aria-label': 'برنامه هفتگی'
                    }, React.createElement('img', {
                        src: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAIAAgADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDgEPNPHWmDGaeK+9sfkbHinUynjpTJFAp4GKaoqTFBLHKOKeq0xc1MgoIbG7aeo4pcUoFFiWwxmlUc0oFPUUiWAFPUU5RS4zSJYAU4cGgCnKM0rCHKeKUZpMHsKeBSaIYAc04CinLUiuAHNPpMCloJbHL0p6imLUiilYzbFWnUoFOC0mK4DrTgM0oFOValktiqDThSqKdgUiGxqqBUgFKozTgPSkxc1hmMU4CnBacFoJ5huKUDIp+2gCkHMIFxQR7U8CgLRcVyMLQVqbZTWX2pXFchIpNvNTFeelJigpMjxQQaeeKMUBcYKXnNOApcCgLjQoNLTgKAtSNMQdKUCnBacBQMTsKVBSgU5RzRYaY4CnULTqljuAp2KMdKeBUgNAp6r3oxzTgKTBAe1KtBFLipZSA0ooxRikDDjGKQ0ppDQI8T47VIoqNRipVr2D22LTlFNxg1IvWgljlAp4HNCCpMUENggp9NUU6ghi45p4GKaKePegm4DrUi00CnikybjxTlFNFPWpJY4ClAxQKdjpQS2A604CgLTwvFJmbkIopwFABFOApE8wDJFOUetOVeKXHqKBNgBT1XFIo5qQCkQ2KtSIDTFFSLUshyHCngelIoFSKM1LIuIFzTgtPAAFOUCpJbGqtSqKAoqQD0pMV7jNvtRtNThaXZxSuK5DjigLUvl96cIxRcZGFp22nhOaftqGwItvFIVqfZSeXzRzAVypphT2q4YxU9npl9ftiytJp8dSq8D6npWdXEU6MeepJRXduy/E0pUqlWXJTi2+y1ZlFKQJiuhk8KeIUTedKmI77CrH8gc1kywvFI0ciMjrwyspBH1BrLD4/DYn+DUjL0af5GuIweIw38am4+qa/MqkGkwasFO9Gyuq5z3IADT8U/bxxRt5phzDcUoFP20oHqKBqQgHtSgU4CnYFIdxoGKcBxS4pyg1LZSEUU8UoUd6coFSyhB1pwFKBSgYqRjce1KBT8UEUmwG0ClIoxUsBKQ80p6UmPWlcDxTqKcppF96kUYr2j22xVGakUUijtipEGKCGOUYFPWminjNBmxaeB7U1etSLigliBadilHSnADFBDBRzUiimgc08UiWxe9PUUADFPUcUrEOQKDTwKVRTwKRk2IBUirxSKKeBSJbGlRSgcVJjNG2gnmEWlxRgilA9aRLkKgqUCo161KtBDY5R2p4XvQinrUqpUshsRRUgHFORPWngVLJuR4PpUicGnKoqRY81DC4i81IgpyRmplTjpUtgMUU8JmpI48mrtlaC4k2lxGi8u57D/ABrjxmNo4OjKvXlyxirts6MJhK2MrRoUIuU5OySM4rjg96l+zT7N/wBnm2+vlnH8q7jRbjRdPKiG1Yt3mZQWNdppVxb3aAwyBga/MX4o0a1f2WGoXXeTs38rP8z9Kh4YYinS58VV5X2Sul87r8jxFVHanbK9h8UeD7PUrZplhWG4AyJYxg5/2h3FeW31lNY3b2tym2RD+BHqPavs8p4ho5jJ0nFwqJX5X1XdPqj5DOuHMTlVpS96D2kvya6MpBOOlKI6m20NhVLHtXs1a8acHOTskrv0R4lKjOtONOmrybSXq9ixptvbB/OvFLIPuxj+P6+1dXY6+IUSNLWNI14CrxgVxMVyXfOfp7Csy48d+GLC++yXeqLG4baW8tiin3YDAr+a8/zTH59jJVdXFfDFXtFenfu+vpof1VkHB+CyPBRpWTm170urf+S6I930S+tb6MFWAbuD1FR+KvC1rq1mzSxjzVHySqPnX8e49jXBaDqYSaK7tpVeJgCGVsqynuCOtetaJqEd7ZqwIPHX1rq4bxMa03SnJwqx+GS0Z5+d5bGMXGceaEt0z5/1Wwn02+ks7gfOnRgOGHYiqhFeo/FTRkkhN5CvzxjcuO47j+teZFeMiv3HhrOZZnhX7X+LTfLL16NeUlr63R/P/EuS/wBlYvkh8ElePp29Vt9xCRgZpB9KkKnNJtr6VHzog69KXg9qUCgdaoBVFPwM0i08DNIaExmlAxTgKAKhloUDinKKVBTsVDLEApaKBmkUFFFFSxXDApDRzS/WpYxtLilI5oOaQ2eJKM1IKYCcVIgz1r2z2GSDrUgqMdaeBQQx9OFNFOUUzNjxT1BzTVFSqOKRNxQOKctIBT1FFyGwUU8DmgCnqtIhsVRUgHFCinAUjJsVRTwKEHNSAe9JmbYLTgKVVp6DtU3IbGhT6U4KakC10fhjws+phbu+n+yWR6H+OT/dz0HvXmZrm+DynDvEYufLFfe32S6s7cuy3FZlXVDCw5pP8PNvojmdtKEr2rRPDHhNECRWFvcN3aY72P51pX3gDw5fQELpkdu5HD252EflwfxFfFYfxLy/ETtClNx76flc+uqeHuY04Xc483bX87HggXNTInFdJ4z8H3vhyTzdxuLJmwJduCh7Bh/XpWBHg9a+6wGY4fMKCr4aXNF/1ZrdPyZ8TjsHXwNZ0MRHlkv6uu6HRrUyrSIO2KmRa6mzhbsT2FlPeTrBbqCx5JJwFHqT2Fdtoeg+HLcj7dKL2bvuyIwfYD+tczZy/Z4PIjOGbmQjv6D8K07aQjB5Nfz9xnxxjsTiZYfA1HClF2utHJrd33t2S+Z/QvCHhxhaOChisfHmqyV7PVRT2Vtr9/u9fRrPw74furcKulWBQjtCufzrB8T/AA+gWJrjSMwuBnymYlG9gTyP5Uzw9q8tlMmWJiJ5HpXp9g8V7Zh+CCOa5+Fs3xeJk40a7jVWtm24v1T3OnPOG8FbkrUk4vqlZr0aPnKSGSGVopkZJEO1lYcg05UrvfiloYt7j7fCvTAf3XsfwrhkFfsuSZws0w3tGuWcW4yXaS3+T3Xkz8LzvKJ5Vi3QbvF6xfdP9ej8xypik+04YRp0B59zRdSCK2kcn7qk1iC/WO3mmJH7tC3PrXwniVi6jp0cHHZ3k/O2i/X8D9U8Hcqp1KuIx81dxtGPlfWX4WX3m++t6VZMkV7qNrbO3RZZQv8AOul0bVHs5kmhbchwTg8EV8t+L7h5fOmmJlkckknnNexfDyOXRdJ07SJpGZRCAS7EkOfmIGe2SQB2AFfn0+Eq0sDUxtB3dPWS8u69PyP1HNM7weFxVHB4jR1m1H1Svr+CXm0fTeiXkd7ZI4wcrn6iuJ+J2iqY/tkS/NH8wx3HcU/wFqn7prctyh4+hroPEBF3p7oACQOM162Fz11MBTxK/jUXdedt16NaM+VzPKY1XUwlT4Zaf5P5bni5X0qlrDmKxLZxlgKZeanPFrNzpkOmzSSQyFMgk5HUEAA9iKnufD3inWYFhj0e5jjLBtwj2/q1ft+LyyvmOWN0moqrC6baWklp+DPxbJKUsuzilUxEG1SmnKyu/df/AADl9a1JrbRriSJ8Ow2Kc9M15Jq0C6hqNvYhgpnmSMn6sBXumpfC7VXhxqGo2dlGDuIubxRg/Ra888YfD/w9aRyNP4psp5h/BbRs/wCtfO8O+GU6ck6mJje+0VKX42SP2XM/EOhVi4UqMlpo5WXztds73wzqmnWc8Gj297Zj5NsNukylgFHQKDnoP0r1rwHqRWJ4Gb7pyM+hr4UtzF4b8V6dqlnI5W1ukkJ6fLuww/EZr7E8N3QS8Qo2Vcdc9a+I8Vch/sHOIYqjoqivp3Wj+9NP1OrgxyxWSPDVJubp7N72eq77ar0PRNdkS6sHUgMQMivDL29MWqXNlHY3DmGQplRkEdv0xXrbXgZCpPUYryjxZ4o1zRPFz2dheeRbvEkgCoM5OQef+A11eE2N+u55Vw7V+enfdrWLVtvJs+e46yilUy+FWp9iX4SX+aRH9rdBmWzuYx6lf8afDeWkrBRMqsezcVcs/H3iTaA1+JR3EkSsD+lXDr2jasoj1/QLVyeDcWg8qQe+Ohr99q5a470//AZX/Bpfmfkcsvw0tITafmv+HKBTB5phAq3qWgzWdmdU8N3h1fTE5lgb/XQj3H+fpVKzuYLyATQPuU8EHqp9CPWvNq4dwXNF3X5eTXRnm4nB1MM7T27kiingUmKXIrA5rAaX0oApRUtFJig07rTSPelxUMtMWiiioYxe1IaWkpMBcUYpc8UnWpGGaBS0cZpDPEVFSpTBUijAr2z2GSLTxUainighjxinrTRinpQZsctSCkXpT1FBDY5RUiCmqKkApGbFxTkpAOaeOlIzkyRadgUxTxTwaDJselSD1qMGnK1JkNkq9KkTmolqWOokQ2aWiWkdzeqsozCnzOPUen4/412UU7uQT0HAA6AegrmNFIjhdjwWYfpVTxnr1xY2qWlm5jmlG5pB1Vfb3r+deP8AHVs1zmWGi/dp+6u195P79Pkj+mfDbI6eAyWGKa9+t7zfl9lfdr8z0C1lkjcSKxVhyCK7/wAH6yLxfKlIEicN7j1r5O8I+K/EUPiuO1W+lurEgtcRTtuwvqpPIbJHtXu+gaksF1BdQPlGx36g18vLAYvIqlLFy1pye/R23Xqe9jJ4XHVKmFhJe0gk2uqTvb77HqfiPSrfUNNlikiWRWQhlI+8O9fOWv6W+j6xNYtkqp3Rsf4kPT/D8K+krO7D2q5OePzFeTfGiwjiEeoAqojbaxPHyt/9fH51+o5Dm9PC5rSlRf7uv7sl/e+y/X7J+U8X5R9cy6dRL36Wq819pfr8jzxDU6nahf0qlHcQv91w305pt1cloWhhU72xgngda/WcbhMZPC1FQg+bldumttNz8myqnCWNo+3VqfNHmfldX/AtNfGGGa4Y5WNSx968q8Va1qE073T31wsucpskK7PTGOldxqWm+Ir+xe10+zml83GTHCzH6dK4/wAReAfGccBll0u5hUDO6VQo/WvyzI/DHN+bnrKEG+81e3orn9NYvxAydrlozcvSLt+Nj1/wDqOoHSbWz1q486+WEFpSAC/cg+46Z74zXsngXVS9sYS2TH8v4dq+H9E8W+J9J8eaTJrGsTz232pYpoiwCbXO08AAcbs/hX1t4PujDfMB0ZcV8tx5kP8AqnnlOpQXLCavZdOkl+vzOTh/FYjNsnbxclKpFvVdVuvw0+R3fiyKK+0uRGAOBj8D1rwS51mztdQnsik7ywyGNvlAGQcdSa9unuvOiZM8EYrx7X/E3/CPeJ7qzttI0uSZwspuJYNztuHf8Qa+m8NMfHH5zXoct+eHNa9tYtK/3S/A+N42yiFXB0603Zwlb5SX+a/EryG81OzkgtLCZ/MUrlVZyPwArNn+H3jC/t2hj066SOQYYsojGPqxrabx74nmTamoi3T+7BEqY/SsXVtb1W8Q/atSu5s9mlbFfs1ThrD4mrGpWw9Ntbc15W+Tsj43L81rZZRlRwlacYyd3ayu9t9Wcd4z+F+pWFsz3mp6dbkDlHu9zfkK8mluLnw94r0/Vvt8lzJa3aSF2dmyA3zcn1GRXqHiAHax5JOa8k8dXFvbKyTN+8cHao6n3r6LEZThaeW1Kc4xSkmnaKirNW6Ho5bmWKrYuE5SlJru7v72fbXhK4Ed+rA/JIpx7+ldm94ChGe1eVeC7t20zSpWyC1rEx+pQV2K3vy8tX8E1a08LUlTT0P3vG4X2s1O26OB8beJdd0TxhLa6ffG3hkhWRdqDOSSDz/wGsybxHrV4n+lateS57GU4/IVU+Kc3m+NIipyRZrn/vt6z7cnYK/tDgKhTqcM4GpOK5vZrW2umi/BH8+8T81PNK8E9Ob/AIJLesZMu5LH1Y5rk/EA3BhXUTnKmuf1eIuTivvcL7rPDpbnjnj28htC0DZeVxkKOw9TX1j4QnY6Tpcz5DNaxMc+pQZr5CuLP+2vE7faX2rcX4hZv7qb9v8AKvrfQZBJFGIuI0QBR6DHFfzV424t4itQg9lzNejsl99j988PsIqeGqv0T9f6Z2IvBjg15T8TJS/jOEjtaLn/AL7eu+RmYgDOa8dk1wa98QvEkaMJILCaO3hYHI+Vdrf+PBq+f8EcI/8AWR1ekYS/Gy/r0M/EWMaWUOK3ckb9k2FFaEb8dazYBtFW0fAr+q6kbs/A2bWjapdabdrdWkpjkXg+jD0I7ipPE0cFvt8XaPFstJmCanaL/wAsn/vAenf/APXWIJMVq+H72OO6e0uvms7xDDOp6YPQ/ga87EYZfHa/dd12/VdmXC04ulPZ/gXFkSSNZI2DIwDKR0I9aAaxfDrS2st9ok5zLp8xRT6xnJU/z/StYmvmcTh3QquG/b06fgfP1qcqVRwl0JwacKiRuKkBrnaIuOBpQaYTSg1lJGg+ikyKXIrNjCilpKTGOxmkPBoXNB4pDQZpDRmkJqRni461IvSmqPanqPWvbPWbHKDUgFNU46U8UyGxwFPWmCnKKRFyVelPXrUa1KlBDJFp4zTB1py0jKRIKctMBp1Bm2PWlzg00HApyK8jhI1LN6AZoIersOBpyGrtro9zKV3HBJ4RBuY1o3+maVolus2tXfkMfuw53SN/wEVvDC1ZtJLV/f8AcdEMBXqdLepjK3HapldVALOq59TUmnw6l4ivhZ+G9KkA/vbQz49Sei11tr4K0fRG83xX4iRbjGTa2g82X6Fu1bVMDTo6Vp+8/spXZtHKZvW+nfZfezmbe9dQFjikcDnIHH61yvi641K+vpZYbcY2hVUtlsAegr1n+3vB2nIV0zwq123aW+nJz/wEVk6l4/1WGF106x0rTgRx5FquR+Jr5ih4fZVVxk8VOhKcpNv3p8q1d9o6n6FQ44zPC4Olg6VSMYwioq0bvRW1ctPuPBRqHiLQHuLiPTo/MmUKHmhbgA545FesfALxRf6/4cvY9VMf2uyudvyLtHlsMrx9Qw/CuD8d6tqurFpL+8knPOAcAD8BTv2cbp4/FmvWe/5XtY5Cue6uRn/x6ufxS4aweH4Xl7GCj7NppJt9bPV67NnscF5hUxWd+3q6zmrN9WktPyR9faDqPm6dCS3IXFZHxES2vPD9yL1JHtxGWkEf3sL83HvxVLw/dbLAKW6E0viK5EujXaMcgwuD/wB8mv5cy7MqlHE0EnrGcWvVSTP0HG5en7SLWjTX3o4DTtd8EQRqbLwxPdNj711cnH5CtNfHTW4xpvh/RrL0Ig3t+Zry7RGIiUewrbU5Ff3dWyug3715erb/AFP5yliqkfh09EjptT8feKplIGqtAv8AdgRUH6CvOfF2qanqO43d/czn/blJrbuSdtc5rCnax7AZP0ruwOEoUXeEEvkhRq1Jv3pNnlPi+WO0kE0rhWDBkz1JHPFfYvhy7LSW8o/iQMfxFfEa29z4o8R2yscC8ulijB6Rx7v8MmvsrQ5R8oi+4igCv5p8ccXHFYjDpK1lJ+dna1/W2h+88BYKVPB1ebyXz1O6F7gda8b+J5VvHAdeptI8/wDfT16KtwTxmvJNc1SHWvHOtrCQRp06WhIPUqgJ/wDHiw/CvB8DsPUlxJKo9o05fi4o4/EGnGjlNurkv1Ldqx2DJp1wcpTIhtUUSdK/rB/Fc/DOphatEWzivCb22k8ReIx5jBWu7wQKT0RN20fpzX0LcRbmBxnFeJa5YzaH4jubYDbJbzi5tmPRlLblP07H6GuHPKdXEYOVOl8VpW/xW0PpeHatOnXvPbS/pfX9D6r8PsEhhijGI4owqj2AwK3Y5STivMvh34/8P6jYhnvoYJ9o82CVwrxn0weo9xxUXxI+MGg6FpE9v4euo9R1mRSsXlENHAT/ABuRxx2XqT7V/Ez4ZzLFY94SNGXPe1rPTzfl5n9G4rH4WnR9vzLlto7mdqOtprvxJ8R28JDxaa8VsrDodq4b/wAf3VqxjC1w/wAGNJubXw9c6zeljLqcu5C5+Z1XOXP1Ymu3zgV/amRYFZfllDBp3VOKj9yP5kz3ELE5hVqr7TuK4zWfeQ7hVx3qGSQd69mF0eZHQ8W8caVNpGuSqoMcdzL9ptZQOA2ckfUN29MV6v8ADz4o6Bb6Ulvrk4sbwACQSA7GPqrdMe3Wl1Ww0/VLRrTUbZLiAnO0nBU+qkcg+9cZe/Dqxluf9F8QTW8Wfu3FvvK/8CUjP5V8NxdwPheIoRVa6cdnHdLs09z77hzi6plaaVrPdO9nbqrbM634jfGvTrXS5rHwiZLi/mQr9sZNscAPVlz95vTt39qxPg/ok+l+Gnv71WWfUnEih/veWOhP1OTUNh4N8L6PcR3N7dy6xOhyqyqIoFPqVyS34muphu7nUZcWVvc3sh6LbQtJj0ACg4FdPCXBeE4bpS9gn728pbv/ACt2ObiTiOtnTUbaeW3+ZpiQClE2O9WtO8GePdRYC18IattPRpohCP8AyIRXQWnwe+I0y7n0/T7b2lvVz/46DX0tXH4GlpOtFfNHzEMsxU9Y039xy6zc9alWUY4PNb9/8KviJYIZDo0N4o5P2W6Rm/JsE1ydwLmyu3s7+2ns7qP78M8ZRx+Bp0cRh8T/AAJqXo0zOtga9D+JFo1L64MfjDTr8fc1OzMUn/XRB/8AYj862t3vXIa5Ow0WzvV+9p96smf9lsZ/lXVFhng5HY14WcUeTkl5Nfc9PwaPEzWFpxn3X5E6vUgfNVQ2e9PV68No8xblpSDTgarhjUgY1jJGiZNnFAPNMU5FOrJlJkmeKKZngU5elSxocDikNL0GaTNIY3FNY05jkUw9KBXPHl6U9aYKete0ewx46U8U1aetBDHL1p4pg605TSIY8e1SR0xRT14NDIbJBUi9KiU1IvSkZSHDrTgDnmm/jSPIFwueT/KrpUp1pqEFqyYQlOSjHcuWsKynLnan6mui8P6dJqF0tjp8Q3nknso7lj6Vy8E5Z1jQEsxwoHc103jbXLfwT4XOkwSBb6aPzNQmB5UEZEQP869/6l9X5adPWcuvbu/RH0GDwMKer/ryF8Y+MLDwnbtpmgFbvUHyr3fUse+z0Uetc/4C8N3XjK8l1fWbxoLG3O66u3P/AI6me9cJ4Utb/wASeIYLc5+1Xzgc/wDLKPrj8ByfevY9au7a1tYfD+lYTT7L5eP+Wsg6sfXmu+tS+pQVGj/Elq5dUu/+S2O2vKNGN5L5GpqPiVLOz/sjwtD/AGZpqjBZOJZvdj1rmnJZizEknkknJNR7qC1c1HDwor3V6vq/Vni1a06rvJjZOlZeocqa0pGyKo3Kbs8V20dGRHc8y+JV9Jp2nL5PE9w/lxn07k/gKv8A7MVlJFqmu6pKWIMccAZurNks3/sv51R+Llo5i0y42/u453Rz6Fl4/ka0/gbfhJLzSgQribzceqsAM/mCPyr8z8WpVqmT1eXa8V6Ldv5vQ/WfDyNJ4unfe0n6va33an0TptwVtlHrzWf451qPS/COqX877Uit2H4t8o/VhU8GzyFKOuAPWvFv2ifF9vfNaeBtGmFxcPcJJfNGchSD8kX1ydxHbC1/M/COR1M1zuhRhG65k5eUU7v/AC9T9Rz3EU8Jg6lSTs2ml6s1tOh2KMdMcVqJx1qtBF5MaRN1RQp+oFTg1/c85c2p/KzQSjcMVl6hbCVGQ9GBU/iMVpMwqGTBpwdioaM8G0130HUrdpUYS6dclZlA5wMqf0Oa+pvAup2VzosVytzG6zKGV1bKkfWvJfF/gtNcmN/p08VtqIUB1lOI5wOmT/Cw6Z/OuOXwx45sJWt7DTNZg3H5vsUx8tvfKNj8a/JeO+AP9YHCpTqKE4q2qumum2zP1rhbjCngaMqdSN4y13s0+u+6PoP4k+PNJ8GaDLdfaIp9UkQiytQ2S7nozDsg6k/h1NeX/Bu1uf8AhG7rVr1mefUbtpN7dXx95vxJNc/ofw01G7vhfeK7g2cGcyRNMJbqb26nb9Sa9LWe2hijgtokt7aFAkUS9EUdBXqcBcEU+GqU2nzznvK1ttkvI8PjHiX+1rU4aRXTf+mXcgUxmFUGv42fZG3mOeipyfyFaVjoXirUsHT/AA1rFwD0YWjqv5sAK/QZuFJXqSS9XY+Gp4erUdoxbK7MuawvFOhaZr9ssN8rpJHnybiLHmR5+vUexr0bTvhR8Rb7BbR7exU97q7Qfom410Fh8A/EEzBtS8SafajutvbvKfzYr/KvPr5xlkE1UrJ+mv5XPTw+U49SUoQaf3fmfM03wxvOsGsaPPGehuN8TD6jaf0NaWg/DfR7SZbjXNSjv/LO5bS0UrEx/wBpzgkewFfVFj8APDi4Opa9rF23cRskKn8lJ/Wul0z4Q/D2xAxoC3ZHe6nkmz+DNj9K8SrxHlcPh5pfJL87M9+GXZlNWlJRPmafVrfIG+GNVAVI1wAqjooHpVmytNZ1NgNM0TVL3PQw2cjD88Yr660vw74e0wD+zdD020x08m1RD+YFag4rlqcaRjpSo/e/0S/Umnwwt6lT7kfJ9j8NfiNfgGLw3JbIf4rq4jj/AE3E/pXQWPwJ8ZXODfavpFiD1CeZMw/RR+tfSFFedV4xzCXwKMfRX/Ns7qfDuDhvd/P/ACPELD9nyyG06n4rv5vVba3SIfm2410Om/A74fWpDXNpf6g3/Tzevg/gm0V6aaaa8utxBmVX4qz+Wn5WO+lleEp/DTX5/mc3pfgHwPpZDWPhPR43HR2tVdv++mBNdDCkUMYjgijiQdFRQAPypxIpAwry6terVd6km/V3O6FKEPhVh240Emm5orK5Y8cVgeOPB+heMdLNlrFoGdQTBcpxLA3qrdvp0PcVuCnA1rSrTozU6bs11RE6cZxcZK6PkLxt4c1Lwzd6t4Y1UB2e2MtrOowtwgOQw9D2I7H8DS+Hbs3eg2VwTlmhUN9Rwf1Br3746+GB4g8Fy3tvFu1LSg11bkDllA/eR/Rlzx6ha+a/BEw/s2e1ByIJ22/7rfMP61+j0scs0yv2r+ODXN81a/z0+dz8w4qy1YZJx2vp/l+R0ytT1PPWqyt71KjV5TR8Wi0rVMhyKqoamj61jJFosLTxio1PFPFYsocaUdKbn2ozxUspDs0EjFNJphNIY400nHSlz7000WB7HkIzT1pg6U9TXsHsMehz1qRfeolqUdKZmxw5NOAxSDApwOaRDHA8U8VHTlNBDJQcU9WqHNOU5qTJk4IxknArGe93ys+eCePp2q3rM3kaXM4OC2EH4nH8s1zJuM96+n4fw65ZVn6L9T08rpJ81R+h6D8OmiOry6ncgNBp0JnIPQsOg/OvNviDrNxrPiNYppC5kkM8+e+DnH54Fdlo12LP4falODh7idY8+w5/pXlEUzXOu3s7HO0Ko/HJ/oK9qjTUsQ5Pq1H5JXf3n0OGhd37anrvwiiFtZanr/8Ay1RPs0B9GbqR+FbYb1OayvBGIfAVqo6zXDyN+HAq/vrnr+/XnN97fceXjZc87diyH4pd9VDLimmcDvUezuee4lxmFQuQRVV7pR/FVWXUYo+XdR9TVxpSGo3E1zS7XVNOnsbpSYplwSOqnsw9wea8q1Hw74j8N3i3iR3TCI/ub+0BIx74+77g8fWvVbW5nvpPLsbW5u2/uwQtIf8Ax0Gug03wd8Qr9gbDwrq8YP8AFKogH/j5FcmOpYacHHESik1ZqTVmvNM9rLa2LoSvSi310vo/Jnho8XePdQjNlbalfS+Z8uLa2CyH8VGR+GK6L4e+BZdEvV1/XQovvvW9qW3NGT/HIfX2r3bTfhB8TrtSLq50/T0bqJLss35Ip/nW9pn7Pt2QDqni8LnqlrZ9P+BOx/lXzWEjw9lMn7Fwjf8Akjv80j6DGYjOcyhy1FL/ALeZ5K1wo5J5qN7xAMlgK+g9O+A3gu3wb251fUGHXzLrYD+CBf510umfDDwBp5Bg8K6e7D+KdDMfzcmumrxhl8NIRlL5Jfm/0PNp8L4iXxSS/E+UVv45X2QnzXP8MY3E/gK2NP8ADfi/UwDp/hfWJgejG1aNfzfAr6+sdPsLGMR2NjbWqD+GGJUH6CrPbmvMq8by/wCXVFL1d/ySO+lwtTXxzfyX/DnyzYfCL4j32C2mWVgD3urxcj8E3V0Ol/s/a7Id2p+KrO2z1W0tmkP/AH0xX+VfQtFeZW4vzKppFqPov87noUuH8FDeLfqzyLTPgD4Wt8Nf6trN838Q81YlP4Kuf1rqdL+FfgDT9pi8NWk7D+K6LTn/AMfJrtaaxwM15VbOcfX+OtL77L7kd9PAYan8NNfcU7PTtM01Alhp9paqOAIYVT+Qq4u48txVe3bzZ3bPCdK+ZfHHxU1LxT4u8Q6HBqt/pml6VeNaJa2LeTJdbCVd5JfvBcjhVxxTy7La2ZVXCD21bZdetDDxTaPoXWvGnhLRL6Ow1bxHpdldSEBYprpVfn1GePxrallVIxIGBQ9DmviPxSLCXw9d2dtp9rbl0JJRMuzY6s7ZYn8a+l/2bNWfxD8DvDs91KZJobc2krE85icoM/gq16Oc5Asuw8K0ZN3dndGGFxjrTcWrHeX99Z6Zpc+q6lcxWtpbxmWWWVsLGgGSSa8Y8V/tF6do96kcHha9ltpFDxyXNwtvJKh6OsZBYKeo3Yo/bS1i70v4caVFAD9mutYhS6HZlVXcKfYsq/lXyFqd9d6lqE9/fTPNcTuXkkY5JJr1OGOHsPjqP1jEK6u1a7X5HJmmPqUJKEND77+FnxO8MfEWymfR5pIb23ANzZTgCWIHo3Bwy+4/Su1Ukkg9RXwV+zRe3tj8dPDa2LuDdSS286g/fiMbFs+w2g/gK+8GbFyBnqvNeHxDldPLcX7Km/dauu68jtwGJliKSlLcmopGYKOTTQXfkDA9TXhHcDGo5HCjJpZg6gt1A64qvZkT3DMTlU6fWpK6EqLJJyfkX360qtbNM1ulwhmQZZA4LAepFfOHxl+OdxF4j1rwzot++mW2lT/ZbiW3Tdd3UuPmEbN8sSKeC3LZ6V4BZ+L9V0nxda+KNHZrW+tJfNDGZ3acZ+ZZWY5cMMg59a+uy/hDE4ug6spKN1dLv2v2v8/M8nEZtTpVOS1+5+hxYqxVuvb3p2eKxfB/iKw8Y+DdN8TaWT5F5AJVU9UPR0PupBB+la6NuUHNfJVISpycZKzR6sWpK6HUopAaBU3KsPADKVYZBGCD3r4zNg3h/wCIWv6A4wIJpEQeqo+U/wDHHWvstTg18v8A7Qlh/ZHxrt9QA2xanbxOT6tgxN/6Ch/GvrOFKvNOvhn9uDfzjqv1PluLMN7XAtrdf1+djJDc4qZDzVdTzUoNd8j8gRbjOKsxmqUTVaiNYSLRYU09c1EDUqtxzWDLQ+imk0tSMRjim0NSZoGLTWPFBb3ppPFAM8lGaevWkpymvWPYY8CpB0qMHFOzxQQx1KOOlIKKCGSZpaaKXv1oM2OB96kT0qJakVuetJmUjN8WuU0lB6zLn8jXJGU+tdb4sG/Ri39yVT/Mf1rjjivr8il/stl3Z7eXP9x82dR5/wDxbplB5F2c/lXm+lPuvb4dw6/yNd1YsZfCeo24P+rkWQCuD0/MesXSf30DD8D/APXr017tSH+J/ij28K7wn6fqeyeD7gHwXZc/ckdT+daNkt9qd4LLSbK51C6PPk20ZdgPU46D3OBTf2e/CeoeOBLo6O9rplrN5l7eAcoCOI0zwXb9ByewP2B4Q8M6J4X0tdO0OwitLccnaMvIf7zseWPua+ZzziGjltSVOK5p726K/fz8jfB5LLFt1Ju0fxZ8+6H8GfHmpqsl6NP0eM84nmMkg/4CmR/49XWaf+z9b4B1TxTdyHutrbLGPzYtXt9BNfE1+K8zqv3ZqK8kv1u/xPepZFgqf2b+rPM9O+B3gG2wbm21DUGH/PxeOAfwTaK6fSfAPgnS8fYfC2lRsOjtbK7f99Nk10tNJxXlVs0xlf8AiVZP5s9Clg6FL4IJfIbDFFAgSGJIlHRUUAD8BTs80hNJmuBu50pCkn1opM00txSuVYfmlBqDzMnaoLH0FSJHIeXYD2HWhAyUUU3aVGc5FKpyKogWl7U0sB3qMOzk7Bx6mgCXNRzn5Dio7mW3to/MurpIU9XcKPzNNge2u4y9tdpKvqjhx+lOztcLoq6U5+2Txk9RkV8W/Ga0Phf9ofxLbRgpDfsl6uOh81Azf+Phq+0BBc2+pxzbd0LfKzL2+or5j/be0cWfjXwx4kjTAu7SWykYd2jYOufwdvyr6fhLEKnmMYvaSa/U8/NYc2HbXTU8uv8AVRsOWz7V73+w9rBuPC3iPQXb/jx1FbiMeiSp/wDFIfzr5amnL9TmvY/2MdZFj8W77SmfCappjYGeskTBh/46Xr7virDKrlc7fZs/u/4B4OVYiTxSv10Pp/4keE9H+IngzUfC+psyLKfkkTBeCVTlJB9D+YJHevj/AFj9nb4u6ZqpsrLTbHV7bdiO7hukRSOxZXIZT7c/U19k3cE8PiIyQyGNZmXP8j/KuB/aY+Jt34A07RbLTna2utYneNrwRCQ28SAFiqngudwAzwOTX51kWYY6jVWHwr+J7Pb1Po8ZQozhz1Fscj8FPhlo3wdlbxh8R/Eek2+tzxmG2jM4EVsjfeCk4LuehIGAMjnOa99sLuw1Ozi1fS72G9tpkDRywyB43X1BHFfn9r/i+71K8nuFEjyzZEl3eSfaLmQHsXbhR7KAK9p/Yn8ZNDqep+Bb2YmKZTf6eGP3WGBKg+o2tj2avcz3h7ELDyxtWpzTW+mlvL0ODA5hTlV9jGNl0Ppy6vLOz06XU9RuYrW2hjMkkszBUjQc7iT0rwL4o/HG4ltXh0CeXRdMcHy794gby8HrbxN9xP8Apo/4Cu//AGm9A1XxH8GNbsdEZvtcSx3XlL1mSJw7IPcgZA7kAV8Lyanc6v8A6deXEk87gBndsngYA/KsuE8nwuN5qtV3ae36/wDD6eXZ5ti6tFJQ2fU+o/2Xfi7qeu6/c+DPFOoy3s8qmfTLq4IMjhfvxMQBuOPmB9m9q98hdbLVzanhLhd0Z9x1H+fWvzl0nUr3SNVtNX02YwX1lMs9vIP4XU5H1HYjuK+wvDP7R3gC/wBEgutb+2adqSoPOtvsrSgP32MoII9M4NacTcO1IYhVsJTvGW6itn6LoxZZmMZUuWrKzXc8V/bC8FN4V+JMfimyhI0zxES0pA4ju1Hzj/gQw313V46K+lPjV8V/BvxA0BNCe0nt9Njuo7p7q5AE7GMkhYYlJO5uRuYgAE1823To9xI8SeXGzkqmc7RngflX1vDn1qODjTxMWnHTXt0PJzN0p1uam73Ppn9h/wAVORrngm4fKRY1CzBPQMQsqj8dh/4Ea+kI/klePsp4+lfEf7J11Lb/AB60dIydtza3UUgHdfLLfzUV9uTkC/OO6ivzzi7Dxo5lJx+0k/mfRZVUc8PG/QkzzThTRTsV8uemKOteF/tgaax0bQNeiX57a4kt2b03KHX9Yz+de5iuC/aG03+0vhDrJC7nswl2v/bNgW/8d3V7XD2I+r5nRm+9vk9P1OHMqPtcLOPkeAxSrJGsi/dcBgfY81Mh9ayPDk3m6LbEnJRfLP8AwE4/pWmhr6rE0vZVZQ7No/B5x5JuPZ2LUZ9KtwtnrVFDzVqIiuGQItg1IpqGM5qZMVjIokHIoyabnApc8VAxGNIaCRTSaY0KRnvTCKUnimFhSGzylTThTFNSKM16x7DHDpT1FNHWpBigzYClooNBnIVT2p2ajBpwNFzNjhTwcUwU5ealszZDrEXn6PdIBk+WWH4c/wBK4fBr0JFDAo3Rhg/jXASIY5GjbqhKn6g4r6XIKl4zh6M9TLJ3jKP9f1oavhoeYb206+dbtge4rhLnMGuxyHgEMp/LP9K7Tw5KItbtmJ+Vm2H8RiuV8axfZNTlwMeVNn8Af8K9rEaQ5u1n9x9DgNanL30Pu/4HaND4W+Gui6SsQjup4lubtsctNKAzZ+gIX6LXqeMAD0rz7T7j5LaQfcwjKR/d4x+leg5yAR3r8Qx05VarqSesm2ffRgoRUVsgozRTSa4irCk0wmj2pD7VJQuabnigmmlsZpDSFZqrXExBCrkseBSszO4jQZY1k+MvFOheCtLW91edjNM3l21vEu+e5k/uRp1J/QdSRWlKlOrJQgrtilNQV2Z/xW8e6b8OfDtvf3kBurm8uFtrSAOE82UgnLMfuqACSea+a/iH8YNd1e4mtrvV2mgBK/YtKdre1Hs0v+sl/wDHVNU/jd8S5vGF3HBrFpbMlnIzWmnQtuS2YjbullHMkmP4Vwo968laTcOtfqvDvDdLD0lUxEL1Pv8AS3+a+8+SzLM5zly0nofSn7GvjS8u9d13wnf3k0sRhW+sY5JGfysNtkVdxJx8yHH1r6VjbbI6eh4r4D+CHiD/AIRj4v8AhvVWfZBJdCzuCenlzfIc/QkH8K++Lw+XKr9ARg/UV8pxhg1h8wc4qymk/nsz2MorOrh0nutBWJmm8sHgct9K8w+MnxPTw/dyeG9Evba1vYYBPqOoSp5iadEfugJ/HM/8KfieK9EutQg0vw/fa1dtiC2hkuJD/sIpJ/QGvz18R+Ib3Xp59RvZCbjU7p7+656u5+UfRVwAO1Twvk8cwrynU+GH5v8Ar+kGaYx4emuXdl/xj4pl13UJJ5JLy9yTi41KYzTP74zsT/dUYFY2n6zqemXiXemX1xYXCHKyWshiYf8AfJFZdzdRwLvlYKtQ2t7b3LlYn59DX6vGFGnFUVa3Y+V/eyftPxPqr4CftB3OoapbeFvHckfmzsIrPVMBA7ngJKBwCegYY56+tdR+2ppH274PDU40zLpOowXGe4RiY2/9DH5V8asoKkGvr34a67N8Wf2add0PUJDPrFpZTafOzctI6x7oZD7nC5Pqpr4PPcpp5biqWPw6tHmXMui812TPfwGLeJpyo1N7HyIz11fwW1gaF8X/AArqjPsjXUEglP8AsS5jP/odcXaOZbZHPXHPsakYyKVeJtkqMHRvRgcg/nX3OKprE4edP+ZNfejw6MvY1VLsz9JvEZaNoZ1HKnB/Dn/GvOP2pvCa+M/g5d3dpD5moaQP7RtcDLHYP3ij6pu/ECrvg34y/D3xF4Us73Vdf0/TrzylN1aXkvlvHKB8wGfvDOcEZyKreJPjh8P7LTprXRZm1qYxsqQwRGOAkjHzSOAoX1Iz9K/G8JgMwo4mLp0pc0X2f57WPsKmIoSp+9JWfmfDtvIJoUkH8Qrf+H3iCTwp490LxHGxVbK9jaXB6xMdsg/75LVU12302yuUs9OuI7lY0/eyx58syEkkJnkqMgA98VkX+PsU3P8AAa/ZasI18O4S2as/uPjqcvZ1k49z9PdysqkHKuOD618FftIeCF8BfFe5t7KLy9I1hTe2QA+WMk/vIx/ut09mWvtbwzcT3ngXQbpc+dJZ2sjfii5/ma8R/bdtLS7sPCcfH29Lq5kU9xCIgXJ9s7K/J+FsRUw+Zxpx2ldP/M+qzKnGeGbl01PlQ0ZI6GkJqCKS7mLmDTryaNWK74omZSfTIHWv1urWhS1m7HyVOlKppFE5amk4GSce5rZ8O+CvH/iWUR6H4K1m4BOPMe2aOMfV3wv617N8N/2Vdbv7uK++IerR2VopDHTrCTfK/s0n3VH+7uPuK8fG8Q4HCxvKd32W53UctrVHqrEH7E3hO+1Px7eeNZYHXS9MtntbeUjAlnkwGC+u1M5/3hX1kJBNqErqcquFH4VRs7bTPC+j2vh7QdPisraCMJDFCuEjX+p9+pPWrtjEIohX5Lm+ZSzDEyrS0vt6H1mEw6oU1FFvIGSTgCuV1bxOyzstqxWIcKVUEv789B/OneMNV8qP7BC3zuMykdl/u/j/AC+tcPqF6IF3MrPI52xxqMs7HoAK/H+LuKK9OusDgX7y+Jre/ZW/H7u59PlmWKqvaVFvseieEtbOrrPDMFE9vtJK8BlbODjseDWprVjHquiX+lygGO8tpIG+jKV/rXO/DvSptOs57i8YNeXbBpQOkYA+VB64yefU11sZ5FfeZG8XDB0nineolq/669zycwhSVacaXw/1f8T4i8ImSGK7sZRiS3mww9DjB/VTXQIai8a2H9ifGPxJpoG1Jbh5ox7PiUfo7flSqxr9gzKSqVVWW01GX3pH8+5vR9hjZw8y0hOatRHHeqUb1YjavJkcCZdibmrMbVSiPvVpD0rCS1KuTEjFIDTMmlBqCrg2aYx5p7Goz1p2GBJxyajY05qY2TRYGeXLUi1GDTwa9M9lkgNODUxTxTlBJwKDNjw2aDTtHFrqmjXmo2V9DK1nNsmtxnzFXOPM6Y25468ZFGOlY069Orfkd7G2KwdfC8vto2vqhuKWlNIc1ocLYoNSKajxxTlqWzNk8Z5ri9fi8rWLlQOGfePxGa7FTiud8Xx7byKYDiSPB+oP/wBcV6+RVeXE8vdP/M68uny1mu6MSBzHOkg6qwP5GofiPbq1/JIB8syBx+Ip5PWrXitRcaLYXIGT5ZjJ+lfYSXNFpn0lCXJUTPrL4Wasda+GXhvUi2Xl02EOf9tFCN+qmvZNLl8/TreX+9GK+Zv2U9SF58JYrItl9Ovp7cj0UkSD/wBGH8q+ivCMvmaOqZ5jcr/WvxLM6Psqkodm0fo0Jc1NSNc0wmntUdeSykFIaU0wnFSUgNQXMgRCTUxNULs+ZNFFn7zgGkUiHX9b0/wp4T1DxJrEnl21pAZpT3IHRR7k4AHqRXxT8R/H+s63rFzqV1Lt1W8Ta5U5FhbnlbaL0OOXYcknFe3ftu69JYeGfDegxtiPUNQaeZezJAoIU+251P4V8mTTPJM8rks7sWYnuTX6bwbldP2DxU1dt2Xov82fMZzip8/soiSXDedHbQwyXFzMwSGGJSzux6AAck07Zf2t9d6dqlpJZX1pKYp7eQYaNh1BHrXun7J+ofDHwzDqXijxZq9pB4k88xWq3EbEwQbRzFgHLMSQSOcDHc55f4+Q6NrPj/VvGmjTm3sb9IQkVwnly3MoXa8ixn5gmFB3MBk5r36Oa16uYvDum1BfaaerOGphKVPDc/NeTPNJWYJujYrIhDKw7Ecg1+hng/XB4s+GmkeILUeZJeWUUxVeu/GHX6htw/CvzxyM1638E/jjqvw60Z9Am06LVtK8xpYEaYxPAzHLANggqTzjHBJ5ri4pyermNKMqCvKL27pmmU4yGHk1PZn0h+0XePpPwF1+NG23FzapZRqDyWldUIH4M1fC8ylJWiYYMfyH8OK9j+Jfxom8YQxTXcCL9mYvY6fDkwRSkECaV2wZGUE7VAABOTXjLsWYsSSxOST3Na8L5ZVy7DShWVpN3f8AkTmmKjiaicNkelfsyaV4T1D4rpN4xn09bW0tGks4L5lEU9wWAH3vlJUbiAe+PSvVP2vfAvhm90fRde8O2+nQ+IPtqweXZhFa7hZSTlV+9swDu7An2r5f3duDVyx1a/sElWyuHt/OQxyNHhWZD1XPXB9K0xWSSrY+ONjVat06el7/AKBSx/JQdHl+ZXkG1yuQcHHFe/8A7Dd/NF438S6UDmC40+K4KnpuSTbn8pDXz5u719EfsJ6ZPc+I/FPiDYRbQW8NijdmdmLsPwCr+dHFU4LK6il1tb70LKYyeJVjxT4laC3hP4l+I/DjqUS2vpHtwRjMLnehH/AWFYFfXH7WvwjvfFdrD428K2xudbsIvLubVBlruAZI2+rrk4HcHHUAV8epexmRop0eCVCVdJFIKkdQQehpcP5tSxuFinL3krNeheYYOdOq5JaMtq7qflYilZ3fG92b6nNVzdW4GTMn51C+o24IVSXY8AAda9yVaEVrI4FSlLZF0tVvw/o154p8TaZ4X05DJdancLAMDOxCfmc+yrkn6Vv+B/hX8S/G7x/2N4ZuLOzc/wDH9fgwQgeoLDLf8BBr64+AvwU0T4YwNfXNyuq+I7pNk1867RGvUxxKeg45PU47Divmc54lw+FpShSlzTfboeng8sqSmpTVkd7r2s6F4I8Ki91W7S00+yiSFM8s+BhURRyzHGABXxp8cPHl14l128vLlfKu7mMQRW27P9n2gO4RkjjzXPzPjpwtdJ+1xr3ivRPiti7QrpM9gi6PMRuWI/8ALZk7LJngnrtK4rwZ23MWJJLHJJPWuPhXJqUKSxcpc0pfh5f5/d66Zri5uXskrL8xHcIpZugFfbv7H+iSaV8ENNuJoykmpzzX+COdrttQ/iqKfxr5H+E/gbUPiZ44tvDlkHWxjYS6ndKOIIAeef7zdFHqfQGv0HsTY6X9i0GxiSGKG3CQxr0REACj8v5VxcaZlCajhYO7Tu/0N8nwzinUfU8J/aL+Ll3o+vXfhHR9Sn037HbJJd3FsB9ollk5SFGPCAL8zP15AFeBeHfix488P6qNQsfEeoykNueC7uXuIpR6Mrk/mMGuj/a/8L6t4e+K174mnglfR9bEbxXABKpKqBGjJ7H5QR6g8dDXjtvO15PFaafDLd3c7COGGJCzux4AAHU17OR4XL/7Oi2ou61vbfr/AF0OXGyxH1jS/kfo38PvEtn468A6X4otofKF1DvaMnJikUlXTPfDAj8q0NYv4tO05rl8HHCL/eY9BXLfBPwve+Bvg3pGhamVGoRwtJcKDkLLK5coD3xux+FM+ITX/wDoTwWs91AisGSFdzBzjBx6Y4r8V4mxEsJQrVMFFyavy9etk/ktT7PLKPt6kYVHa+5zur6jsL3NwxeSRuABkux6AD+lbfhHw/L566pqSZvGHyR9Rbqew/2vU/hTfCPhydrhdU1SMG5/5YxdRAP6t79q7y1t1jUV8Xwrww8M/rmM1qvVX6X6vzPdzLMIxj7Ci9Or/ReX5+g60iEa4FWV601Rx0pw4r9AjofNt3Pmj9qKw/s34paPrSrtS/tVRz6sjFD/AOOuv5VyQbHFetftfaaZvBWkauiZeyvvKZvRZEP/ALMiV47by+dBHMOjoG/MZr9Fw9T2+V4ep1V4v5O6/Bn5Bxlh/ZY7nS3/AK/O5dRqsxE1TjYVZiNcsj5JMvQmrMZqlE1WozwKwZZYzxR2pgPalLcYqSrgzU3NI1NJzRYYMTmmFqCfeo2+tNIo80pwPtTBmnZNeiewyQdKkT7y49ahUnFSIfmH1FDM2cx8MNbXRvEtySokRpXWSNujo3UH612etWp0nUgAd2m3QElpMeynop/lXkNncC08RStnhjnP4mvoTwR4c134g+FP7LtNPfykO6C+nUpAmfvDcfvDvhc18bHEPDVedM/W8TgKePwvsai6aPs+5yzDBppr0X4ifC2fwjoNneafczahb28Kx3zuPnVxx5mP7hPb+HjrmvOq+mwuLp4umqlN6H5TmWX1svrujWWv5rugzSikxT0VmYKAST0A71q9dEeeKtZXi5d2nRSgf6uTB+hH/wBYVuiwvhz9kmx67azPEURbR7pMfMq7sehU5rqwUpUMTCclbU0w0uWvF+ZxLtzV9/8ASfCsydTBNu/A1ks/Oc1qaAwmgvrTvJCSPqK/QIu7sfU25dT039j/AFHZeeJ9EJ4ZYLyMfTcjfzSvqrwNN891bk+jgfpXxN+zfqA074y2kDNhdQtJ7Yj1OPMX9Y6+yvCc3layinpIpX+tflXE1DkxdTz1Pv8ALp8+Fids3SmN0pzU0mvkWdaGmmc1W1jUYNNsXup8lQQqqOrMTwKxrfxRGZAJkjweoQkEfnwf0rxsfnuAy+rGliKnLJ6/I6qWFq1Y80I3R0LdKybt/Ku4X7BxWha3dtdxF7eUOO47j6iqWqxFoiwHPavSpVqdWKqU5Jp9URytPlZ4T+3jpUr+FPDfiONC0VhfSQTEfwrMowfzjA/GvlNWDqGHQ1+i2saPpXjjwdf+Gddh821uoTFKoOGH911PZlIBB9RXxN8TPgl8QvAeoTLb6Tca/oqkmG+sYjIdvbegyyH14x6Gv0rhPO6NKh9VrO1tvmfN5rgZznzwRwySOhyjsp9QcUrSMxyzFiepJyTUdta6zPOLeDQNUmnzjy0tXZs/QDNel+Af2f8A4meMLiOS/sf+EY0wkF7i+GJSv+zF94n67R719dic4weGhzzmjyKeArVJWSPNdwJ4INBNfQPxO/ZW1PS7KC/+Heoy6lJHEBdWV9IqyTOOrxtwvP8AcOMdj2rxW+8FfEPT5zb3vgTxAkgOCFsJHBPsVBB/A1z4LiDBYuPMp28maVstrUnormRkii3hvb7ULbTNKtJb3ULuQRW9tEMvIx6ACu08L/Bv4seJpkjtPCVzpsDHm41H/R0UeuG+Y/gpr6k+BnwQ0H4XRvrup3a6r4ikj2veMuI4FPVIVPIz3Y8n2HFcWa8TYbC02qUuafRI3wuV1Kkr1FZHxNq8OpaHftp+v6VeaZeocNDcRFGH4HqPcVX+32uMmT8MV+kd7P4c1218nWNMtbyLtHdW6yj8mBrGh8CfCmCb7RD4L8OrIDkEaYnB/wC+a8OlxxJR/eU9fU7Z5JBvRnwz8PvBHi/4haolh4X0mZoGYCa/mUrbwL3LP0/AZJ9K+6vh/wCEtK+GXw/tPDWkN5syAtJMy4e4nb78jD+Q7AAdq3U1S2t4VtdMs1REGEVVCIo9gKLW2knm+0XHzSH9K+czjPq+Zu0tIroejhMDDDrQp6Rf3FhGIbwmRB0JrK8XfD74aeNpTdeIfDmnXNy3W42mGY/V0IJ/Emurms0kGCBWdNo6kkqSPoa8WnWnTfNB2fkdkoRlucLafAT4KWj7x4Ztpcc4mvZpB+Reur0Pw98PvDOP7C8NaRZOvRreyRX/AO+sZ/WrkWjb22hiT3JJwKtppGmwukTzfv3+6CwBb1wK1niq9VWlNv1bJVKCeiI5telc7bW3/FuaovHqdxeR3QZ5JUOVQdMVsS2kVqmcZHY4rN8X+IIPB/gi+8RTwGZbaIP5YOC7EhVXPbkiudJt2N6VN1Zxp01dydl6sh+IngjRPiH4Rl0LxLafK/zxSoR5lvKBw6HsfboRkGvl20/ZV8dSeIzY3Ou6VBoiv/x/RlmmdPaLHDY7FsD1Nek6v8QtT1q3R5NbnSORAxt9OX7PGMj7pkOXP4Yqv8JvEV3Y/FmysVlkTT9VhkieFpmdfMCllb5ieeMZ9693B5hjMBSlGlOyfT/I9+twPWnh516zXNBN2s+m6vprbya8z1nwJ4Q8MfDHwuujeHbQKSQ00j4aa5kx9+Ru59ug6AVZkiu5JheAMbknI2/yrYubQS6nuA+8gJJ6DtVLxH4h0jwxAn2l2lupuILWJd0059FX09zgD1rxpSnVm5Sd2z56hSlNqnSjdvoi/fWtnqOhyW/iGzsprZ0/0iK4VXiI/wBoNxXjV9rHg/wlLLdfDzwj4d07G5W1Z7QIsjf3IQo3v9QQo96yPH3ju61a4aLUTG8aN+70yGTMEZHQzOP9a3+yPlFeeatqlzeTme6mMrYwM9FHoB0A9hXfRoyirN79Oh+h5FwUptVsWr+XT/g/l/iPo74UePrbxxZT2Ooww2ur2o3TQKfldO0iZ5x6jsfrXYS2iF9rjJHT3FfGvh7X7vS/GWk3mis8mqi5SOKGPkyhjgoR3BHFfaF65jETkckkGuLFUowloePxbktLKcZH2D92avbs+q9O33dBsUKRj5QBWVqviG0s8pCRPKODg/Kv49/wrlNc8Vtfxt5MogtOcDOCw9Sf6VzI1SW8cx6baXF/IOMxL8g+rHgV+VZtxjiK9R4bKoNvbmtf7l+r+45sJkspLnr6L+t2dRfa/eXMm5pAQOi4wo/D/HNaHgTWZ7vW7rT2cvEsAlx2Rt2Me2fT2rl7Hw3rV+wbUbxLKM9Yrb5n/FzwPwBrvvCejWejWzRWcOzed0jsSzufVietPhrIs2jjo43GTa3um7t3Wz8iswngqdB06dnLy2Xz/wAjM+OOl/2x8JfEFsq7pIrb7TGP9qIiT/2U18reHpfM0mIZzsJX8jx+hFfbFxBHd2s1pMu6KeNo3B7gjB/Q18R6Rbyabe6jpE3ElncNEwPqrFD/AOg1/QXD1T2mXVqL+zKMvv0f6H4zxzh704VV/X9XNdGwasRvyKqKamjPIrWR+ZmjCwq5E1Z0Bq5GaxaHzFoGgtUQanZFRYpMcTTaQmm7qdi0xSaY2M8UpbJpDSKPM+aUCgYpwxXoHssFpxyEJBwRSUN9w/Q0pbEvdHsvgrwN4LstQhvY/DGmNcuiv5ksIkIYjJI3ZA59K9m0O4IxHkAL90dhXmujOEFo3fyU/kK7jT5SrrjvX4m683Wbk76n9L1sND2EeVJaI6a/giubdi8ayRupWRGGQQeCCO4r5p+LXgRvC9+dQ09GfR7h8J3Nux/gPt6H8Pr9LWcoZcE5Brm/GX2WeG60i6thLa3MBRjnoSP5jg16dPP6eStYirK0G0mfH5tkUc3oujb31rF/10Pk6dhDBJM3RFLH6AZqh4e8UW7gMYiZGPJHX6VralbS293c6fcrteN2hkH6GvMdLZ7S9eByd0UhRvwOK/c+GZ0K95b8yTT8n2PyLC4FTjUhUVpRf+Z9MeB9d03UNKu7CPRLUXzWztDcysZH3AdgeB+FecX8hnmnW4wXlBDcYzkYpfAOqm01G1uN2AjjP0PB/SneM4BYa1OxO2JZflPqGPH8xXfi8ujGVWnBatXXXVdr/I4p80+WD3Wn+R5LK7RsUbgqSp/Crnhy68vVosnh8qfxqbxno2oafI+pvbEWFxOVjlU5G487T6HrXOWtwY7uJwcbXB/Wu6nX2b+Z9hSiq1Lmj1Oh8O6gNC+JWh6kW2raapEXP+wXAb/x0mvuOwna21OBieUlAJ/HFfLmgfCex8Uw/btQ16S1kmIZbe2Rd68dSzd/YCvomP8AtOCBGe2km2qPn2NyR34yK/P+JsZh8Tif3TvbRn6LlGQ46hh0q8OW+qTauexFs8io26Vz/hfxLaawn2ZVkhvIkBeGQYJHQkHuK3Sa+KkmnqFShOjNwmrM57xzZSajo720MgjmV1kiY9AynjPseR+NecS6hPZSiHV7V7OQnAcjMbfRhxXsVzEJFIIrGvtKjmiaKSNZI2GCrLkH6g18jxDwvh83aqSfLNKyf+Z6+XZisPH2co3j+PyOM0/UXhdZ7ebp0ZDXW6X4it74CC82wyngP0Vv8D+lctqXgyKNmk0uaXT5Ou1fmiP/AAE9PwNY9yutaWpN7YNPGP8Alta/OPqV6iviaGBzzhuo5UPfp9Vun8t0/P8AM9WpSwePXuytLz0f+TPRrq3mt5vNtiVOc8VZg154wFuYckdxwaxfhxf3OpWVysqS/ZYyoheRSMnnIGeoHFdNJYxP1Ar9TyzG/XcLCvyuPMtnuj5jF0PY1XTluiH/AISG16pCxP1qtLrN7MpW2hEee561cXTYR/CKnjtY16KK77nNyxRi2epalaptmUyDPU81eTxCu3DW5z7E/wCFX2to242io/sEOc7RTuJ2KMmuXEnFvbYPqeajW2ub5w92xb27VrR2kSdFqdVC9BilcNFsZbaTEw+6KRNIiH8IrWooHcqW9jFF0UVaVQowKWkJA60EinpUErfMqA4ZjipV3Sfc4HrVHVL7R9J2T6pqVtac4Rp5lQE+2etNJsqEZSfLFXZk+PfFtn4R0+GJUFxqV3kWltv27yBy7n+FF6k181+MPE0mpap9rF211qQlEramuVZWH3UhGfkjXt3PU16L+1L4U1LU7Ox8daHMbuHT7Yx3cMZ3BoCd3mLjqBk59ue1eDWN5FdRCWPoR09K9PBxhbzP1vgXK8FLC/WIu9TVSXby9Lff16W+r/hD45h8c+HpLK+Kx6vaKEukHG8dBKo9D39D+FbPxF0STXPhjreiOA00tjIsZx1dRuQ/mBXyl4U8Q3/hjxDa65prHzrdvnjzgSxn7yH2I/XBr7G8N6zYeINBtNY0+TzLW6iDrnqPVT7g5B+lc+Io+zldbHy3FmRPJcZHE4dWpyd15SWtv1Xlp0PjDwzeM+jQEn5gMGtWw1Y6Z4h0fVQcfY76KUn/AGdw3fpmqPiPTf8AhHvHHiHQl+VLW/k8of8ATNjuX/x0iqF6TJbSJnkqcV3xSnC/c/XqUKeMoKf2Zx/CS/4J9q+KdUXRvC2p60qh/sdpLcKP721Cw/lXydfeLNQ1OySeRyLy7iD3t2WJlmJJO0H+FAMAKMV9CTXz+Iv2f576MF5bvw9ISByS/kkEfmDXyRo17FPZxKsqllQDGa5MIlzNM/PuAsvpN4hVF78JJfdf9f60RryzqkRZiAqjJJ7U7whoPibx9qLaf4Xsy0KNi4v5flhhHu3c+wyarny2UqwDAjBB716B8N/ijqvg2xh0sWtveaTEflt9ojdATztYDn/gQP1rqrKdvcPus4ljqeGf1CKc/P8ATpf1seu/DD4VeFvh1bjUHxqGtMv7zUJ1+YZ6iNf4B+p7mutM017O0nKxgYQf1rO8J+LPDHjyy8zTrjFzEMyW8nyzRfUdx7jIroYoBAAnHsfWvHqKSdmfgWOliniJPGX9p1vuca3gvR2v2um09GZmLFWYlAfUKTj9K3LbSkRQqqqIOAqjAH4Vtbe+KMVx0sLRo39nFK/ZWIqYurVSU5N27lSG0ROg6VaRQo4FLS1ulYwcrj14INfIfxe0/wDsb4263Aq7Y7xhcp6fvEDn/wAeDV9eDpXzh+1lp4tPGnh/XQuFubZoXPqY3B/9BkP5V9XwnU/2udD+eEl81qvyPmeKcP7bAS8v+GPPYyc1YiPNVVODU6GvUaPxeWhoRHpzVmM8ZqjCeKtxtWTRBYVqXNRK1PFTYaY+kpM+9HvSsaxA0o6Umc0E4FJops8zpwNJRXce4xwOaU52n6UCnUMzZ7VY6zZJHY5f5Wto28wchcqMA119zfN9hj8mTDSAHcp7exrxDwldmaya2frAePdT/k13/hO6DQyWjH7nzJ9D1r+Z+KMVisvr4jCtap6PyfX5o/qnJ6lHMssoYyns4q681o18md/4d128WcWk7LKHBCMw5B9D61b1PdNC0jnc4O6uUjdo5UkQ4ZCGH1rrg6TRLKvKSLuH49q+ExOPxOJoqnVm2l3MsVQjRqqcFa54H8ZrI2eux6mi7YbuL52x0dBg/pj8jXhMsUt7rdxfWrQLbzPvBeUD6/rX1h8U9GOo+GruIJuktj5yDHUAHcPxUmvkHT4xZ3t3p5PMErIPoDx+lf1D4O55HGZVGnU+Ol7j16dPw0+R+ScSZWsHmVarT2qJSXz+L8dfmej+EIbWaQxy6pEuwAsIYy7Y9s4Fdt4rm0WXR2ns7K6ub1FVXur11PGMfLGowPrk15V4OuPs2uxAn5ZQYz+PT9a9DkxLazRH+NCPx7V+2VY+1qRqNvT+v66H53jL0a1ujKHjm8m1/wCGBEj72trQGNAMBGjPzYA7nac+ua8GtXaa7ghB5kkVPzOK9m0m5X+wdUtJDkROTg/3XH+INeSeD9Pnu/GtrYxxtJ5FwXfAzhUOSf0rzM0isJCTWi1/r8T7XhCg8VilhrXvKP3M998MZS9IViNqgcGvVPC2pahbzjyr+5jUqchZDg8V5X4ZYfa5cEZyBXo2jNsR2PaM/wAq/K5u5/VufUozvFq+gzSteu4vHcM801w6hJAxjl2NyPX617V4N1d9ShuoZJTM9rIqiUjBdGXKk+/UfhXzfFepH4mQE4aRXVfc5Fe5fCEE6dqNw3V7pUH0WNf6k1yVz5DizL6UMOqtrNJJff8A8Od+OaCAeDTV6Zqpd6rZWzsjuXdPvKgzt+p6CvMxWLoYWHtK8lFd2fnShKTtFXLL26P1UVWk06JmzgCsq48Vwx58uBT/ALz/AOArPn8XXWCY44V/4AT/ADNfMYjjTJqWntHL0T/Wx3U8vxUto2OutrcQjAOamxXNeDfEr6zeXdpIqFoEVy6DAGSRg+/FdMcV9Hl2OpY/DxxFG/LLvozjxFGpQqOFRahSjpSZBpcV2mAvaiiimIKQtg46n0pGbAqGxbzJpXznbgD2oSuD0RYCOR/CPrQyOASrA47V83+Ovi1rE+v6xYW97f2Asb+S1jgtisYKIcbmcgsWJHQYGKPgf4+1+f4l2uk3+p3l1YaisiiO5nMuyQKWUqW5HQj8a6vqr5Oe59c+DMesDLGSaSUea3la/wCXy8z6OJWOIyzyCNAMkscBR7msaXxZ4RjultZPEOlCZ22qn2tCSfTrXnH7Vt/qeneGNCuLUb7E6kBdxsMq52EoGHdcg8HvivnjUdSu76B4ZpQImyQiIFUH6AVdDDKrFu518N8GrOMN9ZlVsrtadLH1j8dPEmqeEfhre6xoiEzpJFEZAM+SjsAX+ozj6kV8yav4nfV5nulhAaUfNLO5nmcd8u2cfgBX0z4Git/G3wQsLLUG85L7S/ss7NyQwBQn6grn6ivkX7NPptxc6VdrtubKd7eUf7SMQf5Vtgrc7ifQ8A0MPCpXw1SK9pCW/dbfg1+J9IfsveIDqXhq/wDDF7IJX0990KvzmCTPy/QNkfiK8q+PHw8Pw/8AEY1jSIGHh3UpSAqji1lPJT/dPJX8R2qT9n7Vn0n4raYhcrFqCvZyDscjcv8A48or6k8W6FpnifQLzQNWhEttdxFWHdfRl9CDgg1lWvRrXR5+dYqfDfELr0/gqJSa730fzum/mfEiSB0BByDXsv7Mfi37BrM3hG8l/wBHvczWeTwkoHzKP94DP1HvXjevaHqXhDxXf+F9VyZbR8xS4wJojyrj2I/XI7Uafqb6RqVpq0Mmye0nSaPHUsrA4/HpXbPlq0rn6HmWEw+eZXKMXeM1dPs90/66XPRv2mdN/s74tpeouE1Swjkz6uhKH9AtefA5HNe0ftPiDVdQ8PtAv+k2dpNc3PrFG+wIG9CWBx9K8XPpU4Vv2aOLhGtKrk9FT3St8k2l+B9M/sx6gL34WR2b4ZrC7mtyP9ktvH6PWV4++APhHxG0uoeHZm0HUGJbNuN1u7e8f8P/AAEj6V538EPH8Xge+vrXULaafTb9lkYw4LxSAYzg4yCOv0Feuz/GnwrGmbSy1W4J7CBUH5swrjqUKim+VH59nGU5vgc3q1sDGVpPmTW2uuvTR9z5s8Z+D/G3gG4K+INLe4sA2Ev7bMkJ+p/hPswFZtrew3SbonDD09K+itY+NdrLbSRReH7ZkkUqy3l6hVgeoKqGzXhWsw+HGv77VLKzSznuTmO0s9wt4j3OX5/AcfSuqh7ZO01ofecP5hmlaPLj6NvNNO/qlexBpeqX2janBqel3T2t5A26OVO3sfUHuDwa+tvhb4vh8ceDotTCLFeRsYrqIdElA5x7HII+tfG5OTXt37It3L/bfiSxDEw+RBNjsGywz+X8qWNppw5jj4+yqjWy14u3v07WfdN2t+N/+HPoCN9y5paihP72Uejmpa8hn4iFFFFIYua8i/ay0sXvw3ttRVcvp9+hJ9EkBQ/qV/KvXRXMfFrSzrPwx8Raeq7naxkkjH+2g3r+qivTybE/VsfSq9pL7uv4HHmFL22GnDumfJlnJ5ttFLnO5AT9cVdjNY2hzCTTkx/CSPw6j+dasTcV9pi6Xsq84dmz8HxFPlm0XYmx3q5G1ZsbVbibiuRo42i0DmpFNQA5qQGoYIlzRupgODQWpGkWO3e9PBGKi3UhalY0ueeUYpAaAa7D3GPXpTqYOadmghml4fu/smpIzHEb/I/0Pf8AOu90q5+yajHMeFDbW+h615h1rttIujd6bHITlwNj/UV+P+J2UKXs8dFb+7L81+q+4/avCfN+aNXLaj/vR/KS/J/eepZBwQeK3/Ds3mWjwMfmibI+h/8Ar/zrjfDl0bnTE3HLx/I39K3tIuPs9/G5OEb5H+hr8DlBwk4P0P0zGUbwceqNPWolOHIyGG1h618WfFHSD4c+J95aYKxTYkjPqp6fpivtu8jMkLoeo6fWvmr9rbRtlto3iWKPmKY2s7AdmGVz+IIr9G8Jc5+o519Wm7Rqq3/by1X6r5nxPEeC+s4JVFvD8n/wbHmEErQzRyqfmRgw/CvTLe5DokqnhwGH415VaSebAr+orufD115mkxAnLR5Q/h0r+0cHJVaaPxDNqT5VLtoZt3L9l1q9t84WeBh+KnI/QmsHwBGE8a6ncoCP9HDKw7FmGf8A0E1f8bSmHUbe5BwCQGP14P8AOo/h8n+k6jP3+SPP4sa8viqS+pPvp/kfpnhThva57h5d0/wT/wCAexeFbyRY42uIre5zz++iBP59a77TZLC7Qo+jwp8hy0U8ifpk1534eX5Ix7Cu40+TyoJGHGENflbR/QucUYuba0fk2vyOb1OSwhcrBZRxP5y4csXYfN6n8a9i+C8r/wBmvDKeZczj8WP9MV4bfjzGiY9WmBHueT/Svbfh832LUbOBjgeWIj+VceI0PA4rSjg40+r1+49KLBBk9BXjl/qjWF/dWmqtJHOs7sCQSJATkMPXNezMmQRis240tHk3Y5+nSvleIcghnNGNOUnHld0fAZdjoYWUnKN0zy22fV9RONP0uUIek1z+7T6jPJ/AVr2Pg27uJA+q6jLMneG3Hlp9CfvH9K9AhsEXGVBNWkjVRwtcOXcF5Zg7Sced/wB7/I6K+eVp6U1yry3+/wDysZmiabZ6PbGOyto7dDyVQY3H1J6k/Wreuaxpvh/TP7Q1efy0LKigKWZ3PRFUcsT6Cnffvoou2cn8K8a/aO19o/GOj6XHKV/s+zlvuDj9658uM/UYY/jX2WGoxuoRVkYZTgJZrjo0ZN63bfWyV/x2PSLD4k+Cry4FtJqi2FwW2+XexNAc+mWAH611WVMImhcPGRkEHII9Qe9fEVxeSpFIzSu4IO4Mcg/nX0t+zqt5b/BaxudRmdhN580Ib+CIudoHtxn8a6sRQjTSaPf4o4Vo5Ph416dRu7tZ+l9Hp/XU9GjJlJCnAHU1FdXunWhIu9Qt4COolmVP51i+IdWl0j4darrUH+utrCadD/tBSR+uK+S7rxDPex27m3tDIIh5szwh5ZnPJdmbJJ5qcPh/anBw5wxUzrnkp8qi7dz6/n8SeFIsibxBpS/W9T/Gs5vHfgSxZ8eItP3NyRHKZCf++c18mjWr1B+7kjT/AHYUH9Khl1W+mHzXk3/AWx/KutYGPVn19Pw2pv46r+X/AAzNv4r28E3jrVtfsg0dnqlx5sEci7XYBQGk2nkKWzjPWsTw5qc+h+I9N1u2UPLY3CzBCcBgDyue2RkVTkkZyXkdnY9WZsk/nUZcHiuuNNKHIfouEwCpYNYWfvRS5fVWt+R7l8UPiR4e8ceDv7GWGayikljmnmuSuYwh3YRVJLMcY7DmvDCAWJUELngHrimsOeaiubmOBd0jhQTjmiFKNJWRhlGS4fKKUqVBvlbvr/X9WPQPh98TvEHg3TH0qylt5LJnLok8JfymPUrgj64PFcz4p1KDV9SkvYkkMs0jz3M8gAeaVzknA4UDoBWOGVl3A5B70jOFXJOB70404xfMkdNHKcLRxEsVTglOW7Wl/X+vPc3vh9Iw+InhkR/fOqQAY/3xn9K+1bxY42W8lnEUcCsXZiAoGOSSe3FfKf7NPhm48R/EOHXmib+y9EJkMpX5ZJyuEQHuRksfTA9a+gPjZZX2q/CbxFa6O7Nc/ZWZQvVwhDMv4hSK8vFTUqmh+R8eYmjjc4pYeMtIpJvtd/ojyz9o6Lw942sbK88N3bT65YsVjkjt38qWJuqtIQBweQee/rXkeh+F49K1KDU9e1u0aW3YSR20C+e28cgkfd4Prx7GoYtbv9UsIZLy8mnIRUAdyQABgAD6VEXPrXXTw0Ut7n6BlWQSweEWF9o3D79/la3yOj8TeI5tVDxr5ixvJ5kzyyb5rh+zSN3x2A4HauaaUZ61Wu7yOFSZJAMds123gz4PeLfG/hyfX4ZY9JRVB06G6Ug3fqT3VfQ4OT7c1pOrCitT0MTi8DklBOrJRjsv6/rQ5FpOKjLH61a1rwz460C4a11fwhqoKnAlhgaWNvcMmQfzqjBZ+I7lttr4U1qdumEspD/7LTWKpdzop5vgJw541Y29SQORSM5NbemfDz4n6rj7L4KvoFP8V1thH/j5Fddov7PHj7UGB1jWNL0mI9RGTPIPwAA/WoljKS2OHE8VZRhleVZP01/I8svLuG3jJZxnsB1NfUH7Mng+98L+D7zXtbga2v8AVmWXyXGGigUHYrDsTktj3FWvAHwV8EeCJ49UvWk1fVI/mS5vsEIfVIxwD7nJ967ua6fU5RHGhS3U556tXBiMS6unQ/MeLOMVm1P6rhk1Tvdt9bfoW7AlkMjdWJJ/GrNJCgRABS1xnwYUUUUgClKJLG0UgBR1KsD3B60lPTgg007O4mro+Gnsm0fxBq2jPwbO6khwf9hyv8gKtxvXQfHjTv7J+NOq4XbHfLHdL/wNMH/x9Grl0fB61+lY+p7Vwr/zxi/naz/FH4lnGG9ji5w8zRiertvyRjJJ7Vlxv716R8E9Gj1LWnv7lN0VqQFz03dSfwH86+czrNqWU4KeLqK9tl3bdkvmzjyvKqmZ4yGGp6X69ktW/uM+Lwn4key+1ro115OM5wM4+mc/pWQQyMUYFWBwQRgg19GXGozMTHG2yEcKgHGPevHPihHAmtJNEFEkqnzMdyMYP15/Svg+GfEL+180WAnBe8nZpNapX6t3TV7PT010+y4j4EhleAeMozb5bXTt1drqyXV7anKFj0pM0zcKM5r9OsfnSH7qdu4qMUE4NKxZwIp2KaMU4V1HvtBSikBpQaDNjq3PCVz5d29o5+WUZX/eH/1v5Vhg1JbzNbzJOn3kO4V5GeZbHM8BVwr+0tPVar8T1+Hs1llOZUcWtovX0ej/AAPVvC935Oo+QT8swx+I6V1leb2dxuEV1EeDh1r0CzuVubWOdOQ6g1/JWZ4eVKpqrPZ+qP6vrctRRqQd00dfZz+fZxSk/MRtb6jivPvjR4dPiLwNrWjxpumkgMtt/wBdU+dP1GPxrrNBuOZbdj1G9fqOtS6vHlFkHVeDXmYXFVMFjIV6bs4tNeqdzwZUI88qUtnp958KeHZ/MswrcFex7V1/hW4x58JPXDD+VZnxH0j/AIRf4oatpka7baeT7VbDtsk+bA+h3L+FN0ScRajGScBvlP41/f3CeZ08wwdLEU3pJJ/ej8Jz3ASo1alKS2/Qk+IR36duHbNWfhwN+jS3A/5bzZz9AP8A69Z/jh82DLW38NoBH4UsF7uzufxc1jxnV5IRh3/Q/S/BbDc2Yc7+xGT++y/U9Q0EY2D2FdV5hSwmP+wa5jRhjaa2dQn8vTJfcYr85Z+3Y2PPVSRyHjLWY9B0j+1pMH7NIrqp6McgAfrXt+kXG24huUOVDq6n1HX+VeIagnhnUZo9M8VRpJbXCkxh9wAIIycqcg89a9h8O26jS7WKxnFzbRxLHHJu3EqoAGT3OBXyea8TYDA4j6tiOaL/AJre7ql1/wCAfJcTUa9SumrciVvn1/Q9wicSQpIOQyg044rM8L3Hn6JBuOXQbG9iK0s16lOpGpBTg7p7NH5lOHJJxfQSkbpTu1IR8pqySlZsG1bB7Ia+Yf2hrhz8ZNWQnhLS2Qew2bv5mvpi3Pl64mTw4K183ftT2b6f8WLa+2kRanpyYbsXjYqR+W38668K0qiPs+AqkIZwlLrFpeuj/Q82vWLwOoPJU19e+AVjuPgzoKWXK/2XAML7KA36g18g5yPavT/g78V7nwfaf2JqNo9/pYYtCUcCWAk5IGeGXPOMjFd+LoSmk49D9B43yTEZng4fVleUHe3dNa28z3zW9Mk174barodpIgnubGa3QseA7KQM+2a+ONc8P+NfDMWNd8KanbJHw0whLxjHfeuVx+NfU1t8YvDE3NtpesMzckC2QfruxWH4q+MbiB4tOgstP3DBkuZRcSj6RR5Gf95sVyUoV4P3VY+I4blnmVVJUqVDST1vp/wfwZ8z2V0l3CJY87fenXt1HaRCWUkKTjitXXLmymuy1jbGKIszO743yuxyzsBwOegHArb+C1smpfFzw/ZyQR3EXmySyI6Bl2rGxOQePSvRqTlCnzPc/XcVjZYbAzxVRWcYt29FscloVtrviW7W08M6LealM5wPLjOxfdm6KPckV3/iH4EfEPRdMt9R057bW55Iw13aQtteF+4XcQHHuMHPavqW9v7fSGFpbWiDK5CooVR+AqlBrOoq5aWFWVjwMdK8ueKqSd7n4/i/EDMq1WM6KUYrpvf12PkC28D/ABNu5BBD4F1QSE4Jkj2KPxYgfrXrXws+AHlmTVPiR9numeMpDp0UhKRZGNzuOrDsBwDzk17WdbuSQEtB+Oar3I1HURtmcrH/AHV4FRPETmrSZxZlxrmmOpeyuoJ72vf7zxzXv2ZY2u2k8O+LprO2Y5EF1b+bt9gykZ/EVL4f/Zm0+KdZfEvim71CFTkw20QgVvYsSTj6Yr12O11GJdqXDhR05NPFnezHE0zsPcmo9o7bnBLinN3T9m67t8r/AHi6bBo/hvRotC8O2cFtBCu2OOIfKvqSe59zyak8MyGIPYTEsclhu5znrVuz05IhkjmoNRtHVhNCSsg5BFRc8GTcm23ds+W/iD8JfG2j+OdQh8M+HrjUtGupjNaSQlSIw3JRskbdpJHPbFS6H8C/idqsi/2gdN0SA9TNMJHA/wB1M/zFfTaarqEabXgSRh/Fika+1SfgbYwf7ordV5pWTPr48c5tDDxoxaVla9tfzOA8CfAnwf4Xmi1PXJm17UIyGV7tQsKH1WPkH/gRNeg3urTmRRp0Q8tT8xI6+wpkWnTzyB55Gc/7RrWt7OKJNu0Vi5XPmcZjsRjantMTNyfn/WhnR646r++tSG77TilPiFcfLaPn3P8A9atCSziY/dFM+wQ+gpXOTQzm1y6f/VWij3OTUT3WrXHG/wAtT/dGK2VtYh/DUgjRegFK7HoYdvpksj753Zz7mte3t0iUBQKnxikNILh3ptL3pDSGFFFHekADinU2gGgD53/a907yNc8O66q/62GS2c+pRg6/oz15Ar+9fSf7U+mC++F/24Ll9OvYps46KxMbf+hj8q+ZYWzGh9sV97hantsqoy/lco/qvzPy7ivD8mN5u6v+n6F+F/U8V9CfC7TxpXgy3ZhtmuF8x/X5uf5YFfPuh2zajq9nYoCTPMsf4E8/pmvp+ILHbxwoMKigAelfifi/m7o0cPgovduT+Wi/N/cfReHOWqVWtimtkor56v8AJfeM1O7jtLN53PIHHua8N8Q6odT1aWbduRSVQ+vqa674qeICiDTraT524yD0H8R/p+dedRetV4TcNOnCWbV1rLSHp1fz2XzK8Ss8UYxyqk+0p/8Atsf1fyLO7Jp4NRJTwa/bGj8fRJmjOajJ5o3VFjQ4gDFO7UlFbnvMBRk0maKCWSJ7mtzSPDl9qFr9s2GK2zw5HL/Qf1rDtlElxHGxwrOqk+gJr6StNItPsMKwKohCBVVegAGMV+beIfF9fh+jSpYde/Uvr2Stt5u59xwPw7hc1rzrYzWnC2i6t33fbT5nilheW9vcy6QsmZLYA7S2SFP/ANeu58HXweCS0J5T51+h615V4p8G+K/CfjFtVk0+6vtNkkZWu7dDIPLY8FwOVIOOvHHWtHw54lS31eGQSjYG2SDPY8GvyLMcJ9dp+2pz5+ZXb8+vz/zP6MwnsZUFRpJJR0S7JbHs9rcmC5jlH8Lc/TvXQ3W2SFlByGHB/lXEi5DDIPHauh0e9E1ioZstH8p+navhsTRaSl2OXGYdq00eD/tSaIP7O0/xWqHfYyfZrkgc+W5+U/g3H/A68TttWErK1vbTyMDkcBR+Zr66+JmlQ694e1LRJMBL6BkB/ut1U/gwBr410xpbOWW0uVKTQuUdT1VgcEfmK/p3wXzydfL5YKUrezeno9fzufnHGeWRjVjilH4l+KNLxTqGoXlkS8UNsh/hDb2/PpXe/D26s30HS0guEYpEFcZwQw6j86851ydHsiQwxXXfDjSjc6BZLHaTXLOWfESFjyx9K/QeMKyUoTcr+r/pHveEcnSxdWKSS5X5dUey6W6gLVvVpNtic92ArI8PfDjxDdhZLbTtat1Pd38oD/vvFdbY/BnxFflU1HxLNbQk/wCriJmkx+gH61+b4riHL8N8dVX7J3f3I/VsZmGAw9TmnWWnRav8DxD4h34HiS1jV/litgT9WY/4CvoD9nXSNYtfDFze6nDNb2106taQyghtoHL4PQHjHrjNdT4P+CvhHwvd/wBrNYi7viQ32zU3811P+yv3V/AZ966261C1tsrZqZpP+erjAH0FflXFmbQxfMpQ5IvrLRv0jv8ANnwOPzj67UnGitG/69C54ekNrqzWxbAli3FfcHj9Ca6dWzXm9reNF4hsZZHJMkjBifp/9evQIn4619bwRNyymD6Xlb0ufK5jT5at/ItZoNNB4pQa+vPNZkaxuikSdPvIwNcV+0L4Im8d+Ao7vSU8zVtMc3Noo6yDHzx/Ugce6ivRL2ESxEYrMsr5tOmMMwJgJ/KtINrY6MLiamErwr0n70Xc+H7S9WYFGBSVDtkRhggjqMVY3YGRX0z8VfghoHji5fXtFvP7G1mT5pJY03Q3B9XUdG/2hz6g14lrnwc+KujTMiaHFq8KniWznVsj6Ehv0r1KWNja0z9wyjjjLsZTXtpck+qZyQcikEm08cVtJ4A+JkrbI/Amq7unzIFH5k4ro9C+BXxO1ggX0On6HCerTziRwPZUz+pFaPGU0evX4nymhHmlWj8mef3V3DAmZWGT0UdTX0X+zH8Pb3QLa58ZeI4DbXt7F5dpBIMNBb9SzejNgcdgPetr4cfBPwh4Jli1bVJjrWrx/MtzdqAkbescfIB9zk/Su/uLl9TkEMSlbcHJz1euCviXU06H5fxVxp/adN4XCJqm931f/AHWsQvbiS6lX7x+UHsO1X/s8eMbRTreMRRhQMVJXGz8/IRbRA/dqVUVRgClooEGB6UoFHajFAB9KCARyKUCigCI28ROSop6xIOiingVFPc2tuC1xcwwj1dwv86TaW4nJLckFLWJdeLfDltkSatbsR2jJc/+O5rLufiHoEWfJW7uD/sxbR/48RXPUx2Gp/FNfec88ZQhvNfedfzSVxmlfEPTr3Uo7SWymtVlYIkrMGGT0zjpU/xR8S3PhjQoprJENzczeVG7jKpwSTjv0/WtMJXpYv8AgyudOX/8KFVUsO7tux1mKRyqDc5CgdycV86XnjfxZeZ83XblQe0WIx/46BWLeXl5dtm6vLm4P/TWVm/ma9FYR9Wfa0eCsQ/4lVL0Tf8AkfSN94i0Cyz9q1qwiI6qZ1z+QOawr34l+D7YkDUJbg+kMDH9SAK8BPHQCm98mtFhYrdnq0eCsLH+JUk/Sy/zPZL34vaWuRZaPeT+hldYx+maxL34u6w5P2TSrGAdjIzSH+leb7uKaWqlQproepR4Wyyn/wAu7+rf/DHoug/FXXRrEC6qlpNZSyKkgji2MgJxuBz29DXtJHNfJ7n5TjrjivqLw/di/wBB0++H/Le2jkP1KgmufE04xSaR8txdllDCOlUoRUU7p28rWL1FFJ+NcZ8YYPxI0v8Atv4e6/pYXc09jLsH+2F3L+oFfFFrKGhBHfn86++ECtlWGQRgj1r4U8Q6c2j+KdW0lhj7JezQj6K5C/pivseHp+0wOIo/yuMl+T/Q+I4woXjTq/L+vxOw+C1l9s8aRzFcrawtIT6E/KP5mvYvFOrxaTpUtxJIEODg14v8KfElh4d1G7e+GFuI1UP6YJ4/X9Kl8eeLf+EiuhFalhaxnPpuPb8K/FeJ+GMfxFxXGE4NUIqPvdOVauz73bR7nD+cYPJOH3X5k5tv3bq7lsrre1rNvsZuoX0uoX8l3KTlzwPQdhVnSrO7v7tLSyt5Lidz8qIuSf8A63vUvgvw5qXia+FrYxkRoR5s7D5Ix/U+1e++E9B0nwrY+RYRCW5YfvbhxlmP+e3QV95n3FuX8N0Y4Sgk5xSSj0iul/0W78tz4XKeGsbxDXlisQ2oybbk92/L/PZfgcDY/CXxFNY+fcXFnbPjIjZiT+Y/pmuK1zSr3R9Qeyv4vLlXnIOVYeoPcV9A3d2Wy8smT3JNeQfFbVLe/wBTt1hYO0Qbc3tx/wDXr5nhPj7HZtm8cJOPNCSd9FpZN30Wi6Wbe+57/E3BOCy7K54ui3GULbu97tK2vXrpb0OOY00nIpjNzTS1fsdj8qRyVLSZ4ozVn0DEIz3oxRmkzQKwoJByOor3fw7rFwNMtLuCTKywq7KeQSRz+teEA16r8O7n7R4TiTPzW8jxH6ZyP0Nfk/izgVVy6jiLfBK3ykv80j9O8LcTGOYVcNPacb/OL/ybPRLbxPbEBbm1ZD3ZDT5/+EM1L5r2ysZmPUz2yk/mRXIPweabmvwSFGMXeGjP3CWVUZaxbXozuE0rwnKoEaWigDACyMv9as2uiaDDuMEkS7uv+kH/ABrg4utXIeKUrrRu5hUy+otFVZ2kug6FMB5rQNj1uD/Q1zlx8JPhZNqEt/P4f0WS4mcySvI7vvY9SRnFRw4q5CQK0w+Z18G26EnFvtJr8mjzsRlzqrlqT5ku/wDwS/pvgr4dabg2mhaBCR0MenIx/Miuitp9EtIxHbpKFA4WKNUX8hXMxNVmNuaipnNepK9RKT7ycpfm2cby6ENE/wAl+R0X9r2q/wCp04MfWWQn9KJNavGXbG0cA9I1ArFR6fv961WcYvltGXKv7qUfySM/qdJPa/rqTSyySyhpJGc+rHNUpP8AWN9anVssKqO3zn614+Ik5at6nVShYzNVlMeo2rjqgLD8x/hXp9lL5kEcoPDqD+leVam4bVFBOdsYGPTJNejeF5vP0W3bOSq7T+FfvPB8PZ5TQj5X+9tnjZnG7ubkbcVKvWq6Hmp16CvqjxWPPNU7yxSdTkCrg7U6qQrnO+TeWTFreRgPSpE1m/j4lgV/+A1vGNW6gGo2tYj/AA1SZOnUx/7euTwLNc/jTX1LVJuEQRg+grYe3tok3SsiAd2IAqKyu9LupnhtL20nlj+8kcyuV+oBqrStdINOxmwabPcSeZcyM59zWvb26QKAoqPVtRtdLtxPckhScKqjJY+1YE/jOH/lhYSN7u4H8s14+OzvA4GXJXqJS7at/cjpo4SvXV6cbo6qjBrh5vGGpOMQwW0X1BY/zqjP4h1mbreug9EULXhV+N8up/ApS+VvzaO2GTYiW9l8z0bGBzVee9soBma7gj/3pAK8zmurqf8A19zNJ/vOTUQA9K8mtx83/Co/e/8AJfqdUMi/mn9yPQpvEmiwnm83/wC4hP8AStKwu7e+thcWsokjPGR2PofSvK8DPNdZ8O58PeW2eyyD9Qf6V0ZHxbiMdjo4etGKUr2tfda92Z47KoUKDqQbujL174hXEF/PbabZwtHExTzZSSWIOCQBjisC78b+JJwcXkcA9IoVH6nNZniS3+y+ItRgxgLcvj6E5H6GqGKMTmWLlUlFzas3tofmVfHYlzacnuXrnWdYugftGqXkme3nED8hWe2WbLksfU806mmvOnVnP4m2cU5yn8TuNNJT8UhHNZ3JsIpI+ZfvDkfWvQ/jIg1D4c22oAZ8uaGYH0DDaf8A0IV54RxxXqUdjNr3wgFiIy08tkViU8ZKHKfntFfU8K1uWvKPkn+P/BPqOEcUsPmEZPZNP5X1/Bng6dKGp6212ZmgFpc+apw0flNuB9CMZrUsvCvia8wbfQdQYHu0RQfm2K/Q20j+jamKo01ec0vVoxTTSeMV29n8MPF1yAZLS1tQf+e1wMj8FzWxZfBvUn5vdbtYh6RQs/6kiodWC3Z59XiHLaXxVl8tfyueX0017bZ/B/QYQGvdUv7j1AKxqfyBP61pweBPAVh9+xhmYf8APedpP0zj9Kj20eiueZW41y6n8PNL5W/No+fXdQOTyTx619IfDOC7tvAWkwX0bRTrByjDBVdxK5HY7cVNaReFtNIax02ziYdDDaqD+eK17S6huozJC2QDggjkVjiHKUdY2R8nnvE1PNoRo04WSd97vaxIaBSE+9ANcVj5sepwwr5H/aN03+y/i7qLquI76OK7H1ZNjf8AjyH86+thXz5+17pm2/8AD2tqvEkUtpIfcEOv83r6XhWdsa6P88ZR/C6/FHgcS0faYGT7WZ4ah+auy+HXhO88TX5CEwWER/0i4I6f7K+rfyrjEI9etez+GvH/AIb0fwhZWcAMckMQDxBeS/8AETjrk968DjTNsyy7BJZbRc6k3y3Svy+du/bofJ8M5ThMwxT+t1FGEVdptK/ld9O56dpdnp+iaZHp+mRLb28Y7dWPck9yax9d8X6XpiESTq7jsDxXk3iD4ianqTtHaE28J6E9fyrmWmknkMksjSOepY5r8zybwxzLMZ/WM1qcierW8n6vZfi/I+5zPjnLMsh7HBR9rJaLpBfq/lZeZ23iPxxf6kzRWxMcJ/D9P8a5Z5HkYu7FmPUnrVeNhT9wr9pyPhzLskp8mDp2b3e7fq/6R+TZ5xHmOdTTxU/dW0VpFei/V3fmSkimMabuz3oJr3jwbHLg0tMFKTTPoGBNGaQmigkUE5rvfhNeDff2DHllWZR9OD/MVwNb/gC7Fr4rtCThZt0Lf8CHH64r5fjLA/XskxFJLXluvWOv6H0fCON+pZzh6r25rP0lp+p6nNUNTT8EiqzHmv5ahsf1bDYnjbBq3E9Z6NirET1M4k1I3NSF6uRNkVlwOKuROK4pxPPqwNGN+asxPVCJ6nR65ZR1OGpA0Eenb/eqav70/fQpHM6ZajbL/QVVd+TTo35bntVRn4qZapDhT1ZxOj6v9t+Jni3S3fmwazZR/svAM/qteyeBJt1hJD/cbP518peBtY3/ALT3iy2aT5L1ZIl56tCUx+itX074ElCahLDn78efyr+kcDhPqeGw9L/p3B/fFHzNWp7enN9m/wAGdslTp0quOtTIeK9RHlMwPG/jTSfCUMP21ZZ7mcExW8IG4qOrEk4Arg7z42THIsfDyL6Ge4z+ij+tU/2irVl1vSL7nbLbPD+KsD/7PXmAr9ByPI8DXwkK9SPNJ36vv5GkKcWrs9Bvvi34tuARAbCzB/55wbiPxYn+VYV9428W3ufO8QXwB7RuIx/46BXPCgV9FTyzB0vgpR+5GnJFdCa5ubq6YtdXM87HqZZC/wDM1P4fvpdI16y1O2cxPBOjkrxlc/MPoRkVUoaPzFKjjIxXTKlCUHBrR6BY+k/iGhaxtLgDKiQr+Yz/AErixXYyzHU/hpY3h+Zjawyk+4Az/WuRxX8d8cYV0M1lfql+Gn6HvZNUvh+Xs2J2opeAOcU+KCeY4hglk/3UJ/lXyEISm7RVz1XJLVkdFacOhatL92xlH+9hf51eh8JarJje1vEPdyT+gr0qOSZhW+CjL7rfmc08bh4bzX3nPVu+BZCmvhe0kTL+WD/StGHwXnBnv+PRI/6k1saLoFlpcxmhZ5JSMbnPQewFfS5JwvmVHGU69SKiou71X6Hm47M8POjKEXds84+Jlq9v4rmlZCqXEaSK2OCQNp/l+tczjLADk+g5r3rVY7BrfOoQwyRqc/vEDDPsDVCPUdJt1xbWoUf9M4gor7Ktw1PEVpVYS0bvsfneIyuMqspudk9TyG20fVbrH2fTbyQHuIWx+ZFadv4K8ST4P9niIHvLKo/qTXpMuvj/AJZ23/fT1WfXLxvurEg+hNdFLhCP25P8F/mTHLcPH4pNnJ2vw41R8faL20hHooZz/StS2+GtmuDdapcP6iNFQfrmtGTUb5+ty4/3QBVeSSWT78rt9WJr0aXCuEhvG/rdm0cLhI7Qv6slg8FeFbNw8oaXHaa4OD+AwK6q28jyUFvs8oDChMYA9BXG44rb8Lvgzw544YD9D/Su9ZZRwsG6SS+R14eUIy5YRSJ7zV7W2uHjWNpJF4Yrgc+maqS6/Kf9XbIP95s1Q1NBFqNwv+2T+fNVicV308NTcU2rhKtO7VzQfWr58gMif7q/41We+vZPvXUv0DY/lVYtimNIBW6pQWyM3KT3Y+RmY5Z2Y+5zTCwHeot5kbC9alS0Zz8zn6KM189mXF2UZbP2Varef8sVd/O2i+bR00sDXqrmUdPMb5gz1rU8OXA+0zRA9UB/I/8A16oPYRomWlmQnuyU3Tc2N+szyq8JBVmHbPqPrXDDjfJcTek6jg3tzK3462+djaOX4inJStdeR1ZegPVNJ1dQysCp5BB4NSLIK9iMVJXWxpdrQtq1ea/tOad9v+Fb3arl9OvIp8+ik+W36PXoYesjx/Yf2z4A1/S1G557CUIP9sKSv6gV25bV+rYylV7SX56nLjaXtsPOn3TPihOmD24qaMc5qtFJvUPjG4A/nVlOma+sx1H2OJnDs2fj81Z2LMfFWI2qpHkgGrMYPU1zo5JotoxxT1YmoVOBzTge9ao5WicGhm4qLf70jNVk8pztLjiilzTPdYlAoooJCn28rQXEU6HDxOHX6g5plIaipBTi4y2ZUJOElKO6Pb3lSaBJ0OVkQOv0IzVSR8Gs/wAIXYufClmxbLRKYW/4CcD9MVLcSAHrX8j43BSwmMq4d/Yk19zP6+yrFrGYOliF9uKf3otrKPWpo5KxxOB3qWO6A4zXPKi2eib0MtXIpPeuejugO9Worz3rknQZjOnc6KGWrKSVhW92D3FXIrgEda450WjiqUDXWSnCT3rPSbjrT/N9653TOZ0S+JPkc57VVLgkCozLiBz68VQv7oW1jPck8RRNIfwBP9K0pUXOSiuoo0+VNny14T1VbX4+WWrMxVJ9blRyf7srsn/s9faHhaUQ6vA3q20/jXwBeSyW80WoKT5sbrOp77gd386+7dBvY7iCz1CE5jmVJkPswDD9DX9bcT4FYWdC23Kl9x+b5NiPb06i87/eerVIhqGJt8asOhANSL2rxEDPPv2gbE3HhSyvlUt9kuxuI7K6kZP4ha8R2gdSBX1nLDBcwPBcwpNDIu143UMrA9iD1rkJG+GujzuqabprSoxB8q08zB+uCP1r7DI88eGw/sPZuTT0t5jVZU1qfPsMckzbII3lb0jUsf0rXsvCnie9x9l8P6k4PQmAoPzbAr21/iBolqmyw0ucgdAESMfof6Vn3PxKvGJ+z6VAnoZJC38gK9h51j6n8Ohb1f8AwxDxkehwFh8LPGdzgyWNvaA957hf5Lmt+x+DGouy/b9ctoUz8wt4mdsexOB+lXbnx74imJCTW8A/6Zwj/wBmzWZP4j164fdNq12R6LJsH/juKxlic3q/bjH0V/zuZvFt7HsumadaWGkW+lwR4toIhEitzlQMc+tZ0mj+HLeQmWGFW67WkJx+GayvhfrN5qNndW17M0727KUdzlirA8E98EGm3+ft04JJbzGyfxr4nEZRSr4hwxMVJx6tJ7+pnLF1KMbwdrmylzoNr/qIIsj+5D/XFK2vQKMRWzn6kCufA9adXXTy6hSVoq34fkcksVUluzWl16dv9XBGv1JNV5dX1B/+WwQf7KiqNL65rdUKa6GTqzfUkkuruT79xKf+BGmRSywSrNG5DKc5zTaQ81ooq1rEXd73Oi8SfNpySHkBwfzBrnhXR3OLjw3nqREG/L/9Vc5XPhPga7M2xHxJ9xcUYpTSqCxwoLH2Ga6TESjnNWI7K7k+7bSn6rj+dTpo983VET/eb/CodWC3ZapyeyKFaHh59upBf76Ef1/pU8ehTn/WXEa/RSav2GmRWcnm72kfGATwBXPWxFNwaTNqdGaknYyfEKY1HcP40B/ListzjrXXXyW8keZ0RlXnLdqypbrTIeYxESP7sef6VnRxLUVFRvY0nQvK7djAdmbIRWY+gGapiV5ZjCuQVOGPp7Voa5riRWzpBvWWT5UOMY96xrSQQQhVxk8k1+a+IPF9fBRWAw3uzkrya3SfRdm/yPcyrKozj7aWq6djWgCRgA9Kv22oCEjYi5965/7T71j+IPFujaDAZdSvo4sD7ueTX4tg8ViYVF9XXveWrPfeCdXS1zur/VXnj2Ntx6YrFuH25YHFeT3XxO1fWS0XhTRZJY84+0zfIn1yev4VnXB8SX7bta8YQWYPWGzXew9s195heAeJ+IJKtUp2T6y0/wCCeNis5yfKrwr14p9l7z+dtF82ez6Zqa210kLSqY5W24z90noa6JZsHGa+ftMj0a0u4rmTXtbuJYWDoeMZByODwfxFdVF4tjc/8jDrSH1NvCf6V+08J8GZtlOCeGxk1Kz923Nou233Hxma8Y5XWqqWGUn3vyr/ANuPXkl96nhlUMA3IPBFeWWXim6c7LfxVau3Zb6y2Z/4EuK2YPEmv2sQnvNFg1CBeTNps+4Y/wB05/nXvVcqqx00/L87HPR4iwlTe6+V/wArnzXfeHNRfx/qHhfTbVpZ4L2aJV6BUVzhiew2kc1694V+D+hW0SSeIbq41Cc8mGBjHGPbP3j+n0rKm8a+HtN+KesX+z7MNYMLKbnEbhggV0xnn5gDx1z7V6lpV/b3cKz28qyIe4NflvinxnnWEzNYanF0ocsLy6ybiru/RJ6adU79l7GQcL5fXofXXapzN26pa7W79dfkQ2/w98E+WIovC1qw9S7FvzzmsXxF8KPC86N9ht7zTJsZBjlMiZ91b+hFd5p9/wCS4YYPtWjdX9vcw4KAGvj8BnuMnh3VhjpRqLo9U/68z1cRkuDm+SeHi16HzD4s8Eax4fVp2UXlmvWeIH5R/tL1H15HvXLV9SX0asSowQeMeteMfE7wcunGTV9Li22+c3ECjiP/AGl/2fUdvp0+84M8Snja6wGaWVR6RmtFJ9muj7PZ7aHwfEvAqw1J4vAXcVq49Uu67r8UcCTRn3qItz1pd3vX7Fc/N+Ux+1FFIas9YWkNIaBQICcUhakbr1qa3sru5OILaaT/AHVOPzppOWiCx2Hw1us2l/ZFuVZZUH14P8hWzeS7c81zXhLS9Z07UftclqFiaNkZWfBOen6gVuzwT3BzLIka/wB1OT+Zr8k4g8PM1zLOalfC00oTs7tpK9rPTfpfY/a+FOO8tyzJqdDFzfPC6sk27XuvLrbfoUpr0ITlqrNqg6oS3+7zV1tOtQ2WRpD/ALZpRGkYwiKo9hXsZf4PN2eLxCXlFX/F2/Iyx/i9TjdYTDt+cnb8Ff8AMpx6hdsMrBIR78VKL2+7MifXJp43TTCGJWlkPREBZj+A5re0zwF4y1PabPw9eKh/5aXAEK/+PkH9K+ww/hxwxgFfER5v8crfgrI+SxHiLxJmDth3yr+5G/4vmMSPU79DxcL/AN+//r1oWfiO6jOJ4UlX1jO0/kf8a6+L4KeLmtvMku9HjlxxEZnP/jwXFcd4k8LeIPDb7dY0ue3TOBMBvib6OOPzwa3qcIcHZknQjRhf+7eL+TVr/icn+s/FeAarTqTa/vJSXzXT8Df0/XrO4YIJtkh/gkG1v16/hWslyGrzPlhhsMPQ8irlnqF3aYEE7qB/A3zJ+R6fhX53nvgde9TK6/8A27P/AOSX6r5n1mVeLcHaGY0bf3of/Iv9H8j0Oa4C2/J6tXMfETUPs3gDX7hGwyadNg57lCB+pqGLxA8sSpc2/Tq0RyPyPI/WuP8AjVrUC/DLWFhmBMwjhx0PMi54+gNfmcOB83yzMKNPG0HFOcVfeO66q6P0TDcS5VmWEqTwlZSdm7bS27PU8MnXzdIt5DzmPBr65+B2pf2p8LPD05fLpaC3c+8ZMf8A7LXyJpLmfw8AefLYj8K+if2U9SWXwHd6aW+ey1GQAHsrqrD9d1f0txdQVbB0qq6W/FH5vkFR0686b8z6q0Wbz9Kt3z/AAavqa5/wVOJNIMecmNyK3VPNfBxjoevUVpMnlVpLeWNGKsyFQR2JFeCpuX5G6rwa98hPINeJeIbc2niHULYjAS5fH0JyP0Ir6bh2VpTh6M4cStmU6KTpQCM9RX1Bxi5oBqzbaffXR/0eyuZc/wByJj/StS28I+I58bNKlQesrKn8zWM8RSh8UkvmaJM1vhLcGPxBPATxNbnA91IP9TXT63F5eqzHH3sMPxFUPAvg6/0rVhqeoyQqyIVjijbdyeCSenSuu1HTob5lZyyOBjcvcV8pjsVSeMc4O6aNZ0nKFupymeaK6IaPp0PM0jH3aQCl/wCJHB/zwJH/AAM1l9ai/hTZh7B9WjnRzwOamjtbqT7ltK3/AAA1uHV9OiGIo2P+7GBUMmv/APPO1P1ZqPbVXtAPZ01vIox6Tfv/AMsQv+8wFWU0G5OC80afQE0yTXLxvupEn4E1Xk1O/k63LAeigCj/AGiXZBeiu7OntoI4bZYByqrjnvVGTTdKhYtKFTPZpMCm6BfSXCSRStuaPGGPUg//AKqxNR3tqE5kOWDkfhniuWlRn7RxcrG06kVBO1zb87RYPuiAn2TdSNrVnGMRRSN9FArn6K6vqkOrbMfby6I2ZNff/lnbAf7zVXfWr5vu+Wg9lz/Os6irWGpLoS6s31LMupXzjBuXH+7x/Ko4ru4hlEomkJB5yxOfrUWKaTxzV+zha1ieZ9zd14lrAEH5dwJ+n+cVy91IFHFdJcv52hbu/lA/l/8AqrkL58A81hg1aLj2Z019Wn3MHXLv/To42P3Uz+Z/+tVaXVI7eJpJJAiKMlielZHi+8NpdLcSnbF5eC3pgn/GvKdZ1u+8WXj2ltO1to0TbZph1k/2V/xr8YzbhXHZ/wATVsPRjdtrXolZa/cfe0cwwOWZLDF4mVopfNu+y7s6rxH8Qr/VbmTSvCMYlkXiW6Y4jj/GuftdMtobg3mrytrWoHkyTf6pD7L3pIPs9naraWMKwW69FXqfcnuaoatrNrp8Je5lAPZR1Nf0Lwj4aZZkNNScFOp1k/0PwziLjzMc5m6GFvTpP7K3f+J/pt6nQXGoTTKEaQhB0RflUfgKqSXsUQ/eSKg9ziuIstS8TeKL5rHwxpdxcMD8xiXhf95jwv4kV3GhfAnxHqQWfxH4gS1LcmC1UzOPqxwo/AGvuK+MweD92pNJ9keDheGcXifem7Ipy6/p0Zw17EPX5qI/EenMwCX0X516Dp37PnhGKMfaV1W9fuZbraD+CAU3W/hJ8KtAjhfX/K0pLhtkDz6nJHvb2y359hmvO/1iwLlyxjJ/JHq/6mWV3UOTttUikAMcqP8ARs1qabrV1aSrLaXUtvIOd0bEVe1T4C6VnzNG1fVbA9VLOsyfyBx+Nctqngnx94ZLOIotfsl6vbZ81R7oefyzW1PMcvxfuqVm+ktP+AcOJ4ZxuGXPSfNb7zr9Zn0Hxjpzad4w0qK6VxgXkKhZkPqcda42S48V/CKeO4hupvEXhGQ/JcoC8tsPRh1IHoeRUWj69b3WVjcrKpw8TjDKfQiuq0XV2g3oyxz28o2zW8gyki+hH9a8fP8AhPBZrhnQxFNSj+XnF9PyfbqaZJxNjcnr3i7d09n6rr67noXg3xlpfiXS4r3TrqORXXd8jZBroBenHWvmzxV4c1PwXev41+Hgkn0d3DX+mbuYm749D6Hoe9ejfD34g6X4s0yOe2uAJsYdG4ZWHUEdiK/kvjLgDF8OVvaU25UXs+3k+zP3vI81weeUfaUNJrePVea7o9NF1k5zUetrDcQZ2qyyJtdSOCO+aw1vcHrUn20MME8V8LDnhc9l4J3ueHeL9KOia/cWS8wn95CT3Q9Py6fhWOW4r0D4ywLiwvR94O8JPseR/I150X4r+ueDs2nmuTUMTU+K1n6p2v8APc/m/ivKo5Zm1WhBe7e69Hr+F7FIdKD1pmfQ0oJxX1h5jRd0qwl1K5EELIv95nOAK7TTvAtogD3d3JNnsnArzqG/e2u3VHKMMHr1GK6rQvGM8BCStuWvoaOUc1CNSOrauDi4u7Wh21roOkWYzBYRbv7zDcfzNWSu0YVVUegGKraZrllfIMSBWPvWgUVxlSCPUVi6bpO0lYdk9jPnwqkngVs6V4F8V6rGklrpEkUTjIluWESkeuD836Vnzw7uOfwr0Hw18TtQtdsOtwC6jHHnRgBx9R0P4flXLjq+LpU08LFN9b/odmXUcHUqWxcnFdLbfNlbSvgveykNq2uQwr3S1iLn/vpsD9K6/SfhP4NstrTWc+oOO91MWH/fIwv6V0GheKNE1mHzLK+iY/xIx2sv1B5FO1bxT4f0oH7bqtrGw/gDhmP4Dmvi8RmmaVp+zlKSfZK35an3OHyzK6EFUjGLXdu/56FzTNJ0vS4/L07T7W0X0hhVP5CrZFec6v8AFzR4Ny6dY3V63ZmHlr+vP6Vx+r/FbxRd5WyitLBD3VTI35nj9KVHIsfiHdxt5yf9MK2f5fhlyqV/KKv/AMD8T3RioGWIA96w9b8U+GdMR49T1WyXIw0TOGJH+71P5V88arrfiDVSf7Q1i9mB6p5pVP8AvlcCstLUf3a9rD8JLetV+5fq/wDI8XEcXvajS+9/ov8AM6P4mXfgjUp4pvCunS2tx5hM7ohjhdcdkPfOOQB3rjPK74rVFrx0pfsvtX2GEjHDUlSUm0u7uz47F1JYqq6sopN9ErIxyh7VHcW6XCGO5ijnjIwUkUMCPxrZa0PpTDa+1dPtYtanC6TTujh9R8BeH7mGUWML6a8nLeTyhP8Aungfhitb4KaLN4H1DWV1C+hlsr5YmhlRTlXQsCGHOMhuvtXQG2I7VE9uR0zXFjcFQxlH2M9F5HqYDPsfl9TnjLm9df8Ag/ie4/DG/juxdLDIssZAYMjZHpXahvSvl6znvNOlFxYXE9pOP+WkDlG/HHX8a7TQ/ijr1hGqapBb6nGON5/dS4+oG0/lXxuL4UrwfNQkpLts/wDL8j7HCcc4Ws7YmLg++6/zPdoG561na54b0HU5zf6lH5UigB5BL5YIHTd2rE8IeOdC1yWO3jmktLyQfLb3K7Wf/dPRvwOfas/4xvO0WlKrEW5aQsvYsAuM/hmvGw+DrwxUaLbhJn08MXQxFL2tKSlHyNbyPh1YHMklhIw/vStMfyyaB4w8G2AxZWm7HTyLQL+pxXlKrgcU+voP7FhL+JUlL5mft30R6Vc/Ey2UYttJmb0MkoX+QNZdz8SNXkz9ns7OH0zuc/zFcWKK1hlGDh9i/rcPayfU6/TfHmurfpLezQy22f3kYiC/L3wRzmvR/EM8i6arQMQHYAsDjjGa8KYBkI7EYr2ixl+3eB7S46t9mjYn3XAP8jXlZvhKVGVOcIpa2ZpGTlFoxzknLHJ96AKBkmlFYnCKKDxQKCaQwoNKgLcKCT7DNTx2V4/3baU/8BxScordjUW9i34afbfsn99D+lQ64hj1SXjhsN+lX9F064huRPOoTaCAM5JzVvUtNS8kWTzDG4GCcZBFcLrQjW5r6WOlU5OlY5mit9dCgHLzyH6ACn/2fpUP+sZf+By1s8XT6akKhI52lUFjhQT9Bmuh8/RYeggJHom6mPrdkgxGkjD2UCl9YnL4YMfsoreRipaXbn5baX/vnH86f/Zl655RUH+0w/pV6bXiRiO2/wC+nqjPrN0R8qxJ+GaaliHskgSordmisaw2awbtwVcHPf1rm9R0uI7issgX044rVsr5rqN/MwHQjOOhBrjPGupiyS9uri4MdvbqzNzwFHt6n+tLC0a0qzgnZm1WpTjTUmtDkfild6VZaS+nXFst3PeKVijdz8g7yHBBAH6nj1ryeIR28CW9uojhjGEUfzp+o6jc6jqE19dcSzHOzP8Aq1/hQfT+ZNc94p1ldNtCsbDz5Puj096/VMoyangIczV5vd/p6I/L84zKtm+IVGn8Cei6eb/roHibxJHpyGGAh7gj14Wuo+Gnwc1XxNJFrfjE3FvZyEPFZAlZpR2Lnqi+33j7Vrfs9fCyW8mt/F/iW2MskhElhayrkKO0zg9+6g9Ovpj6o0nSo4UBdct1ya+fz7iT2bdHDv1f+R9bk2Q08NBSkryPL9G1TwPoHi+y+HVoY7K/Kr5dvDblYVZl3KpYcbyOeeuRk5NerW2kQIBlBXj/AMfPhb4h1rxZpXivwRBCNSXZFclphHtKMDFNk9dvIPfAXg17nbCUW0YuGVpgg3lRgFsc49s18hmEqLo0qtGpdyT5k901+j6H0FDn55xnGyWz7ohWyhH8Ir5P/bMcXHj6yssZSz0gED/aeRyf0Va+uhXnHxE+D3h3xt4ttPEOp3d/FJFGkU8ELqEuEUkqGyCR1IOCMitOHswo4HGqvXvZJ+erRnmOHqYig6dPe6Ol8L6NFbeENGsnXLW+nwREnrlY1HP5VHqGiIQSo5rpVVVG0DAHAFIygjnFeSsRLmcjt5Fax4V8SPhhpuv77wA2GqoMxX0K/Nn0cfxr9efQ144w1XQ9ZOia/AILxRuikU5juE/vIe/06jvXo/xj+IHifWPiZZeB/h3cPDcW10IZnRAfPmHLhsg4iQZ3evPoK7v4qeBrTxJozWdwoimjPmW1yi/NBL/eHse47j8K+6y/Ma+XQpQxbvGorpdYro/n2Plc0yrD5pGbpq0o6X8+x5X4c1d7OfeFWWKRdk0LcrIh6qRXnHxV8HX/AIP1pPHPgjc1jcnfNbDgOO6nHRh610Gmve2V7caVqkfk6hZv5c6dj6MPUEYIPvXdeHmg1Wyn8P3ZXybwfumb/lnLjg/j0Nenm+X4fE0ZRqx5qclr6d15rdfcfH5VmOLyvFJ03yzi/wCl6M5L4efEXT/Eemowl2zD5XR+GRv7rCuzTUgDy1fO/jnwdqnhTxDNq+iMYZ4nIngP3ZBnkEV0/gTx9Hq9uFuUeGSIhZUfqh+vcV/NfGHhviMpre0w0XOlLVNan9G8NcY4HN8OnUkozW6en5nbfFS9Emm2cRPLzl/wC/8A168931p+K9YGragGiyLeFdkee/q341j54r9M4MyyplmT0qFRWlq2u13e33H4jxrmFLMc5q1qLvBWSfeytf77kQpaBSE19kfOMr3lpFcgF8q6/ddTgitm48C+KLXQrTXLCMaxY3EIlPkLieP1BT+LBBGVz06Cs4c19H/BZE1D4W6ek8RKwzTRK45wA5PPcferPE53isrhGpSd1fVPY+i4dwtLHVpYetta68j5m0/VpI3JjlZHU4ZTwQfQjtXXaH4yuIMLM25a9l8dfC/Q9fjaW5tc3OPku7chJh/wIcMPY5rw/wAV/DTxV4eZ57NDrNivJaFNs6D/AGo+/wBVz9BXvZdxXl+YpQr+5Lz2+T/zOjMeFK9G86PvLy3+49D0vXrG/QfOFY1qeWrLuUgg9xXgOn6q8cn7qUq6nDDoQfQiux0DxlcW5CzMWX1zXrVstuuaiz5adOdN2mj0owDOdvPrUZtgOigfSq2j+IrC/QbnVG+vFbiIrKGRgwPQivJnz0naSsSoxlsZZt/aj7NntWr5Q9KPKFR7cr2SMsWntUi2oz0rR8sUoj+lJ1mP2aKAthjpQLYZ6VrW9jc3BxBbySf7qmpp9LNovmahe2dinfzZRu/Ic1k8VFOzepSotq9jBe29qabY9xVq/wDEPg7T/v3tzqMg/hgXYv5msS8+JiW+V0jRLS39JJv3j/rXVSp4qr/Dpv56fnr+BzzVJPWX3a/8D8TYtdFvrw4t7OaT3CnH51Jc6BFZLu1XVdO08Dqryhn/AO+Vrz7WPHPiDUARcarMI/7iNsUfgK5G+122EmJrsPIT90NuY13QyzEvWpUUV5a/i/8AIiMI1HaEG/67L/M9bu9V8DWPDXOoao47RIIkP4nms2X4g2ts/wDxKPD2nW23pJMpmf8AXivPrKz8TaqFOleGtRlRuksyeTH9cviuhsfhd4uvwv27VLHTw3WO3jad/wAzgfqa5sRiMnwi/wBorcz7Xv8AgtPwPXwvDuY4jWFLlXe1vxepH4s8da1qSpcXF2oltWEkHlxhNjA5BGB6gV9M/EZJLvwTZ3ksZSWN4pXXHQuuCPzIryzwH8HfDWmXVtqOsSahq1/BIJFS6kAhDA5BMagZ7cEkV71eWkGraXNY3gLRTrhsHBHcEe4PNfKZznGErVaEsLG0YX6Wve2x9lk2UVcBCpGrK7l+h4eKWvRoPhtaBj52rXLpngLEqnHuef5VcHhDwfYjN5cFiOvn3YX+WK0lnmF+zd+iPRWHmeXClUFzhAWPoBmvU1m+Hlh91dOcj0jMp/Pmh/HXhu0G2ztJ2x08qBUH6kVH9qVZ/wAOhJ+uhSpJbs87tNG1i6x9n0u9kz3ELAfmeK9g8K6XNp/hW2027IMgRg4Bzt3EnGfbNcxcfEkY/wBH0k57GWb+gFdB4M8SL4ht5mNv9nnhIDpu3Ag9CD+Bry80qYyrSvUp8sUzanGK2Y4aFL0+0JjsdpzU0egxgfvLl2/3VAqpqmo3RvJI45GiRG2gL396ovPNJ9+aRvqxrijCvJXcrHM5UouyRvf2ZpcHMrg/78mKPN0WD7ogJHou41zxANFP6s38UmL2yW0ToW1qyj4ijkP+6oAqvLrx/wCWdr+LP/8AWrGoqlhKSB15s1Ytdm85fMij8snB25yPetDXbiaCxBhO1mbaWHYVzJHHFdFqh8/QxJ/sq9Y1aUITi0tC6dSUoyuzAeSaT/WTSN9WJpmMUtFdyVjm3EOKa1OI9Kjc0wGseKglbI609mzVad8D3q0hE2lSYupUz96PP5H/AOvXjvx61Zv7aj0OJ8qVW7uQD+Ean8QW/AV6xp8cwujO+Y4kU7nbgYx/k18y+I9WbW9f1DWWJP2y4aRM9ox8sY/BQK+g4ZwSrY+VV6qKX3vb8rnkcQYt0MByLeTt8uv+RRublYYXmkOFUZJpPgx4Ol+IXjp76+iL6Tp7LJMrdJW/gi+hxk+wx3rA8YXZS2W2XJZzkgelfW3wD8Ejwp4MsLOSPF1Iv2i7PrM4BYf8BGF/4DX0fE+Y/UsLyxfvS/p/15nl8MZepN1ZIZafE7wjoHjmbwhrBntJ4NiSXrqBbpIyhgp5yBhh82MZ/OvX4DG0avG6ujAFWU5BB7g1578UfhH4a8f7Ly683TdXjUKmoWoG9lH8LqeHHpnkdjXY+HtKt/Dnhmx0e1eaS30+2SCNpGy7Ki4yT6nFfl2Nng6lKE6N1PaSe3qn59j7iiq0ZyU7cvTv6M1Dil45r4N1/wCIeu+JPEdxrmqS/aVlkYw20juEt48/KiBSNpAx8w5zk17z+z78UTezw+FNcvZJ2mBOlXc75eTAy1vI3eRRyD/EvuOfUx3CuJwmFWIvzaXaXT/O3XY4cPnFGtXdG1u3me80UitkUV8ueuKetFJkV578TvironhBZLG3KajrAX/j2V8JD6GV/wCH/dGWPp3rfDYWriqip0Y3bMq1enQg51HZHU2XhXw5Y+JrvxJaaPZw6veJsuLtI8SSDjqffAz64GavajbLNGeAcivkDWfidrmr3slxqV1cXRY/KI7mW2SEf9MljYbcerbie/pXpnwk+NFvF8NdUv8Axdd3F0+k6l9ghlVN010GTfGp6AuAGBY44GTX0ON4cx2HpxqyfM20rbvyS9Nuh5WDzrDYmcoRVktblH4/+HPsyReK7KP/AEixxHeBR/rLcnqfdCc/Qn0rj9HushHjfnhlI/SvQfBPxGg+KOq65o8nhxoNPhtSxmEvmAqx2GOQ4ADEHIwegP1ryvTIJdLu7vR52Jl0+4e3Y+oU/KfxGDX1mTutGlLB4hWnCz6PR+nb9T4/ijD05ShjKW0tH+h1/wAQ7GHV7C01hUBN1HtmH/TReG/Pg15Lc+HI7C7kuLWMK0gwwHevY9LcXfhbULNuTAy3MfsPut/SuTvrcMc45FdmFjGVOWHqK6V0vTofPVpzg/aQfxLVHneaTNWtYtza6lLFjCk7l+h5qoTzXy1SDpycX0N17yuIDx1ozTKUGtzVofmvpr9nMFPhfbs6MitdzsrdiN2Pw5Br5ptrV7yCc27gzQkZiH3iMdR619Dfs/eNfDVx4S0zwkt8LTWrRGWW1uf3bTOXZi0ZPDjnoOR3FcOf5diPqEaqjdX6dFbd+R9RwmorGScnbT8z1Ce1VyWQ7Ce46H6isu/sUkUieID0den/ANatpoih/dtsPdccflUbsM4kHln1/hP418Dqj9KjKx5L49+F2h+It1xcWmy7I+W7tiEmH1PRv+BA14r4o+HHinw6zzW8f9sWScl4EImQf7Uff6rmvryW0AyYzsJ9uD+FZl/YxSLieMKf746fn2r38q4lx2XWUJXj2e3/AADgxuU4XHL95HXutz4w0/VWVswylWU4I6EH0IrsvD/jS5tSqyPle/oa9Y8dfC3RNfLXE1sYrsj5by2wkw+vZ/xBrxXxT8PvE/h0vLDGdXskyTLAhEqD/aj6/iua/SMt4qy/M0qdb3Zdnt8mfDZlwpXoXnS95eW56jpHivT72MeY+xvUciusstNnurIX2+KG0P8Ay2mbYv618x6HqwS7Rll+UNzz0rqNZ8UXV6ix3N8fIjGEQv8AKB9K9Cvk3O06MrLr1+4+YbnRlyzjf8PvPZbzWfCWmk/a9ZN24/5Z2qZH5msK++JmnWuV0jQ48jpJctvP5dK8ettQlv5vs+lWd3qUvTbawtJ+oHFdLpfgHx1qgDPZWmkxt/FdzbnH/AEz+uK5a2HyrA64utd9m/0R24bLsyxf8GlZd7fqzX1f4i+JL9Sjag0EZ/ghGwY/CuP1HxBGCXu74E9y75NekaJ8EI58PrWtajfnvFbKII/z5J/MV6B4c+FPhvSislloNjFKP+WsiebJ/wB9Pk15VbjLKcGuXCU+Z+Ssv8/wPdw/BOJqtSxVS34s+dtNj1rWj/xJdD1C+U9JFiKR/wDfbYH610um/DHxrqDKb660/SYj1Ckzy/kPl/WvpaDQbWMATNuI6An+laVtp8MYAjtj9SMV87jOPcwraUYqC+9/j/kfQ4XhHLqGs05PzPCNG+B2lEq+p3Op6q3UiWXyYz/wFef1r0Dw18ONG0ZR/Z+lWNkR1aKEb/xY8/rXocdpJ6og9FXP86mSxQkbwz/7xz/9avmMVmuOxf8AGqt/PT7tj3aGHw+HVqUEvRHO2+gWCtufMrjt97+Vadpp8anEdqqY6FuP0Fa22KP5cqvoB/hTjnbmOJifVvlFcKiauq2cXf5TWrqM4yH7DA6Cuu0txJaxMTyVFclreY/ENwG27mCOdvTlcf0NdFoEu+yX1U4r1n/DicTWp5Zrer6jqV7NJdXM332AiDkKgBxgDpWeAOuBWh4ntvsviXUYQMAXDMPo3zD+dZ46Yr73DqHsouCsrI8+V0xRzSikUU8CtBITrXZ/Ce48vX5rcnAmtz+akH+RNcgABya3vh2lxN4ttJLZSyR7jKR0VSpHP6Vw5jFSws0+xrDc7rXE2anJjowDfpVIVua9ZyzMk1um9gNrL3rPi0u+ccwhP95hXzFGtD2auzCpSlzuyKlFakeizn780a/QE1Omhx/x3Eh/3VApvFUl1BUJvoYlFdANM0+IfvCT/vyYo36RB0+z8eg3Go+tp/DFsr2DW7SOfALHCgsfQDNdNb27tpC20p2sYyp9qgOr2MfEYc/7qYq5Z3MVzF5kRJGcEHqDXPiKtSSTcbI1owim0ndmENJvdxG1Prv4qWPRbg/fmiX6AmnXurzJPJHAiBVOMsMk4qpJql83/Lbb/uqBXQvrE1fRGT9jF9WaKaJGOXuHb/dUCkfS9Pj5fJ/35MVjy3VzJ9+4lb/gRquxz15pqjVfxTF7SC2ibT/2PDz/AKPkf8CNUrvU7FQfLyQP7qYrLlPFZ93JgEVrDCJvVth9Ya2SMD4teJfsfgjWHgLpLJbmCJj/AHpCE/8AZs187IAqhF4AAAFeqfHO6KeG7O3B/wBfqEYPuFV2/mBXlUPzSKD3NfpvCmFhRwcpJbv8kfDcT15VK8Yvoh3gHSB4k+L2j6e6h4YpxNIp6FIhvI/EgD8a+5NEg8u3UMOcV8ofsr6f9t+JOq3u0FreyIX6ySqP5Ka9Luf2j/DtjrV5ph0DUJI7Od4POWaMFyjFSdh6DIPevnOKMNiswx7o4ePNyJX+ep9Jk9SlhMHGVR2ue8jpiq+oFvsz7Tzjis7wV4k0/wAXeGLLxBpYlFrdoWRZFwykMVIPuCCOK1ZxuTHXNfASjKlNxmrNbn0UWpK62PiH44+CX8I+IptWsYj/AGLqE5YgDi0nY5KH/YY5K+hyPSuP0e+NrOAZJEQsrh4zh4nU5WRD2ZTyPyr7P+IHhyz1fTbqyvbZbi1uEMc0bdGU/wAj3B7Gvjbxx4Y1Dwf4jGiSiS5gnJbT7nH+uT+63o69/wA+9fp3D2e08TR+r4h6pbvqv80fM5pk1SVVVMNG7k0rLu9j6++B3xG/4TLQ3s9SaJdd09VF0E4W4Q/dnQf3W7jscj0r0G+1C1sbKa9vbmK2toULyzSuFRFHUknpXzP8MPhprulW1rrK+IItH1YxEW4fczKrjlWxwAfQ5x9a4X4s+KPHtxrknhrxje5+xNuhhiAWKVc8SnAAdvcjjHAHWvhcHLKM9zSeGy3ERaV7r035ejXazPpMwoV8pwCrYiSlNaNRvp6u1vWzep6V8V/jtPemXSvCEktpZnKvqGNs03/XMH/Vr/tH5j2A614TfX5IaWaUKgJYlm4yepJPUn1PJrGkv5Z7+PTdOt59R1KZsR21upd2PvjpXrXw3+B95qdxFqPjhxcHIZNKgf8AdJ/11cfe+i8e56V+he1y7IaXs4b/AIv1PiVg8bm8/aVXaP4fJHA+EtB8TePLvyPDNt5NirbZtUuFIhT1C93b2H44r6t+HPwe8KWPw6/4RXVbD+07R7gXc8k5KyTXH/PTKkFeOAAenHPOes8LeE7TT7WCJbeKGGJQscMaBUQegA4FdfGiogVRgCviM24gxGMkuV8qWqt0/wCCfUYLLKGEhywXr5mPa6Jpej6KmmaPp9tYWcQwkNvGEUfgO/vXzP8AFCy/s74qXxAwt9axXP8AwIZjP/oAr6unGYz9K+bP2g4RF480WUDl7KdD+Dg/+zV1cJ15fXnFu/Mnf8/0PN4ooqeXyfa35mf4RmJvZID0nt5Iz/3zkfyrLcAkipfC8uzWbQ/7ePzBqo8o8+UZ6Oa+4UGq0rdl+p+br3qa/rscx43g2z28wH3lKn8Dn+tc4RxXV+NcPp8TjqsuPzBrkxXz+ZQ5cQ/M2p6RIyfSlhR5ZViiUu7HCqB1pgrrfhzbQ/bJr+ddwiG1R71w4msqNNzPpuGcklneZU8ItE9W+yWr/wAl5s8/8TNdaLqiykSKhA3OmcxsP6Vbt9Zs9RgUahEsx4K3EXDj3969V13QdJ15WP8AqLhh36NXlfifwDf6TO09rvhOc5UZRvqK6Mq4qlRiqWIV13W6/wAz9jz/AMKqGIiqmUPlkkvck3fRbqXmeoeBPir4t8NQpHcTf8JToycbJpCLmFf9mTkn6Nn6ivdPAvxD8KeNYtmj6gq3oXMlhcgR3Cevyn7w91yK+GoNWvtLuFW7WS2cdJUPymuhs9TsL8xzXIaC5Uho7u2O1lPY8dD7iu/GcP5ZnMXVwslGXdbfNf8ADH5vLF5rkdX2GOg2l33/AOCfdBQr/qjtH908r/8AWprMp4dfLY+vQ/Q185eDPjF4p8PJHFr6jxPpA4FyjAXUY/3uj/RsH/ar3HwZ408MeM7My6DqUVyyjMts42Txf70Z5H15HvX59mnD+My13qxvHutV/wAD5n0uAzbDY2N6Ute3U1JrUDJj+T2x8p/Csm/sIZf9dFsbs46fn2rdMbJ/qmAH9xuR+HpUbFSdrjy2PY9D9DXibHqRkeT+Mfhj4b1iRru90tGuD1ngYxSH6lfvfjmo/C3wY8KWojuDogunIBVryVpQP+Ak7f0r1Ce1AYlDs9RjK/lW9YWbNaQHzAF2DhFx+prtWZ42NP2caslHtdmcqFC/O4K/exzGm+F4LOBYkjjghXpHEgRR+A4rWtdKtE/1cRkPqBn9a3ks4wc7Mn1bk1J+7Q7Swz6Dk1xNNu7KdbsZ0Nm4xiNEHvyasLZ5++7t7ZwP0q38x+7Fj3c4/wDr0bWP3pCPZBj9TVKBk6jZEkEcQyFVB69KeDGR8gZ/oOPzpyxpu4Tc3qeTWX4i8UeHfD0e/Xdc0/T/AEWecBz9F+8fwFa0qE6j5YK78jKdVRV5Oxp4k9ET68mkKAjDu7e2cD9K8r1b46eGw7Q+HtK1bXZhwpSHyYj/AMCf5vyWuS1z4mfES9RnMmieE7U9C5Ek2Pq+efogr38PwvmFa3NHkX952/Df8DyMRn+Co6c935an0BJJFbQtKxjgjXlnYhQPqTXFeIfiz4D0bekuvR306/8ALDT1Nw2fTK/KPxIr5u8Ra9pN/L5uv+IdZ8TTKc7XkKwg+27gfgorn73xvbWA/wCJVp2n6cgHDlfMk/Nv6Cvp8HwNBLmrzb9Fyr73d/8Akp4dfiirPTD0/v8A8l/mekePvEWr+MfF1t4o8O6df6HBa2v2c3M0wjMo3lgXx8oAyeMt1Nep/Azxc/iXRr6G4eOW7sLnyJZo12rMMAq4HbPP5V8eav49udVl8mS6u9Qc8KqksoP8hXuH7OXiGLwroskWs2VxC9/c+fJOvzBRgKqleuAB1Gep4q+IaeAoYGOHptOcdktWl1u+p63DWUZ3mFepivZycLa9FfpZdX6antXjLwrealqf9oae8JaRVWVJG24IGAQfpj8qzrTwDqb/AOvvbOH/AHdzn+QrqpdatpdMivtMniu4pjhJEOV9/wAR6VQk1a+bpOV/3VAr5rDYzGukowaSWnmelXUKU3GadyG1+HdsMG41Sd/aOIL/ADzWnB4L8N2wzOJZP+utxj+WKzWu7mT/AFlxK31c0I27ryaqUsXL4qr+Wn+RzOtFbRN2HTfClqf3dlYkjuU8w/rmr9vqOlxMsNuFiBOPlj2r+lcuDTkPrXPLC8/xyb+YvrEux2N9cLaW7TuM44A9TWQ+tXLH5I4k/M1bvD9o0ISHk7Fb8sZ/rWDmufC0YST5lrcqvUmmrPQuvqd63Sbb/ugCoHuLh/vzyt9WNQijNdapxWyOdyk92B5PPNFLRVkiCtfw6+JJo89QGFZNX9CJF97FDn9KwxKvSZpR0qIramuzUZ17b8j8earNWnrkTi787YdjqOcdxWeIZnPyQyN9FNVRmnTTuKpBqbRCTTHNXF0+8fpbsP8AeIFKdJuT95ol/Emq9vTW7BUpvoZUzcVlX7bVNdNJpGOXuM+yrWXf6db4OWkbHvirhiqV9yvq9R9Dw/44MWsdHz0F83/otsV5/Yjddxr6nFenfHq2jTw7aTxJgQahGSc54ZXX+ZFeXWbiO5jY9nB/Wv1HhuoqmX3j3Z8JxHSlDEpPseo/smReX4n8Qevkwflvkr3bWPhl8P8AXrqW81XwhpFxczMXlm8gK7sepLLgk+9eFfs5yDT/AIn6nYscC5s2K+5SRWH6Ma+ooG+QV8FxZUqUczlOnJq6Tunboj67IZRq4KN9dyPSdOsNI0y30zTLSGzsrZBHDDEu1EUdABVhulGaQmvjpScndnupWKV/AJUIIrxD492UNhpFpqBhV47fUYZJPlyVXnOPTPA/Gvdp/umuG8d6RDq2nz2dzEJYZVKuh7io9pZNPZns5NXhh8ZTrTV1FpnJ2Wv2N3YperdRNFIu4Nu4xXhPxxdPGXiW2OlXbrNCBaq0WCZCzD5f8+tbHir4aa1bXBi0jUi1sz58uR3TI9CFyD9eK2Pg1pelah4v02W9h2XkMTRwoeFEqdyP723dj6H2r5LhfhKOR46WPpVXJxT5baWT01+R+hzy/Kq2DrVX+9ilttbqr+lj0L4SfC7R/D9gE06xWAv/AK64f5pp/wDebrj2GB7V7DpWl29nEFjjA/CjTIFihVFAAArSXpX2U69StLmm7s/KqvKnaKshQABxVLX9Tg0XQ77V7oO0FlbyXEgQZYqiliB74FXaSRUkQo6hlYYIIyCKUWk03sc7PAbX9pzQJApu/Dt5FET8zRXKSFV9cYGeO1Zf7Qk6T+N9E8o7lXTpJvwdxj/0GvYLz4Z/DwzrdnwXoXnRsHVls0XBByDgDBrwf4vX32/4oaowO5LOOK0X2IG9v1cj8K+9yJ4HEY6M8HScOWLvd330VvvPks/dejl841p83M0lpbzMvRJNmoQsf4ST+QrKFzumkORy1TwyiGOaU/wRnH1PFYMU/JOe9fcUqPNKUj4KktLE/iWTzNOVf+mgP6GudC8Vp6rNviRM/wAWaz6+YzhWxLXZI0WhRziuz8HuI9HHq0hJrjsV0Xh+by9OC56Oa+azW/sV6n7J4N04VM7qp7+zdv8AwKJ1aSA96tR3jeX5UqrNEeqPz+VYUNznvVuOYEda+fP6PqYfuiprng7S9YjdrTbFKesTjg/SvL9f8Gajo0zG1D25BzsPKN/hXsKSe9WTOk0Xk3ca3EZ4w3UfjW+HxVXDz56cmn5HnZhl2GzCk6ONpqpHz3XozwOx1u70642XG+1k6Z6o39K6Kx1SznuoryOeXS7+M7ory0coVPrxyPwrs/EHgix1OJ20/aSRzC4/lXmWs+FNS0aZjbB0APMT/dP0r7TLuLVNezxkbruv1R+PZ/4VTg3iMpnzW+y9JL07nu/g/wCNviHRFjtvF9oNd0/ouo2m0XCj1ZeFf/x0/WvbvCvijw94t083eganb30QA8xAcSR+zofmU/UV8JaZr09jN5cm+2kPBR+Ub+hro9N1WBbyO/srmfRtTj5jurWQrg/hyB7dK1xvCuX5nD22Ckot9tY/d0+X3HwMM2x+V1PYY6DdvKzR9tTRFUIibH+y3I/+tXRaUkq6dBu2J8g9TXzP4C+MXiG222/i3TV1m2AwuoWG1Zv+BJwrfUbfxr0OT456QYIrbQ/Deuanc7doRo1hUH3OWP5A18VW4WzOjV5PZ3809Pv6fOx7iz/AVKfN7Vfr9x66Y1P3iz/U8fkKJHit4GlkeOGJRlnYhVH1J4rwDxD8SviNdkhX0XwpbEdXxJNj6vn9EFec65rGlXtwZvEXiHWfEk4/heQiIH23cAfQCvUwXBuIra1JpenvP8NPxPKr8TUI6UouT+5fjr+B9H+Ifiv4D0fcj67Hfzr/AMsdPU3DE+mV+UfiRXFal8aNfv1ZfDHgx44+11qcuAPfauB/49Xhlz41g0+MjSNN0/T1HSRl8yQfi39BXKax48u9SlMc19d3z9kUlh+Q4FfTUOE8vwi56+vnN/orL8WcCzLNcdLkoRtfsrv+vkex+I/GPibU0b/hIviCbWM/es9J+T8CY8E/ixri31rwxYO0lppDXk/ee+lyT7kDr+Jrhba38Vam3+iacYIz/HKf6VuaT8L9Y1WUfbr6eXPWOEHH6VvPOcpwMeWk+byiuVferX+9nvYPw6z3MP3mJ9xd5u34b/gO1n4i3So0KX8VpEf+WNoojH/jvNcxJrOq6m+LDT7q4Zv43yB+tew6N8IdL0pBNfx2toOu+5kGfy61vRxeCdIGN8t/Iv8ADAoRPzPNePX4vrW5cNTUPxf6I+zy3wwy6Fvb1ZVX2gtP/AmeJWHgzxXqahrmdbRG/hQZauy8NfBMz4nvYbm4HUyXDbE/Wuwv/iAtoNmk6fZWCjgOV3v+Zrlr/wAW6vrdz5CTX2pSnpHCGf8AQV8/i82xeJ1rVG162X3bH6Fl/CODwMeajhoU/wC9P3n+On4nU2nhDwd4fUC61GzR1/5Z2kfmP+fSrL+MdA06Mx6doSTuOBPevuP1Cjiua0/wZ4z1QBntIdNjb+K6k+b/AL5XJ/PFdd4b+EOmTzBfEWr3105XKxQYhRvXnliOncV47xdK/KndnVi8blmGhfEVnUt0jovwt+LZt/BS/utStfEshbNqlzBKoA+USsGDAfhtz+Fd3k1a8OaHpeh+H20bRrKO0tsEhFydzf3mJ5J4HJqA29zuKi3l3DttNelgq0XF3dj8a4kxccdmE8RThyxlay9Fb7xVapYzilg02/c/6gr/ALzAVfh0W6bG+WJPxJreeJox3kjxFRm+hVU5p+a1YdDUf6y5Y/7q4q3Ho1kv3vMf6vj+Vc8sdRWzuUsNUZJpOZdD8o91dR+tYgGCVYEMOCD1rp4lSKNURQqqMADtTuM5wM+uK8+GL5JSdtGdMsPzJK+xzSQTP9yGRvopqdNOvG58nb/vMBW/u+tKCKp46fRErCR6sxU0m5P3niX8SanTR1/juGP+6uK0yaQk1k8XVfU0WGproUl0q0U/N5jfVsfyqzBDBb58lFXPU9zTz0pjOB1IH1NYyqzl8TNI04rZEhb0ppNVZb+ziH7y6hX6sKo3HiHSYuDdqT/sjNQaqD7Gm7VA7VhXPi7TUz5cc0n/AAHFZd34zOD5Nj/329XFFeym+h01w2QaxNSJ2H3rnLzxfqjA+XFBH/wHNc9qmva1OjE3Tov+yoAFddLRidCXUo/GC0N34I1aFVzKkPnp9Y2D/wDsprwy3kE0SyL0ZQRXf+JNaskL/wBp6/bRg8Ms14q5/DNea6VPavHJFZ3MdzBFIyRyxtuV1B4INfpnBmLTjUw79V+T/Q+I4uwlowrL0PSPCGpjR/FvhzxKxxAziG5b0B/dvn6Bgfwr6a8YeM9F8GeHTrOtSyLAHESJGu55ZDnCqPXgnJwOK+UPCZGo6deaHIAZHHn2ue7gfMv4j+Ve/eAm0L4k/DmLRvFFjFfvZukN1FKSCXT7kmQQQSvcHruFcfFeDpupCvVTcYu0rb8r1VvxXqcvDOKajPDp6vVX/Eb8Hvi9ffEHxjqOmJ4e+zaZBAZUukcv5bBgAkjY27mBJAHTB69a9bJqhoel6boumxadpNhbWNnEMJDbxhEX8B396vZr4DMKtCrWcsPT5I9Fe/zv5n2uGhOEFGpLmfcY/IxWdfWokB4rSprIDXnNXOyEuU5W60aJwxMYJ7cV4H48tbvwd8SY9SsVKRXbre2/Yech+dfxP6PX1C0QPUV5V8ffDbal4Qnu7aMm701vtkOByVA/eL/3zk/VRTov2c1fY+s4YzNUMaoVfgn7r9H/AMG3yPUdAvrbVNJtNTtGDW91EssZ9mGcVpivHP2Y/Eo1Hw5daBNIDLYv50A/6YueR+D5/wC+hXsIatpx5JNHz+cZfPL8bUw0vsvT06P7h9FZniY6sfDuojQTCNVNtJ9iM33PN2nZu9s4rwj4N/GDxNH4zi8AeO7O5fU5pzCsksYSeGTBOHAADIccMOg9R09DCZZWxdGpVpNPk1avrbq0uyPCrYmNGcYyT97r0PdPFGp22j6LeanduFt7WFppD7KM4+p6fjXx9JdT3lzcX10c3F3M9xN/vOxYj9cV7B+0l4qV0g8I2r5ZitxfkHooOY4z9SNxHoB614ru28k/Wvv+EculRwrryWs9vRf5/wCR8HxZj1WrqhF6R39f+AM1u7EGn7Afmkbn6CsOGfjrVfXL7z73aD8q8CqyTYHrX20IqEdTwKdJqCNCRzI2T0HAphp8abYwD17/AFpGFfA42t7bETmtmyLq5SBq7ps5R2iJ68j61n0jPt5BwRyD6V5uLo+2puJ9pwXxB/q9nFLGtXirqSXWL0f3brzR0kVyVq5Bd+9cra6tGW8u5+U/3x0P+FaaS8BlYEHoRXzU6bi7NWZ/ZGW5lgs2w6xGDqKcX2/VdH5M6WK5B71Zjmz3rmIboqeTV+C9BwM1k42NqmHvsbySkHIJBHcVPNLBeReTfwrOmMbiPmFY8VyD3qzHLmpOOdCzuYPiPwFbX8byWG2ZDyY2HIrzbU/D+qaRMVh3Mi/8spO30Ne4RSshDIxU+oqS5jsdRj8vUbdX/wCmijkV14THV8JPnoys/wCtzxs2ybBZtT9njqSl5rSSPCbHxBNZOEEk1pJnlCcA/wBDXWL8SNSgsfJGuSxxY+6jbf5c119/8OdJvjvVvNhPpzinaZ8NPDkNwuLLzGzwCK+sp8Yz5LVaSk/66a/mflOL8JsJKvz0cTaPnHX9DzL/AISK/wBTnY2Vpd3jsfvkHH5mtCz8LeLdV+ZzHYxt6cmvdZPD/h7QLeP+0pIrViuVtoFDSke/pVO48Z6bp6mPSdIgjI/5a3B3t+XSuDE8VZhXVoy5V5L9dWfQZRwBlFFJ06Uqz7t2j+H+bPP/AA/8G57tlkuxd3p6ktwv+FdzYeA/DehoPt15YWpH8Ef7yT9Kwdb8d6het5UmoSvngQw8Z9gFqOw0LxlrGGtdGktom/5bXjeUPrg/Mfyr5zEYuUpc1Wd35u7PuKWAhl9OzlChHtFJP73v9x1k2ueFdMXFlpkl869HuW2r/wB8isXV/iLqCqUguoNPh/uW6hP161qaT8J7q5ZW1rWpZc9YrJNg/wC+2yf0Fd14b+GWgaa6yW2kQeaP+WtxmV/zbOPwxXnzzCmvhVzzq+c5RhndJ1Zd3t+P6I8Vt5fEXiCUtpumX98WP+uZSqf99tgfrW/pvw18SXxDanqVtYKescAMz/nwB+te+w6DDGAZ24HTJwK0baxhQYhtyw9cYH61yzxtaW2h5GK40xLXLQSgvJfq/wDI8h0H4RaDAyyXNpcalKP47yTK/wDfAwPzzXf6V4VtrSERQww20I/ghjCKPwFdalpJjqqD0UZP5mpo7KIHLKXPqxzXM1KT95ny+KzfEYl3qzb+ZhW+m2cOBHEZT/srn9elc/41Z9P1ywmRfLZYCQueuWP+Fei7Y0GXYD2/+tXzh+0/471HwX8SPD072Ut1od3pzrcRYCuGWU/PGT3AYZB4I9Otd2X4WdasoQV3qeXVxSSvN6Hs2h6jBfwB4jhx95D1FaiOc8mvFvBfi/RfENut34c1aO5IGWRTtlj9nQ8j+XpXbW3iW7hAWZEl9zwa6Z03F2aMnT5tYvQ7uN6sRtXEr4tAA/0M5/36VvF1yeIraJfqSaycWT7KR3it71IDXnE3ifVtpYyJEvqEx+prD1Px5p1qCdS8WafbY6iS9jQ/lnNONOctkJ0rbs9jLooyzqB7mq02pWEP+su4V/4FXz9qXxd8BW5Jk8VxXTDtbpLN+qqR+tc7ffHjwdGWFnZ61eMOhW2VAf8Avtgf0rrpZXjKvw05P5MylUw8Pimj6Ym8SaRH0uS5/wBlSaqT+L7JP9VbzP8AXivla7+PszZXTfBsrE9Gub0D9FQ/zrHuvjJ8QLkf6JpWj2YPQ+S8hH4s2P0r0aXC+Z1dqdvU5amZ5fT3mfWk3jGY/wCqs0X3Zs1Uk8TatL9won+6ma+Qrnxx8U9RyG8QS24Pa2t44/1C5/Ws25tPGuqD/iYeIdauFPUSXkmPyzivTpcEY6XxySOOpxJgIfCrn13qXiee3Utf6zFar3Msyxj9SK5TVPiX4LtATe+NNMJHULd+afyTNfMJ8GQqd95cRBu5kkBP60v9jaDbLiXUIBjsGz/KvRpcB9alb7kcsuLKe1Ome73/AMbvh5bEiLUb69P/AE72Mhz+LhRXP6h+0DoiEjT/AA1q10exmkjhH6FjXk27wtb/APLZ5SP7sdRSa3oEJ/c2Mz47sQK7qfBmAp/xJt/MwlxLi5/BTsd/e/HfxDOSNO8JWEI7Ge4kkP8A46FrCv8A4q/Eq7z5U2m2Kn/njZgkfi5auTm8V2yZ8rT7dPd3zWZdeL5myIzbJ/upk10xyTJqG6v/AF5mLzPNKuysdBqHin4h3+ftPirUVB6rA4iH/jgFc7qFtqt4c32pX1yT/wA9rh3/AJms+bXdTuD8r3DZ/uR4qo41i5OfJuD7s+KidXKqOkIIaljJa1aiXzJLnSI4+SY1PuRW34Fv4dPuzYmZWWQ7lAPQ9/8AGud/snVJT8yon1YmpINEuobhJjdbHRgylV6EVzwzijh6qqUobCrwp1qTp1Kl7ntGnXMtvdRXNvIUkjYMjDsRXrPg/wASnRNUh8V2EZeyucQ6rap1U9yB6g/Mv4jvXhGgaotxCqE4dRgj3rr/AAzrc2lXZkCiWCQbJ4G+7Ivof8a+txmHpZhh+aGqa+9dvXt2Z8OpVcFWUlo0faml39tqFjDeWk6T28yB45EOQynvXM/F3x/Z+APDa6hJGl1fXD+XZ2pfb5jfxMT1CqOSfcDvXmXgLxePDEBubBpdQ8OTPumgHM1k56kD09R0PXg9ew8WeAvCnxS1LRfEsuqXE1tapsaK3cGK5j3btjZGVOeDjBxwa/LZ5XRweLTxabpX6Le32X2fR/eu5+g4XNfr2HfsGlU7Pp5+aOz+HPiKXxZ4K0zxDPp76fJexbzAxzj5iMg8ZU4yPYiugIqKBY4oUiiRUjRQqKowFAGAAOwp+a+br8sqkpQVk3ouy7HvU21FJu7HEVR1O3SWFg6BhgggjgjuK8z1L4r30Hx5tvh7BpdvLZPIkEs+4+aHaLzNw7bRwMYz15r1iQZXBrTGYCthVB1VbnSkvRhh8VCpJ8j+F2PnT4d+HPEPhH45x2Vhpt3JpbySL9oEZ8r7K4JGW6ZUhRjrke9fQGja5o2svcppOq2d81rJ5dwIJlcxN6Njp0P5GnwWqRuzHkHsa+e/hL4a8S+Afj7qGi2ulXsug3QmH2ry28kW5zJE2/puVsJjOeTXZgcLDGUqspz5ZQjdLvbf522PQ4hz2tj69GpOC2UW1u7dX+p9JE1w/wAT/EOh+ErNdfn0+yuNbKNBp+6JfOcnqA+NyoOre3uasfEPx3pPhCyJncXOoOuYbONgHb/aY/wr7n8M18veL/EupeJNam1PUrjzp5BtG3hI07Ig7KPzPU17PD3D9XHTVWomqa/HyXl3Pi88z6ngounTd6j/AA82VtSv7nUL+4v76dp7q4kMs0rdXc9foOwHYAVi65frb25UN8zCn3l2lvEXdgPQetcbqN891cFicjPFfq6jGlFJdD8+w1CWInzy+fmSebuYsTyeav6RGbifefuR8n3PYf1rGi8yWVYohukY4UV1djAtrapCpyRyx9T3NeVmmO9lS5Iv3n+R3YpqlDTdkpGBTT0qTGaQrXyJ5ZkE1FIeKlYZqKReKlnoR3KNwAc4qO21G5sX/dsWTujdKnlU1TmTJNclajGorSR9Hkmd43KKyrYOo4vy2fqtn8zobDU7e8ACtsk7oavrIy+tcFIjK2VJBHQitLTdengxFdqZYxxu7ivJrYWUNVqj+huF/FPCY9KjmSVOf832X/l+Xmdrb3RBGTWlb3YI61zNrcw3KB4JAw/UVajmZT1rjcLn6qlCrFSi7pnVQ3APerKTD1rmbe7Ixk1fhuwe9ZNWOaeHOjt7l4jujYqfatRtaOm6Z/aBVPtjkrBkdD3b8K5WK5PTNReIZzNcJGD8kMYUfzNNHBLAxqzUZLTr/kLYx6x4l1iS2sh51yfnnuJidkQPdj/IDk12uh/CaylcS6teXmpydSinyovyHJ/Oum+EGhW1v4UtGZc3F2PtU20ZJLfdB+i4Fem2Vk6LhIljHq3P6CvGr4qpObUXZHw2e8TV1WlRw8uSEXbTS9vM4/w94L07TEC2GnWtmO5ijG4/VuprpLfSLaI/vCGb0PJ/KtuOyB/1js3sPlH6VZigSMfIqqPYVgoN6s+LrY2dR3k7szIbPaMRQYHq/H/16tJZufvyEeyDH69atho84XLkf3RmnfvSeioPfk1agjjdWTIYrWJDkIM+p5P51ITGpxnc3oBk07y1P32Z/qcD8hSlljjLnakajJJ4A+tWombk2NHmN0RUHqx/oKDGD9+Rj7DgfpXJa98TfBmku8Laqt/crwYLBTO2fQkfKPxIrlrv4k+KNXDL4b8Nx2EP/P1qD7iPfaMKPxY1rGjOWyPUw+SY6uuZQ5Y95e6vx3+Vz1dVVc7ECjuRxXgP7VdpoHiyDRLG21OCfU7SaVXjt3EhjjdRkvjgcoODg81m+I9TuLolPFvjW5v172dk2I/ptTC/nmuePivSNFG3QtKt4AP+WtwQ7Z9cdBXo4OFTC1FVjKzR9Rl3BiqSUq69ou1rRfrJ2f3L5niniTwPqnhjVYisskEzKJIJoWKNj8OQavaf4t+JFiAsXii9lQdBcKk2PxcE1N8RvGMura4sxvfNmQHe5IPPpXPDxRcJ/HAR6lRX6fl1PC43CQqYuC5n5fifkvE9CpleaVMNgZXgrdb2dldX62eh1n/Ce/E6UBf7eC+6WUI/9lqKXVfiJqIxceJ9X2ntHMYx/wCOYrmG8Y3IGEuIl/3EFQS+JtWn4Se8cf7CkV0rDZPQ15Y/gfPyxOZ1FrKx0cvhrU7w79Rv7qcnqbidm/8AQjRH4W0qDme8tI8dfnH9K5U3OtXB/wCPW6f3d8f1pUsNbl6wRxg/3mJrVZpl9LSCXyRyTp1pa1K34nXG28LW3376OQj+4hNRtqXhmD/VQTykf7IXNc4mg6rJw91Gg/2U/wATU8fhZz/rr+dvYED+lRLiGkvgi/uOd0sMvjq3+82W8U6bCP3OkrnsZH/wqtP44kT/AFUFlD+GT+tQx+FLAcyeZIf9piau23h/T4fuWsef90Vyz4gqv4YfiQ54CHRsypvG2pS8JdsB6RR/4Cqkuu6zckgf2hKD65A/Wuuj0+FfuwqPwqwloB91QPwrmnnOLls0iXj8ND4af3/8McF5WtXBz9jcZ7ySVJHomtSfeeCIfQmu8FsakW1PpXLPHYqe8yHnLXwxSOIj8L3bD9/qDfRFAqaPwlbZzLNPJ9XNdstmSPu08WTf3a55OpP4pN/MwedV3tK3ocfF4X0tP+XVWPq3NWk0e0j+5bRr9BXUCwY/w08aex421m6SZzyzOrL4pN/M5f7Ao6RqPwpGtPQV1Daew/hqNrEj+Gj2SIWOfc5V7PHaq8llntXWSWftVaW0HpUSpI6KeNMjwzod7qOq+RZgqVQySvgkIo7n8cD8a14LmSGZrW6Typ04IPf3Fe0fBnw1b2XhJ9RnRTPfMXJP90ZCj+Z/GuV+J3g+OeRrq1GxgSRt6j6V8JlfizHLc8q4Gqr4dPl81JbteV9LeV15/qNDgWOZ5RGqpWrv3vKz2X/B8znNG1i8025E9nM0b9COzD0I7ivQPCHjNLS8Fzpt6dDvXx5sZG+0nP8AtL/D/nmvG4rmazm+z3gORwHrRhuVYAowYV+8Up4DOsP7ajJSjLqtfk1+jWh+WYzL8ZleI5KkXCS+X3M+sdA+KUPlqniDTZbX/p7tP39u3vx8y/rXaaX4l0PVIw+n6vZXOf4UmXd/3z1H5V8Wadq97ZNutLuWE/7DECtUeJ7uTm6gsro/3pYBu/MV85i+CqVR3pO39dn/AJnpYbinF0VarFS/B/5fgfQVp8Kmj+N8vxHl1hJLZnM8doIT5glMXl4LZxtAyRxmvTpLqKNC8sqRoOrOwUfrXxqvimcLtS2WMeiTSKPyBqtc6/PL1ghPu5L/APoRrCvwhisU4+2q35UorRbLbqdEOK40k/Z0bXd9+v3H1frPxC8JaXuWbWILiVf+WVr++Y/988D8SK8u8a/Gu/mjktdBhGnRnjzXIec/QfdT9TXik+pXMqlWlIX+6vyj8hVOS4CjLMAPU16mA4PweHalV99+e33f53POxfEmPxK5YPkXlv8Af/lY1NR1K4vbiSe4mklkkbc7u5ZnPqxPJNZl5eRW0fmSOB7etZGpa5BApWNgzetQ6FomreJ9QRSHit2I3ORzj2Fejm+fZfkeGdXEzUYrp/kupOTcN43NqyhSi3ff/gsztX1R7uU/NtjHSqCuWYKoJJ4AHeu5+IPw0bStDW/tVkM1rIpkyxO5DwSc+hIP51zOl2yW2GPzy/3vT6V8zlHG2DzrCvFYa+7Vnvp38tUfQ53ksshqKhUabaTVtjR0S0FqnmyYM7jB/wBkegrYjPFZsL5q5E3FY1K0q0nKT1PjK7lOXNItil4xTENSYqTmaMUimMualK0oXmoO25TkSq0kQNabR5qJ4uOlS4msaljGmhqpLD7VuSQ+1VZYeelZSgdlOuZETT20m+CQow54Nb2ma9HIRFeDy36b+xrPlg4qrLb5HSuKthYz12Z97wzx5mWRtRpy5qfWL2+XY7QPlQ0bBlPQiporgrXEWV7d2DDy2LJ3RuQa6DT9Utrz5QfLl7qxrzatGVP4j+h+GuOMsz6KjCXJU/le/wAu/wAjpbe6O5ee4qW9kMhnbOSQf5Viq5Q1o2Ennwvk87iDXO4H2PKk7n1f8P4IYvDOnMNoX7JDg9vuCuphkUj5FZ/cDj868++Deq21/wCDNPGUe4toxbzjqVZOB9MgA/jXd3uoWen232jULy3tIQOXnkCD8zXz6i4yaP56zOjOni505LVNr8S4BI3Uqn05NL5cefmBc+rHP6dK881r4veFbJzFppu9ZmHAFpFiPP8AvtgflmuY1Hx54+1iNmsbaw8OWZ/5bSkSSAf7z4X8lrphh5y2Rth+HsfWSlKPIu8vd/Dd/JHtNxPDbQNNPNHBCgyzyMFVfqTxXE678V/B+ms0Vvey6vcDjy9Pj8wZ934T9a8W1m60eScT+JPEeo+IblT9wSFowfYt8o/AVlXXje3sFZdJ0+zsFHR2HmSD8T0/KuqGDX2mfT4DglS96o3L091fe9X9yPVb34i+NtWR20bRLPRbQ9Lm8bzHA9ecIP1ridfv7S7+bxV4tvdalBybeFyYh+Awg/KvLPEHj2S6kJur+a6f0Lkgfh2rl7zxPez5WBQg9TXbSwi+zE7K+K4fyH+NWjGS6QXNP/wLV/kewTeMtN0tNuj6TZ2oA4kmHmP+vArkfEXj25vWJudQmuPRA3yj8BxXnM9xdXJzNM7e2eKdbw47V3wwTfxM+OzLxUw2Hb/s3DXl/NUd392//kxuXXiK9uARDGE9CaxbqC/vyftF5LtPVVO0fpV6CEnHymtC3tSR9012QwdNdD81zjxBzvMbqtXaj2j7q/Df53Oah8L2HVolJPtVy38O6an/AC6ofqBXSx2h/u1YjsmPauyNGK6HxlTNK0t5v7zAi0q1j4S3QfhVqOyRfuxqPwrcSxJ7VMmnn0rRU0jinjZPdmKltxjFSi1z2rci0/2qwlgPSrUTmeKuc8lqfSpRaHP3a6JLAf3anSyA/hp8qMpYlnNrZt/dqVbJj/DXSraD+7Ui2Y9KdkZPEM52PT2P8NWE04+lb6WoA4FTJbj0oM5V2zATTOelTJpuO1b6W4FPEApXI9rIxEsR/dqVbFfStgQ+1O8oelHMS5syFsQP4RS/Y1/uitby/akMY9KLi52Y72g9Kry2g54rddOKgkiz2plKbOdntOOlZt3AyKcCuslgB7VSntg3G3ik1c2hVszW+GHjqytrEeH9TuVgnhJEPmHAdc5wPcelanjLW7JLKSQTxhQDl2O1V+pNeeanoNpd/wCut0f8KxLrwnYvx5TkDoC5IFflmZ+GVDFZhLGUqnKpO7Vr6ve3qfsOReJ0MFg40K1LmlFWTvbRbXOc8VaxFqMzR2efJB+aTp5n09qzbS+u7fG1i4Hr1/Ourbw7DEMLEB6VDJo2OAor7/KsFLKaahhny2/H17nzWZcRf2pWdWu73+5eSKNrr+BiVWU/7Q/qKvxa5bsB86/gwqpLpDYxtqnNoxP/ACzB/CvqKPEWLgrTipfgeU4YSp5G/wD2xAB1b9KifXYB/wDXYVzjaMQfuY+gqN9KcDjf+ZrrXE/em/vKjgsK/tG3ceIsZEePqOaxtQ1uaTPzknsByaiGmkH5lz9eaf8AZTGPlUD6CuatxHOa92P4nXSoYam7pXOq+Gei2+tBbm4DGVWxIr/wnPGB9O9e/wDhPQ7a2iXZGB9BXzX4U1uXw/rEd3hmiPyzIP4l9R7jtX0P4a8XaVd2kc9teQyKR1Dfz9D7V/M/iRhMzeLdaUnOEtnvby8rdPI/cuD8yw2LwHsaMVGpHdLr/e879TsfFOl2uo6I8MoB86JoX+hGM18pqjxSNExyyMVJ9cGvbfHPxFsLPT5Le3uUlvGBEUStzu7E+gFeM2sLsMtknuT3r6HwowONoYevUrpqEnG3m1e7/I+E8R6tGE6NLmTmr38k7WT/ABJoB0q/CDTIYOlXIogK/YEj8lqTTYqA1MBxQq0pGBVHO2ZAHNOAop4FB1sbgelNZM1NilC0CKjxe1V5Ia0itMaPNS1cpTsZMkPtVWSL2rbeHPaoJIPaocDeFaxgzQZqpJAVO5eCOhHWt+a39qqyWx54rKdO530MXKm1KLs0V7DWLi2wlwPNj9e4ro9H1GDz96P+6lHf+E+9c3Lak/wmqjxzxNuhLKe+O9ebWwV9YaH6/wAMeK2LwajRzD97Dv8AaX+fz18z1nSLqCK681ri8tnxgTWk5jkA9MjqK1Zbvwz9o+0Xbatqsw73Mo/mSTXjkGu6rbJsWIuPxpTq+uXAO2Ipn2rhWEnzfCfo1bxD4ZlH27rST7JNP7/+Ceu3vjj7JEU020stOQD7yLuf/vpq4jXPHPnSFrm8lu5Pdi3/AOquROn6ldNuuZXbPYnj8qsQ6FnG81108BJ6s+KzHxew1BtZbh0n/NPV/cv8xb7xRe3GRbp5Y9W5NZUkl5dHM00j57dq6S30aFP4c1dh02NTxGPyrshgox6H5rnHiDmuZ3VetJrstF9y/U5GHT5XxhD+VX7fSpDjcMV1cVjxwv6VZisR6V0RopHx1XM5M5uHSB35q/baUox8tdDDZgdqtR2wHatVBI4KmMnLqY1vpyr/AAir0Nio/hrTSFR2qZY19KtI5J12yhHZjj5anS0UdquogqQKKZi5tlNbZc9KmS3GORVlUFPVaZDkQLAPQVIsI9KmVaeBTJbIlix2p4jHpUqilxQQ2NCD0p4QU8DApcUhXEWMelOVRThgGncGkFhAPSnBaQU4GpYhQtG0ZpQaCeaBDcY7U0rUhxTSRQgI2HFRstS00+1UO5AyCoJIh6VbNMaqQXKLwj0qu9uvpWkwFRsvFBakzJls1P8ADVaSwU/w1tlRTfLB7UFqbOel01cZAqpJpuOQK6l4hjpULwj0osjWNeSOUfT2H8NQtYE9VH5V1jQA9hUTW6+gqXFG0cTI5KTTgT9yoW0xT/BXXPbL6VGbYelLkRrHFyXU4+TRoX4ePIpIvDlisnmCNlb1Ryp/Suta2HpSC29qiVGElaSubwzCtDWEmvQwLPQ7K3cvFAoY9SeSfxq/HbqvAWtIQAdqXygO1aRgoqyRhUxE6jvN3ZUSLHapAtTbMdqNtURe5HjFNK1Kw9qaaYjGHFOGMU2lHpSO1okHWn1GOKep7UCFFLjigU8CghjCuRTDGKmxS4oJuVHgzTGth6VoKoNBQUrFKbMw2gP8NILJM/cFaoQUeVRyoPayMxbNB/CKlW0H92tBYxUixj0o5ROozPFoOm2pUtAO1aCxj0p6xj0osZuoypHajHSp0tgO1WAuKkUClYyc2QJAB2qZIgO1SqKeopGfMIiCpVWkHFOU07ENhjFOHSg0g60yWSJUigE0xMYpwNCESAU4DBpo4pc5piHg04HPWmDgc0qmglomHSnDrUQJpd3NBNicHijNRBvenbqVhWJKcOKiDUu6lYCUmgH1qMN70heiwibf60heot1G6iwWH7qXdURbmjcKdgsSk00HimbqaW4p2Cw5jzTCe1ITTGJFA7DmphpC3FNJp2AU9aTvTSaQmmUD1G1PY9qYSaVhojYdaYRUmaaaLFERAPamEVIaaRSLQwgU0inmm0FIYQKaQKexpjHimWkMOBUbGnnpUTHmixaEc1GTQTTWNBVjJB4pQaiB54p4NI7miQU9etRKaeDQS0TDpTlqJD707PNBBKD7UuaizTs0CJUNPxUKmnhu1BDH08e9MFOFBLHipFqIHFSA0EsmTHenfSo0PFOzQQxw61ItRA04NSJaJwacuMVEpp4NBDRJmnKahBp4YYoJZJmgYBpoNBOKBEymng5quHp4YUySfdShhmoVNODUCZMWpQah3Ub/AHpkk+7FAeod1Ju5osMsq/vTg3NVlbvS76LCaLRakDVAr5pd1FibFgMMdaQsKg30heiwixvGetIXqDdSF6dhk+80BjUG7jrSb8HrRYCwz+9NDk1AzUobFFhkxNMZqYXppahIY8sKTdUee9BbinYVh5amlvWmF6QnvmiwxxYU0vTC4ppIosUPLCmlqaSMUzNAxxYUxm96CRUbmpsUkPLDFISMdaiLU0vTsaWHsaYTTS9ML07FIcxGKiZqGao2NBaQjdKaSB3oYjFR555pFn//2Q==',
                        alt: 'برنامه هفتگی',
                        style: { width: '100%', height: '100%', objectFit: 'cover', display: 'block', borderRadius: 12 }
                    })),
                    React.createElement('button', {
                        onClick: function() {
                            if (window.Android && typeof window.Android.openRating === 'function') {
                                window.Android.openRating();
                            } else if (window.Android && typeof window.Android.openBazaar === 'function') {
                                window.Android.openBazaar();
                            }
                        },
                        className: 'btn-accent text-small',
                        style: {
                            padding: '6px 10px',
                            background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                            color: '#ffffff',
                            border: 'none',
                            borderRadius: 10,
                            fontWeight: 'bold',
                            fontSize: 12,
                            cursor: 'pointer'
                        }
                    }, '⭐ ثبت نظر'),
                    onLogout && React.createElement('button', { onClick: onLogout, className: 'btn-ghost text-small', style: { padding: '6px 10px', borderRadius: 10, fontSize: 12, cursor: 'pointer' } }, 'خروج از حساب')
                )
            );
        }

        // ============================================================

        // ============================================================
        // ثبت سطوح عملکرد دانش‌آموزان
        // جدول بر اساس فرم ارسالی کاربر (پایه اول) و قابل ویرایش برای هر دانش‌آموز
        // ============================================================
        const performanceRow = (id, lesson, content, expect) => ({ id, lesson, content, expect });

        // پایه اول
        const PERFORMANCE_ROWS = [
            performanceRow('quran-reading-group','قرآن','خواندن','جمع‌خوانی'),
            performanceRow('quran-reading','قرآن','خواندن','روخوانی'),
            performanceRow('quran-etiquette','قرآن','آموزه‌های قرآنی','آداب قرآن خواندن'),
            performanceRow('quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
            performanceRow('quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

            performanceRow('farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
            performanceRow('farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
            performanceRow('farsi-reading','فارسی','مهارت‌های خواندن','تصویرخوانی / خواندن'),
            performanceRow('farsi-writing-beautiful','فارسی','مهارت‌های نوشتن','زیبانویسی'),
            performanceRow('farsi-writing-correct','فارسی','مهارت‌های نوشتن','درست‌نویسی'),
            performanceRow('farsi-writing-sentence','فارسی','مهارت‌های نوشتن','جمله‌سازی'),

            performanceRow('math-number','ریاضی','عدد','شمارش تا اعداد سه‌رقمی / مقایسه اعداد'),
            performanceRow('math-operations','ریاضی','عملیات اعداد','جمع و تفریق'),
            performanceRow('math-geometry','ریاضی','هندسه','موقعیت مکانی / اشکال هندسی / تقارن'),
            performanceRow('math-measurement','ریاضی','اندازه‌گیری','طول / زمان / جرم'),
            performanceRow('math-statistics','ریاضی','آمار و نمودار','سرشماری و جدول داده‌ها / نمودار ستونی'),
            performanceRow('math-problem','ریاضی','حل مسئله','راهبردهای حل مسئله / حل مسئله'),
            performanceRow('math-problem-magic','ریاضی','حل مسئله','مربع شگفت‌انگیز'),

            performanceRow('science-process','علوم','مهارت‌های فرایندی و روش علمی','زنگ علوم / سلام به من نگاه کن / چه می‌خواهم بسازم / از گذشته تا آینده'),
            performanceRow('science-life','علوم','دنیای زنده، بدن انسان و سلامت','سالم باش / دنیای جانوران / دنیای گیاهان'),
            performanceRow('science-earth','علوم','زمین و پیرامون آن','زمین خانه‌ی پرآب، سنگی، خاکی ما'),
            performanceRow('science-air','علوم','زمین و پیرامون آن','در اطراف ما هوا وجود دارد'),
            performanceRow('science-motion','علوم','حرکت و انرژی','دنیای سرد و گرم / از خانه تا مدرسه / آهن‌ربای من'),

            performanceRow('art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
            performanceRow('art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

            performanceRow('pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود عضلانی / تعادل / قلبی-عروقی / انعطاف‌پذیری'),
            performanceRow('pe-basic','تربیت بدنی','حرکات پایه','کسب مهارت در جهت‌یابی / راه رفتن / ایستادن و نشستن / دویدن / پرتاب و چرخیدن'),

            performanceRow('general-individual','شایستگی‌های عمومی','شایستگی‌های فردی','رعایت بهداشت و ایمنی'),
            performanceRow('general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی ـ اجتماعی','رعایت آموخته‌های اخلاقی / مسئولیت‌پذیری / مشارکت در کار گروهی / احترام به ارزش‌های ملی و مذهبی'),
            performanceRow('general-learning','شایستگی‌های عمومی','شایستگی‌های یادگیری','توجه به مطالعه و کتابخوانی / تلاش برای یادگیری بیشتر')
        ];


        // ============================================================
        // جداول مستقل شش پایه — هر پایه دقیقاً منطبق با فرم رسمی PDF (جدول شماره ۸)
        // هر پایه آرایه‌ی مستقل خودش را دارد؛ سرفصل/محتوا و انتظارات آموزشی به‌صورت جفت صحیح ثبت شده‌اند.
        // ============================================================

        const PERFORMANCE_GRADE_ROWS = {
            1: PERFORMANCE_ROWS,

            // پایه دوم
            2: [
                performanceRow('g2-quran-reading','قرآن','خواندن','روخوانی'),
                performanceRow('g2-quran-qeraat','قرآن','خواندن','قرائت'),
                performanceRow('g2-quran-etiquette','قرآن','آموزه‌های قرآنی','آداب قرآن خواندن'),
                performanceRow('g2-quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
                performanceRow('g2-quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

                performanceRow('g2-hedayat-thanks','هدیه‌های آسمان','خداشناسی / خودشناسی','خداشناسی و تشکر از خدا'),
                performanceRow('g2-hedayat-prophets','هدیه‌های آسمان','پیامبری / امامت / شخصیت‌های دینی','آشنایی با پیامبران و امامان'),
                performanceRow('g2-hedayat-manners','هدیه‌های آسمان','آداب و اخلاق اسلامی','آشنایی با صفات و اخلاق خوب و مطلوب'),
                performanceRow('g2-hedayat-rules','هدیه‌های آسمان','احکام اسلامی / قرآن کریم','آشنایی با وضو، نماز و انجام صحیح آن'),
                performanceRow('g2-hedayat-ceremony','هدیه‌های آسمان','مراسم دینی و ملی','توجه به مناسبت‌های دینی و ملی'),

                performanceRow('g2-farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
                performanceRow('g2-farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
                performanceRow('g2-farsi-reading','فارسی','مهارت‌های خواندن','خواندن'),
                performanceRow('g2-farsi-writing','فارسی','مهارت‌های نوشتن','درست‌نویسی و املا'),
                performanceRow('g2-farsi-sentence','فارسی','مهارت‌های نوشتن','جمله‌سازی'),

                performanceRow('g2-math-number','ریاضی','عدد','شمارش تا عدد ٤ رقمی / پول و واحدهای آن'),
                performanceRow('g2-math-compare','ریاضی','عدد','مقایسه اعداد / اعداد تقریبی / کسر'),
                performanceRow('g2-math-operations','ریاضی','عملیات روی اعداد','جمع و تفریق فرآیندی / تکنیکی'),
                performanceRow('g2-math-geometry','ریاضی','هندسه','اشکال هندسی'),
                performanceRow('g2-math-symmetry','ریاضی','هندسه','تقارن'),
                performanceRow('g2-math-measure','ریاضی','اندازه‌گیری','طول / زمان'),
                performanceRow('g2-math-stat','ریاضی','آمار و احتمال','آمار و سرشماری / رسم نمودار'),
                performanceRow('g2-math-prob','ریاضی','آمار و احتمال','احتمال'),
                performanceRow('g2-math-problem','ریاضی','حل مسئله','راهبردهای حل مسئله'),
                performanceRow('g2-math-problem2','ریاضی','حل مسئله','حل مسئله'),

                performanceRow('g2-science-process','علوم','مهارت‌های فرایندی و روش علمی','زنگ علوم / ساخت وسیله / نان'),
                performanceRow('g2-science-earth','علوم','زمین و پیرامون آن','زندگی ما و گردش زمین'),
                performanceRow('g2-science-energy','علوم','حرکت و انرژی','صدا / نور / سوخت‌ها'),
                performanceRow('g2-science-life','علوم','دنیای زنده، بدن انسان و سلامت','هوای سالم، آب سالم / سرگذشت دانه / درون آشیانه‌ها / تغییرات بدن'),
                performanceRow('g2-science-materials','علوم','مواد و تغییرات','مواد پرکاربرد / تأثیر آب بر مواد'),

                performanceRow('g2-art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
                performanceRow('g2-art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

                performanceRow('g2-pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود عضلانی / تعادل / قلبی-تنفسی / انعطاف‌پذیری / چابکی'),
                performanceRow('g2-pe-basic','تربیت بدنی','حرکات پایه','خم و راست شدن / پریدن / به‌پهلو دویدن / پرتاب دو دست / لی‌لی کردن'),

                performanceRow('g2-general-individual','شایستگی‌های عمومی','شایستگی‌های فردی','رعایت بهداشت و ایمنی / توجه به مطالعه برای یادگیری بیشتر'),
                performanceRow('g2-general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی ـ اجتماعی','رعایت آموخته‌های اخلاقی / مسئولیت‌پذیری / مشارکت در کار گروهی / احترام به ارزش‌ها'),
            ],

            // پایه سوم
            3: [
                performanceRow('g3-quran-reading','قرآن','خواندن','روخوانی'),
                performanceRow('g3-quran-qeraat','قرآن','خواندن','قرائت'),
                performanceRow('g3-quran-etiquette','قرآن','آموزه‌های قرآنی','آداب قرآن خواندن'),
                performanceRow('g3-quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
                performanceRow('g3-quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

                performanceRow('g3-hedayat-1','هدیه‌های آسمان','خداشناسی / خودشناسی / جهان آخرت','تشکر از خدا'),
                performanceRow('g3-hedayat-2','هدیه‌های آسمان','پیامبری / امامت / شخصیت‌های دینی','آشنایی با زندگینامه پیامبران و امامان'),
                performanceRow('g3-hedayat-3','هدیه‌های آسمان','آداب، مراسم و احکام اسلامی / قرآن کریم','آشنایی با روزه و نماز و جشن تکلیف / سرلوحه قراردادن قرآن در زندگی'),

                performanceRow('g3-farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
                performanceRow('g3-farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
                performanceRow('g3-farsi-reading','فارسی','مهارت‌های خواندن','خواندن'),
                performanceRow('g3-farsi-writing','فارسی','مهارت‌های نوشتن','درست‌نویسی و املا'),
                performanceRow('g3-farsi-writing2','فارسی','مهارت‌های نوشتن','انشا و نگارش'),

                performanceRow('g3-math-number','ریاضی','عدد','شمارش تا عدد رقمی / پول'),
                performanceRow('g3-math-compare','ریاضی','عدد','مقایسه اعداد / اعداد تقریبی / کسر / مقایسه کسر'),
                performanceRow('g3-math-operations','ریاضی','عملیات روی اعداد','جمع، تفریق، ضرب و تقسیم'),
                performanceRow('g3-math-geometry','ریاضی','هندسه','احجام / دایره / زاویه / خطوط / چندضلعی‌ها'),
                performanceRow('g3-math-symmetry','ریاضی','هندسه','تقارن'),
                performanceRow('g3-math-measure','ریاضی','اندازه‌گیری','طول و محیط / مساحت / جرم / زمان'),
                performanceRow('g3-math-stat','ریاضی','آمار و احتمال','جدول داده‌ها / رسم نمودار'),
                performanceRow('g3-math-prob','ریاضی','آمار و احتمال','احتمال'),
                performanceRow('g3-math-problem','ریاضی','حل مسئله','راهبردهای حل مسئله'),
                performanceRow('g3-math-problem2','ریاضی','حل مسئله','حل مسئله'),

                performanceRow('g3-science-process','علوم','مهارت‌های فرایندی و روش علمی','زنگ علوم / ساخت وسیله‌ای با سه آینه / روش‌های مختلف نگهداری مواد غذایی'),
                performanceRow('g3-science-earth','علوم','زمین و پیرامون آن','آب، ماده‌ای با ارزش / زندگی ما و آب'),
                performanceRow('g3-science-energy','علوم','حرکت و انرژی','نور / نیرو'),
                performanceRow('g3-science-life','علوم','دنیای زنده، بدن انسان و سلامت','خوراکی‌ها / گیاهان / جانوران'),
                performanceRow('g3-science-materials','علوم','مواد و تغییرات','مواد اطراف ما / اندازه‌گیری مواد'),

                performanceRow('g3-social-system','مطالعات اجتماعی','نظام اجتماعی','ضرورت نظم و مقررات در مکان‌های مختلف / نهادهای اجتماعی'),
                performanceRow('g3-social-culture','مطالعات اجتماعی','فرهنگ و هویت','شناخت فردی خود / آموزه‌های دینی و اخلاقی درباره‌ی اعضای خانواده و مدرسه'),
                performanceRow('g3-social-time','مطالعات اجتماعی','زمان، تداوم و تغییر','تغییرات خود و محیط پیرامون'),
                performanceRow('g3-social-space','مطالعات اجتماعی','فضا و مکان','رابطه متقابل انسان و محیط'),
                performanceRow('g3-social-resources','مطالعات اجتماعی','منابع و فعالیت‌های اقتصادی','انواع مشاغل / منابع طبیعی'),

                performanceRow('g3-art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
                performanceRow('g3-art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

                performanceRow('g3-pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود عضلانی / تعادل / قلبی-تنفسی / انعطاف‌پذیری / چابکی'),
                performanceRow('g3-pe-basic','تربیت بدنی','حرکات پایه','خم و راست شدن / پریدن / به‌پهلو دویدن / پرتاب دو دست / لی‌لی'),

                performanceRow('g3-general-individual','شایستگی‌های عمومی','شایستگی‌های فردی','رعایت بهداشت و ایمنی / توجه به مطالعه و کتابخوانی / تلاش برای یادگیری بیشتر'),
                performanceRow('g3-general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی ـ اجتماعی','رعایت آموخته‌های اخلاقی / مسئولیت‌پذیری / مشارکت در کار گروهی / احترام به ارزش‌های ملی و مذهبی'),
            ],

            // پایه چهارم
            4: [
                performanceRow('g4-quran-reading','قرآن','خواندن','روخوانی'),
                performanceRow('g4-quran-qeraat','قرآن','خواندن','قرائت'),
                performanceRow('g4-quran-etiquette','قرآن','آموزه‌های قرآنی','ترجمه کلمات و عبارات قرآنی'),
                performanceRow('g4-quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
                performanceRow('g4-quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

                performanceRow('g4-hedayat-1','هدیه‌های آسمان','خداشناسی / خودشناسی / جهان آخرت','تشکر از خدا'),
                performanceRow('g4-hedayat-2','هدیه‌های آسمان','پیامبری / امامت / شخصیت‌های دینی','آشنایی با زندگینامه پیامبران و امامان'),
                performanceRow('g4-hedayat-3','هدیه‌های آسمان','آداب، مراسم و احکام اسلامی / قرآن کریم','آشنایی با تیمم، نمازجماعت و نمازهای مناسبتی / سرلوحه قراردادن قرآن در زندگی'),

                performanceRow('g4-farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
                performanceRow('g4-farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
                performanceRow('g4-farsi-reading','فارسی','مهارت‌های خواندن','خواندن'),
                performanceRow('g4-farsi-writing','فارسی','مهارت‌های نوشتن','درست‌نویسی و املا'),
                performanceRow('g4-farsi-writing2','فارسی','مهارت‌های نوشتن','انشا و نگارش'),

                performanceRow('g4-math-number1','ریاضی','عدد','الگوها / شمارش تا عدد ده‌رقمی / کسر و عدد مخلوط / عدد اعشاری تا یک رقم اعشار'),
                performanceRow('g4-math-number2','ریاضی','عدد','مقایسه اعداد / مقایسه کسر و عدد مخلوط'),
                performanceRow('g4-math-op1','ریاضی','عملیات روی اعداد','جمع، تفریق، ضرب و تقسیم اعداد طبیعی'),
                performanceRow('g4-math-op2','ریاضی','عملیات روی اعداد','جمع، تفریق و ضرب کسر و اعداد مخلوط / بخش‌پذیری / محاسبه‌های تقریبی'),
                performanceRow('g4-math-geometry','ریاضی','هندسه','زاویه / عمود و موازی / چهارضلعی‌ها'),
                performanceRow('g4-math-measure','ریاضی','اندازه‌گیری','زاویه / زمان / طول و محیط / مساحت'),
                performanceRow('g4-math-stat1','ریاضی','آمار و احتمال','نمودار خط شکسته'),
                performanceRow('g4-math-stat2','ریاضی','آمار و احتمال','احتمال وقوع یک پیشامد'),
                performanceRow('g4-math-problem1','ریاضی','حل مسئله','راهبردهای حل مسئله / حل مسئله'),
                performanceRow('g4-math-problem2','ریاضی','حل مسئله','ترکیب راهبردها'),

                performanceRow('g4-science-process','علوم تجربی و بهداشت','مهارت‌های فرایندی و روش علمی','زنگ علوم'),
                performanceRow('g4-science-earth','علوم تجربی و بهداشت','زمین و پیرامون آن','سنگ‌ها / آسمان شب'),
                performanceRow('g4-science-energy','علوم تجربی و بهداشت','حرکت و انرژی','انرژی الکتریکی / گرما و ماده / آهن‌ربا در زندگی'),
                performanceRow('g4-science-life','علوم تجربی و بهداشت','دنیای زنده / بدن انسان و سلامت','بدن ما / بی‌مهره‌ها / گوناگونی گیاهان / زیستگاه'),
                performanceRow('g4-science-materials','علوم تجربی و بهداشت','مواد و تغییرات آن','مخلوط‌ها'),

                performanceRow('g4-social-system','مطالعات اجتماعی','نظام اجتماعی','حقوق افراد / محله'),
                performanceRow('g4-social-culture','مطالعات اجتماعی','فرهنگ و هویت','شناخت نمادهای ملی / تقویم / ویژگی‌های شخصیتی امام خمینی / انواع زندگی'),
                performanceRow('g4-social-time','مطالعات اجتماعی','زمان، تداوم و تغییر','انسان‌های نخستین / مورخان و باستان‌شناسان / سلسله‌های باستانی'),
                performanceRow('g4-social-space','مطالعات اجتماعی','فضا و مکان','جغرافیا / ناهمواری‌ها / آب و هوا'),
                performanceRow('g4-social-resources','مطالعات اجتماعی','منابع و فعالیت‌های اقتصادی','امکانات عمومی محله / برنامه‌ریزی خرید / پوشش گیاهی نواحی مختلف'),

                performanceRow('g4-art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
                performanceRow('g4-art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

                performanceRow('g4-pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود قلبی-عضلانی / تنفسی / انعطاف‌پذیری / سرعت / بهداشت و ایمنی در ورزش'),
                performanceRow('g4-pe-skills','تربیت بدنی','مهارت‌های ورزشی','کسب مهارت‌های فوتبال / والیبال / تنیس روی میز / طناب‌زنی / شرکت در فعالیت‌ها'),

                performanceRow('g4-general-individual','شایستگی‌های عمومی','شایستگی‌های فردی / یادگیری','رعایت بهداشت و ایمنی / توجه به مطالعه برای یادگیری بیشتر'),
                performanceRow('g4-general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی-اجتماعی','رعایت آموخته‌های اخلاقی / مشارکت / مسئولیت‌پذیری / احترام به ارزش‌ها'),
            ],

            // پایه پنجم
            5: [
                performanceRow('g5-quran-reading','قرآن','خواندن','روخوانی'),
                performanceRow('g5-quran-qeraat','قرآن','خواندن','قرائت'),
                performanceRow('g5-quran-etiquette','قرآن','آموزه‌های قرآنی','ترجمه کلمات و عبارات قرآنی'),
                performanceRow('g5-quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
                performanceRow('g5-quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

                performanceRow('g5-hedayat-1','هدیه‌های آسمان','خداشناسی / خودشناسی / جهان آخرت','تشکر از خدا و نظم در آفریده‌هایش'),
                performanceRow('g5-hedayat-2','هدیه‌های آسمان','پیامبری / امامت / شخصیت‌های دینی','آشنایی با زندگینامه پیامبران و امامان'),
                performanceRow('g5-hedayat-3','هدیه‌های آسمان','آداب، مراسم و احکام اسلامی / قرآن کریم','آشنایی با صفات خوب و عمل به آن / نماز جمعه و تفاوت آن با سایر نمازهای روزانه / سرلوحه قراردادن قرآن در زندگی'),

                performanceRow('g5-farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
                performanceRow('g5-farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
                performanceRow('g5-farsi-reading','فارسی','مهارت‌های خواندن','خواندن'),
                performanceRow('g5-farsi-writing','فارسی','مهارت‌های نوشتن','درست‌نویسی و املا'),
                performanceRow('g5-farsi-writing2','فارسی','مهارت‌های نوشتن','انشا و نگارش'),

                performanceRow('g5-math-number1','ریاضی','عدد','الگوها / شمارش تا عدد سیزده‌رقمی / کسر و عدد مخلوط / عدد اعشاری تا یک رقم اعشار'),
                performanceRow('g5-math-number2','ریاضی','عدد','مقایسه اعداد / اعداد مخلوط / اعداد اعشاری'),
                performanceRow('g5-math-op1','ریاضی','عملیات روی اعداد','جمع و تفریق عددهای مرکب / مخلوط / اعشاری'),
                performanceRow('g5-math-op2','ریاضی','عملیات روی اعداد','ضرب کسرها / اعداد مخلوط / اعداد اعشاری'),
                performanceRow('g5-math-op3','ریاضی','عملیات روی اعداد','تقسیم کسرها / نسبت و تناسب / درصد'),
                performanceRow('g5-math-geometry','ریاضی','هندسه','تقارن محوری-مرکزی / نیمساز / خواص چندضلعی‌ها'),
                performanceRow('g5-math-measure','ریاضی','اندازه‌گیری','محیط دایره / مساحت لوزی و ذوزنقه / حجم و گنجایش'),
                performanceRow('g5-math-stat1','ریاضی','آمار و احتمال','جمع‌آوری داده‌ها و رسم نمودار'),
                performanceRow('g5-math-stat2','ریاضی','آمار و احتمال','میانگین / احتمال'),
                performanceRow('g5-math-problem','ریاضی','حل مسئله','راهبردهای حل مسئله / حل مسئله'),

                performanceRow('g5-science-process','علوم تجربی و بهداشت','مهارت‌های فرایندی و روش علمی','زنگ علوم'),
                performanceRow('g5-science-earth','علوم تجربی و بهداشت','زمین و پیرامون آن','برگی از تاریخ، خاکِ باارزش'),
                performanceRow('g5-science-energy','علوم تجربی و بهداشت','حرکت و انرژی','تجزیه نور و کاربرد عدسی، اهرم، ماشین‌های ساده و مرکب'),
                performanceRow('g5-science-life','علوم تجربی و بهداشت','دنیای زنده / بدن انسان و سلامت','حرکت بدن / ساختمان چشم و گوش / حواس / بکارید و بخورید / از ریشه تا برگ'),
                performanceRow('g5-science-materials','علوم تجربی و بهداشت','مواد و تغییرات آن','ماده تغییر می‌کند'),

                performanceRow('g5-social-system','مطالعات اجتماعی','نظام اجتماعی','ارتباط، احساسات و عواطف و ضرورت وجود و رعایت آن‌ها در بین افراد جامعه'),
                performanceRow('g5-social-culture','مطالعات اجتماعی','فرهنگ و هویت','مناسبت‌ها / شهرها و کشورهای مذهبی'),
                performanceRow('g5-social-time','مطالعات اجتماعی','زمان، تداوم و تغییر','ایران بعد از اسلام / آثار باستانی و شخصیت‌های ملی'),
                performanceRow('g5-social-space','مطالعات اجتماعی','فضا و مکان','آشنایی با همسایگان ایران، قاره‌ها'),
                performanceRow('g5-social-resources','مطالعات اجتماعی','منابع و فعالیت‌های اقتصادی','آشنایی با ایران به تفکیک سرفصل‌ها'),

                performanceRow('g5-art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
                performanceRow('g5-art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

                performanceRow('g5-pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود قلبی-تنفسی / انعطاف‌پذیری / سرعت / بهداشت و ایمنی در ورزش'),
                performanceRow('g5-pe-skills','تربیت بدنی','مهارت‌های ورزشی','کسب مهارت‌های بسکتبال / هندبال / بدمینتون / طناب‌زنی / شرکت در فعالیت‌ها'),

                performanceRow('g5-general-individual','شایستگی‌های عمومی','شایستگی‌های فردی / یادگیری','رعایت بهداشت / توجه به مطالعه'),
                performanceRow('g5-general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی-اجتماعی','رعایت آموخته‌های اخلاقی / مشارکت / مسئولیت‌پذیری / احترام به ارزش‌ها'),
            ],

            // پایه ششم
            6: [
                performanceRow('g6-quran-reading','قرآن','خواندن','روخوانی'),
                performanceRow('g6-quran-qeraat','قرآن','خواندن','قرائت'),
                performanceRow('g6-quran-etiquette','قرآن','آموزه‌های قرآنی','ترجمه کلمات و عبارات قرآنی'),
                performanceRow('g6-quran-message','قرآن','آموزه‌های قرآنی','پیام قرآنی'),
                performanceRow('g6-quran-story','قرآن','آموزه‌های قرآنی','داستان‌های قرآنی'),

                performanceRow('g6-hedayat-1','هدیه‌های آسمان','خداشناسی / خودشناسی / جهان آخرت','تشکر از خدا و نظم در آفریده‌هایش'),
                performanceRow('g6-hedayat-2','هدیه‌های آسمان','پیامبری / امامت / شخصیت‌های دینی','آشنایی با زندگینامه پیامبران و امامان'),
                performanceRow('g6-hedayat-3','هدیه‌های آسمان','آداب، مراسم و احکام اسلامی / قرآن کریم','آشنایی با صفات خوب و عمل به آن / فروع دین، نماز مسافر و اعیاد مسلمانان / سرلوحه قراردادن قرآن در زندگی'),

                performanceRow('g6-farsi-listening','فارسی','مهارت‌های خواندن','گوش دادن'),
                performanceRow('g6-farsi-speaking','فارسی','مهارت‌های خواندن','سخن گفتن'),
                performanceRow('g6-farsi-reading','فارسی','مهارت‌های خواندن','خواندن'),
                performanceRow('g6-farsi-writing','فارسی','مهارت‌های نوشتن','درست‌نویسی و املا'),
                performanceRow('g6-farsi-writing2','فارسی','مهارت‌های نوشتن','انشا و نگارش'),

                performanceRow('g6-math-number1','ریاضی','عدد','الگوها / شمارش تا عدد سیزده‌رقمی / کسر و عدد مخلوط / عدد اعشاری تا یک رقم اعشار'),
                performanceRow('g6-math-number2','ریاضی','عدد','مقایسه اعداد صحیح / اعداد مخلوط / اعداد اعشاری'),
                performanceRow('g6-math-op1','ریاضی','عملیات روی اعداد','جمع، تفریق و ضرب عددهای صحیح / مخلوط / اعشاری'),
                performanceRow('g6-math-op2','ریاضی','عملیات روی اعداد','تقسیم کسرها / اعداد اعشاری / نسبت و تناسب / درصد'),
                performanceRow('g6-math-geometry','ریاضی','هندسه','تقارن / دوران / مختصات'),
                performanceRow('g6-math-measure','ریاضی','اندازه‌گیری','طول و سطح / جرم و حجم / خط و زاویه'),
                performanceRow('g6-math-problem','ریاضی','حل مسئله','راهبردهای حل مسئله / حل مسئله'),

                performanceRow('g6-science-process','علوم','مهارت‌های فرایندی و روش علمی','روش علمی / ساخت وسایل متحرک / تغییرات فناوری در طول زمان'),
                performanceRow('g6-science-earth','علوم','زمین و پیرامون آن','سفر به اعماق زمین / زمین پویا'),
                performanceRow('g6-science-energy','علوم','حرکت و انرژی','ورزش و نیرو / سفر انرژی'),
                performanceRow('g6-science-life','علوم','دنیای زنده / بدن انسان و سلامت','میکروسکوپ / شگفتی‌های برگ / جنگل / سالم بمانیم'),
                performanceRow('g6-science-materials','علوم','مواد و تغییرات آن','سرگذشت دفتر من / کارخانه کاغذسازی'),

                performanceRow('g6-social-system','اجتماعی','نظام اجتماعی','تصمیم‌گیری / برنامه‌ریزی / دوست‌یابی'),
                performanceRow('g6-social-culture','اجتماعی','فرهنگ و هویت','صفویه / دوره اسلامی / آداب و آموزه‌های دینی'),
                performanceRow('g6-social-time','اجتماعی','زمان، تداوم و تغییر','استعمار / جنگ تحمیلی / تغییرات پدیده‌های زندگی'),
                performanceRow('g6-social-space','اجتماعی','فضا و مکان','کشاورزی / دریاها و همسایگان ایران'),
                performanceRow('g6-social-resources','اجتماعی','منابع و فعالیت‌های اقتصادی','مشاغل / تولید و مصرف / منابع انرژی'),

                performanceRow('g6-thinking-decision','تفکر و پژوهش','انتخاب و تصمیم‌گیری','تصمیم‌گیری و انتخاب آگاهانه'),
                performanceRow('g6-thinking-research','تفکر و پژوهش','پژوهش','آشنایی با روند انجام پژوهش'),
                performanceRow('g6-thinking-system','تفکر و پژوهش','نظام‌مندی','آشنایی با سیستم و اجرای آن‌ها'),
                performanceRow('g6-thinking-identity','تفکر و پژوهش','هویت و ارزش','تفکر در هویت و ارزش‌های ایرانی و ملی'),

                performanceRow('g6-tech-computer','کار و فناوری','رایانه','آشنایی با رایانه و استفاده مطلوب و بهینه از آن'),
                performanceRow('g6-tech-work','کار و فناوری','کار و خلاقیت','دست‌ورزی و ارتباط آن با اقتصاد و درآمدزایی'),

                performanceRow('g6-art-expression','هنر','بیان ایده در قالب‌های مختلف هنری','زیبایی‌شناسی / ارتباط با طبیعت / تولید و نقد هنری / آشنایی با میراث فرهنگی'),
                performanceRow('g6-art-tools','هنر','استفاده مناسب از ابزار','کاربرد درست ابزار / رعایت ایمنی'),

                performanceRow('g6-pe-fitness','تربیت بدنی','آمادگی جسمانی','توسعه و بهبود قلبی-تنفسی / انعطاف‌پذیری / عضلانی / بهداشت و ایمنی در ورزش'),
                performanceRow('g6-pe-skills','تربیت بدنی','مهارت‌های ورزشی','کسب مهارت‌های دو سرعت و ماریپیچ / پرش / پرتاب / بازی‌های بومی و محلی'),

                performanceRow('g6-general-individual','شایستگی‌های عمومی','شایستگی‌های فردی','رعایت بهداشت / توجه به مطالعه'),
                performanceRow('g6-general-social','شایستگی‌های عمومی','شایستگی‌های فرهنگی-اجتماعی','رعایت آموخته‌های اخلاقی / مشارکت / مسئولیت‌پذیری / احترام به ارزش‌ها'),
            ],
        };

        const PERFORMANCE_MONTHS = [
            { key: 'mehr', label: 'مهر' },
            { key: 'aban', label: 'آبان' },
            { key: 'azar', label: 'آذر' },
            { key: 'dey', label: 'دی' },
            { key: 'bahman', label: 'بهمن' },
            { key: 'esfand', label: 'اسفند' },
            { key: 'farvardin', label: 'فروردین' },
            { key: 'ordibehesht', label: 'اردیبهشت' }
        ];

        // ترکیب سطرهای پیش‌فرض با سطرهای سفارشیِ اضافه‌شده (با درنظرگرفتن جای درج و
        // سطرهای پیش‌فرضی که کاربر مخفی/حذف کرده) — یک منبع واحد برای جدول، گزارش
        // داشبورد و PDF تا همه‌جا دقیقاً هماهنگ باشند.
        function buildPerformanceRows(data, baseRows = PERFORMANCE_ROWS) {
            const customRows = Array.isArray(data.performanceCustomRows) ? data.performanceCustomRows : [];
            const hiddenSet = new Set(Array.isArray(data.performanceHiddenRowIds) ? data.performanceHiddenRowIds : []);
            const visibleBase = baseRows.filter(r => !hiddenSet.has(r.id));

            const appendMap = new Map();
            customRows.forEach(cr => {
                const key = cr.insertAfter || '__end__';
                if (!appendMap.has(key)) appendMap.set(key, []);
                appendMap.get(key).push(cr);
            });

            const result = [];
            visibleBase.forEach(r => {
                result.push(r);
                if (appendMap.has(r.id)) {
                    result.push(...appendMap.get(r.id));
                    appendMap.delete(r.id);
                }
            });
            appendMap.forEach(list => result.push(...list));
            return result;
        }

        // خواندن سطوح عملکرد یک دانش‌آموز با توجه به پایه‌ی خودش — منبع واحد
        // برای داشبورد و گزارش PDF تا با جدول ثبت (که بر اساس پایه ذخیره می‌کند) هماهنگ باشند.
        function getStudentGrade(student) {
            return (student && GRADE_ORDER.includes(student.grade)) ? student.grade : '1';
        }

        function getStudentPerformanceData(data, student) {
            const performance = (data.performance && typeof data.performance === 'object') ? data.performance : {};
            const performanceByGrade = (data.performanceByGrade && typeof data.performanceByGrade === 'object') ? data.performanceByGrade : {};
            const grade = getStudentGrade(student);
            const gradePerf = (performanceByGrade[grade] && typeof performanceByGrade[grade] === 'object')
                ? performanceByGrade[grade]
                : (grade === '1' ? performance : {});
            const studentId = student ? student.id : null;
            return (gradePerf[studentId] && typeof gradePerf[studentId] === 'object') ? gradePerf[studentId] : {};
        }

        // ردیف‌های مربوط به پایه‌ی همان دانش‌آموز را برمی‌گرداند — هر پایه شناسه‌های
        // ردیف متفاوتی دارد، پس نمی‌شود همیشه لیست پایه‌ی اول را به کار برد.
        function getStudentPerformanceRows(data, student) {
            const grade = getStudentGrade(student);
            const gradeRows = PERFORMANCE_GRADE_ROWS[grade] || PERFORMANCE_ROWS;
            return buildPerformanceRows(data, gradeRows);
        }

        // میانگین ترکیبی نمره‌ی یک دانش‌آموز — هم بر اساس آزمون‌های ثبت‌شده و هم
        // بر اساس سطوح عملکردی که در بخش «عملکرد» برای او ثبت شده. اگر هر دو منبع
        // داده داشته باشند، هر کدام وزن برابر (۵۰٪) در میانگین نهایی دارند تا یکی
        // از این دو بر دیگری غالب نشود؛ اگر فقط یکی موجود باشد، همان ملاک قرار می‌گیرد.
        function getStudentCombinedScoreStats(data, student) {
            const exams = (data.exams && data.exams[student.id]) || [];
            let examTotal = 0;
            let examCount = 0;
            exams.forEach(e => {
                // غیبت در آزمون نمره محسوب نمی‌شود و نباید میانگین را کاهش دهد.
                if (e.absent === true) return;
                examTotal += getGradeScore(e.grade);
                examCount++;
            });
            const examAvg = examCount > 0 ? (examTotal / examCount) : null;

            const perfData = getStudentPerformanceData(data, student);
            let perfTotal = 0;
            let perfCount = 0;
            Object.values(perfData || {}).forEach(rowLevels => {
                if (rowLevels && typeof rowLevels === 'object') {
                    Object.values(rowLevels).forEach(level => {
                        const score = getGradeScore(level);
                        if (score > 0) {
                            perfTotal += score;
                            perfCount++;
                        }
                    });
                }
            });
            const perfAvg = perfCount > 0 ? (perfTotal / perfCount) : null;

            let combinedAvg = 0;
            let hasData = false;
            if (examAvg !== null && perfAvg !== null) {
                combinedAvg = (examAvg + perfAvg) / 2;
                hasData = true;
            } else if (examAvg !== null) {
                combinedAvg = examAvg;
                hasData = true;
            } else if (perfAvg !== null) {
                combinedAvg = perfAvg;
                hasData = true;
            }

            const avgPercent = hasData ? Math.round((combinedAvg / 4) * 100) : 0;
            const gradeLevel = !hasData ? 'بدون سابقه' :
                combinedAvg >= 3.5 ? 'عالی' :
                combinedAvg >= 2.5 ? 'خوب' :
                combinedAvg >= 1.5 ? 'قابل قبول' : 'نیاز به تلاش';

            return { examCount, examAvg, perfCount, perfAvg, combinedAvg, avgPercent, gradeLevel, hasData };
        }

        function PerformanceLevels({ data, save, showToast }) {
            const students = Array.isArray(data.students) ? data.students : [];
            const performance = (data.performance && typeof data.performance === 'object') ? data.performance : {};
            const performanceByGrade = (data.performanceByGrade && typeof data.performanceByGrade === 'object') ? data.performanceByGrade : {};
            const customRows = Array.isArray(data.performanceCustomRows) ? data.performanceCustomRows : [];
            const hiddenRowIds = Array.isArray(data.performanceHiddenRowIds) ? data.performanceHiddenRowIds : [];

            const [selectedStudentId, setSelectedStudentId] = React.useState(students[0] ? students[0].id : null);

            React.useEffect(() => {
                if (!students.length) {
                    if (selectedStudentId !== null) setSelectedStudentId(null);
                    return;
                }
                if (!students.some(s => s.id === selectedStudentId)) {
                    setSelectedStudentId(students[0].id);
                }
            }, [students, selectedStudentId]);

            const selectedStudent = students.find(s => s.id === selectedStudentId) || null;
            // پایه دیگر به‌صورت دستی انتخاب نمی‌شود — از پایه‌ی ثبت‌شده‌ی خود دانش‌آموز
            // (در تب «دانش‌آموزان») خوانده می‌شود و با تغییر دانش‌آموز، جدول به‌طور خودکار عوض می‌شود.
            const studentGradeMissing = !!selectedStudent && !GRADE_ORDER.includes(selectedStudent.grade);
            const selectedGrade = (selectedStudent && GRADE_ORDER.includes(selectedStudent.grade)) ? selectedStudent.grade : '1';
            const gradeRows = PERFORMANCE_GRADE_ROWS[selectedGrade] || PERFORMANCE_ROWS;
            const rows = buildPerformanceRows(data, gradeRows);

            const selectedGradePerformance = (performanceByGrade[selectedGrade] && typeof performanceByGrade[selectedGrade] === 'object') ? performanceByGrade[selectedGrade] : (selectedGrade === '1' ? performance : {});

            const getLevel = (studentId, rowId, monthKey) => {
                const sp = selectedGradePerformance[studentId];
                const rp = sp && sp[rowId];
                if (!rp || typeof rp !== 'object') return '';
                return rp[monthKey] || '';
            };

            const [openMonthMenu, setOpenMonthMenu] = React.useState(null);

            const setLevel = (studentId, rowId, monthKey, value) => {
                save(prev => {
                    const prevPerf = prev.performanceByGrade || {};
                    const prevLegacy = prev.performance || {};
                    const gradePerf = { ...(prevPerf[selectedGrade] || {}) };
                    // مهاجرت خودکار داده‌های قدیمی پایه اول
                    if (selectedGrade === '1' && Object.keys(gradePerf).length === 0 && Object.keys(prevLegacy).length) Object.assign(gradePerf, prevLegacy);
                    const studentPerf = { ...(gradePerf[studentId] || {}) };
                    const prevRow = studentPerf[rowId];
                    const rowPerf = { ...((prevRow && typeof prevRow === 'object') ? prevRow : {}) };
                    if (value) rowPerf[monthKey] = value; else delete rowPerf[monthKey];
                    studentPerf[rowId] = rowPerf;
                    gradePerf[studentId] = studentPerf;
                    const next = { ...prev, performanceByGrade: { ...prevPerf, [selectedGrade]: gradePerf } };
                    if (selectedGrade === '1') next.performance = gradePerf;
                    return next;
                });
                showToast(`سطح عملکرد ${gradeName(selectedGrade)} ذخیره شد`);
            };

            const applyLevelToMonth = (studentId, monthKey, value) => {
                if (!studentId || !value) return;
                save(prev => {
                    const prevPerf = prev.performanceByGrade || {};
                    const prevLegacy = prev.performance || {};
                    const gradePerf = { ...(prevPerf[selectedGrade] || {}) };
                    if (selectedGrade === '1' && Object.keys(gradePerf).length === 0 && Object.keys(prevLegacy).length) Object.assign(gradePerf, prevLegacy);
                    const studentPerf = { ...(gradePerf[studentId] || {}) };
                    rows.forEach(row => {
                        const prevRow = studentPerf[row.id];
                        const rowPerf = { ...((prevRow && typeof prevRow === 'object') ? prevRow : {}) };
                        rowPerf[monthKey] = value;
                        studentPerf[row.id] = rowPerf;
                    });
                    gradePerf[studentId] = studentPerf;
                    const next = { ...prev, performanceByGrade: { ...prevPerf, [selectedGrade]: gradePerf } };
                    if (selectedGrade === '1') next.performance = gradePerf;
                    return next;
                });
                showToast(`سطح «${getGradeLabel(value)}» برای همه دروس ${PERFORMANCE_MONTHS.find(m => m.key === monthKey)?.label || ''} اعمال شد`);
                setOpenMonthMenu(null);
            };

            const [rowTexts, setRowTexts] = React.useState((data.performanceRowTexts && typeof data.performanceRowTexts === 'object') ? data.performanceRowTexts : {});
            const rowTextsRef = React.useRef(rowTexts);
            React.useEffect(() => { rowTextsRef.current = rowTexts; }, [rowTexts]);
            const rowTextCommitTimer = React.useRef(null);

            const getRowText = (rowId, field, fallback) => {
                const r = rowTexts[rowId];
                return (r && typeof r[field] === 'string') ? r[field] : fallback;
            };

            const updateRowTextLocal = (rowId, field, value) => {
                const next = { ...rowTextsRef.current, [rowId]: { ...(rowTextsRef.current[rowId] || {}), [field]: value } };
                rowTextsRef.current = next;
                setRowTexts(next);
                // ذخیره‌ی خودکار با کمی تأخیر؛ side-effect دیگر داخل updater نیست
                if (rowTextCommitTimer.current) clearTimeout(rowTextCommitTimer.current);
                rowTextCommitTimer.current = setTimeout(() => {
                    rowTextCommitTimer.current = null;
                    const snapshot = rowTextsRef.current;
                    save(prev => ({ ...prev, performanceRowTexts: snapshot }));
                }, 400);
            };

            const commitRowText = () => {
                if (rowTextCommitTimer.current) { clearTimeout(rowTextCommitTimer.current); rowTextCommitTimer.current = null; }
                const snapshot = rowTextsRef.current;
                save(prev => ({ ...prev, performanceRowTexts: snapshot }));
            };

            const resetRowTextsToDefault = () => {
                if (!window.confirm('متن ویرایش‌شده‌ی جدول به متن پیش‌فرض برگردد؟')) return;
                if (rowTextCommitTimer.current) { clearTimeout(rowTextCommitTimer.current); rowTextCommitTimer.current = null; }
                rowTextsRef.current = {};
                setRowTexts({});
                save(prev => ({ ...prev, performanceRowTexts: {} }));
                showToast('متن جدول به حالت پیش‌فرض برگشت');
            };

            const grouped = (rows, keyFn) => {
                const out = [];
                rows.forEach(row => {
                    const key = keyFn(row);
                    const last = out[out.length - 1];
                    if (last && last.key === key) last.rows.push(row);
                    else out.push({ key, rows:[row] });
                });
                return out;
            };

            const lessonGroups = grouped(rows, r => r.lesson);
            const contentGroups = grouped(rows, r => `${r.lesson}__${r.content}`);

            const rowSpans = new Map();
            lessonGroups.forEach(g => g.rows.forEach((r,i) => rowSpans.set(r.id, i === 0 ? g.rows.length : 0)));
            const contentSpans = new Map();
            contentGroups.forEach(g => g.rows.forEach((r,i) => contentSpans.set(r.id, i === 0 ? g.rows.length : 0)));

            const levelClass = value => value ? `level-${value}` : '';

            const [newRow, setNewRow] = React.useState({ lesson:'', content:'', expect:'', insertAfter:'' });
            const addCustomRow = () => {
                const lesson = newRow.lesson.trim();
                const content = newRow.content.trim();
                const expect = newRow.expect.trim();
                if (!lesson || !expect) {
                    showToast('نام درس و انتظار آموزشی را وارد کنید', 'error');
                    return;
                }
                const id = `custom-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
                const nextCustomRows = [...customRows, { id, lesson, content, expect, insertAfter: newRow.insertAfter || null }];
                const ok = save({ ...data, performanceCustomRows: nextCustomRows });
                if (ok !== false) {
                    showToast('سطر جدید اضافه شد');
                    setNewRow({ lesson:'', content:'', expect:'', insertAfter:'' });
                }
            };

            const cleanupPerformanceForRow = (rowId) => {
                const stripRow = m => (m && typeof m === 'object' && !Array.isArray(m)) ? Object.fromEntries(Object.entries(m).filter(([k]) => k !== rowId)) : m;
                const performance = Object.fromEntries(Object.entries(data.performance || {}).map(([sid, rm]) => [sid, stripRow(rm)]));
                const performanceByGrade = Object.fromEntries(Object.entries(data.performanceByGrade || {}).map(([g, gm]) => [g, Object.fromEntries(Object.entries(gm || {}).map(([sid, rm]) => [sid, stripRow(rm)]))]));
                return { performance, performanceByGrade };
            };
            const deleteRow = (row) => {
                const isCustom = customRows.some(r => r.id === row.id);
                const label = `${row.lesson} — ${getRowText(row.id,'expect',row.expect)}`;
                if (isCustom) {
                    if (!window.confirm(`سطر «${label}» حذف شود؟ این سطر و سطح‌های عملکرد ثبت‌شده برایش از گزارش‌ها هم حذف می‌شود.`)) return;
                    const nextCustomRows = customRows.filter(r => r.id !== row.id);
                    const ok = save({ ...data, ...cleanupPerformanceForRow(row.id), performanceCustomRows: nextCustomRows });
                    if (ok !== false) showToast('سطر حذف شد');
                } else {
                    if (!window.confirm(`سطر «${label}» از جدول حذف شود؟ می‌توانید بعداً از دکمه‌ی بازگرداندن، سطرهای پیش‌فرض حذف‌شده را برگردانید.`)) return;
                    const nextHidden = [...hiddenRowIds, row.id];
                    const ok = save({ ...data, performanceHiddenRowIds: nextHidden });
                    if (ok !== false) showToast('سطر حذف شد');
                }
            };

            const restoreHiddenRows = () => {
                const ok = save({ ...data, performanceHiddenRowIds: [] });
                if (ok !== false) showToast('سطرهای پیش‌فرض حذف‌شده بازگردانده شدند');
            };

            const exportPerformanceStudentPng = async () => {
                const student = selectedStudent;
                if (!student) return showToast('ابتدا دانش‌آموز را انتخاب کنید', 'error');
                const W = 1560, margin = 36, headerH = 190, rowH = 48;
                const monthCol = Math.floor((W - margin * 2 - 810) / PERFORMANCE_MONTHS.length);
                const widths = [150, 190, 470, ...PERFORMANCE_MONTHS.map(() => monthCol)];
                const totalRows = rows.length;
                const H = headerH + 62 + totalRows * rowH + 45;
                const canvas = document.createElement('canvas');
                canvas.width = W; canvas.height = H;
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
                ctx.fillStyle = '#254447'; ctx.fillRect(0, 0, W, headerH);
                ctx.fillStyle = '#fff'; ctx.textAlign = 'right';
                ctx.font = 'bold 34px Tahoma, Arial'; ctx.fillText('گزارش سطوح عملکرد دانش‌آموز', W - margin, 55);
                ctx.font = 'bold 25px Tahoma, Arial'; ctx.fillText(attNameOf(student), W - margin, 105);
                ctx.font = '18px Tahoma, Arial'; ctx.fillText('پایه ' + gradeName(selectedGrade) + '  |  گزارش همه ماه‌ها', W - margin, 148);
                if (student.photo) {
                    try {
                        const im = new Image();
                        await new Promise((resolve, reject) => { im.onload = resolve; im.onerror = reject; im.src = student.photo; });
                        ctx.save(); ctx.beginPath(); ctx.arc(90, 92, 54, 0, Math.PI * 2); ctx.clip();
                        ctx.drawImage(im, 36, 38, 108, 108); ctx.restore();
                    } catch (e) {}
                }
                const labels = ['درس', 'محتوا', 'انتظار آموزشی', ...PERFORMANCE_MONTHS.map(m => m.label)];
                let x = W - margin;
                ctx.fillStyle = '#e8f3f2'; ctx.fillRect(margin, headerH, W - margin * 2, 62);
                ctx.font = 'bold 16px Tahoma, Arial'; ctx.fillStyle = '#254447'; ctx.textAlign = 'center';
                labels.forEach((label, i) => {
                    const w = widths[i] || 92;
                    ctx.fillText(label, x - w / 2, headerH + 36);
                    x -= w;
                });
                rows.forEach((row, index) => {
                    const y = headerH + 62 + index * rowH;
                    ctx.fillStyle = index % 2 ? '#f7faf9' : '#fff';
                    ctx.fillRect(margin, y, W - margin * 2, rowH);
                    const vals = [row.lesson, row.content || '', getRowText(row.id, 'expect', row.expect), ...PERFORMANCE_MONTHS.map(m => {
                        const v = getLevel(student.id, row.id, m.key);
                        return v ? getGradeLabel(v) : '—';
                    })];
                    let xx = W - margin;
                    vals.forEach((val, i) => {
                        const w = widths[i] || 92;
                        ctx.textAlign = 'center';
                        ctx.font = i < 3 ? '14px Tahoma, Arial' : 'bold 13px Tahoma, Arial';
                        ctx.fillStyle = i < 3 ? '#263b3d' : (val === '—' ? '#94a3b8' : '#16845b');
                        let text = String(val || '');
                        const max = i === 2 ? 52 : i < 2 ? 20 : 12;
                        if (text.length > max) text = text.slice(0, max - 1) + '…';
                        ctx.fillText(text, xx - w / 2, y + 29);
                        xx -= w;
                    });
                    ctx.strokeStyle = '#e5eeee'; ctx.beginPath(); ctx.moveTo(margin, y + rowH); ctx.lineTo(W - margin, y + rowH); ctx.stroke();
                });
                const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
                if (!blob) throw new Error('ساخت PNG ناموفق بود');
                const shareResult = await saveOrSharePng(blob, 'سطوح-عملکرد-' + String(student.name || student.id).replace(/[\\/:*?"<>|]/g, '-') + '.png', 'گزارش سطوح عملکرد');
                if (shareResult === 'cancelled') return;
                showToast(shareResult === 'shared' ? '📤 گزارش اشتراک شد' : '📥 گزارش دانلود شد');
            };

            if (!students.length) {
                return React.createElement('div', { className:'card performance-card' },
                    React.createElement('div', { className:'flex-between', style:{gap:10,alignItems:'flex-start'} },
                        React.createElement('div', null,
                            React.createElement('h3', { style:{margin:'0 0 6px'} }, '📝 ثبت سطوح عملکرد دانش‌آموزان'),
                            React.createElement('div', { className:'text-muted text-small' }, `جدول مطابق فرم ارسالی شما — ${gradeName(selectedGrade)}`)
                        )
                    ),
                    React.createElement('div', { className:'performance-empty' },
                        React.createElement('div', { style:{fontSize:34,marginBottom:8} }, '👨‍🎓'),
                        React.createElement('div', { style:{fontWeight:800,marginBottom:6} }, 'ابتدا دانش‌آموزان کلاس را ثبت کنید'),
                        React.createElement('div', null, 'بعد از ثبت دانش‌آموزان، نام آن‌ها به‌صورت خودکار در ستون‌های جدول قرار می‌گیرد و برای هر انتظار آموزشی می‌توانید سطح عملکرد را انتخاب کنید.')
                    )
                );
            }

            return React.createElement('div', { className:'card performance-card' },
                React.createElement('div', { className:'card', style:{marginBottom:8,padding:10} },
                    React.createElement('div', { style:{display:'flex',gap:6,flexWrap:'wrap'} },
                        React.createElement('input', { placeholder:'درس', value:newRow.lesson, onChange:e => setNewRow({...newRow, lesson:e.target.value}), style:{flex:'1 1 100px'} }),
                        React.createElement('input', { placeholder:'محتوا', value:newRow.content, onChange:e => setNewRow({...newRow, content:e.target.value}), style:{flex:'1 1 100px'} }),
                        React.createElement('input', { placeholder:'انتظار آموزشی', value:newRow.expect, onChange:e => setNewRow({...newRow, expect:e.target.value}), style:{flex:'2 1 180px'} }),
                        React.createElement('button', { className:'btn-primary', onClick: addCustomRow }, 'افزودن سطر')
                    )
                ),
                React.createElement('div', { className:'performance-toolbar' },
                    React.createElement('div', null,
                        React.createElement('h3', { style:{margin:'0 0 5px'} }, '📝 ثبت سطوح عملکرد دانش‌آموزان'),
                        React.createElement('div', { className:'text-muted text-small' }, `فرم ${gradeName(selectedGrade)} — جدول مستقل، قابل ویرایش و ذخیره‌شونده`)
                    ),
                    React.createElement('div', { className:'performance-legend' },
                        React.createElement('span',{className:'legend-item excellent'},'خیلی خوب'),
                        React.createElement('span',{className:'legend-item good'},'خوب'),
                        React.createElement('span',{className:'legend-item acceptable'},'قابل قبول'),
                        React.createElement('span',{className:'legend-item needs_work'},'نیاز به تلاش بیشتر')
                    ),
                    React.createElement('button', {
                        onClick: resetRowTextsToDefault,
                        className: 'btn-ghost',
                        style: { fontSize: 12, padding: '5px 10px' }
                    }, '↩️ بازگرداندن متن پیش‌فرض'),
                    hiddenRowIds.length > 0 && React.createElement('button', {
                        onClick: restoreHiddenRows,
                        className: 'btn-ghost',
                        style: { fontSize: 12, padding: '5px 10px' }
                    }, `🔄 بازگرداندن ${toPersianDigits(hiddenRowIds.length)} سطر حذف‌شده`)
                ),
                React.createElement('div',{className:'performance-student-bar',style:{flexWrap:'wrap',gap:10}},
                    React.createElement('label',{className:'performance-student-label',htmlFor:'performance-student-select'},'👨‍🎓 دانش‌آموز:'),
                    React.createElement('select',{
                        id:'performance-student-select',
                        className:'performance-student-select',
                        value:selectedStudentId || '',
                        onChange:e=>setSelectedStudentId(e.target.value)
                    },
                        students.map(s=>React.createElement('option',{key:s.id,value:s.id}, `${s.name || 'بدون نام'} — ${GRADE_ORDER.includes(s.grade) ? gradeName(s.grade) : 'پایه ثبت نشده'}`))
                    ),
                    React.createElement('button', {
                        type: 'button', className: 'btn-primary',
                        onClick: () => exportPerformanceStudentPng().catch(e => { console.error(e); showToast('خطا در ساخت گزارش PNG', 'error'); })
                    }, '📤 گزارش PNG برای والدین'),
                    React.createElement('span',{
                        className:'performance-student-label',
                        style:{
                            background:'#DFF7F3',
                            color:'#2BB3A3',
                            borderRadius:8,
                            padding:'6px 12px',
                            fontWeight:700
                        }
                    }, `🎓 ${gradeName(selectedGrade)}`)
                ),
                selectedStudentId && React.createElement('div',{className:'performance-current-student'},
                    `📋 جدول ماهانه دانش‌آموز: ${(students.find(s=>s.id===selectedStudentId)||{}).name || 'بدون نام'} — ${gradeName(selectedGrade)}`
                ),
                studentGradeMissing && React.createElement('div',{
                    className:'performance-current-student',
                    style:{color:'#FF6B81',fontWeight:600}
                }, `⚠️ پایه‌ی این دانش‌آموز هنوز ثبت نشده — فعلاً جدول «${gradeName('1')}» نمایش داده می‌شود. برای اصلاح، به تب «دانش‌آموزان» بروید و پایه را انتخاب کنید.`),
                React.createElement('div',{className:'performance-table-wrap'},
                    React.createElement('table',{className:'performance-table',dir:'rtl'},
                        React.createElement('thead',null,
                            React.createElement('tr',null,
                                React.createElement('th',{className:'lesson-head'},'نام درس'),
                                React.createElement('th',{className:'content-head'},'سرفصل / محتوا'),
                                React.createElement('th',{className:'expect-head'},'مهم‌ترین انتظارات آموزشی'),
                                PERFORMANCE_MONTHS.map(m=>React.createElement('th',{
                                    key:m.key,
                                    className:'month-head',
                                    style:{background:'linear-gradient(135deg,#22B8B0,#3FD6C5)',position:'relative',overflow:'visible'}
                                },
                                    React.createElement('button',{
                                        type:'button',
                                        onClick:()=>selectedStudentId && setOpenMonthMenu(openMonthMenu === m.key ? null : m.key),
                                        disabled:!selectedStudentId,
                                        title:`اعمال یک سطح برای همه دروس ${m.label}`,
                                        style:{
                                            border:'none',background:'transparent',color:'#fff',fontWeight:900,
                                            cursor:selectedStudentId?'pointer':'not-allowed',padding:'2px 1px',width:'100%',fontFamily:'inherit',fontSize:10
                                        }
                                    }, m.label),
                                    openMonthMenu === m.key && selectedStudentId && React.createElement('div',{
                                        style:{
                                            position:'absolute',top:'100%',right:0,zIndex:1000,background:'#fff',
                                            border:'2px solid #9FF0E4',borderRadius:10,padding:5,minWidth:145,
                                            boxShadow:'0 8px 20px rgba(20,48,52,.18)',color:'#222'
                                        },
                                        onClick:e=>e.stopPropagation()
                                    },
                                        React.createElement('div',{style:{fontSize:10,fontWeight:900,color:'#1AA6A0',padding:'4px 6px',borderBottom:'1px solid #eee',marginBottom:3}},`اعمال برای همه دروس ${m.label}`),
                                        GRADE_OPTIONS.map(g=>React.createElement('button',{
                                            key:g.value,type:'button',
                                            onClick:()=>applyLevelToMonth(selectedStudentId,m.key,g.value),
                                            style:{
                                                display:'block',width:'100%',border:'none',borderRadius:7,background:'#fff',
                                                padding:'7px 8px',textAlign:'right',fontFamily:'inherit',fontSize:10,fontWeight:800,
                                                cursor:'pointer',margin:'2px 0'
                                            }
                                        },g.label))
                                    )
                                )),
                                React.createElement('th',{className:'month-head',style:{background:'#FF6B81'}},'حذف')
                            )
                        ),
                        React.createElement('tbody',null,
                            rows.map((row,index)=>{
                                const firstLesson = rowSpans.get(row.id) > 0;
                                const firstContent = contentSpans.get(row.id) > 0;
                                const previous = rows[index-1];
                                const sectionStart = index === 0 || (previous && previous.lesson !== row.lesson);
                                return React.createElement('tr',{key:row.id,className:sectionStart?'section-start':''},
                                    firstLesson && React.createElement('td',{rowSpan:rowSpans.get(row.id),className:'lesson-cell'},
                                        React.createElement('div',{
                                            contentEditable:true,
                                            suppressContentEditableWarning:true,
                                            className:'editable-row-text',
                                            onInput:e=>updateRowTextLocal(row.id,'lesson',e.currentTarget.innerText),
                                            onBlur:commitRowText,
                                            ref:el=>{
                                                const txt = getRowText(row.id,'lesson',row.lesson);
                                                if (el && el.innerText !== txt) el.innerText = txt;
                                            }
                                        })
                                    ),
                                    firstContent && React.createElement('td',{rowSpan:contentSpans.get(row.id),className:'content-cell'},
                                        React.createElement('div',{
                                            contentEditable:true,
                                            suppressContentEditableWarning:true,
                                            className:'editable-row-text',
                                            onInput:e=>updateRowTextLocal(row.id,'content',e.currentTarget.innerText),
                                            onBlur:commitRowText,
                                            ref:el=>{
                                                const txt = getRowText(row.id,'content',row.content);
                                                if (el && el.innerText !== txt) el.innerText = txt;
                                            }
                                        })
                                    ),
                                    React.createElement('td',{className:'expect-cell'},
                                        React.createElement('div',{
                                            contentEditable:true,
                                            suppressContentEditableWarning:true,
                                            className:'editable-row-text editable-row-text-right',
                                            onInput:e=>updateRowTextLocal(row.id,'expect',e.currentTarget.innerText),
                                            onBlur:commitRowText,
                                            ref:el=>{
                                                const txt = getRowText(row.id,'expect',row.expect);
                                                if (el && el.innerText !== txt) el.innerText = txt;
                                            }
                                        })
                                    ),
                                    PERFORMANCE_MONTHS.map(month=>{
                                        const value = selectedStudentId ? getLevel(selectedStudentId,row.id,month.key) : '';
                                        return React.createElement('td',{key:month.key,className:'performance-cell'},
                                            React.createElement('select',{
                                                value,
                                                disabled:!selectedStudentId,
                                                className:levelClass(value),
                                                title:`سطح عملکرد — ${month.label} — ${getRowText(row.id,'expect',row.expect)}`,
                                                onChange:e=>selectedStudentId && setLevel(selectedStudentId,row.id,month.key,e.target.value)
                                            },
                                                React.createElement('option',{value:''},'—'),
                                                GRADE_OPTIONS.map(g=>React.createElement('option',{key:g.value,value:g.value},g.label))
                                            )
                                        );
                                    })
                                    ,
                                    React.createElement('td',{className:'performance-cell',style:{textAlign:'center'}},
                                        React.createElement('button',{
                                            onClick:()=>deleteRow(row),
                                            title:'حذف این سطر',
                                            style:{
                                                border:'none',
                                                background:'transparent',
                                                color:'#FF6B81',
                                                fontSize:15,
                                                cursor:'pointer',
                                                padding:'4px 6px'
                                            }
                                        }, '🗑')
                                    )
                                );
                            })
                        )
                    )
                ),
                React.createElement('div',{className:'performance-hint'},
                    'اول از نوار بالا دانش‌آموز مورد نظر را انتخاب کنید، سپس برای هر درس در هر ماه سطح عملکرد را ثبت کنید. تغییرات بلافاصله ذخیره می‌شوند. برای دیدن همه ستون‌ها در موبایل، جدول را افقی جابه‌جا کنید.'
                )
            );
        }


        // ============================================================
        // تکالیف و موارد تحویلی - ذخیره خودکار و تاریخ‌های شمسی
        // ============================================================
        function HomeworkTasks({ data, save, showToast }) {
            const h = React.createElement;
            const nm = st => st.name || [st.firstName, st.lastName].filter(Boolean).join(' ');
            const students = [...(data.students || [])].sort((a,b) => (a.lastName || a.name || '').localeCompare((b.lastName || b.name || ''), 'fa'));
            const tasks = Array.isArray(data.tasks) ? data.tasks : [];
            const fa = toPersianDigits;

            const statusMeta = {
                done:       {label:'تحویل داده',  short:'تحویل', icon:'✓', color:'#16845b', bg:'#dcfce7'},
                incomplete: {label:'ناقص',        short:'ناقص',  icon:'½', color:'#a16207', bg:'#fef3c7'},
                missing:    {label:'عدم تحویل', short:'عدم تحویل', icon:'✕', color:'#be123c', bg:'#ffe4e6'},
                pending:    {label:'بررسی نشده',  short:'بررسی نشده', icon:'○', color:'#64748b', bg:'#f1f5f9'}
            };
            const btnOrder = ['done','incomplete','missing'];
            const typeMeta = {
                worksheet:{n:'کاربرگ',i:'📝'}, exercise:{n:'تمرین کتاب',i:'📖'}, homework:{n:'تکلیف',i:'🏠'},
                research:{n:'تحقیق',i:'🔎'}, other:{n:'سایر',i:'📌'}
            };

            // ---- helpers
            const isoParts = iso => { const p = String(iso||'').slice(0,10).split('-').map(Number); return p.length===3 && !p.some(isNaN) ? p : null; };
            const dayNum = iso => { const p = isoParts(iso); return p ? Math.round(Date.UTC(p[0],p[1]-1,p[2])/86400000) : null; };
            const addDays = (iso, n) => { const d = new Date((dayNum(iso)+n)*86400000); return d.toISOString().slice(0,10); };
            const lastType = (() => { try { return localStorage.getItem('hw_last_type') || 'worksheet'; } catch(e) { return 'worksheet'; } })();

            // ---- state
            const [title, setTitle] = React.useState('');
            const [type, setType] = React.useState(lastType);
            const [assignedDate, setAssignedDate] = React.useState(todayISO());
            const [dueMode, setDueMode] = React.useState('d1');   // none | d1 | d3 | d7 | custom
            const [customDue, setCustomDue] = React.useState(todayISO());
            const [description, setDescription] = React.useState('');
            const [showMore, setShowMore] = React.useState(false);
            const [editingId, setEditingId] = React.useState(null);
            const [view, setView] = React.useState({});       // open/closed overrides for months & tasks
            const [rowFilter, setRowFilter] = React.useState('all'); // all | pending | problem
            const [menuId, setMenuId] = React.useState(null);
            const [histStudent, setHistStudent] = React.useState('all');
            const [undo, setUndo] = React.useState(null);
            const [savedFlash, setSavedFlash] = React.useState(false);
            const timers = React.useRef({});
            const titleRef = React.useRef(null);

            const flash = () => {
                setSavedFlash(true);
                clearTimeout(timers.current.f);
                timers.current.f = setTimeout(() => setSavedFlash(false), 1400);
            };
            const persist = (nextTasks, message) => {
                const ok = save({...data, tasks:nextTasks});
                if (ok === false) { showToast('ذخیره انجام نشد؛ فضای ذخیره‌سازی را بررسی کنید','error'); return false; }
                if (message) showToast('✓ '+message); else flash();
                return true;
            };
            const persistWithUndo = (nextTasks, label) => {
                const prev = tasks;
                if (!persist(nextTasks)) return;
                clearTimeout(timers.current.u);
                setUndo({label, prev});
                timers.current.u = setTimeout(() => setUndo(null), 7000);
            };
            const doUndo = () => {
                if (!undo) return;
                persist(undo.prev, 'برگردانده شد');
                clearTimeout(timers.current.u);
                setUndo(null);
            };

            const dueISO = () => dueMode==='none' ? '' : dueMode==='custom' ? customDue : addDays(assignedDate||todayISO(), dueMode==='d1'?1:dueMode==='d3'?3:7);
            const resetForm = () => { setTitle(''); setDescription(''); setEditingId(null); setAssignedDate(todayISO()); setDueMode('d1'); setShowMore(false); };

            const createTask = () => {
                if (!title.trim()) { showToast('عنوان مورد تحویلی را وارد کنید','error'); if (titleRef.current) titleRef.current.focus(); return; }
                if (!students.length) { showToast('ابتدا دانش‌آموزان را اضافه کنید','error'); return; }
                const old = editingId ? tasks.find(t=>t.id===editingId) : null;
                const task = {
                    ...(old||{}),
                    id: editingId || uid(), title: title.trim(), type,
                    assignedDate: assignedDate || todayISO(), dueDate: dueISO(),
                    description: description.trim(),
                    statuses: (old && old.statuses) || {}
                };
                const next = editingId ? tasks.map(t=>t.id===editingId?task:t) : [task,...tasks];
                try { localStorage.setItem('hw_last_type', type); } catch(e) {}
                if (persist(next, editingId?'تغییرات ذخیره شد':'مورد تحویلی ایجاد شد')) {
                    setView(v => ({...v, [task.id]:true}));
                    resetForm();
                    if (!editingId && titleRef.current) titleRef.current.focus();
                }
            };
            const editTask = task => {
                setEditingId(task.id); setTitle(task.title||''); setType(task.type||'other');
                setAssignedDate(task.assignedDate||todayISO()); setDescription(task.description||'');
                if (task.dueDate) { setDueMode('custom'); setCustomDue(task.dueDate); } else setDueMode('none');
                setShowMore(true); setMenuId(null);
                window.scrollTo({top:0,behavior:'smooth'});
            };
            const duplicateTask = task => {
                const copy = {id:uid(), title:task.title, type:task.type, assignedDate:todayISO(), dueDate:task.dueDate ? addDays(todayISO(), Math.max(1,(dayNum(task.dueDate)-dayNum(task.assignedDate||todayISO()))||1)) : '', description:task.description||'', statuses:{}};
                persist([copy,...tasks], 'کپی ایجاد شد');
                setView(v => ({...v, [copy.id]:true})); setMenuId(null);
            };
            const removeTask = task => {
                setMenuId(null);
                persistWithUndo(tasks.filter(t=>t.id!==task.id), 'مورد تحویلی حذف شد');
                if (editingId===task.id) resetForm();
            };
            const updateStatus = (task, studentId, status) => {
                const cur = (task.statuses||{})[studentId] || 'pending';
                const nextStatus = cur===status ? 'pending' : status;   // لمس دوباره = برگشت به «بررسی نشده»
                persist(tasks.map(t => t.id===task.id ? {
                    ...t,
                    statuses:{...(t.statuses||{}),[studentId]:nextStatus},
                    statusDates:{...(t.statusDates||{}),[studentId]:todayISO()}
                } : t));
            };
            const bulk = (task, status, onlyPending) => {
                const statuses = {...(task.statuses||{})}, statusDates = {...(task.statusDates||{})};
                students.forEach(st => {
                    if (onlyPending && (statuses[st.id]||'pending') !== 'pending') return;
                    statuses[st.id] = status; statusDates[st.id] = todayISO();
                });
                persistWithUndo(tasks.map(t=>t.id===task.id?{...t,statuses,statusDates}:t),
                    onlyPending ? 'بقیه «تحویل داده» ثبت شدند' : 'وضعیت همه ثبت شد');
            };
            const counts = task => students.reduce((acc,st)=>{const k=(task.statuses||{})[st.id]||'pending';acc[k]=(acc[k]||0)+1;return acc;},{pending:0,done:0,incomplete:0,missing:0});

            const dueInfo = (task, c) => {
                if (!task.dueDate) return null;
                const diff = dayNum(task.dueDate) - dayNum(todayISO());
                const unfinished = c.pending + c.incomplete > 0;
                if (diff < 0 && unfinished) return {t:'گذشته از مهلت ('+fa(-diff)+' روز)', cls:'hw-late'};
                if (diff === 0) return {t:'مهلت: امروز', cls:'hw-soon'};
                if (diff === 1) return {t:'مهلت: فردا', cls:'hw-soon'};
                return {t:'مهلت: '+toShamsi(task.dueDate), cls:''};
            };

            const css = `
            .hw-wrap{--g:#16845b;--y:#a16207;--r:#be123c;--m:#64748b;--line:#dcece8;--brand:#176b73}
            .hw-wrap *{box-sizing:border-box}
            .hw-card{background:#fff;border:1px solid var(--line);border-radius:18px;padding:16px;margin-bottom:14px}
            .hw-head{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px}
            .hw-head h3{margin:0;font-size:17px}
            .hw-saved{font-size:12px;font-weight:700;color:var(--g);opacity:0;transition:opacity .25s}
            .hw-saved.on{opacity:1}
            .hw-input{width:100%;padding:12px 14px;border:1.5px solid #cfe3df;border-radius:12px;background:#fff;font:inherit;font-size:15px}
            .hw-input:focus{outline:0;border-color:var(--brand);box-shadow:0 0 0 3px rgba(23,107,115,.15)}
            .hw-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
            .hw-lbl{font-size:13px;color:#334155;font-weight:800;margin-bottom:8px}
            .hw-lbl-date{color:var(--brand);font-weight:700}
            .hw-grp{margin-top:16px}
            .hw-chips{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:520px}
            .hw-chips .hw-chip{width:100%;text-align:center;padding:10px 4px;border-radius:12px;font-size:13px}
            .hw-chip{border:1.5px solid #d6e6e2;background:#f8fcfb;color:#2b5a5f;border-radius:999px;padding:7px 13px;font:inherit;font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap}
            .hw-chip.on{background:var(--brand);border-color:var(--brand);color:#fff}
            .hw-primary{background:var(--brand);color:#fff;border:0;border-radius:12px;padding:12px 22px;font:inherit;font-weight:800;font-size:15px;cursor:pointer}
            .hw-ghost{background:transparent;border:1px solid #d6e6e2;color:#2b5a5f;border-radius:10px;padding:8px 12px;font:inherit;font-size:13px;font-weight:700;cursor:pointer}
            .hw-link{background:none!important;box-shadow:none!important;border:0!important;color:var(--brand);font:inherit;font-size:13px;font-weight:700;cursor:pointer;padding:6px 0!important}
            .hw-month{border:1px solid var(--line);border-radius:16px;overflow:hidden;margin-top:12px}
            .hw-month>button{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 16px;border:0;cursor:pointer;background:#f3faf8;color:var(--brand);font:inherit;font-weight:800;font-size:15px;text-align:right}
            .hw-month.open>button{background:#e4f4ef}
            .hw-badge{font-size:12px;background:#d8eee8;padding:4px 10px;border-radius:999px;font-weight:700;white-space:nowrap}
            .hw-task{background:#fff;border:1px solid #e3eeeb;border-radius:14px;margin:10px 10px 0;padding:14px;position:relative}
            .hw-task:last-child{margin-bottom:10px}
            .hw-task.open{border-color:#a9d3cb;box-shadow:0 4px 14px rgba(23,107,115,.08)}
            .hw-top{display:flex;gap:10px;align-items:flex-start;justify-content:space-between}
            .hw-main{flex:1;min-width:0;cursor:pointer}
            .hw-title{font-weight:800;font-size:16px;line-height:1.5}
            .hw-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;align-items:center}
            .hw-tag{font-size:11.5px;background:#f1f5f9;color:#475569;border-radius:8px;padding:3px 8px;font-weight:700}
            .hw-late{background:#ffe4e6;color:var(--r)}
            .hw-soon{background:#fef3c7;color:var(--y)}
            .hw-desc{font-size:13px;margin-top:6px;color:#334155}
            .hw-dots{border:0;background:#f1f5f9;border-radius:10px;width:36px;height:36px;font-size:20px;cursor:pointer;line-height:1}
            .hw-menu{position:absolute;left:12px;top:52px;z-index:5;background:#fff;border:1px solid var(--line);border-radius:12px;box-shadow:0 10px 28px rgba(0,0,0,.14);overflow:hidden;min-width:150px}
            .hw-menu button{display:block;width:100%;text-align:right;padding:11px 14px;border:0;background:#fff;font:inherit;font-size:14px;cursor:pointer}
            .hw-menu button:hover{background:#f3faf8}
            .hw-bar{display:flex;height:10px;border-radius:99px;overflow:hidden;background:#e8eef0;margin-top:12px}
            .hw-bar span{display:block;transition:width .3s}
            .hw-legend{display:flex;gap:12px;flex-wrap:wrap;margin-top:8px;font-size:12px;font-weight:700}
            .hw-legend i{font-style:normal;display:inline-flex;align-items:center;gap:4px}
            .hw-legend i:before{content:"";width:9px;height:9px;border-radius:50%;background:currentColor}
            .hw-tools{display:flex;flex-direction:column;gap:8px;margin:14px 0 12px;padding-top:12px;border-top:1px dashed #d6e6e2}
            .hw-bulk{width:100%;padding:12px;border-radius:12px;border:1.5px solid #bfe8d1;background:#dcfce7;color:#16845b;font:inherit;font-size:14px;font-weight:800;cursor:pointer}
            .hw-bulk:disabled{opacity:.5;cursor:default}
            .hw-two{display:grid;grid-template-columns:1fr 1fr;gap:8px}
            .hw-two .hw-ghost{padding:10px 6px;text-align:center}
            .hw-tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:3px;background:#eaf2f0;border-radius:12px;padding:3px}
            .hw-tab{border:0;background:transparent;border-radius:9px;padding:9px 4px;font:inherit;font-size:12.5px;font-weight:700;color:#4b6b6f;cursor:pointer}
            .hw-tab.on{background:#fff;color:var(--brand);box-shadow:0 1px 4px rgba(0,0,0,.12)}
            .hw-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px}
            .hw-stu{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:10px;border-radius:12px;border:1.5px solid #e6efed;background:#fbfdfc}
            .hw-stu.s-done{background:#f0fbf5;border-color:#bfe8d1}
            .hw-stu.s-incomplete{background:#fffbeb;border-color:#f6dfa0}
            .hw-stu.s-missing{background:#fff1f2;border-color:#fbc6cd}
            .hw-name{font-weight:800;font-size:14.5px;line-height:1.5;flex:1 1 100%;min-width:0}
            .hw-seg{display:flex;gap:6px;flex:1 1 100%}
            .hw-seg button{flex:1;height:42px;border-radius:10px;border:1.5px solid #d3e1de;background:#fff;font-size:13.5px;font-weight:800;cursor:pointer;font-family:inherit;padding:0 4px;white-space:nowrap}
            .hw-seg button:active{transform:scale(.96)}
            .hw-seg button.on{color:#fff!important;border-color:transparent}
            .hw-undo{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:9999;background:#1e293b;color:#fff;border-radius:14px;padding:11px 14px 11px 12px;display:flex;gap:14px;align-items:center;box-shadow:0 10px 30px rgba(0,0,0,.3);font-size:14px;max-width:92vw}
            .hw-undo button{background:#fff;color:#1e293b;border:0;border-radius:9px;padding:6px 12px;font:inherit;font-weight:800;cursor:pointer}
            .hw-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:8px;margin:14px 0}
            .hw-sum div{border-radius:12px;padding:10px;text-align:center;font-size:12px;font-weight:700}
            .hw-sum b{display:block;font-size:20px;margin-bottom:2px}
            .hw-hist{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:10px 12px;border-radius:12px;margin-top:8px;border:1px solid #e6efed}
            .hw-empty{border:1px dashed #cfe3df;border-radius:14px;background:#f8fcfb;padding:20px;text-align:center;color:#64748b;margin-top:12px;font-size:14px}
            @media (max-width:520px){.hw-grid{grid-template-columns:1fr}.hw-card{padding:13px}.hw-primary{width:100%}}
            `;

            // ---- compose form
            const dueChips = [['none','بدون مهلت'],['d1','فردا'],['d3','۳ روز بعد'],['d7','هفته بعد'],['custom','تاریخ دلخواه']];
            const form = h('div',{className:'hw-card'},
                h('div',{className:'hw-head'},
                    h('h3',null,editingId?'✏️ ویرایش مورد تحویلی':'➕ تکلیف جدید'),
                    h('span',{className:'hw-saved'+(savedFlash?' on':'')},'✓ ذخیره شد')
                ),
                h('input',{ref:titleRef,className:'hw-input',value:title,placeholder:'عنوان تکلیف (Enter = ثبت)',
                    onChange:e=>setTitle(e.target.value),onKeyDown:e=>{if(e.key==='Enter'&&!e.nativeEvent.isComposing)createTask();}}),
                h('div',{className:'hw-grp'},
                    h('div',{className:'hw-lbl'},'نوع تکلیف'),
                    h('div',{className:'hw-chips'},Object.entries(typeMeta).map(([k,m])=>h('button',{key:k,type:'button',className:'hw-chip'+(type===k?' on':''),onClick:()=>setType(k)},m.i+' '+m.n)))
                ),
                h('div',{className:'hw-grp'},
                    h('div',{className:'hw-lbl'},'مهلت تحویل',(dueMode!=='none'&&dueMode!=='custom')&&h('span',{className:'hw-lbl-date'},' — '+toShamsi(dueISO()))),
                    h('div',{className:'hw-chips'},dueChips.map(([k,l])=>h('button',{key:k,type:'button',className:'hw-chip'+(dueMode===k?' on':''),onClick:()=>setDueMode(k)},l))),
                    dueMode==='custom' && h('div',{style:{marginTop:10}},h(JalaliDatePicker,{value:customDue,onChange:setCustomDue}))
                ),
                h('div',{style:{marginTop:8}},h('button',{type:'button',className:'hw-link',onClick:()=>setShowMore(v=>!v)},(showMore?'▾ ':'▸ ')+'توضیحات و تاریخ تعیین')),
                showMore && h('div',{style:{marginTop:6}},
                    h('textarea',{className:'hw-input',style:{minHeight:68,resize:'vertical'},value:description,onChange:e=>setDescription(e.target.value),placeholder:'صفحه کتاب، شماره تمرین یا توضیحات لازم...'}),
                    h('div',{style:{marginTop:10,maxWidth:320}},h('label',{style:{fontSize:12,color:'#64748b',fontWeight:700}},'تاریخ تعیین'),h(JalaliDatePicker,{value:assignedDate,onChange:setAssignedDate}))
                ),
                h('div',{className:'hw-row',style:{marginTop:14}},
                    h('button',{className:'hw-primary',onClick:createTask},editingId?'ذخیره تغییرات':'+ ثبت تکلیف'),
                    editingId && h('button',{className:'hw-ghost',onClick:resetForm},'انصراف')
                )
            );

            // ---- task card
            const renderTask = (task, defaultOpen) => {
                const c = counts(task), total = students.length || 1;
                const isOpen = view[task.id]!==undefined ? view[task.id] : defaultOpen;
                const due = dueInfo(task, c);
                const rows = students.filter(st => {
                    const s = (task.statuses||{})[st.id]||'pending';
                    return rowFilter==='all' || (rowFilter==='pending' ? s==='pending' : (s==='incomplete'||s==='missing'));
                });
                const tm = typeMeta[task.type] || typeMeta.other;
                const toggle = () => setView(v => ({...v,[task.id]:!isOpen}));
                return h('div',{key:task.id,className:'hw-task'+(isOpen?' open':'')},
                    h('div',{className:'hw-top'},
                        h('div',{className:'hw-main',onClick:toggle},
                            h('div',{className:'hw-title'},(isOpen?'▾ ':'▸ ')+tm.i+' '+(task.title||'بدون عنوان')),
                            h('div',{className:'hw-meta'},
                                h('span',{className:'hw-tag'},tm.n),
                                h('span',{className:'hw-tag'},'تعیین: '+(task.assignedDate?toShamsi(task.assignedDate):'—')),
                                due && h('span',{className:'hw-tag '+due.cls},due.t)
                            ),
                            task.description && h('div',{className:'hw-desc'},task.description)
                        ),
                        h('button',{className:'hw-dots',type:'button','aria-label':'گزینه‌ها',onClick:()=>setMenuId(menuId===task.id?null:task.id)},'⋯')
                    ),
                    menuId===task.id && h('div',{className:'hw-menu'},
                        h('button',{onClick:()=>editTask(task)},'✏️ ویرایش'),
                        h('button',{onClick:()=>duplicateTask(task)},'📄 کپی تکلیف'),
                        h('button',{style:{color:'#be123c'},onClick:()=>removeTask(task)},'🗑 حذف')
                    ),
                    h('div',{className:'hw-bar',title:fa(c.done)+' از '+fa(students.length)},
                        ['done','incomplete','missing'].map(k=>h('span',{key:k,style:{width:(c[k]/total*100)+'%',background:statusMeta[k].color}}))
                    ),
                    h('div',{className:'hw-legend'},
                        h('span',{style:{fontWeight:800,color:'#334155'}},fa(c.done)+' از '+fa(students.length)+' تحویل'),
                        ['incomplete','missing','pending'].map(k=>c[k]>0 && h('i',{key:k,style:{color:statusMeta[k].color}},statusMeta[k].short+' '+fa(c[k])))
                    ),
                    isOpen && h('div',null,
                        h('div',{className:'hw-tools'},
                            h('button',{className:'hw-bulk',disabled:c.pending===0,onClick:()=>bulk(task,'done',true)},'بقیه‌ی بررسی‌نشده‌ها: تحویل'),
                            h('div',{className:'hw-two'},
                                h('button',{className:'hw-ghost',onClick:()=>bulk(task,'done',false)},'همه تحویل'),
                                h('button',{className:'hw-ghost',onClick:()=>bulk(task,'pending',false)},'پاک‌کردن همه')
                            ),
                            h('div',{className:'hw-tabs'},[['all','همه'],['pending','بررسی‌نشده'],['problem','مشکل‌دار']].map(([k,l])=>h('button',{key:k,type:'button',className:'hw-tab'+(rowFilter===k?' on':''),onClick:()=>setRowFilter(k)},l)))
                        ),
                        rows.length===0 ? h('div',{className:'hw-empty'},rowFilter==='pending'?'همه‌ی دانش‌آموزان بررسی شده‌اند 🎉':'موردی با این فیلتر پیدا نشد.') :
                        h('div',{className:'hw-grid'},rows.map(st=>{
                            const s = (task.statuses||{})[st.id]||'pending';
                            return h('div',{key:st.id,className:'hw-stu s-'+s},
                                h('span',{className:'hw-name'},nm(st)),
                                h('div',{className:'hw-seg'},btnOrder.map(k=>h('button',{key:k,type:'button','aria-label':statusMeta[k].label,title:statusMeta[k].label,
                                    className:s===k?'on':'',style:s===k?{background:statusMeta[k].color}:{color:statusMeta[k].color},
                                    onClick:()=>updateStatus(task,st.id,k)},statusMeta[k].short)))
                            );
                        }))
                    )
                );
            };

            // ---- grouped list
            const monthNames = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
            const groups = {};
            tasks.forEach(task=>{
                let key='unknown', label='بدون تاریخ';
                try { const d=isoToJalali(task.assignedDate || todayISO()); key=String(d.jy)+'-'+String(d.jm).padStart(2,'0'); label=monthNames[d.jm-1]+' '+fa(d.jy); } catch(e) {}
                if(!groups[key]) groups[key]={key,label,tasks:[],sort:key==='unknown'?'0000-00':key};
                groups[key].tasks.push(task);
            });
            const groupList = Object.values(groups).sort((a,b)=>b.sort.localeCompare(a.sort));

            const list = h('div',{className:'hw-card'},
                h('div',{className:'hw-head'},h('h3',null,'📋 فهرست تکالیف'),h('span',{style:{fontSize:13,color:'#64748b'}},fa(tasks.length)+' مورد • '+fa(students.length)+' دانش‌آموز')),
                tasks.length===0 ? h('div',{className:'hw-empty'},'هنوز مورد تحویلی ثبت نشده است. از فرم بالا اولین تکلیف را تعریف کنید.') :
                groupList.map((g,gi)=>{
                    const mk='month:'+g.key;
                    const open = view[mk]!==undefined ? view[mk] : gi===0;
                    let done=0, all=0;
                    g.tasks.forEach(t=>{const c=counts(t); done+=c.done; all+=students.length;});
                    const pct = all ? Math.round(done/all*100) : 0;
                    return h('div',{key:g.key,className:'hw-month'+(open?' open':'')},
                        h('button',{type:'button',onClick:()=>setView(v=>({...v,[mk]:!open}))},
                            h('span',null,(open?'▾ ':'▸ ')+'📅 '+g.label),
                            h('span',{className:'hw-badge'},fa(g.tasks.length)+' مورد • '+fa(pct)+'٪ تحویل')
                        ),
                        open && g.tasks.map((t,ti)=>renderTask(t, gi===0 && ti===0))
                    );
                })
            );

            // ---- student history
            const histTasks = histStudent==='all' ? [] : tasks;
            const hc = {done:0,incomplete:0,missing:0,pending:0};
            histTasks.forEach(t=>{hc[(t.statuses||{})[histStudent]||'pending']++;});
            const checked = hc.done+hc.incomplete+hc.missing;
            const histPct = checked ? Math.round(hc.done/checked*100) : 0;
            const hist = h('div',{className:'hw-card'},
                h('div',{className:'hw-head'},h('h3',null,'👤 سابقه‌ی هر دانش‌آموز')),
                h('select',{className:'hw-input',style:{maxWidth:360},value:histStudent,onChange:e=>setHistStudent(e.target.value)},
                    h('option',{value:'all'},'انتخاب دانش‌آموز...'),
                    students.map(st=>h('option',{key:st.id,value:st.id},nm(st)))
                ),
                histStudent==='all' ? h('div',{className:'hw-empty'},'یک دانش‌آموز را انتخاب کنید.') :
                tasks.length===0 ? h('div',{className:'hw-empty'},'هنوز سابقه‌ای ثبت نشده است.') :
                h('div',null,
                    h('div',{className:'hw-sum'},
                        h('div',{style:{background:'#eef6f7',color:'#176b73'}},h('b',null,fa(histPct)+'٪'),'درصد تحویل'),
                        ['done','incomplete','missing','pending'].map(k=>h('div',{key:k,style:{background:statusMeta[k].bg,color:statusMeta[k].color}},h('b',null,fa(hc[k])),statusMeta[k].label))
                    ),
                    [...tasks].sort((a,b)=>{
                        const w = t => {const s=(t.statuses||{})[histStudent]||'pending'; return s==='missing'?0:s==='incomplete'?1:s==='pending'?2:3;};
                        return w(a)-w(b);
                    }).map(task=>{
                        const s=(task.statuses||{})[histStudent]||'pending', m=statusMeta[s];
                        const sd=(task.statusDates||{})[histStudent]||'';
                        const tm=typeMeta[task.type]||typeMeta.other;
                        return h('div',{key:task.id,className:'hw-hist',style:{background:s==='done'||s==='pending'?'#fff':m.bg}},
                            h('div',{style:{flex:'1 1 180px',minWidth:0}},
                                h('div',{style:{fontWeight:700}},tm.i+' '+(task.title||'بدون عنوان')),
                                h('div',{style:{fontSize:12,color:'#64748b',marginTop:3}},'تعیین: '+(task.assignedDate?toShamsi(task.assignedDate):'—')+(sd?' • ثبت وضعیت: '+toShamsi(sd):''))
                            ),
                            h('span',{style:{background:m.bg,color:m.color,padding:'5px 11px',borderRadius:9,fontSize:12,fontWeight:800,whiteSpace:'nowrap'}},m.label)
                        );
                    })
                )
            );

            return h('div',{className:'hw-wrap',onClick:e=>{ if(menuId && !e.target.closest('.hw-menu,.hw-dots')) setMenuId(null); }},
                h('style',null,css),
                form, list, hist,
                undo && h('div',{className:'hw-undo'},h('span',null,undo.label),h('button',{onClick:doUndo},'↩ واگرد'))
            );
        }

        // Teacher App
        // ============================================================

        function AttendanceNative({ data, save, showToast }) {
            const [date, setDate] = React.useState(todayISO());
            const [calendarOpen, setCalendarOpen] = React.useState(false);
            const [dq, setDq] = React.useState('');
            const [srch, setSrch] = React.useState(() => { const j = isoToJalali(todayISO()); return { student: 'all', status: 'all', reason: '', from: jalaliToIso(j.jy, j.jm, 1), to: todayISO() }; });
            const students = data.students || [];
            const att = data.attendance || {};
            const days = data.attendanceDays || {};
            const cfg = data.attendanceSettings || {};
            const thr = Math.max(1, +cfg.thr || 3);
            const STATUS_FA = { present: 'حاضر', absent: 'غایب', late: 'تأخیر', none: 'ثبت نشده' };
            const REASONS = ['بیماری', 'مسافرت', 'مشکل خانوادگی', 'ترافیک'];
            const nameOf = s => s.name || [s.firstName, s.lastName].filter(Boolean).join(' ') || 'بدون نام';
            const normN = t => String(t).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ').trim();
            // استفاده از توابع مشترک گزارش/داشبورد برای جلوگیری از دوگانگی محاسبات
            const jKey = attKey;
            const isHol = d => attHol(days, d);
            const hol = isHol(date);
            const meta = days[date] || {};
            const isFinal = !!meta.final;
            const recOf = sid => (att[sid] || []).find(r => r.date === date);
            const statusOf = sid => (recOf(sid) || {}).status || 'none';
            const getStatusForStudent = statusOf;
            const getReason = sid => (recOf(sid) || {}).reason || '';
            const setDay = patch => {
                save(prev => {
                    const prevDays = prev.attendanceDays || {};
                    const nextMeta = { ...(prevDays[date] || {}), ...patch };
                    if (nextMeta.holiday === true) delete nextMeta.final;
                    return { ...prev, attendanceDays: { ...prevDays, [date]: nextMeta } };
                });
            };
            // هر تغییر فقط رکورد همین دانش‌آموز در همین تاریخ را عوض می‌کند
            const setField = (sid, patch) => {
                if (isFinal) { showToast('این روز نهایی شده است. ابتدا «بازکردن برای ویرایش» را بزنید.', 'error'); return; }
                save(prev => {
                    const prevAtt = prev.attendance || {};
                    const cur = (prevAtt[sid] || []).find(r => r.date === date);
                    const next = { ...(cur || { id: uid(), date }), ...patch };
                    if (next.status !== 'absent' && next.status !== 'late') delete next.reason;
                    if (next.status !== 'late') delete next.minutes;
                    const list = (prevAtt[sid] || []).filter(r => r.date !== date);
                    return { ...prev, attendance: { ...prevAtt, [sid]: next.status === 'none' ? list : [...list, next] } };
                });
            };
            const shownAll = students.filter(s => s.active !== false || (s.archivedAt && date < s.archivedAt) || recOf(s.id));
            const shown = (hol ? [] : shownAll)
                .filter(s => !dq || normN(nameOf(s)).includes(normN(dq)))
                .sort((a, b) => cfg.sortAZ ? nameOf(a).localeCompare(nameOf(b), 'fa') : 0);
            const cnt = { present: 0, absent: 0, late: 0, none: 0 };
            shown.forEach(s => cnt[statusOf(s.id)]++);
            const finalize = () => {
                if (hol) return;
                if (isFinal) {
                    save(prev => {
                        const prevDays = prev.attendanceDays || {};
                        const m = { ...(prevDays[date] || {}) };
                        delete m.final;
                        return { ...prev, attendanceDays: { ...prevDays, [date]: m } };
                    });
                    return;
                }
                const pending = shownAll.filter(s => statusOf(s.id) === 'none');
                if (pending.length && !confirm(toPersianDigits(pending.length) + ' نفر هنوز ثبت نشده‌اند. همه حاضر ثبت شوند و روز نهایی شود؟')) return;
                save(prev => {
                    const prevAtt = prev.attendance || {};
                    const prevDays = prev.attendanceDays || {};
                    const a = { ...prevAtt };
                    pending.forEach(s => { a[s.id] = [...(prevAtt[s.id] || []), { id: uid(), date, status: 'present' }]; });
                    return { ...prev, attendance: a, attendanceDays: { ...prevDays, [date]: { ...(prevDays[date] || {}), final: true } } };
                });
            };
            const allPresent = () => {
                if (hol) return;
                if (isFinal) { showToast('این روز نهایی شده است. ابتدا «بازکردن برای ویرایش» را بزنید.', 'error'); return; }
                if (shownAll.some(s => statusOf(s.id) === 'absent' || statusOf(s.id) === 'late') && !confirm('بعضی دانش‌آموزان غایب یا متأخر ثبت شده‌اند. همه حاضر ثبت شوند؟')) return;
                save(prev => {
                    const prevAtt = prev.attendance || {};
                    const a = { ...prevAtt };
                    shownAll.forEach(s => { a[s.id] = [...(prevAtt[s.id] || []).filter(r => r.date !== date), { id: uid(), date, status: 'present' }]; });
                    return { ...prev, attendance: a };
                });
            };
            // بایگانی و بازگردانی فقط فیلد وضعیت دانش‌آموز را عوض می‌کند؛ سابقه حفظ می‌شود
            const archive = s => { if (!confirm('«' + nameOf(s) + '» از لیست روزانه کنار گذاشته شود؟ سابقه‌اش حفظ می‌شود.')) return; save({ ...data, students: students.map(x => x.id === s.id ? { ...x, active: false, archivedAt: date } : x) }); };
            const restore = s => save({ ...data, students: students.map(x => x.id === s.id ? { ...x, active: true, archivedAt: undefined } : x) });
            const shift = n => { const x = new Date(date + 'T12:00:00'); x.setDate(x.getDate() + n); setDate(x.toISOString().slice(0, 10)); };
            const finalDays = Object.keys(days).filter(d => days[d] && days[d].final && !isHol(d)).sort();
            const curMonth = jKey(date);
            const lvl = n => n >= thr + 4 ? 3 : n >= thr + 2 ? 2 : n >= thr ? 1 : 0;
            const DOT = ['', '🟡', '🟠', '🔴'];
            const cal = isoToJalali(date);
            const calDays = jalaliDaysInMonth(cal.jy, cal.jm);
            const calOffset = (new Date(jalaliToIso(cal.jy, cal.jm, 1) + 'T12:00:00').getDay() + 1) % 7;
            const calCells = Array.from({ length: calOffset + calDays }, (_, i) => i < calOffset ? null : i - calOffset + 1);
            const shiftMonth = delta => {
                let y = cal.jy, m = cal.jm + delta;
                while (m < 1) { m += 12; y--; }
                while (m > 12) { m -= 12; y++; }
                setDate(jalaliToIso(y, m, 1));
            };

            // خروجی تصویری (PNG) از لیست حضور همان روز، بدون نیاز به کتابخانه خارجی
            const exportAttendanceImage = () => {
                const W = 720, rowH = 40, headH = 100;
                const c = document.createElement('canvas');
                c.width = W; c.height = headH + shown.length * rowH + 40;
                const ctx = c.getContext('2d');
                ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height);
                ctx.fillStyle = '#254447'; ctx.textAlign = 'center';
                ctx.font = 'bold 24px Tahoma, Arial, sans-serif';
                ctx.fillText('لیست حضور و غیاب', W / 2, 40);
                ctx.font = '16px Tahoma, Arial, sans-serif';
                ctx.fillText(getShamsiWithDay(date), W / 2, 72);
                const colors = { present: '#1f9d6b', absent: '#c2473f', late: '#b7791f', none: '#767267' };
                shown.forEach((s, i) => {
                    const y = headH + i * rowH, st = getStatusForStudent(s.id);
                    ctx.fillStyle = i % 2 ? '#f5f8f7' : '#ffffff';
                    ctx.fillRect(16, y, W - 32, rowH);
                    ctx.textAlign = 'right'; ctx.fillStyle = '#254447'; ctx.font = '17px Tahoma, Arial, sans-serif';
                    ctx.fillText(nameOf(s), W - 30, y + 26);
                    const reason = (st === 'absent' || st === 'late') ? getReason(s.id) : '';
                    ctx.textAlign = 'left'; ctx.fillStyle = colors[st] || colors.none; ctx.font = 'bold 16px Tahoma, Arial, sans-serif';
                    ctx.fillText(reason ? `${STATUS_FA[st] || STATUS_FA.none} (${reason})` : (STATUS_FA[st] || STATUS_FA.none), 30, y + 26);
                });
                c.toBlob(blob => {
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url; a.download = `حضور-${date}.png`;
                    document.body.appendChild(a); a.click(); a.remove();
                    setTimeout(() => URL.revokeObjectURL(url), 2000);
                }, 'image/png');
            };

            // جستجوی سابقه حضور با فیلتر دانش‌آموز، وضعیت، دلیل و بازه تاریخ
            const srchRows = (() => {
                const out = [];
                students.forEach(s => {
                    if (srch.student !== 'all' && String(s.id) !== String(srch.student)) return;
                    (data.attendance[s.id] || []).forEach(r => {
                        if (srch.status !== 'all' && r.status !== srch.status) return;
                        if (srch.from && r.date < srch.from) return;
                        if (srch.to && r.date > srch.to) return;
                        if (srch.reason && !(r.reason || '').includes(srch.reason.trim())) return;
                        out.push({ name: nameOf(s), date: r.date, status: r.status, reason: r.reason || '' });
                    });
                });
                return out.sort((a, b) => b.date.localeCompare(a.date) || a.name.localeCompare(b.name));
            })();

            const exportSearchCsv = () => {
                const esc = v => `"${String(v).replace(/"/g, '""')}"`;
                const lines = [['نام دانش‌آموز', 'تاریخ', 'وضعیت', 'دلیل'].map(esc).join(',')]
                    .concat(srchRows.map(r => [r.name, toShamsi(r.date), STATUS_FA[r.status] || r.status, r.reason].map(esc).join(',')));
                const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url; a.download = `سابقه-حضور-${todayISO()}.csv`;
                document.body.appendChild(a); a.click(); a.remove();
                setTimeout(() => URL.revokeObjectURL(url), 2000);
            };

            const selStyle = { width: '100%', padding: '8px', borderRadius: 8, marginBottom: 8, fontSize: 14, boxSizing: 'border-box' };
            const searchCard = React.createElement('div', { className: 'card' },
                React.createElement('h4', { className: 'mb-8' }, '🔎 جستجوی سابقه حضور و غیاب'),
                React.createElement('select', { value: srch.student, onChange: e => setSrch({ ...srch, student: e.target.value }), style: selStyle },
                    React.createElement('option', { value: 'all' }, 'همه دانش‌آموزان'),
                    students.map(s => React.createElement('option', { key: s.id, value: s.id }, nameOf(s)))
                ),
                React.createElement('select', { value: srch.status, onChange: e => setSrch({ ...srch, status: e.target.value }), style: selStyle },
                    React.createElement('option', { value: 'all' }, 'همه وضعیت‌ها'),
                    React.createElement('option', { value: 'present' }, 'حاضر'),
                    React.createElement('option', { value: 'absent' }, 'غایب'),
                    React.createElement('option', { value: 'late' }, 'تأخیر')
                ),
                React.createElement('input', { type: 'text', placeholder: 'جستجو در دلیل (مثلاً بیماری)', value: srch.reason, onChange: e => setSrch({ ...srch, reason: e.target.value }), style: selStyle }),
                React.createElement('div', { className: 'text-small mb-8' }, 'از تاریخ'),
                React.createElement(JalaliDatePicker, { value: srch.from, onChange: v => setSrch({ ...srch, from: v }) }),
                React.createElement('div', { className: 'text-small mb-8 mt-8' }, 'تا تاریخ'),
                React.createElement(JalaliDatePicker, { value: srch.to, onChange: v => setSrch({ ...srch, to: v }) }),
                React.createElement('div', { className: 'text-small mt-8 mb-8' }, `${toPersianDigits(srchRows.length)} مورد پیدا شد`),
                React.createElement('div', { style: { maxHeight: 360, overflowY: 'auto' } },
                    srchRows.slice(0, 300).map((r, i) => React.createElement('div', { key: i, style: { display: 'flex', gap: 8, padding: '6px 0', borderBottom: '1px solid #eee', fontSize: 13 } },
                        React.createElement('span', { style: { flex: 1 } }, r.name),
                        React.createElement('span', null, toShamsi(r.date)),
                        React.createElement('b', { style: { color: r.status === 'absent' ? '#FF6B81' : r.status === 'late' ? '#B7791F' : '#1f9d6b' } }, STATUS_FA[r.status] || r.status),
                        r.reason ? React.createElement('span', { className: 'text-muted' }, r.reason) : null
                    ))
                ),
                React.createElement('button', { onClick: exportSearchCsv, className: 'btn-accent', style: { width: '100%', marginTop: 10 } }, '📄 خروجی CSV از نتایج')
            );
            const LABEL = { present: '✅ حاضر', absent: '❌ غایب', late: '⏰ تأخیر' };
            const alerts = students.map(s => {
                let a = 0, l = 0, run = 0;
                finalDays.forEach(d => {
                    const r = (att[s.id] || []).find(x => x.date === d);
                    if (!r) return;
                    run = r.status === 'absent' ? run + 1 : 0;
                    if (jKey(d) === curMonth) { if (r.status === 'absent') a++; if (r.status === 'late') l++; }
                });
                const p = [];
                if (lvl(a)) p.push(DOT[lvl(a)] + ' ' + toPersianDigits(a) + ' غیبت');
                if (run >= 3) p.push('🚨 ' + toPersianDigits(run) + ' روز غیبت متوالی');
                if (l >= thr) p.push('⏰ ' + toPersianDigits(l) + ' تأخیر');
                return p.length ? nameOf(s) + ': ' + p.join('، ') : null;
            }).filter(Boolean);
            const avatarOf = s => s.photo
                ? React.createElement('img', { src: s.photo, alt: nameOf(s), style: { width: 40, height: 40, flex: '0 0 40px', borderRadius: '50%', objectFit: 'cover' } })
                : React.createElement('div', { style: { width: 40, height: 40, flex: '0 0 40px', borderRadius: '50%', background: '#4361ee', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 } }, nameOf(s).charAt(0));
            const row = s => {
                const st = statusOf(s.id), rec = recOf(s.id) || {};
                const kids = [
                    React.createElement('div', { key: 'top', className: 'flex items-center gap-8' },
                        avatarOf(s),
                        React.createElement('input', {
                            key: 'daily-name-' + s.id,
                            type: 'text',
                            defaultValue: nameOf(s),
                            'aria-label': 'ویرایش نام دانش‌آموز',
                            onBlur: e => {
                                const value = e.target.value.trim();
                                if (value && value !== nameOf(s)) {
                                    const parts = value.split(/\s+/); save({ ...data, students: students.map(x => x.id === s.id ? { ...x, name: value, firstName: parts[0] || '', lastName: parts.slice(1).join(' ') } : x) });
                                } else if (!value) e.target.value = nameOf(s);
                            },
                            style: { flex: 1, minWidth: 0, fontWeight: 700, border: '1px solid transparent', background: 'transparent', padding: '6px 4px' }
                        }),
                        (s.active !== false && !hol) ? React.createElement('button', { className: 'btn-ghost', 'aria-label': 'کنار گذاشتن', onClick: () => archive(s), style: { minHeight: 32, padding: '0 10px' } }, '✕') : null),
                    React.createElement('div', { key: 'seg', className: 'flex gap-4', style: { marginTop: 8 } },
                        ['present', 'absent', 'late'].map(k => React.createElement('button', { key: k, className: st === k ? 'btn-primary' : 'btn-ghost', onClick: () => setField(s.id, { status: k }), style: { flex: 1, minHeight: 36 } }, LABEL[k])))
                ];
                if ((st === 'absent' || st === 'late') && !hol) {
                    kids.push(React.createElement('div', { key: 'why', className: 'flex gap-8', style: { marginTop: 8, flexWrap: 'wrap' } },
                        st === 'late' ? React.createElement('input', { key: 'min' + rec.minutes, type: 'number', min: 0, placeholder: 'دقیقه', defaultValue: rec.minutes || '', onBlur: e => setField(s.id, { minutes: +e.target.value || 0 }), style: { width: 90 } }) : null,
                        React.createElement('input', { key: 'txt' + (rec.reason || ''), type: 'text', placeholder: st === 'absent' ? 'دلیل غیبت…' : 'دلیل تأخیر…', defaultValue: rec.reason || '', onBlur: e => setField(s.id, { reason: e.target.value.trim() || undefined }), style: { flex: 1, minWidth: 120 } })));
                    kids.push(React.createElement('div', { key: 'chips', className: 'flex gap-4', style: { marginTop: 6, flexWrap: 'wrap' } },
                        REASONS.map(t => React.createElement('button', { key: t, className: rec.reason === t ? 'btn-primary' : 'btn-ghost', onClick: () => setField(s.id, { reason: t }), style: { minHeight: 30, fontSize: 12, padding: '0 10px' } }, t))));
                }
                return React.createElement('div', { key: s.id, className: 'card' }, ...kids);
            };
            const ctl = React.createElement('div', { className: 'card' },
                React.createElement('h4', { className: 'mb-8' }, '🗓️ حضور و غیاب — ' + getShamsiWithDay(date)),
                React.createElement('div', { className: 'flex gap-8 mb-8' },
                    React.createElement('button', { className: 'btn-ghost', onClick: () => shift(-1), title: 'روز قبل' }, '◀'),
                    React.createElement('div', { style: { flex: 1 } }, React.createElement(JalaliDatePicker, { value: date, onChange: setDate })),
                    React.createElement('button', { className: 'btn-ghost', onClick: () => shift(1), title: 'روز بعد' }, '▶')),
                React.createElement('div', { className: 'flex flex-wrap gap-8 mb-8' },
                    React.createElement('button', { className: calendarOpen ? 'btn-primary' : 'btn-ghost', onClick: () => setCalendarOpen(v => !v) }, calendarOpen ? 'بستن تقویم ماهانه' : '📅 تقویم شمسی ماهانه'),
                    React.createElement('button', { className: cfg.darkMode ? 'btn-primary' : 'btn-ghost', onClick: () => save({ ...data, attendanceSettings: { ...cfg, darkMode: !cfg.darkMode } }) }, cfg.darkMode ? '☀️ حالت روز' : '🌙 حالت شب')),
                calendarOpen && React.createElement('div', { className: 'attendance-calendar mb-8' },
                    React.createElement('div', { className: 'flex-between mb-8' },
                        React.createElement('button', { className: 'btn-ghost', onClick: () => shiftMonth(-1) }, 'ماه قبل'),
                        React.createElement('b', null, JALALI_MONTHS[cal.jm - 1] + ' ' + toPersianDigits(cal.jy)),
                        React.createElement('button', { className: 'btn-ghost', onClick: () => shiftMonth(1) }, 'ماه بعد')),
                    React.createElement('div', { className: 'attendance-calendar-grid' },
                        ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map((w, i) => React.createElement('div', { key: 'w' + i, className: 'attendance-calendar-weekday' }, w)),
                        calCells.map((day, i) => {
                            if (!day) return React.createElement('div', { key: 'blank' + i });
                            const iso = jalaliToIso(cal.jy, cal.jm, day);
                            const record = students.map(st => (att[st.id] || []).find(r => r.date === iso)).filter(Boolean);
                            const selected = iso === date;
                            const holiday = isHol(iso);
                            const marks = record.reduce((o, r) => { o[r.status] = (o[r.status] || 0) + 1; return o; }, {});
                            return React.createElement('button', {
                                key: iso, type: 'button', onClick: () => setDate(iso),
                                className: 'attendance-calendar-day' + (selected ? ' selected' : '') + (holiday ? ' holiday' : '')
                            },
                                React.createElement('span', null, toPersianDigits(day)),
                                React.createElement('small', null, marks.absent ? '●' : marks.present ? '●' : ''),
                                React.createElement('small', { className: 'attendance-calendar-count' }, toPersianDigits(record.length)));
                        })
                    )),
                React.createElement('div', { className: 'text-small text-muted mb-8' }, hol ? '🏖️ این روز تعطیل است؛ حضور و غیاب ثبت نمی‌شود.' : (isFinal ? '✅ روز نهایی شد' : '⏳ روز هنوز نهایی نشده')),
                hol ? null : React.createElement('div', { className: 'text-small mb-8' }, '✅ ' + toPersianDigits(cnt.present) + ' حاضر · ❌ ' + toPersianDigits(cnt.absent) + ' غایب · ⏰ ' + toPersianDigits(cnt.late) + ' تأخیر · ⚪ ' + toPersianDigits(cnt.none) + ' ثبت‌نشده'),
                React.createElement('div', { className: 'flex flex-wrap gap-8' },
                    React.createElement('button', { className: 'btn-ghost', onClick: () => setDay({ holiday: !hol }) }, hol ? '↩ روز کاری' : '🏖️ روز تعطیل'),
                    hol ? null : React.createElement('button', { className: 'btn-secondary', onClick: allPresent }, '✅ همه حاضر'),
                    hol ? null : React.createElement('button', { className: 'btn-primary', onClick: finalize }, isFinal ? '✏️ بازکردن برای ویرایش' : '✅ تأیید نهایی روز'),
                    hol ? null : React.createElement('button', { className: 'btn-secondary', onClick: exportAttendanceImage }, '📷 تصویر لیست (PNG)')));
            const alertBox = alerts.length === 0 ? null : React.createElement('div', { className: 'card', style: { background: '#FCF3D9', border: '1px solid #FFB454' } },
                React.createElement('b', null, '⚠️ نیازمند پیگیری – ' + JALALI_MONTHS[+curMonth.slice(5) - 1]),
                alerts.map((t, i) => React.createElement('div', { key: i, className: 'text-small', style: { marginTop: 4 } }, t)));
            const tools = React.createElement('div', { className: 'card' },
                React.createElement('div', { className: 'flex flex-wrap gap-8 items-center' },
                    React.createElement('input', { type: 'text', placeholder: 'جستجوی نام…', value: dq, onChange: e => setDq(e.target.value), style: { flex: 1, minWidth: 120 } }),
                    React.createElement('button', { className: cfg.sortAZ ? 'btn-primary' : 'btn-ghost', onClick: () => save({ ...data, attendanceSettings: { ...cfg, sortAZ: !cfg.sortAZ } }) }, 'مرتب‌سازی الفبایی'),
                    React.createElement('button', { className: 'btn-secondary', onClick: () => importLegacyAttendance(data, save, showToast) }, '📥 وارد کردن داده‌های نسخه قبلی'),
                    React.createElement('label', { className: 'text-small' }, 'حد هشدار: ',
                        React.createElement('input', { key: 'thr' + thr, type: 'number', min: 1, defaultValue: thr, style: { width: 60 }, onBlur: e => save({ ...data, attendanceSettings: { ...cfg, thr: Math.max(1, +e.target.value || 3) } }) }))));
            const list = React.createElement('div', { className: 'card' },
                students.length === 0 ? React.createElement('p', { className: 'empty-state' }, 'هنوز دانش‌آموزی ثبت نشده. از بخش دانش‌آموزان اضافه کنید.') : null,
                hol ? null : React.createElement('div', { className: 'text-small text-muted mb-8' }, '💡 روی وضعیت هر نفر بزنید؛ تغییرات خودکار ذخیره می‌شوند.'),
                shown.map(row));
            const archivedList = students.filter(s => s.active === false);
            const archivedCard = archivedList.length === 0 ? null : React.createElement('div', { className: 'card' },
                React.createElement('h4', { className: 'mb-8' }, '📦 کنار گذاشته‌شده‌ها'),
                React.createElement('div', { className: 'text-small text-muted mb-8' }, 'سابقه حضور و غیابشان حفظ شده است.'),
                archivedList.map(s => React.createElement('button', { key: s.id, className: 'btn-ghost', onClick: () => restore(s), style: { margin: 3 } }, '↩ ' + nameOf(s))));
            return React.createElement('div', null, ctl, alertBox, tools, list, archivedCard, searchCard);
        }

        // وارد کردن داده‌های نسخه‌ی قبلی (فایل حضور و غیاب مستقل) به همین فهرست دانش‌آموزان.
        // دانش‌آموزان بر اساس نام تطبیق داده می‌شوند و تکراری ساخته نمی‌شود.
        function importLegacyAttendance(data, save, showToast) {
            let old = null;
            try {
                const reg = JSON.parse(localStorage.getItem('att_classes') || 'null');
                const key = reg && reg.cur && reg.cur !== 'c1' ? 'attendance_v2_' + reg.cur : 'attendance_v2';
                old = JSON.parse(localStorage.getItem(key) || 'null');
            } catch (e) { old = null; }
            if (!old || !Array.isArray(old.students)) { showToast('داده‌ای از نسخه قبلی پیدا نشد', 'error'); return; }
            const norm = t => String(t || '').trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ');
            const students = (data.students || []).map(s => ({ ...s }));
            const byName = {};
            students.forEach(s => { byName[norm(s.name)] = s; });
            const idMap = {};
            old.students.forEach(os => {
                const f = os.f || {};
                let ns = byName[norm(os.name)];
                if (!ns) {
                    ns = { id: uid(), name: os.name, active: true };
                    students.push(ns); byName[norm(os.name)] = ns;
                }
                ns.photo = ns.photo || os.ph || '';
                ns.fatherPhone = ns.fatherPhone || f.fp || '';
                ns.motherPhone = ns.motherPhone || f.mp || '';
                if (os.active === false) { ns.active = false; ns.archivedAt = ns.archivedAt || os.end || undefined; }
                idMap[os.id] = ns.id;
            });
            const attendance = { ...(data.attendance || {}) };
            const days = { ...(data.attendanceDays || {}) };
            let added = 0;
            Object.keys(old.data || {}).forEach(d => {
                Object.keys(old.data[d] || {}).forEach(oid => {
                    const g = old.data[d][oid] || {};
                    const nid = idMap[oid];
                    const st = g.s === 'p' ? 'present' : g.s === 'a' ? 'absent' : g.s === 'l' ? 'late' : null;
                    if (!nid || !st) return;
                    const list = attendance[nid] || [];
                    if (list.some(r => r.date === d)) return;
                    const rec = { id: uid(), date: d, status: st };
                    if (g.r && st !== 'present') rec.reason = g.r;
                    if (st === 'late' && +g.m) rec.minutes = +g.m;
                    attendance[nid] = [...list, rec];
                    added++;
                });
            });
            Object.keys(old.holidays || {}).forEach(d => { days[d] = { ...(days[d] || {}), holiday: !!old.holidays[d] }; });
            Object.keys(old.final || {}).forEach(d => { days[d] = { ...(days[d] || {}), final: !!old.final[d] }; });
            save({ ...data, students, attendance, attendanceDays: days });
            showToast(added + ' ثبت حضور و غیاب از نسخه قبلی وارد شد');
        }


        const attNameOf = s => s.name || [s.firstName, s.lastName].filter(Boolean).join(' ') || 'بدون نام';
        // ===== بخش‌های گزارش، داشبورد و سابقه‌ی حضور و غیاب (بومی) =====
        const ATT_FA = { present: 'حاضر', absent: 'غایب', late: 'تأخیر' };
        const attKey = d => { const o = {}; new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', { year: 'numeric', month: 'numeric' }).formatToParts(new Date(d + 'T12:00:00')).forEach(p => o[p.type] = p.value); return o.year + '-' + String(o.month).padStart(2, '0'); };
        const attHol = (days, d) => {
            const m = days[d] || {};
            if (m.holiday !== undefined) return !!m.holiday;
            const x = new Date(d + 'T12:00:00');
            if (x.getDay() === 5) return true;
            const p = {};
            new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', { month: 'numeric', day: 'numeric' }).formatToParts(x).forEach(q => p[q.type] = q.value);
            return ['1-1', '1-2', '1-3', '1-4', '1-12', '1-13', '3-14', '3-15', '11-22', '12-29'].includes(p.month + '-' + p.day);
        };
        const attFinalDays = data => Object.keys(data.attendanceDays || {}).filter(d => data.attendanceDays[d] && data.attendanceDays[d].final && !attHol(data.attendanceDays, d)).sort();
        // فقط روزهای نهایی‌شده و غیرتعطیل شمارش می‌شوند
        function attStats(data, inScope) {
            const days = data.attendanceDays || {}, att = data.attendance || {}, out = {};
            (data.students || []).forEach(s => {
                const r = { p: 0, a: 0, l: 0, m: 0 };
                (att[s.id] || []).forEach(x => {
                    if (!days[x.date] || !days[x.date].final || attHol(days, x.date) || !inScope(x.date)) return;
                    if (x.status === 'present') r.p++;
                    else if (x.status === 'absent') r.a++;
                    else if (x.status === 'late') { r.l++; r.m += +x.minutes || 0; }
                });
                out[s.id] = r;
            });
            return out;
        }
        function attDownload(blob, name) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = name;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 2000);
        }

        function AttReport({ data, showToast }) {
            const thr = Math.max(1, +((data.attendanceSettings || {}).thr) || 3);
            const keys = Array.from(new Set(attFinalDays(data).map(attKey))).sort().reverse();
            const years = Array.from(new Set(keys.map(k => k.slice(0, 4)))).sort().reverse();
            const opts = keys.map(k => ['m:' + k, 'ماه ' + JALALI_MONTHS[+k.slice(5) - 1] + ' ' + toPersianDigits(k.slice(0, 4))])
                .concat(years.map(y => ['y:' + y, 'کل سال ' + toPersianDigits(y)]));
            const [per, setPer] = React.useState(opts[0] ? opts[0][0] : '');
            const [sortBy, setSortBy] = React.useState('name');
            const [kind, key] = per.split(':');
            const label = (opts.find(o => o[0] === per) || [, ''])[1];
            const S = attStats(data, d => kind === 'y' ? attKey(d).slice(0, 4) === key : attKey(d) === key);
            const rows = (data.students || []).filter(s => S[s.id] && (S[s.id].p + S[s.id].a + S[s.id].l) > 0)
                .sort((x, y) => sortBy === 'abs' ? S[y.id].a - S[x.id].a : attNameOf(x).localeCompare(attNameOf(y), 'fa'));
            const csv = () => {
                if (!rows.length) return showToast('داده‌ای برای گزارش نیست', 'error');
                const esc = v => '"' + String(v).replace(/"/g, '""') + '"';
                const lines = [['ردیف', 'نام', 'حاضر', 'غایب', 'تأخیر', 'دقیقه تأخیر'].map(esc).join(',')]
                    .concat(rows.map((s, i) => [i + 1, attNameOf(s), S[s.id].p, S[s.id].a, S[s.id].l, S[s.id].m].map(esc).join(',')));
                attDownload(new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' }), 'گزارش-' + per.replace(':', '-') + '.csv');
            };
            const png = () => {
                if (!rows.length) return showToast('داده‌ای برای گزارش نیست', 'error');
                exportRosterPng({
                    title: 'گزارش حضور و غیاب', subtitle: label,
                    sections: [{ title: 'آمار حضور و غیاب', color: '#254447', rows: rows.map(s => ({
                        name: attNameOf(s), photo: s.photo || '',
                        value: 'غایب ' + toPersianDigits(S[s.id].a) + ' · تأخیر ' + toPersianDigits(S[s.id].l),
                        color: S[s.id].a >= thr ? '#be123c' : '#254447'
                    })) }],
                    filename: 'گزارش-' + per.replace(':', '-') + '.png'
                }).catch(() => showToast('خطا در ساخت تصویر', 'error'));
            };
            const head = React.createElement('div', { className: 'flex gap-8 mb-8', style: { fontWeight: 700, borderBottom: '2px solid #e5e7eb', paddingBottom: 6 } },
                React.createElement('span', { style: { flex: 1 } }, 'نام'), React.createElement('span', { style: { width: 50, textAlign: 'center' } }, 'حاضر'),
                React.createElement('span', { style: { width: 50, textAlign: 'center' } }, 'غایب'), React.createElement('span', { style: { width: 60, textAlign: 'center' } }, 'تأخیر'));
            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📊 گزارش حضور و غیاب'),
                    React.createElement('select', { value: per, onChange: e => setPer(e.target.value), style: { width: '100%', marginBottom: 8 } },
                        opts.map(o => React.createElement('option', { key: o[0], value: o[0] }, o[1]))),
                    React.createElement('div', { className: 'flex gap-8 flex-wrap' },
                        React.createElement('button', { className: sortBy === 'name' ? 'btn-primary' : 'btn-ghost', onClick: () => setSortBy('name') }, 'مرتب‌سازی الفبایی'),
                        React.createElement('button', { className: sortBy === 'abs' ? 'btn-primary' : 'btn-ghost', onClick: () => setSortBy('abs') }, 'بیشترین غیبت'),
                        React.createElement('button', { className: 'btn-secondary', onClick: csv }, '📄 CSV'),
                        React.createElement('button', { className: 'btn-secondary', onClick: png }, '📷 تصویر گزارش (PNG)'))),
                React.createElement('div', { className: 'card' },
                    rows.length === 0 ? React.createElement('p', { className: 'empty-state' }, 'برای این بازه روز نهایی‌شده‌ای وجود ندارد.') : null,
                    rows.length ? head : null,
                    rows.map(s => React.createElement('div', { key: s.id, className: 'flex gap-8', style: { padding: '6px 0', borderBottom: '1px solid #f1f5f9', background: S[s.id].a >= thr ? '#ffe3e3' : 'transparent' } },
                        React.createElement('span', { style: { flex: 1, fontWeight: 600 } }, attNameOf(s)),
                        React.createElement('span', { style: { width: 50, textAlign: 'center' } }, toPersianDigits(S[s.id].p)),
                        React.createElement('span', { style: { width: 50, textAlign: 'center', color: '#be123c', fontWeight: 700 } }, toPersianDigits(S[s.id].a)),
                        React.createElement('span', { style: { width: 60, textAlign: 'center' } }, toPersianDigits(S[s.id].l) + (S[s.id].m ? ' (' + toPersianDigits(S[s.id].m) + ' د)' : '')))),
                    rows.length ? React.createElement('div', { className: 'text-small text-muted mt-8' }, 'ردیف‌های قرمز: غیبت به حد هشدار (' + toPersianDigits(thr) + ') رسیده یا بیشتر.') : null));
        }

        function AttDash({ data }) {
            const days = data.attendanceDays || {}, att = data.attendance || {};
            const thr = Math.max(1, +((data.attendanceSettings || {}).thr) || 3);
            const active = (data.students || []).filter(s => s.active !== false);
            const today = todayISO();
            const t = { present: 0, absent: 0, late: 0 };
            active.forEach(s => { const r = (att[s.id] || []).find(x => x.date === today); if (r && t[r.status] !== undefined) t[r.status]++; });
            const monthTot = {};
            (data.students || []).forEach(s => (att[s.id] || []).forEach(x => {
                if (!days[x.date] || !days[x.date].final || attHol(days, x.date)) return;
                const k = attKey(x.date);
                monthTot[k] = monthTot[k] || { a: 0, l: 0 };
                if (x.status === 'absent') monthTot[k].a++;
                if (x.status === 'late') monthTot[k].l++;
            }));
            const months = Object.keys(monthTot).sort().slice(-12);
            const maxV = Math.max(1, ...months.map(k => monthTot[k].a));
            const curS = attStats(data, d => attKey(d) === attKey(today));
            const risk = Object.keys(curS).filter(id => curS[id].a >= thr).length;
            const W = 340, H = 180, bw = (W - 20) / Math.max(1, months.length);
            const bars = months.map((k, i) => {
                const v = monthTot[k].a, h = Math.round((v / maxV) * 120), x = 10 + i * bw;
                return React.createElement('g', { key: k },
                    React.createElement('rect', { x: x + 4, y: 140 - h, width: bw - 8, height: h, rx: 4, fill: '#ef476f' }),
                    React.createElement('text', { x: x + bw / 2, y: 134 - h, textAnchor: 'middle', fontSize: 10, fill: '#254447' }, toPersianDigits(v)),
                    React.createElement('text', { x: x + bw / 2, y: 158, textAnchor: 'middle', fontSize: 9, fill: '#6b7280' }, JALALI_MONTHS[+k.slice(5) - 1].slice(0, 5)));
            });
            const card = (label, value) => React.createElement('div', { className: 'card', style: { flex: '1 1 140px', textAlign: 'center' } },
                React.createElement('div', { className: 'text-small text-muted' }, label),
                React.createElement('div', { style: { fontSize: 24, fontWeight: 800 } }, value));
            return React.createElement('div', null,
                React.createElement('div', { className: 'flex flex-wrap gap-8' },
                    card('دانش‌آموزان فعال', toPersianDigits(active.length)),
                    card('حاضر امروز', toPersianDigits(t.present)),
                    card('غایب امروز', toPersianDigits(t.absent)),
                    card('نیازمند پیگیری این ماه', toPersianDigits(risk))),
                React.createElement('div', { className: 'card', style: { marginTop: 8 } },
                    React.createElement('h4', { className: 'mb-8' }, '📈 غیبت‌های ماهانه'),
                    months.length ? React.createElement('svg', { viewBox: `0 0 ${W} ${H}`, style: { width: '100%' } }, bars)
                        : React.createElement('p', { className: 'empty-state' }, 'هنوز روز نهایی‌شده‌ای نیست.')));
        }

        function AttHistory({ data, save, showToast }) {
            const students = data.students || [];
            const [sid, setSid] = React.useState(students[0] ? students[0].id : '');
            const s = students.find(x => x.id === sid) || students[0];
            if (!s) return React.createElement('div', { className: 'card' }, React.createElement('p', { className: 'empty-state' }, 'هنوز دانش‌آموزی ثبت نشده.'));
            const days = data.attendanceDays || {};
            const rows = ((data.attendance || {})[s.id] || []).filter(x => days[x.date] && days[x.date].final && !attHol(days, x.date)).sort((a, b) => b.date.localeCompare(a.date));
            const cnt = { present: 0, absent: 0, late: 0 };
            rows.forEach(r => { if (cnt[r.status] !== undefined) cnt[r.status]++; });
            const patch = p => save({ ...data, students: students.map(x => x.id === s.id ? { ...x, ...p } : x) });
            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('select', { value: s.id, onChange: e => setSid(e.target.value), style: { width: '100%', marginBottom: 8 } },
                        students.map(x => React.createElement('option', { key: x.id, value: x.id }, attNameOf(x)))),
                    React.createElement('div', { className: 'flex items-center gap-8 mb-8' },
                        s.photo ? React.createElement('img', { src: s.photo, alt: '', style: { width: 56, height: 56, borderRadius: '50%', objectFit: 'cover' } })
                            : React.createElement('div', { style: { width: 56, height: 56, borderRadius: '50%', background: '#4361ee', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, fontWeight: 700 } }, attNameOf(s).charAt(0)),
                        React.createElement('input', { key: 'nm' + s.id, type: 'text', defaultValue: s.name || '', placeholder: 'نام دانش‌آموز', style: { flex: 1 }, onBlur: e => { const v = e.target.value.trim(); if (v && v !== s.name) patch({ name: v }); } })),
                    React.createElement('div', { className: 'text-small mb-8' }, '✅ ' + toPersianDigits(cnt.present) + ' حاضر · ❌ ' + toPersianDigits(cnt.absent) + ' غایب · ⏰ ' + toPersianDigits(cnt.late) + ' تأخیر')),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '🗒️ یادداشت'),
                    React.createElement('textarea', { key: 'note' + s.id, defaultValue: s.attNote || '', placeholder: 'یادداشت درباره‌ی این دانش‌آموز…', style: { width: '100%', minHeight: 80, boxSizing: 'border-box' }, onBlur: e => patch({ attNote: e.target.value }) })),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📅 سابقه‌ی روزهای نهایی‌شده'),
                    rows.length === 0 ? React.createElement('p', { className: 'empty-state' }, 'سابقه‌ای ثبت نشده است.') : null,
                    rows.map((r, i) => React.createElement('div', { key: i, className: 'flex gap-8', style: { padding: '6px 0', borderBottom: '1px solid #f1f5f9', fontSize: 14 } },
                        React.createElement('span', { style: { flex: 1 } }, toShamsi(r.date)),
                        React.createElement('b', { style: { color: r.status === 'absent' ? '#be123c' : r.status === 'late' ? '#b7791f' : '#16845b' } }, ATT_FA[r.status] || ''),
                        r.minutes ? React.createElement('span', null, toPersianDigits(r.minutes) + ' دقیقه') : null,
                        r.reason ? React.createElement('span', { className: 'text-muted' }, r.reason) : null))));
        }

        function AttendanceHub(props) {
            const [view, setView] = React.useState('daily');
            const tabs = [['daily', '🗓️ ثبت روزانه'], ['report', '📊 گزارش'], ['dash', '📈 داشبورد'], ['history', '👤 سابقه و یادداشت']];
            const body = view === 'daily' ? React.createElement(AttendanceNative, props)
                : view === 'report' ? React.createElement(AttReport, props)
                : view === 'dash' ? React.createElement(AttDash, props)
                : React.createElement(AttHistory, props);
            const dark = !!((props.data.attendanceSettings || {}).darkMode);
            return React.createElement('div', { className: dark ? 'attendance-theme-dark' : 'attendance-theme-light' },
                React.createElement('div', { className: 'flex flex-wrap gap-8 mb-8' },
                    tabs.map(([k, l]) => React.createElement('button', { key: k, className: view === k ? 'btn-primary' : 'btn-ghost', onClick: () => setView(k) }, l))),
                body);
        }

        // ===== لیست تصویری کلاس برای ارسال به والدین (همراه با عکس دانش‌آموزان) =====
        function buildRosterRequest(tab, data) {
            const students = (Array.isArray(data.students) ? data.students : []).filter(s => s.active !== false);
            const nameOf = s => s.name || [s.firstName, s.lastName].filter(Boolean).join(' ') || 'بدون نام';
            const person = (s, value, color) => ({ name: nameOf(s), photo: s.photo || '', value: value || '', color: color || '#254447' });
            const today = todayISO();
            if (tab === 'tasks') {
                const tasks = Array.isArray(data.tasks) ? data.tasks : [];
                const dates = tasks.map(t => t.assignedDate).filter(Boolean).sort();
                const day = dates.includes(today) ? today : dates[dates.length - 1];
                const dayTasks = tasks.filter(t => t.assignedDate === day);
                if (!dayTasks.length) return null;
                const sections = [];
                dayTasks.forEach(t => {
                    const st = t.statuses || {};
                    const pick = k => students.filter(s => st[s.id] === k).map(s => person(s, '', ''));
                    sections.push({ title: '📚 ' + t.title + ' — تحویل داده', color: '#16845b', rows: pick('done') });
                    sections.push({ title: 'ناقص', color: '#a16207', rows: pick('incomplete') });
                    sections.push({ title: 'انجام نداده', color: '#be123c', rows: pick('missing') });
                });
                return { title: 'وضعیت تکالیف', subtitle: toShamsi(day), sections: sections.filter(x => x.rows.length), filename: 'تکالیف-' + day + '.png' };
            }
            if (tab === 'exams') {
                const all = [];
                Object.keys(data.exams || {}).forEach(sid => (Array.isArray(data.exams[sid]) ? data.exams[sid] : []).forEach(e => all.push({ ...e, sid })));
                if (!all.length) return null;
                const day = all.map(e => e.date).filter(Boolean).sort().pop();
                const groups = {};
                all.filter(e => e.date === day).forEach(e => { const k = (e.subject || '') + ' ' + (e.type || ''); (groups[k] = groups[k] || {})[e.sid] = e; });
                const sections = Object.keys(groups).map(k => ({
                    title: '📋 ' + k.trim(),
                    color: '#254447',
                    rows: students.filter(s => groups[k][s.id]).map(s => {
                        const e = groups[k][s.id];
                        return e.absent ? person(s, 'غایب', '#be123c') : person(s, getGradeLabel(e.grade), '#16845b');
                    })
                }));
                return { title: 'نتیجه آزمون‌ها', subtitle: toShamsi(day), sections, filename: 'آزمون-' + day + '.png' };
            }
            if (tab === 'scores') {
                const from = new Date(Date.now() - 6 * 864e5).toISOString().slice(0, 10);
                const sum = {};
                (Array.isArray(data.pointHistory) ? data.pointHistory : []).forEach(p => {
                    const d = String(p.date || '').slice(0, 10);
                    if (d < from || d > today) return;
                    sum[p.studentId] = (sum[p.studentId] || 0) + (Number(p.amount) || 0);
                });
                const rows = students.map(s => ({ s, v: sum[s.id] || 0 })).sort((a, b) => b.v - a.v)
                    .map(({ s, v }) => person(s, (v > 0 ? '+' : '') + toPersianDigits(v), v > 0 ? '#16845b' : v < 0 ? '#be123c' : '#6b7280'));
                return { title: 'گزارش امتیازهای هفتگی', subtitle: toShamsi(from) + ' تا ' + toShamsi(today), sections: [{ title: 'امتیاز هفته', color: '#254447', rows }], filename: 'امتیاز-هفتگی-' + today + '.png' };
            }
            return null;
        }

        async function saveOrSharePng(blob, filename, title) {
            try {
                if (typeof File !== 'undefined' && navigator.share && navigator.canShare) {
                    const file = new File([blob], filename, { type: 'image/png' });
                    if (navigator.canShare({ files: [file] })) {
                        await navigator.share({ files: [file], title: title || filename });
                        return 'shared';
                    }
                }
            } catch (e) {
                if (e && e.name === 'AbortError') return 'cancelled';
                console.warn('share unavailable; falling back to download', e);
            }
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = filename;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 2500);
            return 'downloaded';
        }

        // نسخه‌ی بدون وابستگی به اینترنت: تصویر مستقیم روی canvas کشیده می‌شود
        async function exportRosterPng(req) {
            const W = 680, rowH = 60, secH = 44, headH = 96;
            const H = headH + req.sections.reduce((n, sec) => n + secH + sec.rows.length * rowH, 0) + 30;
            const c = document.createElement('canvas');
            c.width = W * 2; c.height = H * 2;
            const ctx = c.getContext('2d');
            ctx.scale(2, 2);
            ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, W, H);
            ctx.textAlign = 'center';
            ctx.fillStyle = '#254447'; ctx.font = 'bold 22px Tahoma, Arial, sans-serif';
            ctx.fillText(req.title, W / 2, 36);
            ctx.fillStyle = '#6b7280'; ctx.font = '15px Tahoma, Arial, sans-serif';
            ctx.fillText(req.subtitle, W / 2, 62);
            const photos = {};
            const rows = req.sections.flatMap(sec => sec.rows);
            await Promise.all(rows.filter(r => r.photo && !photos[r.photo]).map(r => new Promise(res => {
                const im = new Image();
                im.onload = () => { photos[r.photo] = im; res(); };
                im.onerror = () => res();
                im.src = r.photo;
            })));
            let y = headH;
            req.sections.forEach(sec => {
                ctx.textAlign = 'right'; ctx.fillStyle = sec.color; ctx.font = 'bold 17px Tahoma, Arial, sans-serif';
                ctx.fillText(sec.title + ' (' + toPersianDigits(sec.rows.length) + ')', W - 24, y + 28);
                y += secH;
                sec.rows.forEach(r => {
                    const cx = W - 46, cy = y + rowH / 2;
                    ctx.save();
                    ctx.beginPath(); ctx.arc(cx, cy, 22, 0, Math.PI * 2); ctx.closePath(); ctx.clip();
                    if (photos[r.photo]) {
                        ctx.drawImage(photos[r.photo], cx - 22, cy - 22, 44, 44);
                    } else {
                        ctx.fillStyle = '#4361ee'; ctx.fillRect(cx - 22, cy - 22, 44, 44);
                        ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center'; ctx.font = 'bold 18px Tahoma, Arial, sans-serif';
                        ctx.fillText(r.name.charAt(0), cx, cy + 6);
                    }
                    ctx.restore();
                    ctx.textAlign = 'right'; ctx.fillStyle = '#254447'; ctx.font = 'bold 17px Tahoma, Arial, sans-serif';
                    ctx.fillText(r.name, W - 80, cy + 6);
                    ctx.textAlign = 'left'; ctx.fillStyle = r.color; ctx.font = 'bold 17px Tahoma, Arial, sans-serif';
                    ctx.fillText(r.value, 24, cy + 6);
                    ctx.strokeStyle = '#eef2f2'; ctx.beginPath(); ctx.moveTo(16, y + rowH); ctx.lineTo(W - 16, y + rowH); ctx.stroke();
                    y += rowH;
                });
            });
            const blob = await new Promise(res => c.toBlob(res, 'image/png'));
            if (!blob) throw new Error('ساخت تصویر ناموفق بود');
            return await saveOrSharePng(blob, req.filename, req.title);
        }

        // ===== درباره من =====
        function AboutMe({ data, save }) {
            const [text, setText] = React.useState(data.aboutMe || '');
            return React.createElement('div', { className: 'card' },
                React.createElement('h3', { className: 'mb-8' }, '🙋 درباره من'),
                React.createElement('textarea', {
                    value: text,
                    onChange: e => setText(e.target.value),
                    onBlur: () => save({ ...data, aboutMe: text }),
                    placeholder: 'اطلاعات شما اینجا نوشته می‌شود…',
                    style: { width: '100%', minHeight: 220, boxSizing: 'border-box', padding: 10, borderRadius: 10, fontFamily: 'inherit', fontSize: 15 }
                }),
                React.createElement('div', { className: 'text-small mt-8' }, 'بعد از نوشتن، بیرون کادر کلیک کنید تا ذخیره شود.'));
        }

        function TeacherApp({ data: rootData, save: saveRoot, user, setUser, onLogout, showToast, storageOk }) {
            const rootClasses = Array.isArray(rootData.classes) ? rootData.classes : [];
            const [activeClassId, setActiveClassId] = React.useState(rootData.activeClassId || (rootClasses[0] && rootClasses[0].id) || 'class-main');
            const legacyClassData = React.useMemo(() => {
                const { classes, activeClassId: ignoredId, users, meta, ...rest } = rootData;
                return rest;
            }, [rootData]);
            const classes = rootClasses.length ? rootClasses : [{ id: 'class-main', name: 'کلاس فعلی', data: legacyClassData }];
            const activeClass = classes.find(c => c.id === activeClassId) || classes[0];
            const activePayload = activeClass.data || emptyData();
            const data = { ...activePayload, users: rootData.users || {}, meta: rootData.meta || {}, aboutMe: rootData.aboutMe !== undefined ? rootData.aboutMe : (activePayload.aboutMe || '') };
            const save = nextClassData => {
                saveRoot(prevRoot => {
                    const prevClasses = Array.isArray(prevRoot.classes) && prevRoot.classes.length ? prevRoot.classes : classes;
                    const activeIdx = prevClasses.findIndex(c => c.id === activeClass.id);
                    const prevData = (activeIdx >= 0 ? prevClasses[activeIdx].data : null) || activeClass.data || legacyClassData || {};
                    const baseForFn = { ...prevData, users: prevRoot.users || {}, meta: prevRoot.meta || {}, aboutMe: prevRoot.aboutMe !== undefined ? prevRoot.aboutMe : (prevData.aboutMe || '') };
                    const nextData = typeof nextClassData === 'function' ? nextClassData(baseForFn) : nextClassData;
                    if (nextData === baseForFn) return prevRoot; // بدون تغییر
                    const { users, meta, aboutMe, classes: ignoredClasses, activeClassId: ignoredActive, ...payload } = nextData;
                    const nextClasses = prevClasses.map(c => c.id === activeClass.id ? { ...c, data: payload } : c);
                    if (!nextClasses.some(c => c.id === activeClass.id)) nextClasses.push({ ...activeClass, data: payload });
                    return { ...prevRoot, users: users || prevRoot.users || {}, meta: meta || prevRoot.meta || {}, aboutMe: aboutMe !== undefined ? aboutMe : prevRoot.aboutMe, classes: nextClasses, activeClassId: activeClass.id };
                });
                return true;
            };
            React.useEffect(() => {
                if (!rootClasses.length) {
                    saveRoot({ ...rootData, classes: [{ id: activeClass.id, name: activeClass.name || 'کلاس فعلی', data: legacyClassData }], activeClassId: activeClass.id });
                }
            }, []);
            React.useEffect(() => {
                if (rootData.activeClassId && rootData.activeClassId !== activeClassId) setActiveClassId(rootData.activeClassId);
            }, [rootData.activeClassId]);
            const [tab, setTab] = React.useState('dashboard');
            const [examEntryContext, setExamEntryContext] = React.useState(null);
            const [dashboardOverlayOpen, setDashboardOverlayOpen] = React.useState(false);
            const [weeklyOpen, setWeeklyOpen] = React.useState(false);
            const [storageEstimate, setStorageEstimate] = React.useState(null);
            const switchClass = id => {
                setActiveClassId(id);
                tabHistoryRef.current = ['dashboard'];
                saveRoot({ ...rootData, classes, activeClassId: id });
                setTab('dashboard');
            };
            const createClass = () => {
                const name = prompt('نام کلاس جدید را وارد کنید:', 'کلاس جدید');
                if (!name || !name.trim()) return;
                if (classes.some(c => c.name === name.trim())) { showToast('کلاسی با این نام وجود دارد', 'error'); return; }
                const fresh = emptyData();
                const { classes: omitC, activeClassId: omitA, users: omitU, meta: omitM, ...classData } = fresh;
                const entry = { id: uid(), name: name.trim(), data: classData };
                const next = [...classes, entry];
                saveRoot({ ...rootData, classes: next, activeClassId: entry.id });
                setActiveClassId(entry.id);
                setTab('dashboard');
                showToast('کلاس جدید ساخته شد');
            };
            const renameClass = () => {
                const name = prompt('نام جدید کلاس:', activeClass.name);
                if (!name || !name.trim()) return;
                if (classes.some(c => c.id !== activeClass.id && c.name === name.trim())) { showToast('کلاسی با این نام وجود دارد', 'error'); return; }
                const next = classes.map(c => c.id === activeClass.id ? { ...c, name: name.trim() } : c);
                saveRoot({ ...rootData, classes: next });
                showToast('نام کلاس تغییر کرد');
            };
            const deleteClass = () => {
                if (classes.length <= 1) return showToast('حداقل یک کلاس باید باقی بماند', 'error');
                if (!confirm('کلاس «' + activeClass.name + '» و تمام اطلاعات اختصاصی آن حذف شود؟ این کار قابل بازگشت نیست.')) return;
                const next = classes.filter(c => c.id !== activeClass.id);
                saveRoot({ ...rootData, classes: next, activeClassId: next[0].id });
                setActiveClassId(next[0].id);
                setTab('dashboard');
                showToast('کلاس حذف شد');
            };
            const tabHistoryRef = React.useRef(['dashboard']);
            const backHandlingRef = React.useRef(false);

            // مدیریت یکپارچه‌ی Back:
            // - هر بار تغییر تب، همان تب به تاریخچه‌ی داخلی برنامه اضافه می‌شود.
            // - Back ابتدا لایه‌ی باز (عکس/بودجه‌بندی/مودال) را می‌بندد.
            // - سپس دقیقاً به آخرین تب واقعی برمی‌گردد.
            // - وقتی تاریخچه تمام شد، مقصد قطعی «داشبورد» است.
            React.useEffect(() => {
                const ensureHistoryEntry = () => {
                    try {
                        if (!window.history.state || window.history.state.__classAppBack !== true) {
                            window.history.pushState({ __classAppBack: true }, '', window.location.href);
                        }
                    } catch (e) {}
                };

                ensureHistoryEntry();

                const findVisibleElement = (selector) => {
                    const els = Array.from(document.querySelectorAll(selector));
                    return els.find(el => {
                        const r = el.getBoundingClientRect();
                        const st = window.getComputedStyle(el);
                        return r.width > 0 && r.height > 0 &&
                            st.display !== 'none' && st.visibility !== 'hidden';
                    });
                };

                const goToPreviousTab = () => {
                    const history = tabHistoryRef.current;

                    // تاریخچه نباید هیچ‌وقت بدون داشبورد بماند.
                    if (history.length <= 1) {
                        history.length = 1;
                        history[0] = 'dashboard';
                        backHandlingRef.current = true;
                        setTab('dashboard');
                        setDashboardOverlayOpen(false);
                        setWeeklyOpen(false);
                        setTimeout(() => { backHandlingRef.current = false; }, 0);
                        return;
                    }

                    // صفحه‌ی فعلی را حذف کن و دقیقاً آخرین صفحه‌ی قبلی را نمایش بده.
                    history.pop();
                    const previous = history[history.length - 1] || 'dashboard';

                    backHandlingRef.current = true;
                    setTab(previous);
                    setDashboardOverlayOpen(false);
                    setWeeklyOpen(false);
                    setTimeout(() => { backHandlingRef.current = false; }, 0);
                };

                const handleBack = () => {
                    // 1) نمایش تمام‌صفحه‌ی عکس: فقط همان بسته شود.
                    const lightboxClose = findVisibleElement('div[style*="z-index: 1000"] button');
                    if (lightboxClose) {
                        lightboxClose.click();
                        ensureHistoryEntry();
                        return;
                    }

                    // 2) بودجه‌بندیِ تمام‌صفحه‌ی بازشده از داشبورد.
                    const budgetingPage = findVisibleElement('[data-app-overlay="budgeting"]');
                    if (budgetingPage) {
                        const closeBtn = budgetingPage.querySelector('.weekly-close-btn');
                        if (closeBtn) closeBtn.click();
                        ensureHistoryEntry();
                        return;
                    }

                    // 2.5) صفحه‌ی مستقل «سوابق آزمون‌ها» که از داخل داشبورد باز می‌شود.
                    // این صفحه مودال نیست و دکمه‌ی آن «بازگشت به داشبورد» نام دارد؛
                    // بنابراین باید همان دکمه اجرا شود، نه اینکه تاریخچه‌ی تب‌ها تمام شود.
                    const examHistoryPage = findVisibleElement('.exam-history-page');
                    if (examHistoryPage) {
                        const visibleButtons = Array.from(examHistoryPage.querySelectorAll('button')).filter(btn => {
                            const r = btn.getBoundingClientRect();
                            const st = window.getComputedStyle(btn);
                            return r.width > 0 && r.height > 0 &&
                                st.display !== 'none' && st.visibility !== 'hidden' &&
                                st.pointerEvents !== 'none';
                        });
                        // اگر در حال ویرایش یک آزمون هستیم، اول به فهرست سوابق برگردیم.
                        // فقط وقتی در خود فهرست هستیم، به داشبورد برگردیم.
                        const editorBack = visibleButtons
                            .filter(btn => /^←?\s*بازگشت\s*→?$/.test((btn.textContent || '').trim()))
                            .sort((a, b) => {
                                const depth = el => { let n = 0; while (el && el !== examHistoryPage) { n++; el = el.parentElement; } return n; };
                                return depth(b) - depth(a);
                            })[0];
                        const dashboardBack = visibleButtons.find(btn => /بازگشت به داشبورد/.test((btn.textContent || '').trim()));
                        const backButton = editorBack || dashboardBack;
                        if (backButton) {
                            backButton.click();
                            ensureHistoryEntry();
                            return;
                        }
                    }

                    // 2.6) پشتیبان برای مرورگرهای موبایل: ممکن است کلاس صفحه‌ی سوابق
                    // در بعضی حالت‌های رندر در دسترس نباشد؛ در این صورت دکمه‌ی مشخص
                    // «بازگشت به داشبورد» را در کل صفحه پیدا کن و اجرا کن.
                    const globalDashboardBack = Array.from(document.querySelectorAll('button')).find(btn => {
                        const txt = (btn.textContent || '').replace(/\s+/g, ' ').trim();
                        const r = btn.getBoundingClientRect();
                        const st = window.getComputedStyle(btn);
                        return /بازگشت به داشبورد/.test(txt) && r.width > 0 && r.height > 0 &&
                            st.display !== 'none' && st.visibility !== 'hidden' &&
                            st.pointerEvents !== 'none';
                    });
                    if (globalDashboardBack) {
                        globalDashboardBack.click();
                        ensureHistoryEntry();
                        return;
                    }

                    // 3) مودال‌های داشبورد.
                    // این مودال‌ها «صفحه‌ی جدید» نیستند؛ با Back باید فقط بسته شوند
                    // و کاربر روی خود داشبورد بماند. مخصوصاً صفحه‌ی «آزمون‌های دانش‌آموز».
                    const dashboardModal = findVisibleElement('[data-dashboard-drill="true"]');
                    if (dashboardModal) {
                        // مسیر آزمون‌ها باید دقیقاً مرحله‌به‌مرحله طی شود:
                        // جزئیات آزمون ← آزمون‌های یک درس ← فهرست آزمون‌های دانش‌آموز ← داشبورد.
                        const drillBack = dashboardModal.querySelector('.drill-back-button');
                        if (drillBack) {
                            drillBack.click();
                            ensureHistoryEntry();
                            return;
                        }

                        // اگر به هر دلیل دکمه‌ی داخلی وجود نداشت، فقط همان مودال بسته شود.
                        const innerBack = Array.from(dashboardModal.querySelectorAll('button')).find(btn => {
                            const txt = (btn.textContent || '').trim();
                            const r = btn.getBoundingClientRect();
                            const st = window.getComputedStyle(btn);
                            return r.width > 0 && r.height > 0 &&
                                st.display !== 'none' && st.visibility !== 'hidden' &&
                                /^(بازگشت|برگشت|←\s*بازگشت|←\s*برگشت|→\s*بازگشت|→\s*برگشت)$/.test(txt);
                        });

                        if (innerBack) {
                            innerBack.click();
                        } else {
                            // در اولین صفحه‌ی پنجره (مثل «آزمون‌های صادق») فقط خود
                            // پنجره بسته شود و کاربر دقیقاً روی داشبورد بماند.
                            const closeBtn =
                                dashboardModal.querySelector('.modal-header button') ||
                                dashboardModal.querySelector('button');
                            if (closeBtn) closeBtn.click();
                            else dashboardModal.click();
                        }
                        ensureHistoryEntry();
                        return;
                    }

                    // 4) مودال‌های سایر بخش‌ها.
                    const modal = findVisibleElement('.modal-overlay');
                    if (modal) {
                        const closeBtn =
                            modal.querySelector('.modal-header button') ||
                            modal.querySelector('button');
                        if (closeBtn) closeBtn.click();
                        else modal.click();
                        ensureHistoryEntry();
                        return;
                    }

                    // 5) دکمه‌ی Back اختصاصی یک بخش (اگر وجود داشته باشد).
                    // فقط دکمه‌های صریحاً نام‌گذاری‌شده‌ی «بازگشت/برگشت» را می‌گیریم
                    // تا دکمه‌های «قبلی» مربوط به فرم‌ها یا کنترل‌های دیگر، مسیر صفحه را خراب نکنند.
                    const backButtons = Array.from(document.querySelectorAll('button')).filter(btn => {
                        const txt = (btn.textContent || '').trim();
                        const r = btn.getBoundingClientRect();
                        const st = window.getComputedStyle(btn);
                        return r.width > 0 && r.height > 0 &&
                            st.display !== 'none' && st.visibility !== 'hidden' &&
                            st.pointerEvents !== 'none' &&
                            /^(بازگشت|برگشت|←\s*بازگشت|←\s*برگشت|→\s*بازگشت|→\s*برگشت)$/.test(txt);
                    });

                    // اگر چند دکمه‌ی برگشت هم‌زمان در DOM دیده شوند، دکمه‌ی
                    // داخلی‌ترین صفحه را انتخاب کن؛ این باعث می‌شود Back مرحله‌به‌مرحله
                    // از زیرصفحه به صفحه‌ی والد برگردد، نه اینکه یک دکمه‌ی بیرونی زودتر اجرا شود.
                    const elementDepth = (el) => {
                        let depth = 0;
                        while (el && el !== document.body) {
                            depth++;
                            el = el.parentElement;
                        }
                        return depth;
                    };
                    backButtons.sort((a, b) => elementDepth(b) - elementDepth(a));
                    const backBtn = backButtons[0];
                    if (backBtn) {
                        backBtn.click();
                        ensureHistoryEntry();
                        return;
                    }

                    // 6) در نهایت، تاریخچه‌ی واقعی تب‌ها.
                    goToPreviousTab();
                    ensureHistoryEntry();
                };

                const onPopState = () => {
                    // قبل از اجرای منطق بازگشت، فوراً یک ورودی نگهبان بساز.
                    // بعضی مرورگرهای موبایل اگر ابتدا مودال/تب تغییر کند، ممکن است
                    // قبل از pushState بعدی صفحه را ببندند یا به صفحه‌ی قبلی خارج از برنامه بروند.
                    try {
                        window.history.pushState({ __classAppBack: true }, '', window.location.href);
                    } catch (e) {}

                    // سپس فقط یک مرحله داخل خود برنامه عقب برو.
                    // هیچ کاشی‌ای نباید با Back از برنامه خارج شود؛ مقصد نهایی داشبورد است.
                    handleBack();

                    // اطمینان دوباره از باقی ماندن ورودی نگهبان، بدون تغییر آدرس.
                    try {
                        if (!window.history.state || window.history.state.__classAppBack !== true) {
                            window.history.pushState({ __classAppBack: true }, '', window.location.href);
                        }
                    } catch (e) {}
                };

                window.addEventListener('popstate', onPopState);
                return () => window.removeEventListener('popstate', onPopState);
            }, []);

            const changeTab = (nextTab) => {
                if (!nextTab || nextTab === tab) return;

                if (!backHandlingRef.current) {
                    const history = tabHistoryRef.current;

                    // اگر کاربر از مسیر Back برگشته و دوباره وارد یک تب جدید شده،
                    // مسیر آینده حذف می‌شود و مسیر جدید از همین نقطه ادامه پیدا می‌کند.
                    if (history[history.length - 1] !== nextTab) {
                        history.push(nextTab);
                    }
                }

                setTab(nextTab);
            };

            React.useEffect(() => {
                let cancelled = false;
                getStorageEstimate().then(est => {
                    if (!cancelled) setStorageEstimate(est);
                });
                return () => { cancelled = true; };
            }, [data]);

            const nearFull = !!storageEstimate && storageEstimate.percent >= 70;
            const critical = !!storageEstimate && storageEstimate.percent >= 90;

            const tabs = [
                { key: 'dashboard', label: '📊 داشبورد' },
                { key: 'students', label: '👨‍🎓 دانش‌آموزان' },
                { key: 'scores', label: '🏆 امتیازدهی' },
                { key: 'exams', label: '📋 آزمون‌ها' },
                { key: 'attendancePro', label: '✅ حضور و غیاب' },
                { key: 'tasks', label: '📚 تکالیف و موارد تحویلی' },
                { key: 'performance', label: '📝 سطوح عملکرد' },
                { key: 'parentMeetings', label: '👨‍👩‍👧 جلسات اولیا' },
                { key: 'teacherNotes', label: '🗒️ دفترچه یادداشت معلم' },
                { key: 'backup', label: '💾 پشتیبان‌گیری' },
                { key: 'aboutMe', label: '🙋 درباره من' },
            ];

            return React.createElement('div', { className: 'container' },
                React.createElement(AppHeader, {
                    title: '📚 دفتر کلاس',
                    user,
                    onLogout: onLogout || (() => setUser(null)),
                    onWeekly: () => setWeeklyOpen(true)
                }),
                !storageOk &&
                React.createElement('div', {
                    className: 'card',
                    style: { background: '#FFE1E8', border: '1px solid #FF6B81' }
                },
                    React.createElement('div', { style: { fontWeight: 700, color: '#FF6B81', marginBottom: 4 } },
                        '⚠️ حافظه‌ی مرورگر در دسترس نیست'),
                    React.createElement('div', { className: 'text-small', style: { color: '#FF6B81' } },
                        'به همین دلیل هیچ چیزی (آزمون، حضور و غیاب) ذخیره نمی‌شود. اگر این فایل را مستقیم از مدیریت فایل گوشی یا داخل یک اپ دیگر (مثل تلگرام) باز کرده‌اید، آن را در مرورگر اصلی (کروم/سافاری) باز کنید یا حالت مرور خصوصی/ناشناس را خاموش کنید.')
                ),
                storageOk && nearFull &&
                React.createElement('div', {
                    className: 'card',
                    style: {
                        background: critical ? '#FFE1E8' : '#FCF3D9',
                        border: `1px solid ${critical ? '#FF6B81' : '#FFB454'}`
                    }
                },
                    React.createElement('div', {
                        style: { fontWeight: 700, color: critical ? '#FF6B81' : '#FFB454', marginBottom: 4 }
                    }, critical ?
                        '🚫 حافظه‌ی گوشی تقریباً پر شده!' :
                        '⚠️ حافظه‌ی گوشی در حال پر شدن است'),
                    React.createElement('div', {
                        className: 'text-small',
                        style: { color: critical ? '#FF6B81' : '#FFB454' }
                    }, critical ?
                        `${storageEstimate.percent}٪ از فضای مجاز مرورگر برای این اپ استفاده شده و ممکن است ثبت‌های جدید (آزمون، حضور و غیاب، دانش‌آموز) ذخیره نشوند. همین حالا از تب «پشتیبان‌گیری» یک فایل بکاپ بگیرید و در صورت امکان فضای خالی گوشی را زیاد کنید یا عکس‌های آزمون‌های قدیمی‌تر را حذف کنید.` :
                        `${storageEstimate.percent}٪ از فضای مجاز مرورگر برای این اپ استفاده شده. پیشنهاد می‌شود از تب «پشتیبان‌گیری» یک بکاپ بگیرید تا در صورت پر شدن حافظه چیزی از دست نرود.`)
                ),
                React.createElement('div', { className: 'card class-manager-card' },
                    React.createElement('div', { className: 'flex flex-wrap items-center gap-8' },
                        React.createElement('strong', null, '🏫 کلاس فعال:'),
                        React.createElement('select', { value: activeClass.id, onChange: e => switchClass(e.target.value), style: { flex: 1, minWidth: 130 } },
                            classes.map(c => React.createElement('option', { key: c.id, value: c.id }, c.name))),
                        React.createElement('button', { className: 'btn-primary', onClick: createClass }, '＋ کلاس جدید'),
                        React.createElement('button', { className: 'btn-ghost', onClick: renameClass, title: 'تغییر نام کلاس' }, '✏️'),
                        classes.length > 1 ? React.createElement('button', { className: 'btn-ghost', onClick: deleteClass, title: 'حذف کلاس' }, '🗑️') : null
                    )
                ),
                React.createElement('div', { className: `tab-bar ${dashboardOverlayOpen ? 'dashboard-tab-hidden' : ''}` },
                    tabs.map(t =>
                        React.createElement('button', {
                            key: t.key,
                            onClick: () => changeTab(t.key),
                            className: tab === t.key ? 'active' : ''
                        }, t.label)
                    )
                ),
                ['tasks', 'exams', 'scores'].includes(tab) && React.createElement('div', { className: 'card', style: { display: 'flex', justifyContent: 'center' } },
                    React.createElement('button', { onClick: async () => {
                        const req = buildRosterRequest(tab, data);
                        if (!req) return showToast('داده‌ای برای این لیست وجود ندارد', 'error');
                        try { await exportRosterPng(req); showToast('تصویر لیست آماده شد'); } catch (e) { showToast('خطا در ساخت تصویر', 'error'); }
                    } }, '📷 تصویر لیست برای والدین (PNG)')),
                tab === 'dashboard' && React.createElement(Dashboard, { data, save, showToast, onOverlayChange: setDashboardOverlayOpen }),
                tab === 'students' && React.createElement(Students, { data, save, showToast }),
                tab === 'scores' && React.createElement(StudentScores, { data, save, showToast }),
                tab === 'exams' && React.createElement(Exams, { data, save, showToast, initialSelection: examEntryContext, onInitialSelectionConsumed: () => setExamEntryContext(null) }),
                tab === 'attendancePro' && React.createElement(AttendanceHub, { key: activeClass.id, data, save, showToast }),
                tab === 'tasks' && React.createElement(HomeworkTasks, { data, save, showToast }),
                tab === 'performance' && React.createElement(PerformanceLevels, { data, save, showToast }),
                tab === 'parentMeetings' && React.createElement(ParentMeetings, { data, save, showToast }),
                tab === 'teacherNotes' && React.createElement(TeacherNotes, { data, save, showToast }),
                tab === 'backup' && React.createElement(Backup, { data: { ...rootData, classes, activeClassId: activeClass.id }, save: saveRoot, showToast }),
                tab === 'aboutMe' && React.createElement(AboutMe, { data, save }),
                weeklyOpen && React.createElement(WeeklySchedule, {
                    data,
                    save,
                    showToast,
                    onClose: () => setWeeklyOpen(false)
                })
            );
        }

        // ============================================================
        // جلسات عمومی با اولیا
        // ============================================================
        function ParentMeetings({ data, save, showToast }) {
            const meetings = Array.isArray(data.parentMeetings) ? data.parentMeetings : [];
            const blank = { date: todayISO(), topic: '', presentCount: '', absentCount: '', absentNames: '', summary: '', suggestions: '' };
            const [form, setForm] = React.useState(blank);
            const [editingId, setEditingId] = React.useState(null);
            const setField = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
            const reset = () => { setForm({ ...blank, date: todayISO() }); setEditingId(null); };
            const saveMeeting = () => {
                if (!form.date) return showToast('تاریخ برگزاری را وارد کنید', 'error');
                if (!form.topic.trim()) return showToast('موضوع جلسه را وارد کنید', 'error');
                const meeting = {
                    id: editingId || uid(), date: form.date, topic: form.topic.trim(),
                    presentCount: Number(form.presentCount) || 0, absentCount: Number(form.absentCount) || 0, absentNames: form.absentNames.trim(),
                    summary: form.summary.trim(), suggestions: form.suggestions.trim()
                };
                const next = editingId ? meetings.map(m => m.id === editingId ? meeting : m) : [...meetings, meeting];
                const ok = save({ ...data, parentMeetings: next });
                if (ok !== false) { showToast(editingId ? '✏️ اطلاعات جلسه ویرایش شد' : '✅ جلسه ثبت شد'); reset(); }
            };
            const edit = m => { setEditingId(m.id); setForm({ date:m.date||todayISO(), topic:m.topic||'', presentCount:m.presentCount??'', absentCount:m.absentCount??'', absentNames:m.absentNames||'', summary:m.summary||'', suggestions:m.suggestions||'' }); window.scrollTo({top:0,behavior:'smooth'}); };
            const remove = id => { if (!confirm('این جلسه حذف شود؟')) return; const ok=save({...data,parentMeetings:meetings.filter(m=>m.id!==id)}); if(ok!==false){if(editingId===id)reset();showToast('🗑️ جلسه حذف شد');} };
            const sorted = [...meetings].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
            const inputStyle={width:'100%',boxSizing:'border-box',padding:'10px 12px',border:'1px solid #D8D3C7',borderRadius:8,background:'#fff',fontFamily:"'Vazirmatn', Tahoma, sans-serif"};
            const labelStyle={display:'block',fontWeight:700,marginBottom:6,fontSize:13};
            return React.createElement('div', null,
                React.createElement('div',{className:'card'},
                    React.createElement('h4',{className:'mb-8'},editingId?'✏️ ویرایش جلسه عمومی اولیا':'👨‍👩‍👧 ثبت جلسه عمومی با اولیا'),
                    React.createElement('div',{className:'flex flex-wrap gap-8 mb-8'},
                        React.createElement('div',{style:{flex:'1 1 180px'}},React.createElement('label',{style:labelStyle},'تاریخ برگزاری'),React.createElement(JalaliDatePicker,{value:form.date,onChange:v=>setField('date',v)})),
                        React.createElement('div',{style:{flex:'2 1 300px'}},React.createElement('label',{style:labelStyle},'موضوع جلسه'),React.createElement('input',{value:form.topic,onChange:e=>setField('topic',e.target.value),placeholder:'موضوع جلسه',style:inputStyle}))
                    ),
                    React.createElement('div',{className:'flex flex-wrap gap-8 mb-8'},
                        React.createElement('div',{style:{flex:'1 1 150px'}},React.createElement('label',{style:labelStyle},'تعداد حاضرین'),React.createElement('input',{type:'number',min:0,value:form.presentCount,onChange:e=>setField('presentCount',e.target.value),placeholder:'۰',style:inputStyle})),
                        React.createElement('div',{style:{flex:'1 1 150px'}},React.createElement('label',{style:labelStyle},'تعداد غایبین'),React.createElement('input',{type:'number',min:0,value:form.absentCount,onChange:e=>setField('absentCount',e.target.value),placeholder:'۰',style:inputStyle}))
                    ),
                    React.createElement('div',{className:'mb-8'},React.createElement('label',{style:labelStyle},'اسامی غایبین جلسه'),React.createElement('textarea',{rows:3,value:form.absentNames,onChange:e=>setField('absentNames',e.target.value),placeholder:'نام و نام خانوادگی اولیای غایب را وارد کنید...',style:{...inputStyle,resize:'vertical',lineHeight:1.8}})),
                    React.createElement('div',{className:'mb-8'},React.createElement('label',{style:labelStyle},'خلاصه مباحث مطرح شده'),React.createElement('textarea',{rows:5,value:form.summary,onChange:e=>setField('summary',e.target.value),placeholder:'مهم‌ترین مطالب، تصمیم‌ها و موارد مطرح‌شده...',style:{...inputStyle,resize:'vertical',lineHeight:1.8}})),
                    React.createElement('div',{className:'mb-8'},React.createElement('label',{style:labelStyle},'نظرها و پیشنهادهای اولیا'),React.createElement('textarea',{rows:5,value:form.suggestions,onChange:e=>setField('suggestions',e.target.value),placeholder:'نظرات، پیشنهادها و درخواست‌های اولیا...',style:{...inputStyle,resize:'vertical',lineHeight:1.8}})),
                    React.createElement('div',{className:'flex flex-wrap gap-4'},React.createElement('button',{onClick:saveMeeting,className:'btn-primary'},editingId?'💾 ذخیره تغییرات':'➕ ثبت جلسه'),editingId&&React.createElement('button',{onClick:reset,className:'btn-secondary'},'انصراف'))
                ),
                React.createElement('div',{className:'card'},
                    React.createElement('h4',{className:'mb-8'},`📚 سوابق جلسات عمومی با اولیا (${meetings.length})`),
                    sorted.length===0?React.createElement('div',{className:'empty-state'},React.createElement('p',null,'هنوز جلسه‌ای ثبت نشده است.')):
                    sorted.map(m=>React.createElement('div',{key:m.id,style:{border:'1px solid #E9DFF0',borderRadius:12,padding:16,marginBottom:12,background:'#FCFBF7'}},
                        React.createElement('div',{className:'flex flex-wrap gap-8',style:{alignItems:'center',marginBottom:10}},
                            React.createElement('div',{style:{flex:1}},React.createElement('div',{style:{fontWeight:800,fontSize:16}},m.topic),React.createElement('div',{className:'text-muted text-small',style:{marginTop:4}},`📅 ${getShamsiWithDay(m.date)}`)),
                            React.createElement('div',{className:'text-small'},`✅ حاضر: ${m.presentCount||0}   ❌ غایب: ${m.absentCount||0}`)
                        ),
                        m.absentNames&&React.createElement('div',{style:{marginTop:10,lineHeight:1.9}},React.createElement('b',null,'👤 اسامی غایبین'),React.createElement('div',null,m.absentNames)),
                        m.summary&&React.createElement('div',{style:{marginTop:10,lineHeight:1.9}},React.createElement('b',null,'📝 خلاصه مباحث'),React.createElement('div',null,m.summary)),
                        m.suggestions&&React.createElement('div',{style:{marginTop:10,lineHeight:1.9}},React.createElement('b',null,'💬 نظرها و پیشنهادهای اولیا'),React.createElement('div',null,m.suggestions)),
                        React.createElement('div',{className:'flex gap-4',style:{marginTop:12}},React.createElement('button',{onClick:()=>edit(m),className:'btn-secondary'},'✏️ ویرایش'),React.createElement('button',{onClick:()=>remove(m.id),className:'btn-danger'},'🗑️ حذف'))
                    ))
                )
            );
        }

        // ============================================================
        // دفترچه یادداشت معلم
        // ============================================================
        function TeacherNotes({ data, save, showToast }) {
            const notes = Array.isArray(data.teacherNotes) ? data.teacherNotes : [];
            const blank = { date: todayISO(), text: '' };
            const [form, setForm] = React.useState(blank);
            const [editingId, setEditingId] = React.useState(null);

            const setField = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
            const reset = () => {
                setForm({ ...blank, date: todayISO() });
                setEditingId(null);
            };

            const saveNote = () => {
                if (!form.date) return showToast('تاریخ یادداشت را وارد کنید', 'error');
                if (!form.text.trim()) return showToast('متن یادداشت را وارد کنید', 'error');

                const note = {
                    id: editingId || uid(),
                    date: form.date,
                    text: form.text.trim()
                };
                const next = editingId
                    ? notes.map(n => n.id === editingId ? note : n)
                    : [...notes, note];
                const ok = save({ ...data, teacherNotes: next });
                if (ok !== false) {
                    showToast(editingId ? '✏️ یادداشت ویرایش شد' : '✅ یادداشت ثبت شد');
                    reset();
                }
            };

            const edit = note => {
                setEditingId(note.id);
                setForm({ date: note.date || todayISO(), text: note.text || '' });
                window.scrollTo({ top: 0, behavior: 'smooth' });
            };

            const remove = id => {
                if (!confirm('این یادداشت حذف شود؟')) return;
                const ok = save({ ...data, teacherNotes: notes.filter(n => n.id !== id) });
                if (ok !== false) {
                    if (editingId === id) reset();
                    showToast('🗑️ یادداشت حذف شد');
                }
            };

            const sorted = [...notes].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
            const inputStyle = {
                width: '100%', boxSizing: 'border-box', padding: '10px 12px',
                border: '1px solid #D8D3C7', borderRadius: 8, background: '#fff',
                fontFamily: "'Vazirmatn', Tahoma, sans-serif"
            };
            const labelStyle = { display: 'block', fontWeight: 700, marginBottom: 6, fontSize: 13 };

            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, editingId ? '✏️ ویرایش یادداشت' : '🗒️ یادداشت جدید'),
                    React.createElement('div', { className: 'mb-8' },
                        React.createElement('label', { style: labelStyle }, 'تاریخ'),
                        React.createElement(JalaliDatePicker, {
                            value: form.date,
                            onChange: v => setField('date', v)
                        })
                    ),
                    React.createElement('div', { className: 'mb-8' },
                        React.createElement('label', { style: labelStyle }, 'متن یادداشت'),
                        React.createElement('textarea', {
                            rows: 7,
                            value: form.text,
                            onChange: e => setField('text', e.target.value),
                            placeholder: 'یادداشت خود را برای این تاریخ بنویسید...',
                            style: { ...inputStyle, resize: 'vertical', lineHeight: 1.9 }
                        })
                    ),
                    React.createElement('div', { className: 'flex flex-wrap gap-4' },
                        React.createElement('button', { onClick: saveNote, className: 'btn-primary' }, editingId ? '💾 ذخیره تغییرات' : '➕ ثبت یادداشت'),
                        editingId && React.createElement('button', { onClick: reset, className: 'btn-secondary' }, 'انصراف')
                    )
                ),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, `📚 دفترچه یادداشت‌ها (${notes.length})`),
                    sorted.length === 0
                        ? React.createElement('div', { className: 'empty-state' }, React.createElement('p', null, 'هنوز یادداشتی ثبت نشده است.'))
                        : sorted.map(note =>
                            React.createElement('div', {
                                key: note.id,
                                style: {
                                    border: '1px solid #E9DFF0', borderRadius: 12, padding: 16,
                                    marginBottom: 12, background: '#FCFBF7'
                                }
                            },
                                React.createElement('div', {
                                    className: 'flex flex-wrap gap-8',
                                    style: { alignItems: 'center', marginBottom: 10 }
                                },
                                    React.createElement('div', { style: { flex: 1 } },
                                        React.createElement('div', { className: 'text-muted text-small' }, `📅 ${getShamsiWithDay(note.date)}`)
                                    )
                                ),
                                React.createElement('div', { style: { whiteSpace: 'pre-wrap', lineHeight: 1.9 } }, note.text),
                                React.createElement('div', { className: 'flex gap-4', style: { marginTop: 12 } },
                                    React.createElement('button', { onClick: () => edit(note), className: 'btn-secondary' }, '✏️ ویرایش'),
                                    React.createElement('button', { onClick: () => remove(note.id), className: 'btn-danger' }, '🗑️ حذف')
                                )
                            )
                        )
                )
            );
        }

        // ============================================================
        // برنامه هفتگی کلاس
        // ============================================================
        function WeeklySchedule({ data, save, showToast, onClose }) {
            const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه'];
            const bells = [
                { key: 'bell1', label: 'زنگ اول', icon: '🌱' },
                { key: 'bell2', label: 'زنگ دوم', icon: '📚' },
                { key: 'bell3', label: 'زنگ سوم', icon: '✏️' },
                { key: 'bell4', label: 'زنگ چهارم', icon: '🎨' },
                { key: 'bell5', label: 'زنگ پنجم', icon: '⭐' },
                { key: 'prayer', label: 'زنگ نماز', icon: '🕌' }
            ];

            const initial = {};
            days.forEach(day => {
                initial[day] = {};
                bells.forEach(b => {
                    initial[day][b.key] = (data.weeklySchedule &&
                        data.weeklySchedule[day] &&
                        data.weeklySchedule[day][b.key]) || '';
                });
            });

            const initialFontSizes = {};
            days.forEach(day => {
                bells.forEach(b => {
                    const key = day + '|' + b.key;
                    initialFontSizes[key] = (data.weeklyScheduleFontSizes && data.weeklyScheduleFontSizes[key]) || 13;
                });
            });

            const [schedule, setSchedule] = React.useState(initial);
            const [saving, setSaving] = React.useState(false);
            const [fontSizes, setFontSizes] = React.useState(initialFontSizes);
            const [activeCell, setActiveCell] = React.useState(null); // { day, bellKey }
            const cellRefs = React.useRef({});

            const cellKey = (day, bellKey) => day + '|' + bellKey;
            const getFontSize = (day, bellKey) => fontSizes[cellKey(day, bellKey)] || 13;

            // حداقل و حداکثر مجاز برای تناسب خودکار فونت
            const MIN_AUTO_FONT_SIZE = 9;
            const MAX_AUTO_FONT_SIZE = 28;

            // تناسب خودکار فونت: اگر متن از کادر بزرگ‌تر شده باشد، فونت را
            // قدم‌به‌قدم کوچک می‌کند تا کامل داخل کادر جا شود.
            const autoFitFontSize = (el, day, bellKey) => {
                if (!el) return;
                const k = cellKey(day, bellKey);
                let size = fontSizes[k] || 13;
                if (size > MAX_AUTO_FONT_SIZE) size = MAX_AUTO_FONT_SIZE;

                el.style.fontSize = size + 'px';
                let guard = 0;
                while (
                    size > MIN_AUTO_FONT_SIZE &&
                    (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) &&
                    guard < 40
                ) {
                    size -= 1;
                    el.style.fontSize = size + 'px';
                    guard++;
                }

                if (size !== (fontSizes[k] || 13)) {
                    setFontSizes(prev => ({ ...prev, [k]: size }));
                }
            };

            // یک‌بار بعد از باز شدن برنامه، متن‌های از پیش پرشده را هم با کادرشان تنظیم کن
            React.useEffect(() => {
                Object.keys(cellRefs.current).forEach(k => {
                    const el = cellRefs.current[k];
                    if (!el) return;
                    const idx = k.indexOf('|');
                    const day = k.slice(0, idx);
                    const bellKey = k.slice(idx + 1);
                    autoFitFontSize(el, day, bellKey);
                });
                // eslint-disable-next-line react-hooks/exhaustive-deps
            }, []);

            const updateCell = (day, bell, value) => {
                setSchedule(prev => ({
                    ...prev,
                    [day]: { ...prev[day], [bell]: value }
                }));
            };

            const saveSchedule = () => {
                setSaving(true);
                const ok = save({ ...data, weeklySchedule: schedule, weeklyScheduleFontSizes: fontSizes });
                setTimeout(() => setSaving(false), 300);
                if (ok !== false) showToast('✅ برنامه هفتگی ذخیره شد و همیشه قابل مشاهده است');
            };

            const clearSchedule = () => {
                if (!confirm('همه برنامه هفتگی پاک شود؟')) return;
                const blank = {};
                days.forEach(day => {
                    blank[day] = {};
                    bells.forEach(b => blank[day][b.key] = '');
                });
                setSchedule(blank);
                const ok = save({ ...data, weeklySchedule: blank, weeklyScheduleFontSizes: fontSizes });
                if (ok !== false) showToast('🗑️ برنامه هفتگی پاک شد');
            };

            const baseInputStyle = {
                width: '100%',
                boxSizing: 'border-box',
                padding: '5px',
                border: '2px solid #9FF0E4',
                borderRadius: 12,
                background: '#FFFFFF',
                fontFamily: "'Vazirmatn', Tahoma, sans-serif",
                fontWeight: 700,
                lineHeight: 1.45,
                textAlign: 'center',
                resize: 'none',
                overflow: 'hidden',
                outline: 'none',
                color: '#1AA6A0',
                transition: 'all .18s ease',
                caretColor: '#E85D8E'
            };


            return React.createElement('div', {
                'data-app-overlay': 'budgeting',
                style: {
                    position: 'fixed',
                    inset: 0,
                    zIndex: 9999,
                    background: 'linear-gradient(135deg,#FFF3B8 0%,#DDF8FF 35%,#E8F8E9 68%,#FFE2F1 100%)',
                    padding: 0,
                    overflowY: 'auto'
                }
            },
                React.createElement('div', {
                    style: {
                        position: 'relative',
                        width: '100%',
                        minHeight: '100vh',
                        maxWidth: 'none',
                        margin: 0,
                        background: 'linear-gradient(145deg,rgba(255,255,255,.98),rgba(245,255,253,.97))',
                        padding: '16px clamp(7px, 2vw, 28px) 22px',
                        boxSizing: 'border-box',
                        borderRadius: 0,
                        overflow: 'hidden'
                    }
                },
                    React.createElement('div', { style: { position:'absolute', top:8, left:8, fontSize:28, opacity:.85, transform:'rotate(-8deg)' } }, '🌈'),
                    React.createElement('div', { style: { position:'absolute', top:18, right:12, fontSize:28, opacity:.8, transform:'rotate(8deg)' } }, '🎈'),
                    React.createElement('div', { style: { position:'absolute', bottom:10, left:10, fontSize:26, opacity:.7 } }, '🖍️'),
                    React.createElement('div', { style: { position:'absolute', bottom:12, right:12, fontSize:26, opacity:.7 } }, '🧸'),

                    React.createElement('div', {
                        className: 'flex items-center',
                        style: { justifyContent: 'space-between', gap: 8, marginBottom: 14, position:'relative', zIndex:1 }
                    },
                        React.createElement('div', {
                            style: {
                                display:'flex', alignItems:'center', gap:8,
                                background:'linear-gradient(90deg,#FFE66D,#FFB7D5)',
                                padding:'8px 13px', borderRadius:18,
                                boxShadow:'0 5px 15px rgba(60,150,140,.10)'
                            }
                        },
                            React.createElement('div', { style:{fontSize:30} }, '📅'),
                            React.createElement('h3', {
                                style: { margin: 0, fontSize: 'clamp(21px, 4vw, 30px)', fontWeight: 900, color: '#1AA6A0' }
                            }, 'برنامه هفتگی')
                        ),
                        React.createElement('button', {
                            onClick: onClose,
                            className: 'weekly-close-btn',
                            style: {
                                whiteSpace: 'nowrap',
                                background:'linear-gradient(135deg,#D8F9F0,#D7EEFF)', color:'#1AA6A0', border:'2px solid #9FF0E4',
                                borderRadius:14, fontWeight:800
                            }
                        }, '✕ بستن')
                    ),

                    React.createElement('div', {
                        className: 'weekly-table-wrap',
                        style: {
                            overflow: 'hidden',
                            border: '3px solid #7BE0D6',
                            borderRadius: 16,
                            background: '#fff',
                            boxShadow:'0 10px 25px rgba(43,179,163,.12)',
                            position:'relative',
                            zIndex:1
                        }
                    },
                        React.createElement('table', {
                            style: {
                                width: '100%',
                                borderCollapse: 'separate',
                                borderSpacing: 0,
                                tableLayout: 'fixed'
                            }
                        },
                            React.createElement('thead', null,
                                React.createElement('tr', null,
                                    React.createElement('th', {
                                        style: { border:'1px solid #9FF0E4', padding:'8px 3px', background:'linear-gradient(135deg,#2FBFAE,#4FC9BE)', color:'#fff', width:'13%', fontSize:12, fontWeight:900 }
                                    }, 'روز'),
                                    bells.map((b, i) =>
                                        React.createElement('th', {
                                            key: b.key,
                                            style: {
                                                border:'1px solid #9FF0E4', padding:'7px 2px',
                                                background: i % 2 === 0 ? 'linear-gradient(135deg,#22B8B0,#3FD6C5)' : 'linear-gradient(135deg,#8A7BEF,#B79CFF)',
                                                color:'#fff', fontSize:10, lineHeight:1.25, fontWeight:900
                                            }
                                        },
                                            React.createElement('div',{style:{fontSize:15, marginBottom:2}},b.icon),
                                            b.label
                                        )
                                    )
                                )
                            ),
                            React.createElement('tbody', null,
                                days.map((day, rowIndex) =>
                                    React.createElement('tr', { key: day },
                                        React.createElement('th', {
                                            style: {
                                                border:'1px solid #C9F5EE', padding:'7px 2px',
                                                background: rowIndex % 2 === 0 ? '#FFF1A8' : '#E3FFFA',
                                                color:'#2A9D96', fontWeight:900, fontSize:11,
                                                whiteSpace:'nowrap'
                                            }
                                        }, day),
                                        bells.map((b, colIndex) =>
                                            React.createElement('td', {
                                                key: b.key,
                                                style: {
                                                    border:'1px solid #C9F5EE', padding:4,
                                                    verticalAlign:'middle',
                                                    background: colIndex % 2 === 0 ? '#FFFDF2' : '#F2FFFD'
                                                }
                                            },
                                                React.createElement('div', {
                                                    contentEditable: true,
                                                    suppressContentEditableWarning: true,
                                                    role: 'textbox',
                                                    'aria-label': `${day} - ${b.label}`,
                                                    onInput: e => {
                                                        const el = e.currentTarget;
                                                        updateCell(day, b.key, el.innerText);
                                                        autoFitFontSize(el, day, b.key);
                                                    },
                                                    onFocus: () => setActiveCell({ day, bellKey: b.key }),
                                                    onClick: () => setActiveCell({ day, bellKey: b.key }),
                                                    ref: el => {
                                                        cellRefs.current[cellKey(day, b.key)] = el;
                                                        if (el && el.innerText !== schedule[day][b.key]) {
                                                            el.innerText = schedule[day][b.key];
                                                        }
                                                    },
                                                    style: {
                                                        ...baseInputStyle,
                                                        height: Math.max(68, Math.round(getFontSize(day, b.key) * 4.4)),
                                                        minHeight: Math.max(68, Math.round(getFontSize(day, b.key) * 4.4)),
                                                        fontSize: getFontSize(day, b.key),
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'center',
                                                        whiteSpace: 'pre-wrap',
                                                        wordBreak: 'normal',
                                                        overflowWrap: 'break-word',
                                                        overflow: 'hidden',
                                                        cursor: 'text',
                                                        userSelect: 'text',
                                                        boxShadow: (activeCell && activeCell.day === day && activeCell.bellKey === b.key)
                                                            ? '0 0 0 2px #FFB454 inset' : 'none'
                                                    }
                                                })
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    ),

                    React.createElement('div', {
                        className: 'flex flex-wrap gap-8',
                        style: { marginTop: 13, justifyContent:'center', position:'relative', zIndex:1 }
                    },
                        React.createElement('button', {
                            onClick: saveSchedule,
                            className: 'weekly-action-btn weekly-save-btn',
                            style: {
                                fontSize:13, padding:'10px 16px', borderRadius:14,
                                background:'linear-gradient(135deg,#FFB454,#FF8E5B)', color:'#fff',
                                border:'none', fontWeight:900, boxShadow:'0 6px 14px rgba(255,142,91,.25)'
                            }
                        }, saving ? '⏳ در حال ذخیره...' : '💾 ذخیره برنامه'),
                        React.createElement('button', {
                            onClick: clearSchedule,
                            className: 'weekly-action-btn weekly-clear-btn',
                            style: {
                                fontSize:13, padding:'10px 16px', borderRadius:14,
                                background:'linear-gradient(135deg,#FFD7E4,#FFC2D1)', color:'#8B4058',
                                border:'none', fontWeight:900, boxShadow:'0 6px 14px rgba(214,104,133,.16)'
                            }
                        }, '🗑️ پاک کردن برنامه')
                    )
                )
            );
        }

        // ============================================================
        // بودجه‌بندی دروس
        // ============================================================
        function Budgeting({ data, save, showToast, onClose }) {
            const MONTHS = [
                { key: 'mehr', label: 'مهر' },
                { key: 'aban', label: 'آبان' },
                { key: 'azar', label: 'آذر' },
                { key: 'dey', label: 'دی' },
                { key: 'bahman', label: 'بهمن' },
                { key: 'esfand', label: 'اسفند' },
                { key: 'farvardin', label: 'فروردین' },
                { key: 'ordibehesht', label: 'اردیبهشت' },
                { key: 'khordad', label: 'خرداد' }
            ];
            const TERMS = [
                { key: 't1', label: 'نوبت اول', months: MONTHS.slice(0, 4) },
                { key: 't2', label: 'نوبت دوم', months: MONTHS.slice(4) }
            ];
            const HALVES = [
                { key: 'h1', label: 'نیمه اول' },
                { key: 'h2', label: 'نیمه دوم' }
            ];
            const leafCols = [];
            MONTHS.forEach(m => {
                HALVES.forEach(h => {
                    leafCols.push({ key: m.key + '_' + h.key, month: m, half: h });
                });
            });

            // ترتیب جدول عمودی از بالا به پایین: نوبت اول (مهر) تا نوبت دوم (خرداد).
            // یعنی ترتیب قبلی که جدول را وارونه نمایش می‌داد، به حالت طبیعی برگردانده شده است.
            const TERMS_DISPLAY = TERMS;
            const HALVES_DISPLAY = HALVES;
            const verticalRows = [];
            TERMS_DISPLAY.forEach(term => {
                const monthsDisplay = term.months;
                monthsDisplay.forEach((m, mIdx) => {
                    HALVES_DISPLAY.forEach((h, hIdx) => {
                        verticalRows.push({
                            term, month: m, half: h,
                            colKey: m.key + '_' + h.key,
                            isFirstOfTerm: mIdx === 0 && hIdx === 0,
                            isFirstOfMonth: hIdx === 0
                        });
                    });
                });
            });

            const defaultSubjects = () => Array.from({ length: 6 }, () => ({ id: uid(), name: '' }));

            const initialSubjects = (data.budgeting && Array.isArray(data.budgeting.subjects) && data.budgeting.subjects.length)
                ? data.budgeting.subjects
                : defaultSubjects();
            const initialValues = (data.budgeting && data.budgeting.values) ? data.budgeting.values : {};
            const initialCompleted = (data.budgeting && data.budgeting.completed) ? data.budgeting.completed : {};

            const [subjects, setSubjects] = React.useState(initialSubjects);
            const [values, setValues] = React.useState(initialValues);
            const [completed, setCompleted] = React.useState(initialCompleted);
            const [saving, setSaving] = React.useState(false);
            const [fontSizes, setFontSizes] = React.useState(data.budgetingFontSizes || {});
            const [activeCell, setActiveCell] = React.useState(null);
            const [selectedSubjectId, setSelectedSubjectId] = React.useState(null);
            const [orientation, setOrientation] = React.useState('vertical'); // 'vertical' | 'horizontal'
            const [editMode, setEditMode] = React.useState(false);

            // ذخیره خودکار بودجه‌بندی پس از مکث کوتاه در ویرایش
            React.useEffect(() => {
                const timer = setTimeout(() => {
                    const cleanSubjects = subjects.map(s => ({ id: s.id, name: (s.name || '').trim() || 'بدون نام' }));
                    setSaving(true);
                    save({
                        ...data,
                        budgeting: { subjects: cleanSubjects, values, completed },
                        budgetingFontSizes: fontSizes
                    });
                    setSaving(false);
                }, 450);
                return () => clearTimeout(timer);
                // فقط تغییرات قابل ویرایش بودجه‌بندی محرک ذخیره هستند.
                // eslint-disable-next-line react-hooks/exhaustive-deps
            }, [subjects, values, completed, fontSizes]);

            const cellKey = (subjectId, colKey) => subjectId + '|' + colKey;
            const getFontSize = (subjectId, colKey) => fontSizes[cellKey(subjectId, colKey)] || 12;
            const getValue = (subjectId, colKey) => (values[subjectId] && values[subjectId][colKey]) || '';

            const updateCell = (subjectId, colKey, val) => {
                setValues(prev => ({
                    ...prev,
                    [subjectId]: { ...prev[subjectId], [colKey]: val }
                }));
            };

            const toggleCompleted = (subjectId, colKey) => {
                const k = cellKey(subjectId, colKey);
                setCompleted(prev => ({ ...prev, [k]: !prev[k] }));
            };

            const renameSubject = (subjectId, name) => {
                if (!editMode) return;
                setSubjects(prev => prev.map(s => s.id === subjectId ? { ...s, name } : s));
            };

            const addSubject = () => {
                if (!editMode) return;
                const newId = uid();
                setSubjects(prev => [...prev, { id: newId, name: '' }]);
                setSelectedSubjectId(newId);
            };

            const removeSubject = (subjectId) => {
                if (!editMode) return;
                if (!confirm('این درس از بودجه‌بندی حذف شود؟')) return;
                setSubjects(prev => prev.filter(s => s.id !== subjectId));
                setValues(prev => {
                    const next = { ...prev };
                    delete next[subjectId];
                    return next;
                });
                if (activeCell && activeCell.subjectId === subjectId) setActiveCell(null);
                if (selectedSubjectId === subjectId) setSelectedSubjectId(null);
            };

            const changeActiveFontSize = (delta) => {
                if (!editMode || !activeCell) return;
                const k = cellKey(activeCell.subjectId, activeCell.colKey);
                setFontSizes(prev => ({
                    ...prev,
                    [k]: Math.max(8, Math.min(26, (prev[k] || 12) + delta))
                }));
            };

            const setActiveFontSize = (value) => {
                if (!editMode || !activeCell) return;
                const k = cellKey(activeCell.subjectId, activeCell.colKey);
                setFontSizes(prev => ({ ...prev, [k]: value }));
            };

            const resetActiveFontSize = () => {
                if (!editMode || !activeCell) return;
                const k = cellKey(activeCell.subjectId, activeCell.colKey);
                setFontSizes(prev => ({ ...prev, [k]: 12 }));
            };

            const saveBudgeting = () => {
                setSaving(true);
                const cleanSubjects = subjects.map(s => ({ id: s.id, name: (s.name || '').trim() || 'بدون نام' }));
                const ok = save({
                    ...data,
                    budgeting: { subjects: cleanSubjects, values, completed },
                    budgetingFontSizes: fontSizes
                });
                setTimeout(() => setSaving(false), 300);
                if (ok !== false) showToast('✅ بودجه‌بندی ذخیره شد');
            };

            const clearBudgeting = () => {
                if (!confirm('کل جدول بودجه‌بندی (همه‌ی دروس و مقادیر) کامل پاک شود؟ این کار قابل بازگشت نیست.')) return;
                setSubjects([]);
                setValues({});
                setCompleted({});
                setFontSizes({});
                setActiveCell(null);
                setSelectedSubjectId(null);
                const ok = save({
                    ...data,
                    budgeting: { subjects: [], values: {}, completed: {} },
                    budgetingFontSizes: {}
                });
                if (ok !== false) showToast('🗑️ کل جدول بودجه‌بندی پاک شد');
            };

            const baseCellStyle = {
                width: '100%',
                height: '100%',
                boxSizing: 'border-box',
                padding: '3px 2px',
                border: '2px solid #9FF0E4',
                borderRadius: 8,
                background: '#FFFFFF',
                fontFamily: "'Vazirmatn', Tahoma, sans-serif",
                fontWeight: 700,
                textAlign: 'center',
                outline: 'none',
                color: '#1AA6A0',
                cursor: editMode ? 'text' : 'default',
                userSelect: 'text',
                whiteSpace: 'normal',
                wordBreak: 'break-word',
                overflow: 'hidden',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                lineHeight: 1.15
            };

            // ---------- تنظیمات جدول عمودی (پیش‌فرض، تمام‌عرض، بدون نیاز به اسکرول افقی) ----------
            const termColWidth = 24;
            const monthColWidth = 30;
            const halfColWidth = 34;
            const fixedColsWidth = termColWidth + monthColWidth + halfColWidth;
            const subjCount = Math.max(subjects.length, 1);
            const subjectColCss = `calc((100% - ${fixedColsWidth}px) / ${subjCount})`;

            // ---------- تنظیمات جدول افقی (قدیمی، با اسکرول افقی در صورت نیاز) ----------
            const subjectLabelColWidth = 48;
            const leafColWidth = 30;

            const renderVerticalTable = () => (
                React.createElement('div', {
                    className: 'weekly-table-wrap',
                    style: {
                        overflowX: 'hidden',
                        overflowY: 'visible',
                        border: '3px solid #7BE0D6',
                        borderRadius: 16,
                        background: '#fff',
                        boxShadow: '0 10px 25px rgba(43,179,163,.12)',
                        position: 'relative',
                        zIndex: 1,
                        width: '100%'
                    }
                },
                    React.createElement('table', {
                        style: {
                            borderCollapse: 'separate',
                            borderSpacing: 0,
                            tableLayout: 'fixed',
                            width: '100%'
                        }
                    },
                        React.createElement('colgroup', null,
                            React.createElement('col', { style: { width: termColWidth } }),
                            React.createElement('col', { style: { width: monthColWidth } }),
                            React.createElement('col', { style: { width: halfColWidth } }),
                            subjects.map(s => React.createElement('col', { key: s.id, style: { width: subjectColCss } }))
                        ),
                        React.createElement('thead', null,
                            React.createElement('tr', null,
                                React.createElement('th', {
                                    colSpan: 3,
                                    style: {
                                        position: 'sticky', top: 0, right: 0, zIndex: 4,
                                        border: '1px solid #9FF0E4', padding: '8px 2px',
                                        background: 'linear-gradient(135deg,#2FBFAE,#4FC9BE)', color: '#fff',
                                        fontSize: 11, fontWeight: 900
                                    }
                                }, 'عنوان دروس'),
                                subjects.length
                                    ? subjects.map(s =>
                                        React.createElement('th', {
                                            key: s.id,
                                            style: {
                                                position: 'sticky', top: 0, zIndex: 3,
                                                border: '1px solid #9FF0E4', padding: '4px 2px',
                                                background: selectedSubjectId === s.id
                                                    ? 'linear-gradient(135deg,#FF9F6B,#FF6F91)'
                                                    : 'linear-gradient(135deg,#8A7BEF,#B79CFF)'
                                            }
                                        },
                                            React.createElement('input', {
                                                value: s.name,
                                                onChange: e => renameSubject(s.id, e.target.value),
                                                onFocus: () => setSelectedSubjectId(s.id),
                                                onClick: () => setSelectedSubjectId(s.id),
                                                placeholder: 'نام درس',
                                                style: {
                                                    width: '100%', minWidth: 0, boxSizing: 'border-box',
                                                    border: '1px solid #fff', borderRadius: 8,
                                                    padding: '4px 2px', fontSize: 10, fontWeight: 800,
                                                    color: '#2BB3A3', background: '#fff',
                                                    fontFamily: "'Vazirmatn', Tahoma, sans-serif",
                                                    outline: 'none', textAlign: 'center'
                                                }
                                            })
                                        )
                                    )
                                    : React.createElement('th', {
                                        style: {
                                            position: 'sticky', top: 0, zIndex: 3,
                                            border: '1px solid #9FF0E4', padding: '8px 4px',
                                            background: 'linear-gradient(135deg,#8A7BEF,#B79CFF)', color: '#fff',
                                            fontSize: 10, fontWeight: 800
                                        }
                                    }, '➕ اضافه کن')
                            )
                        ),
                        React.createElement('tbody', null,
                            verticalRows.map(r =>
                                React.createElement('tr', { key: r.colKey },
                                    r.isFirstOfTerm
                                        ? React.createElement('td', {
                                            rowSpan: r.term.months.length * 2,
                                            style: {
                                                position: 'sticky', right: 0, zIndex: 2,
                                                border: '1px solid #9FF0E4', padding: '2px 1px',
                                                background: 'linear-gradient(135deg,#8A7BEF,#B79CFF)', color: '#fff',
                                                fontSize: 10, fontWeight: 900, textAlign: 'center',
                                                writingMode: 'vertical-rl'
                                            }
                                        }, r.term.label)
                                        : null,
                                    r.isFirstOfMonth
                                        ? React.createElement('td', {
                                            rowSpan: 2,
                                            style: {
                                                position: 'sticky', right: termColWidth, zIndex: 2,
                                                border: '1px solid #C9F5EE', padding: '2px 1px',
                                                background: 'linear-gradient(135deg,#22B8B0,#3FD6C5)', color: '#fff',
                                                fontSize: 11, fontWeight: 900, textAlign: 'center',
                                                writingMode: 'vertical-rl'
                                            }
                                        }, r.month.label)
                                        : null,
                                    React.createElement('td', {
                                        style: {
                                            position: 'sticky', right: termColWidth + monthColWidth, zIndex: 2,
                                            border: '1px solid #C9F5EE', padding: '2px 1px',
                                            background: r.half.key === 'h1' ? '#E3FFFA' : '#FFF1A8',
                                            color: '#2A9D96', fontWeight: 800, fontSize: 9, textAlign: 'center'
                                        }
                                    }, r.half.label),
                                    subjects.length
                                        ? subjects.map((s, sIdx) =>
                                            React.createElement('td', {
                                                key: s.id,
                                                style: {
                                                    border: '1px solid #C9F5EE', padding: 2,
                                                    verticalAlign: 'middle',
                                                    background: sIdx % 2 === 0 ? '#FFFDF2' : '#F2FFFD'
                                                }
                                            },
                                                React.createElement('div', {
                                                    contentEditable: editMode,
                                                    suppressContentEditableWarning: true,
                                                    role: 'textbox',
                                                    'aria-label': `${s.name} - ${r.month.label} - ${r.half.label}`,
                                                    onInput: e => { if (editMode) updateCell(s.id, r.colKey, e.currentTarget.innerText); },
                                                    onFocus: () => { if (editMode) setActiveCell({ subjectId: s.id, colKey: r.colKey }); },
                                                    onClick: () => {
                                                        setActiveCell({ subjectId: s.id, colKey: r.colKey });
                                                    },
                                                    onDoubleClick: () => {
                                                        // با دوبار کلیک، خانه بدون نیاز به «ویرایش جدول» قرمز/عادی می‌شود
                                                        toggleCompleted(s.id, r.colKey);
                                                    },
                                                    ref: el => {
                                                        if (el && el.innerText !== getValue(s.id, r.colKey)) {
                                                            el.innerText = getValue(s.id, r.colKey);
                                                        }
                                                    },
                                                    style: {
                                                        ...baseCellStyle,
                                                        minHeight: Math.max(34, Math.round(getFontSize(s.id, r.colKey) * 2.6)),
                                                        fontSize: getFontSize(s.id, r.colKey),
                                                        color: completed[cellKey(s.id, r.colKey)] ? '#fff' : '#1AA6A0',
                                                        background: completed[cellKey(s.id, r.colKey)]
                                                            ? 'linear-gradient(135deg,#FF6B81,#E53958)' : '#fff',
                                                        border: completed[cellKey(s.id, r.colKey)]
                                                            ? '2px solid #C62843' : '2px solid #9FF0E4',
                                                        boxShadow: (activeCell && activeCell.subjectId === s.id && activeCell.colKey === r.colKey)
                                                            ? '0 0 0 2px #FFB454 inset' : 'none'
                                                    }
                                                })
                                            )
                                        )
                                        : React.createElement('td', {
                                            style: { border: '1px solid #C9F5EE', background: '#FAFAFA' }
                                        })
                                )
                            )
                        ),

                    )
                )
            );

            const renderHorizontalTable = () => (
                React.createElement('div', {
                    className: 'weekly-table-wrap',
                    style: {
                        overflowX: 'auto',
                        overflowY: 'auto',
                        border: '3px solid #7BE0D6',
                        borderRadius: 16,
                        background: '#fff',
                        boxShadow: '0 10px 25px rgba(43,179,163,.12)',
                        position: 'relative',
                        zIndex: 1,
                        maxWidth: '100%'
                    }
                },
                    React.createElement('table', {
                        style: {
                            borderCollapse: 'separate',
                            borderSpacing: 0,
                            tableLayout: 'fixed',
                            width: 'max-content'
                        }
                    },
                        React.createElement('thead', null,
                            React.createElement('tr', null,
                                React.createElement('th', {
                                    rowSpan: 3,
                                    style: {
                                        position: 'sticky', right: 0, zIndex: 3,
                                        border: '1px solid #9FF0E4', padding: '8px 4px',
                                        background: 'linear-gradient(135deg,#2FBFAE,#4FC9BE)', color: '#fff',
                                        width: subjectLabelColWidth, minWidth: subjectLabelColWidth,
                                        fontSize: 11, fontWeight: 900
                                    }
                                }, 'عنوان درس'),
                                TERMS.map(term =>
                                    React.createElement('th', {
                                        key: term.key,
                                        colSpan: term.months.length * 2,
                                        style: {
                                            border: '1px solid #9FF0E4', padding: '6px 2px',
                                            background: 'linear-gradient(135deg,#8A7BEF,#B79CFF)', color: '#fff',
                                            fontSize: 11, fontWeight: 900
                                        }
                                    }, term.label)
                                )
                            ),
                            React.createElement('tr', null,
                                MONTHS.map((m, i) =>
                                    React.createElement('th', {
                                        key: m.key,
                                        colSpan: 2,
                                        style: {
                                            border: '1px solid #9FF0E4', padding: '5px 2px',
                                            background: i % 2 === 0 ? 'linear-gradient(135deg,#22B8B0,#3FD6C5)' : 'linear-gradient(135deg,#2FBFAE,#4FC9BE)',
                                            color: '#fff', fontSize: 10, fontWeight: 900
                                        }
                                    }, m.label)
                                )
                            ),
                            React.createElement('tr', null,
                                leafCols.map((c, i) =>
                                    React.createElement('th', {
                                        key: c.key,
                                        style: {
                                            border: '1px solid #C9F5EE', padding: '4px 1px',
                                            background: Math.floor(i / 2) % 2 === 0 ? '#FFF1A8' : '#E3FFFA',
                                            color: '#2A9D96', fontWeight: 800, fontSize: 9,
                                            width: leafColWidth, minWidth: leafColWidth
                                        }
                                    }, c.half.label)
                                )
                            )
                        ),
                        React.createElement('tbody', null,
                            subjects.map((s, rowIndex) =>
                                React.createElement('tr', { key: s.id },
                                    React.createElement('td', {
                                        style: {
                                            position: 'sticky', right: 0, zIndex: 2,
                                            border: '1px solid #C9F5EE', padding: 4,
                                            background: rowIndex % 2 === 0
                                                ? 'linear-gradient(135deg,#D9F7FF,#BFEAF4)'
                                                : 'linear-gradient(135deg,#FFE0EE,#FFC8DB)',
                                            width: subjectLabelColWidth, minWidth: subjectLabelColWidth
                                        }
                                    },
                                        React.createElement('input', {
                                            value: s.name,
                                            onChange: e => renameSubject(s.id, e.target.value),
                                            onFocus: () => setSelectedSubjectId(s.id),
                                            onClick: () => setSelectedSubjectId(s.id),
                                            placeholder: 'نام درس',
                                            style: {
                                                width: '100%', minWidth: 0, boxSizing: 'border-box',
                                                border: '1px solid #C9F5EE', borderRadius: 7,
                                                padding: '4px 4px', fontSize: 11, fontWeight: 800,
                                                color: '#2BB3A3', background: '#fff',
                                                fontFamily: "'Vazirmatn', Tahoma, sans-serif",
                                                outline: 'none'
                                            }
                                        })
                                    ),
                                    leafCols.map((c, colIndex) =>
                                        React.createElement('td', {
                                            key: c.key,
                                            style: {
                                                border: '1px solid #C9F5EE', padding: 2,
                                                verticalAlign: 'middle',
                                                background: colIndex % 2 === 0 ? '#FFFDF2' : '#F2FFFD',
                                                width: leafColWidth, minWidth: leafColWidth
                                            }
                                        },
                                            React.createElement('div', {
                                                contentEditable: editMode,
                                                suppressContentEditableWarning: true,
                                                role: 'textbox',
                                                'aria-label': `${s.name} - ${c.month.label} - ${c.half.label}`,
                                                onInput: e => { if (editMode) updateCell(s.id, c.key, e.currentTarget.innerText); },
                                                onFocus: () => { if (editMode) setActiveCell({ subjectId: s.id, colKey: c.key }); },
                                                onClick: () => {
                                                    setActiveCell({ subjectId: s.id, colKey: c.key });
                                                    if (getValue(s.id, c.key).trim()) toggleCompleted(s.id, c.key);
                                                },
                                                ref: el => {
                                                    if (el && el.innerText !== getValue(s.id, c.key)) {
                                                        el.innerText = getValue(s.id, c.key);
                                                    }
                                                },
                                                style: {
                                                    ...baseCellStyle,
                                                    minHeight: Math.max(30, Math.round(getFontSize(s.id, c.key) * 2.2)),
                                                    fontSize: getFontSize(s.id, c.key),
                                                    color: completed[cellKey(s.id, c.key)] ? '#fff' : '#1AA6A0',
                                                    background: completed[cellKey(s.id, c.key)]
                                                        ? 'linear-gradient(135deg,#FF6B81,#E53958)' : '#fff',
                                                    border: completed[cellKey(s.id, c.key)]
                                                        ? '2px solid #C62843' : '2px solid #9FF0E4',
                                                    boxShadow: (activeCell && activeCell.subjectId === s.id && activeCell.colKey === c.key)
                                                        ? '0 0 0 2px #FFB454 inset' : 'none'
                                                }
                                            })
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            );

            return React.createElement('div', {
                'data-app-overlay': 'budgeting',
                style: {
                    position: 'fixed',
                    inset: 0,
                    zIndex: 9999,
                    background: 'linear-gradient(135deg,#FFF3B8 0%,#DDF8FF 35%,#E8F8E9 68%,#FFE2F1 100%)',
                    padding: 0,
                    overflowY: 'auto'
                }
            },
                React.createElement('div', {
                    style: {
                        position: 'relative',
                        width: '100%',
                        minHeight: '100vh',
                        maxWidth: 'none',
                        margin: 0,
                        background: 'linear-gradient(145deg,rgba(255,255,255,.98),rgba(245,255,253,.97))',
                        padding: '16px clamp(7px, 2vw, 28px) 22px',
                        boxSizing: 'border-box',
                        borderRadius: 0,
                        overflow: 'hidden'
                    }
                },
                    React.createElement('div', {
                        className: 'flex items-center',
                        style: { justifyContent: 'space-between', gap: 8, marginBottom: 14, flexWrap: 'wrap', position: 'relative', zIndex: 1 }
                    },
                        React.createElement('div', {
                            style: {
                                display: 'flex', alignItems: 'center', gap: 6,
                                background: 'linear-gradient(90deg,#FFE66D,#FFB7D5)',
                                padding: '6px 11px', borderRadius: 16,
                                boxShadow: '0 5px 15px rgba(60,150,140,.10)'
                            }
                        },
                            React.createElement('div', { style: { fontSize: 20 } }, '📘'),
                            React.createElement('h3', {
                                style: { margin: 0, fontSize: 'clamp(14px, 2.6vw, 18px)', fontWeight: 900, color: '#1AA6A0' }
                            }, 'بودجه‌بندی دروس')
                        ),
                        React.createElement('button', {
                            onClick: () => {
                                setEditMode(v => !v);
                                if (editMode) setActiveCell(null);
                            },
                            style: {
                                whiteSpace: 'nowrap',
                                background: editMode ? 'linear-gradient(135deg,#FFD7E4,#FFC2D1)' : 'linear-gradient(135deg,#D8F9F0,#D7EEFF)',
                                color: editMode ? '#8B4058' : '#1AA6A0',
                                border: editMode ? '2px solid #F2A7BB' : '2px solid #9FF0E4',
                                borderRadius: 14, fontWeight: 900, padding: '7px 12px'
                            }
                        }, editMode ? '🔒 پایان ویرایش' : '✏️ ویرایش جدول'),
                        React.createElement('button', {
                            onClick: onClose,
                            className: 'weekly-close-btn',
                            style: {
                                whiteSpace: 'nowrap',
                                background: 'linear-gradient(135deg,#D8F9F0,#D7EEFF)', color: '#1AA6A0', border: '2px solid #9FF0E4',
                                borderRadius: 14, fontWeight: 800
                            }
                        }, '✕ بستن')
                    ),

                    orientation === 'vertical' ? renderVerticalTable() : renderHorizontalTable(),

                    React.createElement('div', {
                        style: {
                            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                            marginTop: 14, position: 'relative', zIndex: 1,
                            background: '#F2FFFD', border: '2px solid #9FF0E4', borderRadius: 14,
                            padding: '9px 12px', flexWrap: 'wrap'
                        }
                    },
                        React.createElement('span', { style: { fontSize: 13, fontWeight: 800, color: '#1AA6A0' } },
                            activeCell
                                ? (() => {
                                    const subj = subjects.find(s => s.id === activeCell.subjectId);
                                    const col = leafCols.find(c => c.key === activeCell.colKey);
                                    return `🔠 اندازه متن (${subj ? subj.name : ''} - ${col ? col.month.label + ' ' + col.half.label : ''}):`;
                                })()
                                : '🔠 اندازه متن: (اول روی یک خانه از جدول بزن)'
                        ),
                        React.createElement('button', {
                            onClick: () => changeActiveFontSize(-1),
                            disabled: !editMode || !activeCell,
                            style: {
                                width: 32, height: 32, borderRadius: 10, border: '2px solid #9FF0E4',
                                background: '#fff', color: '#1AA6A0', fontWeight: 900, fontSize: 16,
                                cursor: editMode && activeCell ? 'pointer' : 'not-allowed', opacity: editMode && activeCell ? 1 : .5
                            }
                        }, '−'),
                        React.createElement('span', { style: { fontSize: 13, fontWeight: 900, color: '#1AA6A0', minWidth: 28, textAlign: 'center' } },
                            activeCell ? getFontSize(activeCell.subjectId, activeCell.colKey) : '–'
                        ),
                        React.createElement('button', {
                            onClick: () => changeActiveFontSize(1),
                            disabled: !editMode || !activeCell,
                            style: {
                                width: 32, height: 32, borderRadius: 10, border: '2px solid #9FF0E4',
                                background: '#fff', color: '#1AA6A0', fontWeight: 900, fontSize: 16,
                                cursor: editMode && activeCell ? 'pointer' : 'not-allowed', opacity: editMode && activeCell ? 1 : .5
                            }
                        }, '+'),
                        React.createElement('input', {
                            type: 'range', min: 8, max: 26,
                            value: activeCell ? getFontSize(activeCell.subjectId, activeCell.colKey) : 12,
                            disabled: !editMode || !activeCell,
                            onChange: e => setActiveFontSize(Number(e.target.value)),
                            style: { width: 110, margin: '0 4px', cursor: editMode && activeCell ? 'pointer' : 'not-allowed', opacity: editMode && activeCell ? 1 : .5 }
                        }),
                        React.createElement('button', {
                            onClick: resetActiveFontSize,
                            disabled: !editMode || !activeCell,
                            style: {
                                fontSize: 11, fontWeight: 800, color: '#1AA6A0', background: '#E3FFFA',
                                border: '2px solid #9FF0E4', borderRadius: 10, padding: '6px 10px',
                                cursor: editMode && activeCell ? 'pointer' : 'not-allowed', opacity: editMode && activeCell ? 1 : .5
                            }
                        }, 'پیش‌فرض'),
                        React.createElement('span', { style: { fontSize: 11, color: '#5FA39A' } },
                            'مثلاً می‌توانی داخل هر خانه بنویسی: 1-2-3-4')
                    ),

                    React.createElement('div', {
                        style: {
                            marginTop: 13, display: 'flex', flexWrap: 'wrap', gap: 7,
                            justifyContent: 'center', alignItems: 'center',
                            position: 'relative', zIndex: 1
                        }
                    },
                        React.createElement('button', {
                            onClick: addSubject,
                            style: {
                                fontSize: 12, padding: '8px 12px', borderRadius: 11,
                                background: 'linear-gradient(135deg,#2CC9A5,#159FBD)', color: '#fff',
                                border: 'none', fontWeight: 900
                            }
                        }, '➕ افزودن درس'),
                        React.createElement('button', {
                            onClick: () => selectedSubjectId && removeSubject(selectedSubjectId),
                            disabled: !selectedSubjectId,
                            style: {
                                fontSize: 12, padding: '8px 12px', borderRadius: 11,
                                background: selectedSubjectId
                                    ? 'linear-gradient(135deg,#FF6B81,#E04761)' : '#E7E7E7',
                                color: selectedSubjectId ? '#fff' : '#999',
                                border: 'none', fontWeight: 900,
                                cursor: selectedSubjectId ? 'pointer' : 'not-allowed'
                            }
                        }, '🗑️ حذف درس انتخاب‌شده'),
                        React.createElement('span', {
                            className: 'text-muted text-small',
                            style: { fontSize: 11, padding: '8px 4px', fontWeight: 700 }
                        }, saving ? '⏳ در حال ذخیره خودکار...' : '✓ ذخیره خودکار فعال است'),
                        React.createElement('button', {
                            onClick: clearBudgeting,
                            style: {
                                fontSize: 12, padding: '8px 12px', borderRadius: 11,
                                background: 'linear-gradient(135deg,#FFD7E4,#FFC2D1)', color: '#8B4058',
                                border: 'none', fontWeight: 900
                            }
                        }, '🗑️ پاک کردن کل جدول'),
                        React.createElement('button', {
                            onClick: () => setOrientation(o => o === 'vertical' ? 'horizontal' : 'vertical'),
                            style: {
                                fontSize: 12, padding: '8px 12px', borderRadius: 11,
                                background: 'linear-gradient(135deg,#FFE0B8,#FFC9A8)', color: '#7A3E10',
                                border: '2px solid #FFB870', fontWeight: 900
                            }
                        }, orientation === 'vertical' ? '↔️ نمای افقی' : '↕️ نمای عمودی')
                    )
                )
            );
        }

        // ============================================================
        // Dashboard - با آمار کامل هر دانش‌آموز
        // ============================================================
        // ============================================================
        // نمودار روند نمرات توصیفی آزمون‌ها (بر اساس تاریخ)
        // ============================================================
        function StudentExamChart({ data, studentId }) {
            const [subject, setSubject] = React.useState('all');
            const canvasRef = React.useRef(null);
            const chartRef = React.useRef(null);

            const sortedExams = React.useMemo(() => {
                const studentExams = (data.exams || {})[studentId] || [];
                const filtered = subject === 'all' ? studentExams : studentExams.filter(e => e.subject === subject);
                return [...filtered].sort((a, b) => a.date.localeCompare(b.date));
            }, [data.exams, studentId, subject]);

            React.useEffect(() => {
                if (chartRef.current) {
                    chartRef.current.destroy();
                    chartRef.current = null;
                }
                if (!canvasRef.current || sortedExams.length === 0) return;
                if (typeof Chart === 'undefined') return;

                const gradeColors = {
                    excellent: '#34C77B',
                    good: '#2BB3A3',
                    acceptable: '#FFB454',
                    needs_work: '#FF6B81'
                };
                const gradeTickLabels = { 1: 'نیاز به تلاش', 2: 'قابل قبول', 3: 'خوب', 4: 'خیلی خوب' };

                const labels = sortedExams.map(e => getShamsiWithDay(e.date));
                const scores = sortedExams.map(e => getGradeScore(e.grade));
                const pointColors = sortedExams.map(e => gradeColors[e.grade] || '#2BB3A3');
                const subjectsForTooltip = sortedExams.map(e => e.subject);
                const gradesForTooltip = sortedExams.map(e => getGradeLabel(e.grade));

                const ctx = canvasRef.current.getContext('2d');
                chartRef.current = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels,
                        datasets: [{
                            label: 'روند نمره توصیفی',
                            data: scores,
                            borderColor: '#2BB3A3',
                            backgroundColor: 'rgba(43,179,163, 0.08)',
                            pointBackgroundColor: pointColors,
                            pointBorderColor: '#fff',
                            pointBorderWidth: 1.5,
                            pointRadius: 5,
                            pointHoverRadius: 7,
                            tension: 0.25,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                min: 0.5,
                                max: 4.5,
                                ticks: {
                                    stepSize: 1,
                                    callback: (val) => gradeTickLabels[val] || ''
                                }
                            },
                            x: {
                                ticks: { autoSkip: true, maxRotation: 40, minRotation: 40, font: { size: 10 } }
                            }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: (ctx2) => `${subjectsForTooltip[ctx2.dataIndex]} — ${gradesForTooltip[ctx2.dataIndex]}`
                                }
                            }
                        }
                    }
                });

                return () => {
                    if (chartRef.current) {
                        chartRef.current.destroy();
                        chartRef.current = null;
                    }
                };
                // eslint-disable-next-line
            }, [sortedExams]);

            return React.createElement('div', { className: 'mb-12' },
                React.createElement('div', { className: 'flex-between mb-8' },
                    React.createElement('h4', null, '📈 نمودار عملکرد'),
                    React.createElement('select', {
                        value: subject,
                        onChange: e => setSubject(e.target.value),
                        style: { width: 'auto', maxWidth: 140, padding: '6px 8px', fontSize: 13 }
                    },
                        React.createElement('option', { value: 'all' }, 'همه‌ی درس‌ها'),
                        SUBJECTS.map(sub => React.createElement('option', { key: sub, value: sub }, sub))
                    )
                ),
                sortedExams.length === 0 ?
                React.createElement('div', { className: 'empty-state' },
                    React.createElement('p', null, 'برای این درس هنوز آزمونی ثبت نشده')
                ) :
                React.createElement('div', { style: { position: 'relative', height: 200 } },
                    React.createElement('canvas', { ref: canvasRef })
                )
            );
        }

        // ============================================================
        // خروجی PDF کارنامه‌ی کامل هر دانش‌آموز
        // (اطلاعات + نمودار عملکرد + لیست حضور و غیاب + برگه‌های آزمون)
        // ============================================================
        function waitForImagesToLoad(container) {
            const imgs = Array.from(container.querySelectorAll('img'));
            return Promise.all(imgs.map(img => {
                if (img.complete && img.naturalWidth > 0) return Promise.resolve();
                return new Promise(resolve => {
                    img.onload = () => resolve();
                    img.onerror = () => resolve();
                });
            }));
        }

        function buildChartImageForStudent(student, data, selectedSubject = null, selectedMonth = null) {
            return new Promise(resolve => {
                try {
                    const exams = (data.exams[student.id] || []).filter(e => {
                        if (selectedSubject && e.subject !== selectedSubject) return false;
                        if (selectedMonth) { try { return isoToJalali(e.date).jm === selectedMonth; } catch (err) { return false; } }
                        return true;
                    }).slice().sort((a, b) => a.date.localeCompare(b.date));
                    if (exams.length === 0) {
                        resolve(null);
                        return;
                    }
                    const canvas = document.createElement('canvas');
                    canvas.width = 1400;
                    canvas.height = 560;

                    const gradeColors = {
                        excellent: '#34C77B',
                        good: '#2BB3A3',
                        acceptable: '#FFB454',
                        needs_work: '#FF6B81'
                    };
                    const gradeTickLabels = { 1: 'نیاز به تلاش', 2: 'قابل قبول', 3: 'خوب', 4: 'خیلی خوب' };
                    const labels = exams.map(e => getShamsiWithDay(e.date));
                    const scores = exams.map(e => getGradeScore(e.grade));
                    const pointColors = exams.map(e => gradeColors[e.grade] || '#2BB3A3');

                    const chart = new Chart(canvas.getContext('2d'), {
                        type: 'line',
                        data: {
                            labels,
                            datasets: [{
                                label: 'روند نمره توصیفی',
                                data: scores,
                                borderColor: '#2BB3A3',
                                backgroundColor: 'rgba(43,179,163, 0.08)',
                                pointBackgroundColor: pointColors,
                                pointBorderColor: '#fff',
                                pointBorderWidth: 1.5,
                                pointRadius: 5,
                                tension: 0.25,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: false,
                            animation: false,
                            devicePixelRatio: 2,
                            scales: {
                                y: {
                                    min: 0.5,
                                    max: 4.5,
                                    ticks: { stepSize: 1, callback: v => gradeTickLabels[v] || '', font: { size: 16 } }
                                },
                                x: {
                                    ticks: { autoSkip: true, maxRotation: 0, minRotation: 0, font: { size: 13 } }
                                }
                            },
                            plugins: {
                                legend: { display: false }
                            }
                        }
                    });

                    setTimeout(() => {
                        const dataUrl = chart.toBase64Image('image/png', 1);
                        chart.destroy();
                        resolve(dataUrl);
                    }, 60);
                } catch (err) {
                    console.error('chart build error', err);
                    resolve(null);
                }
            });
        }

        function buildStudentReportElement(student, data, chartDataUrl, selectedSubject = null, selectedMonth = null) {
            const el = document.createElement('div');
            el.style.position = 'fixed';
            el.style.top = '0';
            el.style.left = '-99999px';
            el.style.width = '780px';
            el.style.background = '#ffffff';
            el.style.color = '#1c1c1c';
            el.style.direction = 'rtl';
            el.style.fontFamily = "'Vazirmatn', Tahoma, sans-serif";
            el.style.padding = '20px';
            el.style.lineHeight = '1.55';

            const exams = (data.exams && data.exams[student.id] ? data.exams[student.id] : [])
                .filter(e => !selectedSubject || e.subject === selectedSubject)
                .filter(e => { if (!selectedMonth) return true; try { return isoToJalali(e.date).jm === selectedMonth; } catch (err) { return false; } })
                .slice()
                .sort((a, b) => a.date.localeCompare(b.date));
            const attendance = data.attendance[student.id] || [];

            const gradeStyles = {
                excellent: { bg: '#DFFBE9', color: '#34C77B' },
                good: { bg: '#DFF7F3', color: '#2BB3A3' },
                acceptable: { bg: '#FFEFD1', color: '#FFB454' },
                needs_work: { bg: '#FFE1E8', color: '#FF6B81' }
            };

            // گروه‌بندی بر اساس ماه شمسی؛ هر ماه یک بخش مستقل دارد.
            const monthMap = new Map();
            exams.forEach(exam => {
                try {
                    const { jy, jm } = isoToJalali(exam.date);
                    const key = `${jy}-${String(jm).padStart(2, '0')}`;
                    if (!monthMap.has(key)) monthMap.set(key, { jy, jm, exams: [] });
                    monthMap.get(key).exams.push(exam);
                } catch (e) {}
            });
            const monthlyGroups = Array.from(monthMap.values()).sort((a, b) => (a.jy * 100 + a.jm) - (b.jy * 100 + b.jm));

            // سطح عملکرد همان درس، ماه‌به‌ماه
            const studentPerf = getStudentPerformanceData(data, student);
            const rowTexts = (data.performanceRowTexts && typeof data.performanceRowTexts === 'object') ? data.performanceRowTexts : {};
            const getRowLabel = (row, field, fallback) => {
                const r = rowTexts[row.id];
                return (r && typeof r[field] === 'string') ? r[field] : fallback;
            };
            const performanceRows = getStudentPerformanceRows(data, student)
                .filter(row => !selectedSubject || row.lesson === selectedSubject);

            const performanceByMonth = PERFORMANCE_MONTHS.filter(month => !selectedMonth || (PERFORMANCE_MONTHS.indexOf(month) + 1) === selectedMonth).map(month => {
                const items = performanceRows.map(row => {
                    const rp = studentPerf[row.id];
                    const value = (rp && typeof rp === 'object') ? rp[month.key] : '';
                    return value ? { row, value } : null;
                }).filter(Boolean);
                return { month, items };
            }).filter(m => m.items.length > 0);

            let html = `
                <div style="background:#1F8A94;color:#fff;border-radius:12px;padding:14px 16px;margin-bottom:10px;">
                    <div style="font-size:20px;font-weight:800;">📄 کارنامه ${selectedSubject ? `درس ${selectedSubject}` : 'کامل'}</div>
                    <div style="font-size:16px;margin-top:6px;">${escHtml(student.name)}${student.className ? ' — ' + escHtml(student.className) : ''}</div>
                    <div style="font-size:12px;opacity:0.8;margin-top:6px;">تاریخ تهیه گزارش: ${getShamsiWithDay(todayISO())}</div>
                </div>
            `;

            // خلاصه سطح عملکرد را در بالای کارنامه و بر اساس ماه انتخاب‌شده نمایش می‌دهیم.
            // اگر درس انتخاب شده باشد فقط همان درس؛ در حالت کل سال/گزارش کامل، همه درس‌ها جداگانه.
            const topPerformanceItems = [];
            const perfLessons = selectedSubject ? [selectedSubject] : [...new Set(performanceRows.map(r => r.lesson))];
            const targetMonths = selectedMonth
                ? PERFORMANCE_MONTHS.filter(m => PERFORMANCE_MONTHS.indexOf(m) + 1 === selectedMonth)
                : PERFORMANCE_MONTHS;
            perfLessons.forEach(lessonName => {
                const lessonRows = performanceRows.filter(r => r.lesson === lessonName);
                targetMonths.forEach(month => {
                    const items = lessonRows.map(row => {
                        const rp = studentPerf[row.id];
                        const value = (rp && typeof rp === 'object') ? rp[month.key] : '';
                        return value ? { row, value } : null;
                    }).filter(Boolean);
                    if (items.length) topPerformanceItems.push({ lessonName, month, items });
                });
            });

            if (topPerformanceItems.length) {
                html += `<div style="margin:6px 0 10px;border:1px solid #BFECE6;border-radius:10px;padding:8px 10px;background:#F9FFFE;page-break-inside:avoid;">
                    <div style="font-size:15px;font-weight:900;color:#148F8A;margin-bottom:7px;border-bottom:2px solid #9FF0E4;padding-bottom:5px;">📝 سطح عملکرد ${selectedMonth ? `— ${JALALI_MONTHS[selectedMonth - 1] || ''}` : '— کل سال'}</div>`;
                topPerformanceItems.forEach(({ lessonName, month, items }) => {
                    html += `<div style="margin-bottom:7px;">
                        <div style="font-size:13px;font-weight:900;color:#1F6F73;margin-bottom:4px;">📚 ${escHtml(lessonName)}${!selectedMonth ? ` — ${month.label}` : ''}</div>
                        <div style="display:flex;flex-wrap:wrap;gap:5px;">`;
                    items.forEach(({ row, value }) => {
                        const gs = gradeStyles[value] || { bg: '#DFF7F3', color: '#2BB3A3' };
                        html += `<div style="display:flex;align-items:center;gap:5px;background:#fff;border:1px solid #E5EEEE;border-radius:7px;padding:4px 7px;page-break-inside:avoid;">
                            <span style="font-size:10px;color:#68635B;">${escHtml(getRowLabel(row, 'expect', row.expect))}</span>
                            <span style="padding:2px 7px;border-radius:5px;font-size:10px;font-weight:800;background:${gs.bg};color:${gs.color};">${getGradeLabel(value)}</span>
                        </div>`;
                    });
                    html += `</div></div>`;
                });
                html += `</div>`;
            }

            if (chartDataUrl) {
                html += `<div style="margin:6px 0 8px;border:1px solid #E6E6E6;border-radius:10px;padding:6px 8px;background:#fff;page-break-inside:avoid;">
                    <div style="font-size:14px;font-weight:900;color:#1AA6A0;margin-bottom:2px;">📈 نمودار عملکرد${selectedSubject ? ` — ${selectedSubject}` : ''}${selectedMonth ? ` — ${JALALI_MONTHS[selectedMonth - 1] || ''}` : ''}</div>
                    <img src="${chartDataUrl}" style="display:block;width:100%;max-height:190px;object-fit:contain;margin:0 auto;" />
                </div>`;
            }

            if (selectedSubject) {
                const avg = exams.length ? Math.round(exams.reduce((sum, e) => sum + getGradeScore(e.grade), 0) / exams.length * 25) : 0;
                const present = attendance.filter(a => a.status === 'present').length;
                const absent = attendance.filter(a => a.status === 'absent').length;
                html += `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;">
                    <span style="background:#E7F8F5;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:700;">📚 تعداد آزمون: ${toPersianDigits(exams.length)}</span>
                    <span style="background:#FFF4DD;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:700;">🎯 میانگین: ${toPersianDigits(avg)}٪</span>
                    <span style="background:#E8F8EA;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:700;">حاضر: ${toPersianDigits(present)}</span>
                    <span style="background:#FFE8EC;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:700;">غایب: ${toPersianDigits(absent)}</span>
                </div>`;
            }

            if (monthlyGroups.length === 0 && performanceByMonth.length === 0) {
                html += `<div style="color:#767267;font-size:13px;padding:20px 0;">برای درس «${selectedSubject || 'این دانش‌آموز'}» اطلاعاتی برای دانلود ثبت نشده است.</div>`;
            }

            // ماه‌های آزمون؛ هر ماه با یک data-pdf-month-block شروع می‌شود.
            monthlyGroups.forEach(group => {
                const monthLabel = JALALI_MONTHS[group.jm - 1] || '';
                html += `<div data-pdf-month-block style="margin-top:8px;padding-top:0;">
                    <div style="font-size:18px;font-weight:900;color:#1AA6A0;border-bottom:2px solid #9FF0E4;padding-bottom:4px;margin-bottom:6px;">📅 ${monthLabel} ${toPersianDigits(group.jy)}</div>`;
                group.exams.forEach(exam => {
                    const isAbsent = exam.absent === true;
                    const gs = isAbsent ? { bg: '#FEE2E2', color: '#B91C1C' } : (gradeStyles[exam.grade] || { bg: '#DFF7F3', color: '#2BB3A3' });
                    const examLabel = isAbsent ? '❌ غایب (آزمون نداده)' : getGradeLabel(exam.grade);
                    html += `<div data-pdf-block="exam" style="border:1px solid ${isAbsent ? '#FECACA' : '#E9DFF0'};border-radius:8px;padding:8px 10px;margin-bottom:6px;background:${isAbsent ? '#FFF7F7' : '#FAFAF8'};page-break-inside:avoid;">
                        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                            <span style="display:inline-block;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:700;background:${gs.bg};color:${gs.color};">${examLabel}</span>
                            <span style="font-size:12px;color:#767267;">${getShamsiWithDay(exam.date)}</span>
                        </div>`;
                    if (exam.images && exam.images.length > 0) {
                        html += `<div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:0;">`;
                        exam.images.forEach(img => {
                            html += `<img src="${img}" style="max-width:340px;max-height:410px;border-radius:6px;border:1px solid #ddd;object-fit:contain;" />`;
                        });
                        html += `</div>`;
                    }
                    html += `</div>`;
                });
                html += `</div>`;
            });

            // سطح عملکرد در بالای گزارش نمایش داده می‌شود؛ این بخش قدیمی فقط برای سازگاری در گزارش‌های بدون خلاصه نگه داشته می‌شود.
            if (!topPerformanceItems.length) performanceByMonth.forEach(({ month, items }) => {
                html += `<div data-pdf-month-block style="margin-top:18px;padding-top:2px;">
                    <div style="font-size:18px;font-weight:900;color:#1AA6A0;border-bottom:2px solid #9FF0E4;padding-bottom:7px;margin-bottom:10px;">📝 سطح عملکرد — ${month.label}</div>`;
                items.forEach(({ row, value }) => {
                    const gs = gradeStyles[value] || { bg: '#DFF7F3', color: '#2BB3A3' };
                    html += `<div style="border:1px solid #E9DFF0;border-radius:8px;padding:10px 12px;margin-bottom:8px;background:#FAFAF8;page-break-inside:avoid;">
                        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;">
                            <span style="font-weight:700;font-size:13px;">${escHtml(getRowLabel(row, 'content', row.content))}</span>
                            <span style="display:inline-block;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:700;background:${gs.bg};color:${gs.color};">${getGradeLabel(value)}</span>
                        </div>
                        <div style="font-size:12px;color:#767267;margin-top:4px;">${escHtml(getRowLabel(row, 'expect', row.expect))}</div>
                    </div>`;
                });
                html += `</div>`;
            });

            el.innerHTML = html;
            document.body.appendChild(el);
            return el;
        }


        // ============================================================
        // PDF pagination helper
        // صفحه‌بندی هوشمند: کارت‌های آزمون (به‌خصوص عکس‌ها) از وسط
        // یک صفحه به صفحه‌ی بعد منتقل نمی‌شوند.
        // ============================================================
        // ============================================================
        // صفحه‌بندی هوشمند PDF (برش تصویر بلند به صفحات A4 بدون نصف‌شدن بخش‌ها)
        // قواعد:
        //  ۱) کارت/ردیف جدول/نمودار/پاراگراف (data-pdf-block, tr, p, li و فرزندان مستقیم) هرگز از وسط بریده نمی‌شود.
        //  ۲) تیتر (h2/h3) و سرستون جدول با اولین محتوای بعدی‌شان هم‌صفحه می‌مانند (تیتر یتیم نداریم).
        //  ۳) اگر جدولی به صفحه‌ی بعد برود، سرستون آن بالای صفحه‌ی بعد دوباره تکرار می‌شود.
        // ============================================================
        function smartPaginatePdf(pdf, canvas, rootEl, opts) {
            opts = opts || {};
            const margin = opts.margin || 0;
            const pageW = pdf.internal.pageSize.getWidth();
            const pageH = pdf.internal.pageSize.getHeight();
            const imgW = pageW - margin * 2;
            const pxPerUnit = canvas.width / imgW;
            const pagePx = Math.floor((pageH - margin * 2) * pxPerUnit);
            const rRoot = rootEl.getBoundingClientRect();
            const sc = canvas.width / rRoot.width;
            const Y = v => Math.round((v - rRoot.top) * sc);
            const box = n => { const r = n.getBoundingClientRect(); return { top: Y(r.top), bottom: Y(r.bottom) }; };

            // واحدهای تقسیم‌ناپذیر
            const atomNodes = new Set(rootEl.querySelectorAll('[data-pdf-block],tr,p,li,h2,h3'));
            Array.from(rootEl.children).forEach(c => { if (!/^(TABLE|THEAD|TBODY)$/.test(c.tagName)) atomNodes.add(c); });
            const atoms = Array.from(atomNodes).map(box).filter(b => b.bottom - b.top > 2 && b.bottom - b.top <= pagePx * 0.92);

            // «همراه بعدی»: تیتر و سرستون باید با محتوای بعدی‌شان بیایند.
            // اگر بین تیتر و محتوای اصلی چند المان سبک (زیرعنوان، نوار نام دانش‌آموز، توضیح کوتاه) باشد، همه با هم می‌مانند.
            const LIGHT_PX = Math.floor(110 * sc);
            const firstAtomOf = n => n.matches('tr,[data-pdf-block],p,li') ? n : (n.querySelector('tbody tr,[data-pdf-block],tr,p,li') || n);
            const keeps = Array.from(rootEl.querySelectorAll('h2,h3,thead tr,[data-pdf-keep]')).map(k => {
                const kb = box(k);
                let n = k.closest('thead')
                    ? (k.nextElementSibling || (k.closest('table').tBodies[0] && k.closest('table').tBodies[0].rows[0]))
                    : k.nextElementSibling;
                let end = kb.bottom;
                for (let hops = 0; n && hops < 5; hops++) {
                    const nb = box(n);
                    const light = /^H[1-6]$/.test(n.tagName) || (nb.bottom - nb.top) <= LIGHT_PX;
                    end = Math.max(end, light ? nb.bottom : box(firstAtomOf(n)).bottom);
                    if (!light) break;
                    n = n.nextElementSibling;
                }
                return { top: kb.top, chainEnd: Math.min(end, kb.bottom + Math.floor(pagePx * 0.35)) };
            });

            // سرستون جدول‌ها برای تکرار در صفحات بعد
            const tables = Array.from(rootEl.querySelectorAll('table')).filter(t => t.tHead).map(t => {
                const h = box(t.tHead), b = box(t);
                return { hTop: h.top, hBot: h.bottom, bot: b.bottom };
            });

            const pages = [];
            let start = 0;
            while (start < canvas.height - 2) {
                const rep = start > 0 ? tables.find(t => t.hBot <= start + 1 && t.bot > start + 6) : null;
                const hdrH = rep ? rep.hBot - rep.hTop : 0;
                const avail = pagePx - hdrH;
                let end = Math.min(canvas.height, start + avail);
                if (end < canvas.height) {
                    const crossing = atoms.filter(b => b.top < end && b.bottom > end && b.top > start + avail * 0.3).map(b => b.top);
                    if (crossing.length) end = Math.min.apply(null, crossing) - 1;
                    for (let g = 0; g < 12; g++) {
                        const k = keeps.find(k => k.top > start + avail * 0.2 && k.top < end && end < k.chainEnd);
                        if (!k) break;
                        end = k.top - 1;
                    }
                }
                if (end <= start + 20) end = Math.min(canvas.height, start + avail);
                pages.push({ start, end, rep });
                start = end;
            }

            pages.forEach((pg, i) => {
                const sliceH = pg.end - pg.start;
                const hdrH = pg.rep ? pg.rep.hBot - pg.rep.hTop : 0;
                const part = document.createElement('canvas');
                part.width = canvas.width; part.height = sliceH + hdrH;
                const ctx = part.getContext('2d');
                ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, part.width, part.height);
                if (hdrH) ctx.drawImage(canvas, 0, pg.rep.hTop, canvas.width, hdrH, 0, 0, canvas.width, hdrH);
                ctx.drawImage(canvas, 0, pg.start, canvas.width, sliceH, 0, hdrH, canvas.width, sliceH);
                if (i > 0) pdf.addPage();
                pdf.addImage(part.toDataURL('image/jpeg', 0.93), 'JPEG', margin, margin, imgW, (sliceH + hdrH) / pxPerUnit, undefined, 'FAST');
            });
            return pages;
        }

        function addCanvasToPdfPaged(pdf, canvas, rootEl) {
            smartPaginatePdf(pdf, canvas, rootEl, { margin: 0 });
        }

        // خروجی یکپارچه: کل کارنامه روی یک صفحه بلند با زمینه کاملاً سفید.
        function addCanvasToPdfContinuous(pdf, canvas) {
            const pageWidth = pdf.internal.pageSize.getWidth();
            const canvasWidth = canvas.width;
            const canvasHeight = canvas.height;
            const pageHeight = canvasHeight * pageWidth / canvasWidth;
            const imgData = canvas.toDataURL('image/jpeg', 0.95);
            pdf.addImage(imgData, 'JPEG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
        }

        async function exportStudentReportPdf(student, data, showToast, selectedSubject = null, selectedMonth = null, exportMode = 'paged') {
            let el = null;
            try {
                if (!window.html2canvas || !window.jspdf) {
                    showToast('⚠️ کتابخانه‌ی ساخت PDF بارگذاری نشد. اتصال اینترنت را بررسی کنید.', 'error');
                    return;
                }
                const chartDataUrl = await buildChartImageForStudent(student, data, selectedSubject, selectedMonth);
                el = buildStudentReportElement(student, data, chartDataUrl, selectedSubject, selectedMonth);

                if (document.fonts && document.fonts.ready) {
                    try { await document.fonts.ready; } catch (e) {}
                }
                await waitForImagesToLoad(el);
                await new Promise(r => setTimeout(r, 50));

                const canvas = await html2canvas(el, {
                    scale: 2,
                    backgroundColor: '#ffffff',
                    useCORS: true,
                    logging: false
                });

                const { jsPDF } = window.jspdf;
                let pdf;
                if (exportMode === 'continuous') {
                    const pageWidth = 595.28;
                    const pageHeight = canvas.height * pageWidth / canvas.width;
                    // PDF page dimensions have a practical upper limit; fall back to A4 pagination if exceeded.
                    if (pageHeight <= 14000) {
                        pdf = new jsPDF('p', 'pt', [pageWidth, pageHeight]);
                        addCanvasToPdfContinuous(pdf, canvas);
                    } else {
                        pdf = new jsPDF('p', 'pt', 'a4');
                        addCanvasToPdfPaged(pdf, canvas, el);
                    }
                } else {
                    pdf = new jsPDF('p', 'pt', 'a4');
                    addCanvasToPdfPaged(pdf, canvas, el);
                }

                const safeName = (student.name || 'دانش‌آموز').replace(/[\\/:*?"<>|]/g, '_');
                const subjectPart = selectedSubject ? `-${selectedSubject}` : '';
                const monthPart = selectedMonth ? `-${JALALI_MONTHS[selectedMonth - 1] || 'ماه'}` : '-کل-سال';
                const cardFileName = `کارنامه-${safeName}${subjectPart}${monthPart}-${todayISO()}.pdf`;
                const cardDataUrl = pdf.output('datauristring');

                if (window.Android && typeof window.Android.saveStudentReport === 'function') {
                    window.Android.saveStudentReport(cardDataUrl, student.name || 'دانش‌آموز', cardFileName);
                } else if (window.Android && typeof window.Android.saveFile === 'function') {
                    window.Android.saveFile(cardDataUrl, cardFileName, 'application/pdf');
                } else {
                    const pdfBlob = pdf.output('blob');
                    const blobUrl = URL.createObjectURL(pdfBlob);
                    const a = document.createElement('a');
                    a.href = blobUrl;
                    a.download = cardFileName;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
                }
                showToast('📄 کارنامه‌ی PDF با موفقیت ساخته شد');
            } catch (err) {
                console.error('export pdf error', err);
                showToast('⚠️ خطا در ساخت فایل PDF', 'error');
            } finally {
                if (el && el.parentNode) el.parentNode.removeChild(el);
            }
        }

        // ============================================================
        // گزارش PDF سطح عملکرد ماهانه (توصیفی) یک دانش‌آموز
        // ============================================================
        function buildPerformanceReportElement(student, data) {
            const el = document.createElement('div');
            el.style.position = 'fixed';
            el.style.top = '0';
            el.style.left = '-99999px';
            el.style.width = '780px';
            el.style.background = '#ffffff';
            el.style.color = '#1c1c1c';
            el.style.direction = 'rtl';
            el.style.fontFamily = "'Vazirmatn', Tahoma, sans-serif";
            el.style.padding = '32px';
            el.style.lineHeight = '1.7';

            const studentPerf = getStudentPerformanceData(data, student);
            const rowTexts = (data.performanceRowTexts && typeof data.performanceRowTexts === 'object') ? data.performanceRowTexts : {};
            const getRowLabel = (row, field, fallback) => {
                const r = rowTexts[row.id];
                return (r && typeof r[field] === 'string') ? r[field] : fallback;
            };
            const gradeStyles = {
                excellent: { bg: '#DFFBE9', color: '#34C77B' },
                good: { bg: '#DFF7F3', color: '#2BB3A3' },
                acceptable: { bg: '#FFEFD1', color: '#FFB454' },
                needs_work: { bg: '#FFE1E8', color: '#FF6B81' }
            };

            let html = `
                <div style="background:#1F8A94;color:#fff;border-radius:12px;padding:18px 20px;margin-bottom:18px;">
                    <div style="font-size:20px;font-weight:800;">📝 گزارش سطح عملکرد ماهانه</div>
                    <div style="font-size:16px;margin-top:6px;">${escHtml(student.name)}${student.className ? ' — ' + escHtml(student.className) : ''}</div>
                    <div style="font-size:12px;opacity:0.75;margin-top:6px;">تاریخ تهیه‌ی گزارش: ${getShamsiWithDay(todayISO())}</div>
                </div>
            `;

            const allRowsForPdf = getStudentPerformanceRows(data, student);
            const monthsWithData = PERFORMANCE_MONTHS.map(month => {
                const items = allRowsForPdf.map(row => {
                    const rp = studentPerf[row.id];
                    const value = (rp && typeof rp === 'object') ? rp[month.key] : '';
                    return value ? { row, value } : null;
                }).filter(Boolean);
                return { month, items };
            }).filter(m => m.items.length > 0);

            if (monthsWithData.length === 0) {
                html += `<div style="color:#767267;font-size:13px;">هنوز سطح عملکردی برای این دانش‌آموز ثبت نشده است.</div>`;
            } else {
                monthsWithData.forEach(({ month, items }) => {
                    html += `<div style="font-size:15px;font-weight:800;color:#1AA6A0;margin:16px 0 8px;border-bottom:2px solid #9FF0E4;padding-bottom:6px;">📅 ${month.label}</div>`;
                    items.forEach(({ row, value }) => {
                        const gs = gradeStyles[value] || { bg: '#DFF7F3', color: '#2BB3A3' };
                        html += `<div style="border:1px solid #E9DFF0;border-radius:8px;padding:10px 12px;margin-bottom:8px;background:#FAFAF8;page-break-inside:avoid;">
                            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                                <span style="font-weight:700;font-size:13px;">${escHtml(row.lesson)} — ${escHtml(getRowLabel(row, 'content', row.content))}</span>
                                <span style="display:inline-block;padding:2px 10px;border-radius:6px;font-size:12px;font-weight:700;background:${gs.bg};color:${gs.color};">${getGradeLabel(value)}</span>
                            </div>
                            <div style="font-size:12px;color:#767267;margin-top:4px;">${escHtml(getRowLabel(row, 'expect', row.expect))}</div>
                        </div>`;
                    });
                });
            }

            el.innerHTML = html;
            document.body.appendChild(el);
            return el;
        }

        async function exportPerformanceReportPdf(student, data, showToast) {
            let el = null;
            try {
                if (!window.html2canvas || !window.jspdf) {
                    showToast('⚠️ کتابخانه‌ی ساخت PDF بارگذاری نشد. اتصال اینترنت را بررسی کنید.', 'error');
                    return;
                }
                el = buildPerformanceReportElement(student, data);

                if (document.fonts && document.fonts.ready) {
                    try { await document.fonts.ready; } catch (e) {}
                }
                await new Promise(r => setTimeout(r, 50));

                const canvas = await html2canvas(el, {
                    scale: 2,
                    backgroundColor: '#ffffff',
                    useCORS: true,
                    logging: false
                });

                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF('p', 'pt', 'a4');
                addCanvasToPdfPaged(pdf, canvas, el);

                const safeName = (student.name || 'دانش‌آموز').replace(/[\\/:*?"<>|]/g, '_');
                const perfFileName = `سطح-عملکرد-${safeName}-${todayISO()}.pdf`;
                const perfDataUrl = pdf.output('datauristring');

                if (window.Android && typeof window.Android.saveStudentReport === 'function') {
                    window.Android.saveStudentReport(perfDataUrl, student.name || 'دانش‌آموز', perfFileName);
                } else if (window.Android && typeof window.Android.saveFile === 'function') {
                    window.Android.saveFile(perfDataUrl, perfFileName, 'application/pdf');
                } else {
                    const pdfBlob = pdf.output('blob');
                    const blobUrl = URL.createObjectURL(pdfBlob);
                    const a = document.createElement('a');
                    a.href = blobUrl;
                    a.download = perfFileName;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
                }
                showToast('📄 گزارش سطح عملکرد با موفقیت ساخته شد');
            } catch (err) {
                console.error('export performance pdf error', err);
                showToast('⚠️ خطا در ساخت فایل PDF', 'error');
            } finally {
                if (el && el.parentNode) el.parentNode.removeChild(el);
            }
        }

        function Dashboard({ data, save, showToast, onOverlayChange }) {
            const [exportingId, setExportingId] = React.useState(null);
            const [exportPicker, setExportPicker] = React.useState(null);
            const [exportSubject, setExportSubject] = React.useState(null);
            const [exportMode, setExportMode] = React.useState(null);
            const handleExportPdf = async (student, selectedSubject, selectedMonth, mode = 'paged') => {
                if (exportingId) return;
                setExportPicker(null);
                setExportMode(null);
                setExportingId(student.id);
                try {
                    await exportStudentReportPdf(student, data, showToast, selectedSubject, selectedMonth, mode);
                } finally {
                    setExportingId(null);
                }
            };

            const [drill, setDrill] = React.useState(null);
            const [attendanceReportOpen, setAttendanceReportOpen] = React.useState(false);
            const [generalReportOpen, setGeneralReportOpen] = React.useState(false);
            const [generalReportStudent, setGeneralReportStudent] = React.useState(null);
            const [studentListOpen, setStudentListOpen] = React.useState(false);
            const [examHistoryOpen, setExamHistoryOpen] = React.useState(false);
            const [budgetingOpen, setBudgetingOpen] = React.useState(false);
            React.useEffect(() => {
                if (onOverlayChange) onOverlayChange(!!(drill || attendanceReportOpen || generalReportOpen || studentListOpen || examHistoryOpen || budgetingOpen || exportPicker));
                return () => { if (onOverlayChange) onOverlayChange(false); };
            }, [drill, attendanceReportOpen, generalReportOpen, studentListOpen, examHistoryOpen, budgetingOpen, exportPicker, onOverlayChange]);
            const budgetingSubjectCount = (data.budgeting && Array.isArray(data.budgeting.subjects)) ? data.budgeting.subjects.length : 0;
            const students = data.students || [];
            const examDateSet = new Set();
            Object.values(data.exams || {}).forEach(arr => arr.forEach(e => examDateSet.add(e.date)));
            const totalExams = examDateSet.size;

            const attendanceDateSet = new Set();
            Object.values(data.attendance || {}).forEach(arr => arr.forEach(a => attendanceDateSet.add(a.date)));
            const totalAttendance = attFinalDays(data).length;

            const attS = React.useMemo(() => attStats(data, () => true), [data.students, data.attendance, data.attendanceDays]);
            const studentStats = students.map(s => {
                const exams = data.exams[s.id] || [];
                const attendance = data.attendance[s.id] || [];

                const combined = getStudentCombinedScoreStats(data, s);

                const st = attS[s.id] || { p: 0, a: 0, l: 0 };
                const present = st.p, absent = st.a, late = st.l;

                return {
                    ...s,
                    examCount: exams.length,
                    perfCount: combined.perfCount,
                    avgPercent: combined.avgPercent,
                    present,
                    absent,
                    late,
                    gradeLevel: combined.gradeLevel
                };
            });

            const sortedStats = [...studentStats].sort((a, b) => b.avgPercent - a.avgPercent);
            // سوابق آزمون در یک صفحه مستقل داخل برنامه نمایش داده می‌شود تا با مودال روی داشبورد تداخل نداشته باشد.
            if (examHistoryOpen) {
                return React.createElement('div', { className: 'exam-history-page', dir: 'rtl' },
                    React.createElement('div', { className: 'exam-history-page-header' },
                        React.createElement('div', null,
                            React.createElement('h2', { style: { margin: 0 } }, '🗂️ سوابق آزمون‌ها'),
                            React.createElement('div', { className: 'text-muted', style: { marginTop: 5 } }, 'مشاهده و ویرایش آزمون‌های ثبت‌شده')
                        ),
                        React.createElement('button', { type: 'button', className: 'btn-primary', onClick: () => setExamHistoryOpen(false) }, '← بازگشت به داشبورد')
                    ),
                    React.createElement('div', { className: 'exam-history-page-body' },
                        React.createElement(ExamHistory, { data, save, showToast })
                    )
                );
            }
return React.createElement('div', null,
                React.createElement('div', { className: 'dashboard-pro' },
                    React.createElement(Reveal, {
                        as: 'div',
                        delay: 0,
                        className: 'dash-stat student-list-clickable',
                        onClick: () => setStudentListOpen(true),
                        title: 'نمایش فهرست دانش‌آموزان به ترتیب حروف الفبا'
                    },
                        React.createElement('span', { className: 'dash-orb' }),
                        React.createElement('div', { className: 'dash-icon' }, '👨‍🎓'),
                        React.createElement('div', { className: 'dash-label' }, 'دانش‌آموزان'),
                        React.createElement('div', { className: 'dash-value pro-counter' }, students.length),
                        React.createElement('div', { className: 'dash-foot' }, 'تعداد ثبت‌شده در کلاس')
                    ),
                    React.createElement(Reveal, { as: 'div', delay: 70, className: 'dash-stat accent', onClick: () => setExamHistoryOpen(true), title: 'مشاهده آزمون‌های ثبت‌شده به تفکیک درس و تاریخ', style: { cursor: 'pointer' } },
                        React.createElement('span', { className: 'dash-orb' }),
                        React.createElement('div', { className: 'dash-icon' }, '📊'),
                        React.createElement('div', { className: 'dash-label' }, 'آزمون‌ها'),
                        React.createElement('div', { className: 'dash-value pro-counter' }, totalExams),
                        React.createElement('div', { className: 'dash-foot' }, 'روز آزمون ثبت‌شده')
                    ),
                    React.createElement(Reveal, {
                        as: 'div',
                        delay: 140,
                        className: 'dash-stat success attendance-clickable',
                        onClick: () => setAttendanceReportOpen(true),
                        title: 'نمایش آمار حضور و غیاب همه دانش‌آموزان'
                    },
                        React.createElement('span', { className: 'dash-orb' }),
                        React.createElement('div', { className: 'dash-icon' }, '✓'),
                        React.createElement('div', { className: 'dash-label' }, 'حضور و غیاب'),
                        React.createElement('div', { className: 'dash-value pro-counter' }, totalAttendance),
                        React.createElement('div', { className: 'dash-foot' }, 'روز ثبت‌شده • برای جزئیات کلیک کنید')
                    ),
                    React.createElement(Reveal, {
                        as: 'div',
                        delay: 210,
                        className: 'dash-stat danger budgeting-clickable',
                        onClick: () => setBudgetingOpen(true),
                        title: 'مشاهده و ویرایش بودجه‌بندی دروس'
                    },
                        React.createElement('span', { className: 'dash-orb' }),
                        React.createElement('div', { className: 'dash-icon' }, '📘'),
                        React.createElement('div', { className: 'dash-label' }, 'بودجه‌بندی'),
                        React.createElement('div', { className: 'dash-value pro-counter' }, budgetingSubjectCount),
                        React.createElement('div', { className: 'dash-foot' }, 'درس ثبت‌شده • برای ثبت و ویرایش کلیک کنید')
                    )
                ),


                students.length > 0 &&
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📊 عملکرد دانش‌آموزان'),
                    sortedStats.map((s, idx) =>
                        React.createElement(Reveal, { key: s.id, as: 'div', delay: Math.min(idx * 45, 450), className: 'student-stat-card' },
                            React.createElement('div', { className: 'stat-row' },
                                React.createElement('div', null,
                                    React.createElement('span', { style: { fontWeight: 700, display: 'inline-block', unicodeBidi: 'isolate' } },
                                        `#${idx + 1} ${s.name}`
                                    ),
                                    React.createElement('span', { className: 'text-muted text-small', style: { marginRight: 8, display: 'inline-block', unicodeBidi: 'isolate' } },
                                        s.className || ''
                                    )
                                ),
                                React.createElement('div', { className: 'flex gap-4 flex-wrap' },
                                    React.createElement('span', {
                                        className: 'tag tag-primary stat-tag-clickable',
                                        onClick: () => setDrill({ studentId: s.id, view: 'subjects' })
                                    },
                                        '📋 ', s.examCount, ' آزمون'
                                    ),
                                    React.createElement('span', {
                                        className: 'tag tag-accent stat-tag-clickable',
                                        onClick: () => setDrill({ studentId: s.id, view: 'performanceLevels' })
                                    },
                                        '📝 ', s.perfCount, ' سطح عملکرد'
                                    ),
                                    React.createElement('span', { className: `tag ${s.avgPercent >= 70 ? 'tag-success' : s.avgPercent >= 50 ? 'tag-accent' : 'tag-danger'}` },
                                        '🎯 ', s.avgPercent, '%'
                                    ),
                                    React.createElement('span', {
                                        className: 'tag tag-success stat-tag-clickable',
                                        onClick: () => setDrill({ studentId: s.id, view: 'attendance', status: 'present' })
                                    },
                                        '✅ ', s.present
                                    ),
                                    React.createElement('span', {
                                        className: 'tag tag-danger stat-tag-clickable',
                                        onClick: () => setDrill({ studentId: s.id, view: 'attendance', status: 'absent' })
                                    },
                                        '❌ ', s.absent
                                    ),
                                    React.createElement('span', {
                                        className: 'tag tag-accent stat-tag-clickable',
                                        onClick: () => setDrill({ studentId: s.id, view: 'attendance', status: 'late' })
                                    },
                                        '⏰ ', s.late
                                    )
                                )
                            ),
                            React.createElement('div', { style: { marginTop: 4, fontSize: 13 } },
                                React.createElement('span', { className: 'text-muted' }, 'وضعیت: '),
                                React.createElement('span', { style: { fontWeight: 600, color: s.avgPercent >= 70 ? '#34C77B' : s.avgPercent >= 50 ? '#FFB454' : '#FF6B81' } },
                                    s.gradeLevel
                                ),
                                React.createElement('span', { className: 'text-muted text-small', style: { marginRight: 6 } },
                                    '(بر اساس آزمون‌ها و سطح عملکرد)'
                                )
                            ),
                            React.createElement('button', {
                                className: 'btn-ghost w-full mt-8',
                                style: { fontSize: 13, padding: '8px' },
                                disabled: exportingId === s.id,
                                onClick: () => { setExportSubject(null); setExportPicker(s); }
                            }, exportingId === s.id ? '⏳ در حال ساخت PDF...' : '📄 گزارش درس‌به‌درس (PDF)'),
                            React.createElement('button', {
                                className: 'btn-primary w-full mt-8', type: 'button', style: { fontSize: 13, padding: '8px' },
                                onClick: () => { setGeneralReportStudent(s); setGeneralReportOpen(true); }
                            }, '📊 گزارش جامع بازه‌ای این دانش‌آموز (PDF)')
                        )
                    )
                ),
                exportPicker &&
                React.createElement('div', { className: 'modal-overlay', onClick: () => !exportingId && setExportPicker(null) },
                    React.createElement('div', {
                        className: 'modal-content',
                        style: { maxWidth: 430, width: 'calc(100% - 32px)', padding: 20 },
                        onClick: e => e.stopPropagation()
                    },
                        React.createElement('div', { style: { fontSize: 18, fontWeight: 900, marginBottom: 6 } }, exportMode ? '📄 انتخاب نوع PDF' : (exportSubject ? '📅 انتخاب ماه گزارش' : '📄 انتخاب درس برای دانلود')),
                        React.createElement('div', { className: 'text-muted', style: { fontSize: 12, marginBottom: 14 } },
                            exportSubject ? `برای درس «${exportSubject}» ماه مورد نظر را انتخاب کنید.` : `برای ${exportPicker.name} کدام درس را می‌خواهید؟`
                        ),
                        !exportSubject && React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 } },
                            SUBJECTS.map(subject => React.createElement('button', { key: subject, type: 'button', className: 'btn-ghost', style: { padding: '10px 8px', fontWeight: 800 }, onClick: () => setExportSubject(subject) }, `📚 ${subject}`))
                        ),
                        exportSubject && !exportMode && React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 } },
                            React.createElement('button', { type: 'button', className: 'btn-ghost', style: { gridColumn: '1 / -1', padding: '11px', fontWeight: 900 }, onClick: () => setExportMode({ month: null }) }, '📚 کل سال'),
                            JALALI_MONTHS.map((month, idx) => React.createElement('button', { key: month, type: 'button', className: 'btn-ghost', style: { padding: '9px 6px', fontWeight: 800 }, onClick: () => setExportMode({ month: idx + 1 }) }, `📅 ${month}`))
                        ),
                        exportSubject && exportMode && React.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr', gap: 8 } },
                            React.createElement('div', { style: { gridColumn: '1 / -1', textAlign: 'center', fontSize: 12, color: '#6f6a61', marginBottom: 2 } }, `نوع PDF برای ${exportMode.month ? (JALALI_MONTHS[exportMode.month - 1] || 'ماه') : 'کل سال'}`),
                            React.createElement('button', { type: 'button', className: 'btn-ghost', style: { padding: '11px', fontWeight: 900 }, onClick: () => handleExportPdf(exportPicker, exportSubject, exportMode.month, 'continuous') }, '📄 PDF'),
                            React.createElement('button', { type: 'button', className: 'btn-ghost', style: { gridColumn: '1 / -1', padding: '8px', fontSize: 12 }, onClick: () => setExportMode(null) }, '↩️ انتخاب ماه دوباره')
                        ),
                        React.createElement('button', {
                            type: 'button',
                            className: 'btn-ghost w-full',
                            style: { marginTop: 10, padding: '9px', fontSize: 12 },
                            onClick: () => { setExportMode(null); setExportSubject(null); setExportPicker(null); },
                            disabled: !!exportingId
                        }, 'انصراف')
                    )
                ),
                students.length === 0 &&
                React.createElement('div', { className: 'card' },
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('div', { className: 'icon' }, '👨‍🎓'),
                        React.createElement('p', null, 'هنوز دانش‌آموزی ثبت نشده')
                    )
                ),
                React.createElement('button', { className: 'btn-primary w-full mt-8', type: 'button', style: { fontSize: 13, padding: '8px' }, onClick: () => { setGeneralReportStudent(null); setGeneralReportOpen(true); } }, '📊 گزارش جامع کل کلاس (PDF)'),
                drill && React.createElement(DrilldownModal, { data, drill, setDrill, showToast }),
                attendanceReportOpen && React.createElement(AttendanceReportModal, { data, onClose: () => setAttendanceReportOpen(false) }),
                generalReportOpen && React.createElement(GeneralClassReportModal, { data, student: generalReportStudent, onClose: () => { setGeneralReportOpen(false); setGeneralReportStudent(null); } }),
                studentListOpen && React.createElement(StudentListModal, { data, onClose: () => setStudentListOpen(false) }),
                budgetingOpen && React.createElement(Budgeting, { data, save, showToast, onClose: () => setBudgetingOpen(false) })
            );
        }

        // ============================================================
        // Dashboard Drilldown Modal - نمایش جزئیات با کلیک روی تگ‌های آمار
        // ============================================================
        function DrilldownModal({ data, drill, setDrill, showToast }) {
            const [lightbox, setLightbox] = React.useState(null);
            const [exportingPerf, setExportingPerf] = React.useState(false);
            const [openPerformanceMonth, setOpenPerformanceMonth] = React.useState(null);
            React.useEffect(() => {
                if (drill.view !== 'performanceLevels') setOpenPerformanceMonth(null);
            }, [drill.view, drill.studentId]);

            const student = (data.students || []).find(s => s.id === drill.studentId);
            if (!student) return null;

            const close = () => setDrill(null);
            const exams = data.exams[student.id] || [];
            const attendance = data.attendance[student.id] || [];

            let title = '';
            let body = null;
            let onBack = null;

            if (drill.view === 'subjects') {
                title = `📋 آزمون‌های ${student.name}`;
                // این اولین صفحه‌ی آزمون‌های دانش‌آموز است؛ برگشت از اینجا فقط
                // همین پنجره را می‌بندد و کاربر دقیقاً روی داشبورد می‌ماند.
                onBack = close;
                const subjectRows = SUBJECTS.map(sub => ({
                    subject: sub,
                    count: exams.filter(e => e.subject === sub).length
                }));
                const listBody = subjectRows.every(r => r.count === 0) ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('div', { className: 'icon' }, '📋'),
                        React.createElement('p', null, 'هنوز آزمونی ثبت نشده')
                    ) :
                    subjectRows.map(r =>
                        React.createElement('div', {
                            key: r.subject,
                            className: `drill-row${r.count > 0 ? ' clickable' : ''}`,
                            style: { opacity: r.count > 0 ? 1 : 0.45 },
                            onClick: () => r.count > 0 && setDrill({ ...drill, view: 'subjectDetail', subject: r.subject })
                        },
                            React.createElement('span', null, r.subject),
                            React.createElement('span', { className: 'tag tag-primary' }, r.count, ' آزمون')
                        )
                    );
                body = React.createElement(React.Fragment, null,
                    React.createElement(StudentExamChart, { data, studentId: student.id }),
                    listBody
                );
            } else if (drill.view === 'subjectDetail') {
                title = `${drill.subject} - ${student.name}`;
                onBack = () => setDrill({ studentId: drill.studentId, view: 'subjects' });
                const subjectExams = exams
                    .filter(e => e.subject === drill.subject)
                    .slice()
                    .sort((a, b) => b.date.localeCompare(a.date));
                body = subjectExams.length === 0 ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('p', null, 'آزمونی برای این درس ثبت نشده')
                    ) :
                    React.createElement('div', null,
                        React.createElement('div', { className: 'text-muted text-small mb-8', style: { textAlign: 'center' } },
                            'برای دیدن توضیحات و عکس‌های هر آزمون، روی همان آزمون بزنید.'
                        ),
                        subjectExams.map((exam, idx) =>
                            React.createElement(Reveal, {
                                key: exam.id,
                                as: 'div',
                                delay: Math.min(idx * 40, 400),
                                className: 'exam-card',
                                style: { cursor: 'pointer', marginBottom: 10 }
                            },
                                React.createElement('div', {
                                    onClick: () => setDrill({ ...drill, view: 'examDetail', examId: exam.id }),
                                    style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }
                                },
                                    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' } },
                                        React.createElement('span', {
                                            className: `tag ${exam.absent ? 'tag-danger' : getGradeClass(exam.grade)}`,
                                            style: exam.absent ? { background: '#fee2e2', color: '#b91c1c', border: '1px solid #fecaca' } : undefined
                                        },
                                            exam.absent ? '❌ غایب (آزمون نداده)' : getGradeLabel(exam.grade)
                                        ),
                                        React.createElement('span', { className: 'text-muted text-small' },
                                            getShamsiWithDay(exam.date)
                                        )
                                    ),
                                    React.createElement('span', {
                                        className: 'tag tag-primary',
                                        style: { fontSize: 12 }
                                    },
                                        exam.images && exam.images.length > 0 ? `📷 ${exam.images.length} عکس • مشاهده جزئیات` : '👁️ مشاهده جزئیات'
                                    )
                                )
                            )
                        )
                    );
            } else if (drill.view === 'examDetail') {
                const exam = exams.find(e => e.id === drill.examId);
                title = exam ? `📋 جزئیات آزمون ${drill.subject} - ${student.name}` : `📋 جزئیات آزمون - ${student.name}`;
                onBack = () => setDrill({ studentId: drill.studentId, view: 'subjectDetail', subject: drill.subject });
                if (!exam) {
                    body = React.createElement('div', { className: 'empty-state' },
                        React.createElement('p', null, 'اطلاعات این آزمون پیدا نشد')
                    );
                } else {
                    const description = (exam.description || exam.notes || '').trim();
                    const examImages = Array.isArray(exam.images) ? exam.images : [];
                    body = React.createElement('div', null,
                        exam.absent && React.createElement('div', { className: 'card', style: { marginBottom: 12, borderRight: '4px solid #dc2626', background: '#fff7f7' } },
                            React.createElement('div', { style: { fontWeight: 800, color: '#b91c1c' } }, '❌ غایب — این دانش‌آموز در این تاریخ آزمون نداده است.'),
                            React.createElement('div', { className: 'text-muted text-small', style: { marginTop: 5 } }, `${drill.subject || exam.subject || 'درس نامشخص'} • ${exam.date ? getShamsiWithDay(exam.date) : 'تاریخ نامشخص'}`)
                        ),
                        React.createElement('div', { className: 'exam-card', style: { marginBottom: 12 } },
                            React.createElement('div', { className: 'exam-header' },
                                React.createElement('span', { className: `tag ${getGradeClass(exam.grade)}` },
                                    getGradeLabel(exam.grade)
                                ),
                                React.createElement('span', { className: 'text-muted text-small' },
                                    `📅 ${getShamsiWithDay(exam.date)}`
                                )
                            ),
                            React.createElement('div', { style: { marginTop: 12 } },
                                React.createElement('div', { className: 'text-muted text-small', style: { marginBottom: 5 } }, '📝 توضیحات عملکرد:'),
                                React.createElement('div', {
                                    style: {
                                        background: '#faf8fc',
                                        border: '1px solid #e8e1ee',
                                        borderRadius: 10,
                                        padding: 12,
                                        lineHeight: 1.9,
                                        whiteSpace: 'pre-wrap',
                                        minHeight: description ? 'auto' : 44
                                    }
                                }, description || 'برای این آزمون توضیحی ثبت نشده است.')
                            )
                        ),
                        React.createElement('div', { className: 'exam-card' },
                            React.createElement('div', { className: 'text-muted text-small mb-8' }, '📷 برگه‌های آزمون:'),
                            examImages.length > 0 ?
                            React.createElement('div', { className: 'exam-images' },
                                examImages.map((img, idx) =>
                                    React.createElement('img', {
                                        key: idx,
                                        src: img,
                                        alt: `برگه ${idx + 1}`,
                                        style: { cursor: 'pointer' },
                                        onClick: () => setLightbox({ images: examImages, index: idx })
                                    })
                                )
                            ) :
                            React.createElement('div', { className: 'text-muted text-small', style: { padding: '12px 0' } },
                                'برای این آزمون عکسی ثبت نشده است.'
                            )
                        )
                    );
                }
            } else if (drill.view === 'attendance') {
                const statusLabel = { present: '✅ حاضر', absent: '❌ غایب', late: '⏰ تأخیر' }[drill.status];
                title = `${statusLabel} - ${student.name}`;
                const records = attendance
                    .filter(r => r.status === drill.status)
                    .slice()
                    .sort((a, b) => b.date.localeCompare(a.date));
                body = records.length === 0 ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('p', null, 'موردی ثبت نشده')
                    ) :
                    records.map(r =>
                        React.createElement('div', { key: r.id, className: 'drill-row' },
                            React.createElement('span', null, getShamsiWithDay(r.date))
                        )
                    );
            } else if (drill.view === 'performanceLevels') {
                title = `📝 سطح عملکرد ماهانه — ${student.name}`;
                const studentPerf = getStudentPerformanceData(data, student);
                const rowTexts = (data.performanceRowTexts && typeof data.performanceRowTexts === 'object') ? data.performanceRowTexts : {};
                const getRowLabel = (row, field, fallback) => {
                    const r = rowTexts[row.id];
                    return (r && typeof r[field] === 'string') ? r[field] : fallback;
                };
                const allRowsForReport = getStudentPerformanceRows(data, student);
                const monthsWithData = PERFORMANCE_MONTHS.map(month => {
                    const items = allRowsForReport.map(row => {
                        const rp = studentPerf[row.id];
                        const value = (rp && typeof rp === 'object') ? rp[month.key] : '';
                        return value ? { row, value } : null;
                    }).filter(Boolean);
                    return { month, items };
                });
                const hasAnyPerformanceData = monthsWithData.some(m => m.items.length > 0);
                body = !hasAnyPerformanceData ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('div', { className: 'icon' }, '📝'),
                        React.createElement('p', null, 'هنوز سطح عملکردی برای این دانش‌آموز ثبت نشده')
                    ) :
                    React.createElement(React.Fragment, null,
                        monthsWithData.map(({ month, items }) => {
                            const isOpen = openPerformanceMonth === month.key;
                            return React.createElement('div', { key: month.key, style: { marginBottom: 8 } },
                                React.createElement('button', {
                                    type: 'button',
                                    onClick: () => setOpenPerformanceMonth(isOpen ? null : month.key),
                                    style: {
                                        width: '100%',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        gap: 8,
                                        padding: '9px 10px',
                                        border: '1px solid ' + (items.length ? '#B9EDE6' : '#EDEAE0'),
                                        borderRadius: isOpen ? '10px 10px 6px 6px' : 10,
                                        background: items.length ? '#F2FFFD' : '#FAFAF8',
                                        color: items.length ? '#1AA6A0' : '#8A877F',
                                        fontWeight: 800,
                                        fontSize: 12,
                                        textAlign: 'right',
                                        cursor: 'pointer'
                                    }
                                },
                                    React.createElement('span', null, `📅 ${month.label}`),
                                    React.createElement('span', { style: { display: 'flex', alignItems: 'center', gap: 6 } },
                                        React.createElement('span', { style: { fontSize: 10, fontWeight: 700, opacity: .8 } },
                                            items.length ? `${toPersianDigits(items.length)} مورد ثبت‌شده` : 'بدون ثبت'
                                        ),
                                        React.createElement('span', { style: { fontSize: 15, lineHeight: 1, transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform .18s ease' } }, '⌄')
                                    )
                                ),
                                isOpen && items.length > 0 &&
                                (() => {
                                    const lessonGroups = {};
                                    items.forEach(item => {
                                        const lesson = item.row.lesson || 'سایر';
                                        const content = getRowLabel(item.row, 'content', item.row.content) || 'بدون عنوان';
                                        if (!lessonGroups[lesson]) lessonGroups[lesson] = {};
                                        if (!lessonGroups[lesson][content]) lessonGroups[lesson][content] = [];
                                        lessonGroups[lesson][content].push(item);
                                    });
                                    const colors = {
                                        excellent: { background: '#DFFBE9', color: '#34C77B' },
                                        good: { background: '#DFF7F3', color: '#2BB3A3' },
                                        acceptable: { background: '#FFEFD1', color: '#FFB454' },
                                        needs_work: { background: '#FFE1E8', color: '#FF6B81' }
                                    };
                                    return React.createElement('div', {
                                        style: { paddingTop: 6, display: 'flex', flexDirection: 'column', gap: 6 }
                                    },
                                        Object.entries(lessonGroups).map(([lesson, branches]) =>
                                            React.createElement('div', {
                                                key: lesson,
                                                style: { border: '1px solid #DDEEEB', borderRadius: 8, overflow: 'hidden', background: '#fff' }
                                            },
                                                React.createElement('div', {
                                                    style: { padding: '6px 8px', background: '#EAFBF8', color: '#167D76', fontWeight: 900, fontSize: 11 }
                                                }, `📚 ${lesson}`),
                                                Object.entries(branches).map(([content, branchItems]) =>
                                                    React.createElement('div', {
                                                        key: content,
                                                        style: { padding: '6px 7px 7px', borderTop: '1px solid #EEF3F2' }
                                                    },
                                                        React.createElement('div', {
                                                            style: { fontSize: 10.5, fontWeight: 800, color: '#666', marginBottom: 5 }
                                                        }, content),
                                                        React.createElement('div', {
                                                            style: { display: 'flex', flexWrap: 'wrap', gap: 4 }
                                                        },
                                                            branchItems.map(({ row, value }) =>
                                                                React.createElement('div', {
                                                                    key: row.id,
                                                                    style: { display: 'inline-flex', alignItems: 'center', gap: 3, padding: '4px 6px', background: '#FAFAF8', border: '1px solid #EEF1EF', borderRadius: 6, maxWidth: '100%' }
                                                                },
                                                                    React.createElement('span', { style: { fontSize: 9.5, fontWeight: 700, lineHeight: 1.3 } },
                                                                        getRowLabel(row, 'expect', row.expect)
                                                                    ),
                                                                    React.createElement('span', {
                                                                        style: { fontSize: 9, fontWeight: 800, whiteSpace: 'nowrap', ...(colors[value] || {}) }
                                                                    }, `(${getGradeLabel(value)})`)
                                                                )
                                                            )
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    );
                                })()                            );
                        }),
                        React.createElement('button', {
                            className: 'btn-ghost w-full mt-8',
                            style: { fontSize: 13, padding: '8px' },
                            disabled: exportingPerf,
                            onClick: async () => {
                                if (exportingPerf) return;
                                setExportingPerf(true);
                                try {
                                    await exportPerformanceReportPdf(student, data, showToast);
                                } finally {
                                    setExportingPerf(false);
                                }
                            }
                        }, exportingPerf ? '⏳ در حال ساخت PDF...' : '📄 دانلود گزارش سطح عملکرد (PDF)')
                    );
            }

            return React.createElement(React.Fragment, null,
                React.createElement('div', { className: 'modal-overlay', 'data-dashboard-drill': 'true', onClick: close },
                    React.createElement('div', { className: 'modal-box', 'data-dashboard-drill-box': 'true', onClick: e => e.stopPropagation() },
                        React.createElement('div', { className: 'modal-header' },
                            onBack &&
                            React.createElement('button', {
                                className: 'btn-ghost drill-back-button',
                                type: 'button',
                                style: { padding: '6px 10px', fontSize: 13 },
                                onClick: e => { e.stopPropagation(); onBack(); }
                            }, '→ بازگشت'),
                            React.createElement('h4', null, title),
                            React.createElement('button', {
                                className: 'btn-ghost',
                                style: { padding: '4px 10px', fontSize: 15 },
                                onClick: close
                            }, '✕')
                        ),
                        React.createElement('div', null, body)
                    )
                ),
                lightbox &&
                React.createElement(ImageLightbox, {
                    images: lightbox.images,
                    index: lightbox.index,
                    onClose: () => setLightbox(null),
                    onNavigate: (newIndex) => setLightbox({ images: lightbox.images, index: newIndex })
                })
            );
        }

        // گزارش جامع بازه‌ای کلاس: همه درس‌ها، آزمون‌ها، حضور و غیاب، تکالیف و نمودار میله‌ای
        function GeneralClassReportModal({ data, student = null, onClose }) {
            const fmtJ = iso => { try { const j = isoToJalali(iso); return toPersianDigits(j.jy + '/' + String(j.jm).padStart(2,'0') + '/' + String(j.jd).padStart(2,'0')); } catch (e) { return ''; } };
            // بازه‌ی پیش‌فرض: از اولین آزمون/حضور ثبت‌شده تا امروز (یا آخرین ثبت)، تا آزمون‌های قبل از ۱۴۰۵/۰۷/۰۱ جا نیفتند.
            const dataDates = React.useMemo(() => {
                const ds = [];
                Object.entries(data.exams || {}).forEach(([sid, arr]) => { if (student && String(sid) !== String(student.id)) return; (arr || []).forEach(e => { if (e && e.date) ds.push(e.date); }); });
                Object.entries(data.attendance || {}).forEach(([sid, arr]) => { if (student && String(sid) !== String(student.id)) return; (arr || []).forEach(a => { if (a && a.date) ds.push(a.date); }); });
                return ds.sort();
            }, [data, student]);
            const firstIso = dataDates.length ? dataDates[0] : null;
            const lastIso = dataDates.length ? dataDates[dataDates.length - 1] : null;
            const [from, setFrom] = React.useState(firstIso ? fmtJ(firstIso) : fmtJ(todayISO()));
            const [to, setTo] = React.useState(fmtJ(lastIso && lastIso > todayISO() ? lastIso : todayISO()));
            const [busy, setBusy] = React.useState(false);
            const [typeFilter, setTypeFilter] = React.useState('all');
            const typeFilterOptions = [{ value: 'all', label: 'همه' }, ...EXAM_TYPES.map(t => ({ value: t.value, label: 'فقط ' + t.plural }))];
            // انتخاب تاریخ با لیست کشویی (سال/ماه/روز) به‌جای تایپ؛ مقدار همچنان به‌صورت «۱۴۰۵/۰۷/۰۱» نگه داشته می‌شود.
            const splitJ = v => { const d = String(v || '').replace(/[۰-۹]/g, x => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(x))).split('/').map(Number); return d.length === 3 && d.every(Number.isFinite) ? { y: d[0], m: d[1], d: d[2] } : { y: isoToJalali(todayISO()).jy, m: 1, d: 1 }; };
            const joinJ = (y, m, d) => toPersianDigits(y + '/' + String(m).padStart(2,'0') + '/' + String(d).padStart(2,'0'));
            const nowY = isoToJalali(todayISO()).jy;
            const JalaliPicker = ({ label, value, onChange }) => {
                const p = splitJ(value);
                const maxD = jalaliDaysInMonth(p.y, p.m);
                const day = Math.min(p.d, maxD);
                const years = []; for (let y = nowY - 6; y <= nowY + 1; y++) years.push(y);
                if (!years.includes(p.y)) years.push(p.y);
                const sel = (val, opts, set, w) => React.createElement('select', { value: val, onChange: e => set(Number(e.target.value)), style: { flex: w, minWidth: 0, padding: '8px 4px' } }, opts);
                return React.createElement('div', null,
                    React.createElement('div', { style: { fontSize: 13, marginBottom: 4 } }, label),
                    React.createElement('div', { style: { display: 'flex', gap: 6 } },
                        sel(day, Array.from({ length: maxD }, (_, i) => React.createElement('option', { key: i + 1, value: i + 1 }, toPersianDigits(String(i + 1)))), v => onChange(joinJ(p.y, p.m, v)), 1),
                        sel(p.m, JALALI_MONTHS.map((m, i) => React.createElement('option', { key: m, value: i + 1 }, m)), v => onChange(joinJ(p.y, v, Math.min(day, jalaliDaysInMonth(p.y, v)))), 2),
                        sel(p.y, years.sort((a, b) => a - b).map(y => React.createElement('option', { key: y, value: y }, toPersianDigits(String(y)))), v => onChange(joinJ(v, p.m, Math.min(day, jalaliDaysInMonth(v, p.m)))), 1.4)
                    ));
            };
            const parseJ = (v) => {
                const d = String(v || '').replace(/[۰-۹]/g, x => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(x))).replace(/[٠-٩]/g, x => String('٠١٢٣٤٥٦٧٨٩'.indexOf(x))).trim().split(/[\/-]/).map(Number);
                if (d.length !== 3 || !d.every(Number.isFinite) || d[0] < 1300 || d[1] < 1 || d[1] > 12 || d[2] < 1 || d[2] > 31) return null;
                try { return jalaliToIso(d[0],d[1],d[2]); } catch(e) { return null; }
            };
            const exportPdf = async () => {
                const start = parseJ(from), end = parseJ(to);
                if (!start || !end || start > end) { alert('بازه تاریخ شمسی را درست وارد کنید؛ نمونه: ۱۴۰۵/۰۷/۰۱'); return; }
                if (!window.html2canvas || !window.jspdf) { alert('ابزار PDF در دسترس نیست؛ برنامه را در مرورگر اصلی باز کنید.'); return; }
                setBusy(true);
                let el;
                try {
                    const inRange = d => !!d && d >= start && d <= end;
                    const students = (data.students || []).filter(st => !student || String(st.id) === String(student.id)).slice().sort((a,b) => String(a.familyName || a.lastName || a.name || '').localeCompare(String(b.familyName || b.lastName || b.name || ''),'fa'));
                    const allExams = Object.entries(data.exams || {}).flatMap(([sid, arr]) => (arr || []).filter(e => inRange(e.date) && (!student || String(sid) === String(student.id))).map(e => ({...e, studentId:sid})).filter(e => typeFilter === 'all' || (e.type || '') === typeFilter)); 
                    const allAtt = Object.entries(data.attendance || {}).flatMap(([sid, arr]) => (arr || []).filter(a => inRange(a.date) && (!student || String(sid) === String(student.id))).map(a => ({...a, studentId:sid}))); 
                    const tasks = (Array.isArray(data.tasks) ? data.tasks : []).filter(t => inRange(t.assignedDate || t.date || t.dueDate || t.createdAt));
                    const subjects = [...new Set(['املا', ...SUBJECTS, ...allExams.map(e => e.subject || e.lesson), ...(data.budgeting?.subjects || []).map(x => typeof x === 'string' ? x : x.name || x.subject)].filter(Boolean))];
                    // ابتدا نمره عددی واقعی را بخوان؛ فقط اگر وجود نداشت از سطح توصیفی استفاده کن.
                    const numScore = v => {
                        if (v === '' || v == null) return NaN;
                        return Number(String(v).replace(/[۰-۹]/g, x => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(x))).replace(/[٠-٩]/g, x => String('٠١٢٣٤٥٦٧٨٩'.indexOf(x))).replace(',', '.'));
                    };
                    const readExamScore = e => {
                        if (e.absent) return null;
                        for (const key of ['score','mark','markObtained','obtainedScore','numericScore','studentScore','scoreValue','gradeValue','points']) {
                            const raw = numScore(e[key]);
                            if (Number.isFinite(raw) && raw >= 0) {
                                const max = ['maxScore','totalScore','outOf','fullScore','scoreMax'].map(k=>numScore(e[k])).find(n=>Number.isFinite(n)&&n>0) || 20;
                                const pct = Math.max(0,Math.min(100,raw/max*100));
                                return { score: pct/5, max: 20, pct, scale: 'عدد' };
                            }
                        }
                        const gradeScore = getGradeScore(e.grade ?? e.level ?? e.result);
                        if (gradeScore > 0) {
                            const score = gradeScore * 5;
                            return { score, max: 20, pct: score * 5, scale: 'توصیفی' };
                        }
                        return null;
                    };
                    const normalizeSubject = v => String(v || '').trim().replace(/[ي]/g,'ی').replace(/[ك]/g,'ک').replace(/\s+/g,' ').toLowerCase();
                    const scoreStatsFor = sub => {
                        const examsForSubject = allExams.filter(e => normalizeSubject(e.subject || e.lesson || e.subjectName) === normalizeSubject(sub)).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
                        const valid = examsForSubject.map(e=>({e,...(readExamScore(e)||{})})).filter(x=>Number.isFinite(x.score));
                        if (!valid.length) return {count:0,avg:null,max:null,pct:null,items:[]};
                        const avgPct = valid.reduce((a,x)=>a+x.pct,0)/valid.length;
                        // گزارش خلاصه همیشه بر مبنای ۲۰ نمایش داده می‌شود، حتی اگر آزمون اصلی توصیفی یا از مقیاس دیگری باشد.
                        const avgScore20 = valid.reduce((a,x)=>a+(x.pct/5),0)/valid.length;
                        const first = valid[0].pct, last = valid[valid.length-1].pct;
                        const progress = first >= 100 ? (last >= 100 ? 0 : -100) : Math.round((last-first)/(100-first)*100);
                        return {count:valid.length,avg:Math.round(avgScore20*100)/100,max:20,pct:Math.round(avgPct),progress,items:valid};
                    };
                    const esc = v => String(v ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
                    const pers = v => toPersianDigits(v);
                    const T_STATUS = { done:{t:'تحویل داده',c:'#16845b',bg:'#dcfce7'}, incomplete:{t:'ناقص',c:'#a16207',bg:'#fef3c7'}, missing:{t:'تحویل نداده',c:'#be123c',bg:'#ffe4e6'}, pending:{t:'بررسی نشده',c:'#64748b',bg:'#f1f5f9'} };
                    const taskKey = (t, sid) => { const v = (t.statuses || {})[sid]; return v && T_STATUS[v] ? v : 'pending'; };
                    const taskStatFor = st => { const c = { done:0, incomplete:0, missing:0, pending:0 }; tasks.forEach(t => { c[taskKey(t, st.id)]++; }); c.total = tasks.length; c.pct = c.total ? Math.round(c.done / c.total * 100) : null; return c; };
                    const rows = students.map((st,i) => {
                        const a = allAtt.filter(x => String(x.studentId) === String(st.id));
                        const e = allExams.filter(x => String(x.studentId) === String(st.id));
                        const absent = a.filter(x => x.status === 'absent').length;
                        const ts = taskStatFor(st);
                        const pointsNow = Number((data.studentPoints || {})[st.id]) || 0;
                        return `<tr><td>${pers(i+1)}</td><td>${esc(st.name)}</td><td>${pers(e.length)}</td><td style="color:#b42318;font-weight:800">${pers(absent)}</td><td style="font-weight:800;color:${pointsNow<0?'#b42318':'#087f5b'}">${pers(pointsNow)}</td><td><span style="color:#16845b;font-weight:800">${pers(ts.done)}</span> / <span style="color:#a16207;font-weight:800">${pers(ts.incomplete)}</span> / <span style="color:#be123c;font-weight:800">${pers(ts.missing)}</span></td></tr>`;
                    }).join('');
                    const chartSubjects = subjects.map(sub=>({sub,stats:scoreStatsFor(sub)})).filter(x=>x.stats.count>0);
                    const palette = ['#16866f','#c2415d','#3478c8','#b7791f','#805ad5','#0891b2','#4d7c0f','#be185d','#d97706','#475569','#db2777','#0f766e'];
                    const shortDate = d => { try { const j = isoToJalali(d); return String(j.jm).padStart(2,'0') + '/' + String(j.jd).padStart(2,'0'); } catch(e) { return ''; } };
                    const persZ = v => String(v).replace(/[0-9]/g, x => '۰۱۲۳۴۵۶۷۸۹'[x]);
                    const levelName = s => s >= 17.5 ? 'خیلی خوب' : s >= 12.5 ? 'خوب' : s >= 7.5 ? 'قابل قبول' : 'نیاز به تلاش بیشتر';
                    const chartLevelName = s => s >= 17.5 ? 'خیلی خوب' : s >= 12.5 ? 'خوب' : s >= 7.5 ? 'قابل قبول' : 'نیاز به تلاش بیشتر';
                    const levelPosition = s => s >= 17.5 ? 4 : s >= 12.5 ? 3 : s >= 7.5 ? 2 : 1;
                    // برای هر درس: میانگین نمره‌ی هر تاریخ (چند آزمون در یک روز → میانگین) و روند اول→آخر
                    const subjData = chartSubjects.map((item,i) => {
                        // هر آزمون یک نقطه‌ی مستقل باشد؛ آزمونک و آزمون ماهانه در یک روز نباید یکی شوند.
                        const pts = item.stats.items.filter(it => it.e.date).slice().sort((a,b)=>String(a.e.date).localeCompare(String(b.e.date)) || String(a.e.type||'').localeCompare(String(b.e.type||''))).map(it => ({date:it.e.date, type:it.e.type || '', score:it.pct/5, examTitle:it.e.title || it.e.name || ''}));
                        const first = pts[0].score, last = pts[pts.length-1].score;
                        const delta = Math.round((last-first)*10)/10;
                        const dir = pts.length < 2 ? 'none' : delta > 0.4 ? 'up' : delta < -0.4 ? 'down' : 'flat';
                        return { sub:item.sub, color:palette[i%palette.length], pts, first, last, delta, dir, avg:item.stats.avg, count:item.stats.count };
                    });
                    const dirInfo = { up:{c:'#15803d',bg:'#ecfdf3',t:'▲ پیشرفت'}, down:{c:'#b91c1c',bg:'#fef2f2',t:'▼ افت'}, flat:{c:'#475569',bg:'#f1f5f9',t:'● ثابت'}, none:{c:'#64748b',bg:'#f1f5f9',t:'فقط یک آزمون'} };
                    const miniChart = d => {
                        const W=440,H=210,pl=44,pr=16,pt=22,pb=34,pw=W-pl-pr,ph=H-pt-pb;
                        const X = i => pl + (d.pts.length<=1 ? pw/2 : i*pw/(d.pts.length-1));
                        const Y = s => pt + ph - levelPosition(s)*ph/4;
                        const levelTicks = [{v:1,t:'نیاز به تلاش بیشتر'},{v:2,t:'قابل قبول'},{v:3,t:'خوب'},{v:4,t:'خیلی خوب'}];
                        const grid = levelTicks.map(t=>`<line x1="${pl}" y1="${Y(t.v===4?20:t.v===3?15:t.v===2?10:5)}" x2="${W-pr}" y2="${Y(t.v===4?20:t.v===3?15:t.v===2?10:5)}" stroke="#e5ebf0" stroke-width="1"/><text x="${pl-8}" y="${Y(t.v===4?20:t.v===3?15:t.v===2?10:5)+4}" text-anchor="end" font-size="9" fill="#64748b">${t.t}</text>`).join('');
                        const line = d.pts.length>1 ? `<path d="${d.pts.map((p,i)=>`${i?'L':'M'} ${X(i)} ${Y(p.score)}`).join(' ')}" fill="none" stroke="${d.color}" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>` : '';
                        const area = d.pts.length>1 ? `<path d="M ${X(0)} ${Y(0)} ${d.pts.map((p,i)=>`L ${X(i)} ${Y(p.score)}`).join(' ')} L ${X(d.pts.length-1)} ${Y(0)} Z" fill="${d.color}" opacity="0.10"/>` : '';
                        const step = Math.max(1, Math.ceil(d.pts.length/7));
                        const dots = d.pts.map((p,i)=>`<circle cx="${X(i)}" cy="${Y(p.score)}" r="5.5" fill="${d.color}" stroke="#fff" stroke-width="2"/>${(i%step===0||i===d.pts.length-1)?`<text x="${X(i)}" y="${H-12}" text-anchor="middle" font-size="9" fill="#64748b">${persZ(shortDate(p.date))}${p.type==='quiz'?' · آزمونک':p.type==='monthly'?' · ماهانه':''}</text>`:''}`).join('');
                        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" style="width:100%;height:auto;display:block;direction:ltr;font-family:Vazirmatn,Tahoma,sans-serif">${grid}${area}${line}${dots}</svg>`;
                    };
                    const subjectCards = subjData.map(d => {
                        const di = dirInfo[d.dir];
                        const deltaTxt = d.dir==='none' ? 'برای نمایش روند حداقل دو آزمون لازم است' : `از «${chartLevelName(d.first)}» به «${chartLevelName(d.last)}»`; 
                        return `<div data-pdf-block="1" style="width:48%;margin-left:2%;box-sizing:border-box;border:1px solid #dce7eb;border-top:5px solid ${d.color};border-radius:12px;padding:12px;background:#fff;margin-bottom:14px;float:right">
                            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><b style="font-size:16px;color:${d.color}">${esc(d.sub)}</b><span style="font-size:12px;font-weight:800;color:${di.c};background:${di.bg};padding:3px 10px;border-radius:99px">${di.t}</span></div>
                            <div style="font-size:12px;color:#475569;margin-bottom:4px">سطح عملکرد میانگین: <b>${chartLevelName(d.avg)}</b> — ${pers(d.count)} آزمون</div>
                            <div style="font-size:12px;font-weight:700;color:${di.c};margin-bottom:6px">${deltaTxt}</div>
                            ${miniChart(d)}</div>`;
                    }).join('');
                    const barsFallback = subjData.slice().sort((a,b)=>levelPosition(b.avg)-levelPosition(a.avg)).map(d=>`<div style="display:flex;align-items:center;gap:10px;margin:7px 0"><div style="width:90px;font-size:13px;font-weight:700;text-align:right">${esc(d.sub)}</div><div style="flex:1;height:18px;background:#eef3f6;border-radius:9px;overflow:hidden;direction:ltr"><div style="width:${levelPosition(d.avg)/4*100}%;height:100%;background:${d.color};border-radius:9px"></div></div><div style="width:125px;font-size:12px;font-weight:800;text-align:right">${chartLevelName(d.avg)}</div></div>`).join('');
                    // نمودار راداری: هر درس یک محور؛ شکل پر = میانگین، خط‌چین = نمره‌ی اولین آزمون
                    const radarHtml = (() => {
                        const n = subjData.length; if (n < 3) return barsFallback;
                        const W=620,H=460,cx=W/2,cy=H/2+4,R=150;
                        const ang = i => -Math.PI/2 + i*2*Math.PI/n;
                        const pt = (i,v) => [cx + Math.cos(ang(i))*R*levelPosition(v)/4, cy + Math.sin(ang(i))*R*levelPosition(v)/4];
                        const poly = vals => vals.map((v,i)=>pt(i,v).map(x=>x.toFixed(1)).join(',')).join(' ');
                        const rings = [1,2,3,4].map(v=>`<polygon points="${poly(subjData.map(()=>v*5))}" fill="${v===4?'#fafcfd':'none'}" stroke="#d5e0e6" stroke-width="1"/>`).join('');
                        const ringLabels = {1:'نیاز به تلاش بیشتر',2:'قابل قبول',3:'خوب',4:'خیلی خوب'};
                        const ringLbl = [1,2,3,4].map(v=>`<text x="${cx+4}" y="${(cy-R*v/4+3).toFixed(1)}" font-size="9" fill="#7a8a95">${ringLabels[v]}</text>`).join('');
                        const axes = subjData.map((d,i)=>{const [x,y]=pt(i,20);return `<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="#d5e0e6" stroke-width="1"/>`;}).join('');
                        const firstPoly = `<polygon points="${poly(subjData.map(d=>d.first))}" fill="none" stroke="#94a3b8" stroke-width="2" stroke-dasharray="6 4"/>`;
                        const avgPoly = `<polygon points="${poly(subjData.map(d=>d.avg))}" fill="#1fa6a0" fill-opacity="0.28" stroke="#0f766e" stroke-width="3" stroke-linejoin="round"/>`;
                        const dots = subjData.map((d,i)=>{const [x,y]=pt(i,d.avg);return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="${d.color}" stroke="#fff" stroke-width="2"/>`;}).join('');
                        const labels = subjData.map((d,i)=>{const [x,y]=pt(i,20);const dx=Math.cos(ang(i)),dy=Math.sin(ang(i));const lx=cx+dx*(R+44),ly=cy+dy*(R+30);
                            return `<div style="position:absolute;left:${(lx/W*100).toFixed(2)}%;top:${(ly/H*100).toFixed(2)}%;transform:translate(-50%,-50%);text-align:center;white-space:nowrap;line-height:1.35"><div style="font-size:13px;font-weight:800;color:${d.color}">${esc(d.sub)}</div><div style="font-size:12px;font-weight:700;color:#334155">${chartLevelName(d.avg)}</div></div>`;}).join('');
                        return `<div style="position:relative;width:100%;max-width:${W}px;margin:0 auto"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" style="width:100%;height:auto;display:block;direction:ltr">${rings}${axes}${ringLbl}${firstPoly}${avgPoly}${dots}</svg>${labels}</div><div style="display:flex;justify-content:center;gap:22px;font-size:12px;color:#475569;margin-top:6px"><span><i style="display:inline-block;width:16px;height:10px;background:#1fa6a0;opacity:.5;border:2px solid #0f766e;vertical-align:middle;margin-left:6px"></i>میانگین نمره</span><span><i style="display:inline-block;width:18px;border-top:2px dashed #94a3b8;vertical-align:middle;margin-left:6px"></i>نمره‌ی اولین آزمون</span></div>`;
                    })();
                    const avgBars = radarHtml;
                    const trendRows = subjData.map(d=>{const di=dirInfo[d.dir];return `<tr data-pdf-block="1"><td style="font-weight:800;color:${d.color}">${esc(d.sub)}</td><td>${pers(d.count)}</td><td>${chartLevelName(d.first)}</td><td>${chartLevelName(d.last)}</td><td>${chartLevelName(d.avg)}</td><td style="font-weight:800;color:${di.c}">${d.dir==='none'?'—':d.dir==='up'?'بهبود':d.dir==='down'?'کاهش':'بدون تغییر'}</td><td style="font-weight:800;color:${di.c}">${di.t}</td></tr>`;}).join('');
                    const bars = subjData.length ? `<div data-pdf-block="1" style="font-size:12px;color:#53636c;background:#f4f8fa;border-radius:10px;padding:10px;margin-bottom:14px;line-height:1.9"><b>راهنما:</b> در نمودارها به‌جای عدد نمره، سطح توصیفی نمایش داده می‌شود: خیلی خوب، خوب، قابل قبول و نیاز به تلاش بیشتر. در هر نمودار، محور افقی تاریخ آزمون‌های همان درس است. روند با مقایسه سطح توصیفی آزمون نخست و آخر مشخص می‌شود؛ بهبود یعنی ارتقای سطح، کاهش یعنی پایین آمدن سطح و ثابت یعنی بدون تغییر سطح.</div>
                        <h3 data-pdf-block="1" style="margin:6px 0 8px;color:#176b73">مقایسه‌ی توصیفی سطح عملکرد درس‌ها</h3><div data-pdf-block="1" style="border:1px solid #dce7eb;border-radius:12px;padding:14px;margin-bottom:16px">${avgBars}</div>
                        <h3 data-pdf-block="1" style="margin:6px 0 8px;color:#176b73">جدول روند هر درس</h3><table style="width:100%;border-collapse:collapse;font-size:13px;margin-bottom:18px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="padding:8px">درس</th><th>تعداد آزمون</th><th>سطح اولین</th><th>سطح آخرین</th><th>سطح کلی</th><th>تغییر سطح</th><th>روند</th></tr></thead><tbody>${trendRows}</tbody></table>
                        <h3 data-pdf-block="1" style="margin:6px 0 10px;color:#176b73">نمودار روند هر درس</h3><div style="overflow:hidden">${subjectCards}</div><div style="clear:both"></div>` : '<p style="padding:14px;background:#f5f7f8;border-radius:10px">در بازه انتخابی هیچ نمره معتبری برای رسم نمودار ثبت نشده است.</p>';
                    // در گزارش یک دانش‌آموز، ستون نام تکراری حذف می‌شود و نام فقط یک‌بار بالای جدول می‌آید.
                    const stuTh = student ? '' : '<th style="padding:7px;border:1px solid #ddd">دانش‌آموز</th>';
                    const stuCaption = student ? `<div style="margin:0 0 8px;padding:8px 12px;background:#edf8fa;border-radius:10px;font-size:13px;text-align:center">دانش‌آموز: <b>${esc(student.name)}</b></div>` : '';
                    const examDetails = allExams.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))).map(e => `<tr><td>${esc(toShamsi(e.date))}</td>${student ? '' : `<td>${esc((students.find(s=>String(s.id)===String(e.studentId))||{}).name)}</td>`}<td>${esc(e.subject || e.lesson || '—')}</td><td>${esc(e.title || e.name || 'آزمون')}</td><td>${esc(e.absent ? 'غایب' : (e.score != null && e.score !== '' ? e.score : (e.grade ? getGradeLabel(e.grade) : 'ثبت نشده')))}</td><td>${esc(getExamTypeLabel(e.type))}</td></tr>`).join('');
                    const attDetails = allAtt.filter(a=>a.status==='absent').slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))).map(a => `<tr><td>${esc(toShamsi(a.date))}</td>${student ? '' : `<td>${esc((students.find(s=>String(s.id)===String(a.studentId))||{}).name)}</td>`}<td>${a.status==='absent'?'غایب':a.status==='late'?'تأخیر':a.status==='present'?'حاضر':esc(a.status)}</td><td>${esc(a.note || a.description || '—')}</td></tr>`).join('');
                    const pointHistory = (Array.isArray(data.pointHistory) ? data.pointHistory : []).filter(p => inRange(String(p.date || '').slice(0,10)) && (!student || String(p.studentId) === String(student.id))).slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
                    const pointRows = pointHistory.map(p => `<tr><td>${esc(p.date ? toShamsi(String(p.date).slice(0,10)) : '—')}</td>${student ? '' : `<td>${esc((students.find(st=>String(st.id)===String(p.studentId))||{}).name || '—')}</td>`}<td style="font-weight:800;color:${Number(p.amount)<0?'#b42318':'#087f5b'}">${Number(p.amount)>0?'+':''}${pers(p.amount)}</td><td>${esc(p.reason || (Number(p.amount)<0?'کسر امتیاز':'امتیاز مثبت'))}</td></tr>`).join('');
                    const pointsSection = `<h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">گزارش امتیازها</h2><div style="padding:10px 12px;background:#edf8fa;border-radius:10px;margin-bottom:10px">امتیاز فعلی: <b>${pers(student ? ((data.studentPoints||{})[student.id]||0) : students.reduce((sum,st)=>sum+(Number((data.studentPoints||{})[st.id])||0),0))}</b></div>${stuCaption}<table style="width:100%;border-collapse:collapse;font-size:12px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="padding:7px;border:1px solid #ddd">تاریخ</th>${stuTh}<th style="padding:7px;border:1px solid #ddd">امتیاز</th><th style="padding:7px;border:1px solid #ddd">دلیل</th></tr></thead><tbody>${pointRows || '<tr><td colspan="${student ? 3 : 4}" style="padding:10px;text-align:center">در این بازه تغییر امتیازی ثبت نشده است</td></tr>'}</tbody></table>`;
                    const T_TYPES = { worksheet:'کاربرگ', exercise:'تمرین کتاب', homework:'تکلیف', research:'تحقیق', other:'سایر' };
                    const sortedTasks = tasks.slice().sort((a,b) => String(a.assignedDate || a.date || '').localeCompare(String(b.assignedDate || b.date || '')));
                    const sd = d => d ? esc(toShamsi(d)) : '—';
                    const tTotals = { done:0, incomplete:0, missing:0, pending:0 };
                    // در گزارش دانش‌آموز، آمار کلی فقط برای همان دانش‌آموز محاسبه می‌شود؛ گزارش کلاس همچنان همه دانش‌آموزان را در بر می‌گیرد.
                    if (student) {
                        sortedTasks.forEach(t => { tTotals[taskKey(t, student.id)]++; });
                    } else {
                        students.forEach(st => sortedTasks.forEach(t => { tTotals[taskKey(t, st.id)]++; }));
                    }
                    const tAll = student ? sortedTasks.length : students.length * sortedTasks.length;
                    const tPct = tAll ? Math.round(tTotals.done / tAll * 100) : 0;
                    const th = 'padding:7px;border:1px solid #ddd';
                    const tCards = ['done','incomplete','missing','pending'].map(k => `<div style="background:${T_STATUS[k].bg};color:${T_STATUS[k].c};padding:12px;border-radius:12px;text-align:center"><b>${T_STATUS[k].t}</b><div style="font-size:23px;font-weight:900">${pers(tTotals[k])}</div></div>`).join('') + `<div style="background:#edf8fa;color:#176b73;padding:12px;border-radius:12px;text-align:center"><b>درصد تحویل</b><div style="font-size:23px;font-weight:900">${pers(tPct)}٪</div></div>`;
                    const taskRows = sortedTasks.map(t => {
                        const common = `<td>${sd(t.assignedDate || t.date)}</td><td>${esc(t.title || 'بدون عنوان')}</td><td>${esc(T_TYPES[t.type] || 'سایر')}</td><td>${sd(t.dueDate)}</td>`;
                        if (student) {
                            const status = taskKey(t, student.id);
                            // جزئیات دانش‌آموز فقط موارد ناقص یا تحویل‌نداده را نشان می‌دهد؛ تحویل‌شده‌ها فقط در آمار کلی شمرده می‌شوند.
                            if (status !== 'incomplete' && status !== 'missing') return '';
                            const m = T_STATUS[status];
                            return `<tr>${common}<td><span style="background:${m.bg};color:${m.c};font-weight:800;padding:2px 10px;border-radius:99px">${m.t}</span></td></tr>`;
                        }
                        const c = { done:0, incomplete:0, missing:0, pending:0 }; students.forEach(st => { c[taskKey(t, st.id)]++; });
                        return `<tr>${common}<td style="color:#16845b;font-weight:800">${pers(c.done)}</td><td style="color:#a16207;font-weight:800">${pers(c.incomplete)}</td><td style="color:#be123c;font-weight:800">${pers(c.missing)}</td><td style="color:#64748b">${pers(c.pending)}</td></tr>`;
                    }).join('');
                    const taskHead = student
                        ? `<th style="${th}">تاریخ تعیین</th><th style="${th}">عنوان</th><th style="${th}">نوع</th><th style="${th}">مهلت</th><th style="${th}">وضعیت</th>`
                        : `<th style="${th}">تاریخ تعیین</th><th style="${th}">عنوان</th><th style="${th}">نوع</th><th style="${th}">مهلت</th><th style="${th}">تحویل داده</th><th style="${th}">ناقص</th><th style="${th}">تحویل نداده</th><th style="${th}">بررسی نشده</th>`;
                    const stuTaskRows = student ? '' : students.map((st, i) => {
                        const c = taskStatFor(st); const risky = c.total && c.missing / c.total >= 0.3;
                        return `<tr style="${risky ? 'background:#fff5f5' : ''}"><td>${pers(i + 1)}</td><td>${esc(st.name)}</td><td style="color:#16845b;font-weight:800">${pers(c.done)}</td><td style="color:#a16207;font-weight:800">${pers(c.incomplete)}</td><td style="color:#be123c;font-weight:800">${pers(c.missing)}</td><td style="color:#64748b">${pers(c.pending)}</td><td style="font-weight:800">${c.pct == null ? '—' : pers(c.pct) + '٪'}</td></tr>`;
                    }).join('');
                    const tasksSection = sortedTasks.length === 0
                        ? `<h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">تکالیف و موارد تحویلی</h2><p style="padding:12px;background:#f5f7f8;border-radius:10px;font-size:13px">در این بازه تکلیف یا مورد تحویلی ثبت نشده است.</p>`
                        : `<h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">تکالیف و موارد تحویلی</h2>
                        <div data-pdf-block="1" style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:14px">${tCards}</div>
                        <table style="width:100%;border-collapse:collapse;font-size:12px;text-align:center;margin-bottom:16px"><thead><tr style="background:#eaf4f5">${taskHead}</tr></thead><tbody>${taskRows || (student ? `<tr><td colspan="5" style="padding:12px;text-align:center;color:#16845b;font-weight:700">همه تکالیف و موارد تحویلی این دانش‌آموز کامل تحویل داده شده‌اند.</td></tr>` : '')}</tbody></table>
                        ${student ? '' : `<h3 data-pdf-block="1" style="margin:6px 0 8px;color:#176b73">وضعیت تحویل هر دانش‌آموز <span style="font-size:11px;font-weight:400;color:#64748b">(ردیف قرمز: بیش از ۳۰٪ تحویل‌نداده)</span></h3><table style="width:100%;border-collapse:collapse;font-size:12px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="${th}">ردیف</th><th style="${th}">نام دانش‌آموز</th><th style="${th}">تحویل داده</th><th style="${th}">ناقص</th><th style="${th}">تحویل نداده</th><th style="${th}">بررسی نشده</th><th style="${th}">درصد تحویل</th></tr></thead><tbody>${stuTaskRows}</tbody></table>`}`;
                    el = document.createElement('div'); Object.assign(el.style,{position:'fixed',left:'-100000px',top:'0',width:'1000px',padding:'34px',background:'#fff',color:'#263238',direction:'rtl',fontFamily:"'Vazirmatn',Tahoma,sans-serif",lineHeight:'1.7',boxSizing:'border-box'});
                    el.innerHTML = `<div style="background:linear-gradient(120deg,#125d72,#1fa6a0);color:white;border-radius:18px;padding:28px;margin-bottom:20px"><div style="font-size:28px;font-weight:900">گزارش جامع آموزشی ${student ? 'دانش‌آموز' : 'کلاس'}</div><div style="font-size:16px;margin-top:6px">${student ? esc(student.name) + ' — ' : ''}از ${esc(from)} تا ${esc(to)}${typeFilter !== 'all' ? ' — ' + esc((typeFilterOptions.find(o => o.value === typeFilter) || {}).label) : ''}</div><div style="opacity:.9;font-size:12px;margin-top:4px">تاریخ تهیه: ${esc(toShamsi(todayISO()))}</div></div><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:22px"><div style="background:#edf8fa;padding:14px;border-radius:12px;text-align:center"><b>دانش‌آموزان</b><div style="font-size:25px;font-weight:900">${pers(students.length)}</div></div><div style="background:#f0f7ff;padding:14px;border-radius:12px;text-align:center"><b>آزمون‌ها</b><div style="font-size:25px;font-weight:900">${pers(allExams.length)}</div></div><div style="background:#fff1f0;padding:14px;border-radius:12px;text-align:center"><b>غیبت</b><div style="font-size:25px;font-weight:900">${pers(allAtt.filter(a=>a.status==='absent').length)}</div></div><div style="background:#fff7e8;padding:14px;border-radius:12px;text-align:center"><b>تأخیر</b><div style="font-size:25px;font-weight:900">${pers(allAtt.filter(a=>a.status==='late').length)}</div></div></div><h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px">روند نمرات در طول زمان</h2>${bars}<h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">خلاصه هر دانش‌آموز</h2><table style="width:100%;border-collapse:collapse;font-size:13px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="padding:8px;border:1px solid #d5e0e3">ردیف</th><th style="padding:8px;border:1px solid #d5e0e3">نام دانش‌آموز</th><th style="padding:8px;border:1px solid #d5e0e3">آزمون</th><th style="padding:8px;border:1px solid #d5e0e3">غیبت</th><th style="padding:8px;border:1px solid #d5e0e3">امتیاز فعلی</th><th style="padding:8px;border:1px solid #d5e0e3">تکالیف (تحویل / ناقص / نداده)</th></tr></thead><tbody>${rows}</tbody></table><h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">جزئیات آزمون‌ها</h2>${stuCaption}<table style="width:100%;border-collapse:collapse;font-size:12px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="padding:7px;border:1px solid #ddd">تاریخ</th>${stuTh}<th style="padding:7px;border:1px solid #ddd">درس</th><th style="padding:7px;border:1px solid #ddd">عنوان</th><th style="padding:7px;border:1px solid #ddd">نمره</th><th style="padding:7px;border:1px solid #ddd">نوع آزمون</th></tr></thead><tbody>${examDetails || '<tr><td colspan="${student ? 5 : 6}" style="padding:10px;text-align:center">آزمونی در این بازه ثبت نشده است</td></tr>'}</tbody></table>${tasksSection}${pointsSection}<h2 style="color:#176b73;border-bottom:2px solid #d8eeee;padding-bottom:7px;margin-top:28px">جزئیات غیبت‌ها</h2>${stuCaption}<table style="width:100%;border-collapse:collapse;font-size:12px;text-align:center"><thead><tr style="background:#eaf4f5"><th style="padding:7px;border:1px solid #ddd">تاریخ</th>${stuTh}<th style="padding:7px;border:1px solid #ddd">وضعیت</th><th style="padding:7px;border:1px solid #ddd">توضیحات</th></tr></thead><tbody>${attDetails || '<tr><td colspan="${student ? 3 : 4}" style="padding:10px;text-align:center">غیبتی در این بازه ثبت نشده است</td></tr>'}</tbody></table><div style="margin-top:24px;padding:12px;border-radius:10px;background:#f4f7f8;color:#607078;font-size:11px">این گزارش بر اساس اطلاعات ثبت‌شده در برنامه و بازه تاریخ انتخابی تهیه شده است. در خلاصه هر درس، میانگین نمره از ۲۰ درج شده است. نمودار برای هر درس رنگ جداگانه دارد و میانگین نمره ثبت‌شده همان درس را در هر تاریخ از ۲۰ نشان می‌دهد.</div>`;
                    document.body.appendChild(el);
                    const canvas = await window.html2canvas(el,{scale:2,backgroundColor:'#ffffff',useCORS:true,logging:false});
                    const {jsPDF}=window.jspdf; const pdf=new jsPDF({orientation:'portrait',unit:'mm',format:'a4'});
                    smartPaginatePdf(pdf, canvas, el, { margin: 8 });
                    const stuName = student ? String(student.name || 'دانش‌آموز').replace(/[\\/:*?"<>|]/g, '_').trim() : '';
                    const reportFileName = stuName ? `گزارش جامع - ${stuName}.pdf` : 'گزارش جامع - کلاس.pdf';
                    const pdfDataUrl = pdf.output('datauristring');

                    if (window.Android && typeof window.Android.saveStudentReport === 'function' && stuName) {
                        window.Android.saveStudentReport(pdfDataUrl, stuName, reportFileName);
                    } else if (window.Android && typeof window.Android.saveFile === 'function') {
                        window.Android.saveFile(pdfDataUrl, reportFileName, 'application/pdf');
                    } else {
                        pdf.save(reportFileName);
                    }
                    if(el.parentNode) el.parentNode.removeChild(el);
                    if(typeof showToast==='function') showToast('گزارش جامع PDF ساخته شد');
                } catch(err) { console.error('general report PDF error',err); alert('ساخت گزارش PDF با خطا مواجه شد.'); if(el?.parentNode) el.parentNode.removeChild(el); }
                finally { setBusy(false); }
            };
            return React.createElement('div',{className:'modal-overlay',onClick:onClose},React.createElement('div',{className:'modal-box',onClick:e=>e.stopPropagation(),style:{maxWidth:560}},
                React.createElement('div',{className:'modal-header'},React.createElement('h4',null,student ? '📑 گزارش جامع PDF دانش‌آموز' : '📑 گزارش جامع PDF کلاس'),React.createElement('button',{className:'btn-ghost',onClick:onClose},'✕')),
                React.createElement('p',{className:'text-muted text-small'},student ? 'گزارش کلی همین دانش‌آموز در بازه انتخابی: همه درس‌ها، آزمون‌ها، امتیازها، غیبت‌ها، تکالیف و نمودار توصیفی روند نمرات.' : 'گزارش همه درس‌ها و آزمون‌ها، امتیازها، غیبت‌ها، وضعیت تکالیف و نمودار توصیفی پیشرفت در بازه انتخابی.'),
                React.createElement('div',{className:'grid-2 gap-12'},JalaliPicker({label:'از تاریخ',value:from,onChange:setFrom}),JalaliPicker({label:'تا تاریخ',value:to,onChange:setTo})),
                React.createElement('div',{className:'text-muted text-small',style:{marginTop:8}},`بازه انتخاب‌شده: ${from} تا ${to} (تقویم شمسی)`),
                firstIso && React.createElement('div',{className:'text-small',style:{marginTop:8,padding:'8px 10px',background:'#f1f8f8',borderRadius:8}},
                    `اولین ثبت: ${fmtJ(firstIso)} — آخرین ثبت: ${fmtJ(lastIso)} `,
                    React.createElement('button',{type:'button',className:'btn-ghost',style:{padding:'3px 10px',fontSize:12,marginRight:6},onClick:()=>{setFrom(fmtJ(firstIso));setTo(fmtJ(lastIso > todayISO() ? lastIso : todayISO()));}},'کل دوره')),
                React.createElement('div',{style:{marginTop:12}},
                    React.createElement('div',{style:{fontSize:13,marginBottom:4}},'🏷️ نوع آزمون‌های گزارش (نمودارها، رادار و میانگین‌ها هم همین را رعایت می‌کنند)'),
                    React.createElement('div',{style:{display:'flex',gap:6,flexWrap:'wrap'}},typeFilterOptions.map(o=>React.createElement('button',{key:o.value,type:'button',onClick:()=>setTypeFilter(o.value),style:{padding:'7px 12px',borderRadius:99,fontSize:13,fontWeight:700,cursor:'pointer',border:typeFilter===o.value?'2px solid #2BB3A3':'1px solid #dce9e7',background:typeFilter===o.value?'rgba(43,179,163,.13)':'#fff',color:typeFilter===o.value?'#176b73':'#4b5563'}},o.label)))),
                React.createElement('div',{className:'flex gap-8',style:{marginTop:18}},React.createElement('button',{className:'btn-primary',onClick:exportPdf,disabled:busy},busy?'⏳ در حال ساخت گزارش...':'📄 ساخت و دانلود PDF'),React.createElement('button',{className:'btn-ghost',onClick:onClose},'انصراف'))
            ));
        }

        // ============================================================
        // Attendance Report - گزارش کلی حضور و غیاب همه دانش‌آموزان
        // ============================================================
        function AttendanceReportModal({ data, onClose }) {
            const [exporting, setExporting] = React.useState(false);
            const students = data.students || [];
            const attendanceData = data.attendance || {};

            const allStats = React.useMemo(() => attStats(data, () => true), [data.students, data.attendance, data.attendanceDays]);
            const rows = students.map((student, index) => {
                const st = allStats[student.id] || { p: 0, a: 0, l: 0 };
                const present = st.p, absent = st.a, late = st.l;
                const total = present + absent + late;
                const percent = total ? Math.round((present / total) * 100) : 0;
                return { index: index + 1, student, present, absent, late, total, percent };
            });

            const totals = rows.reduce((a, r) => ({
                present: a.present + r.present,
                absent: a.absent + r.absent,
                late: a.late + r.late,
                total: a.total + r.total
            }), { present: 0, absent: 0, late: 0, total: 0 });
            const studentsWithRecord = rows.filter(r => r.total > 0).length;
            const overallPercent = totals.total ? Math.round((totals.present / totals.total) * 100) : 0;

            const exportPdf = async () => {
                if (exporting) return;
                if (!window.html2canvas || !window.jspdf) {
                    alert('ابزار خروجی PDF در دسترس نیست. فایل را در مرورگر اصلی باز کنید.');
                    return;
                }
                setExporting(true);
                let el = null;
                try {
                    el = document.createElement('div');
                    el.style.position = 'fixed';
                    el.style.left = '-100000px';
                    el.style.top = '0';
                    el.style.width = '900px';
                    el.style.background = '#fff';
                    el.style.color = '#222';
                    el.style.direction = 'rtl';
                    el.style.fontFamily = "'Vazirmatn', Tahoma, sans-serif";
                    el.style.padding = '36px';
                    el.style.lineHeight = '1.8';

                    const statusCell = (value, color) => `<td style="padding:8px;border:1px solid #ddd;text-align:center;color:${color};font-weight:700">${toPersianDigits(value)}</td>`;
                    el.innerHTML = `
                        <div style="background:#1F8A94;color:#fff;border-radius:12px;padding:20px;margin-bottom:18px;text-align:center">
                            <div style="font-size:24px;font-weight:800">گزارش کلی حضور و غیاب دانش‌آموزان</div>
                            <div style="font-size:13px;margin-top:5px">تاریخ تهیه گزارش: ${getShamsiWithDay(todayISO())}</div>
                        </div>
                        <div style="display:flex;gap:10px;margin-bottom:18px">
                            <div style="flex:1;text-align:center;border:1px solid #ddd;border-radius:10px;padding:10px"><b>${toPersianDigits(students.length)}</b><br><small>کل دانش‌آموزان</small></div>
                            <div style="flex:1;text-align:center;border:1px solid #ddd;border-radius:10px;padding:10px"><b style="color:#34C77B">${toPersianDigits(totals.present)}</b><br><small>حاضر</small></div>
                            <div style="flex:1;text-align:center;border:1px solid #ddd;border-radius:10px;padding:10px"><b style="color:#FF6B81">${toPersianDigits(totals.absent)}</b><br><small>غایب</small></div>
                            <div style="flex:1;text-align:center;border:1px solid #ddd;border-radius:10px;padding:10px"><b style="color:#FFB454">${toPersianDigits(totals.late)}</b><br><small>تأخیر</small></div>
                            <div style="flex:1;text-align:center;border:1px solid #ddd;border-radius:10px;padding:10px"><b>${toPersianDigits(overallPercent)}٪</b><br><small>درصد حضور</small></div>
                        </div>
                        <table style="width:100%;border-collapse:collapse;font-size:13px">
                            <thead><tr style="background:#EEF3F2">
                                <th style="padding:8px;border:1px solid #ddd">ردیف</th>
                                <th style="padding:8px;border:1px solid #ddd;text-align:right">نام دانش‌آموز</th>
                                <th style="padding:8px;border:1px solid #ddd">کلاس</th>
                                <th style="padding:8px;border:1px solid #ddd">حاضر</th>
                                <th style="padding:8px;border:1px solid #ddd">غایب</th>
                                <th style="padding:8px;border:1px solid #ddd">تأخیر</th>
                                <th style="padding:8px;border:1px solid #ddd">کل ثبت</th>
                                <th style="padding:8px;border:1px solid #ddd">درصد حضور</th>
                            </tr></thead>
                            <tbody>
                                ${rows.map(r => `<tr>
                                    <td style="padding:7px;border:1px solid #ddd;text-align:center">${toPersianDigits(r.index)}</td>
                                    <td style="padding:7px;border:1px solid #ddd">${escHtml(r.student.name || '—')}</td>
                                    <td style="padding:7px;border:1px solid #ddd;text-align:center">${escHtml(r.student.className || (GRADE_ORDER.includes(r.student.grade) ? gradeName(r.student.grade) : '—'))}</td>
                                    ${statusCell(r.present, '#34C77B')}
                                    ${statusCell(r.absent, '#FF6B81')}
                                    ${statusCell(r.late, '#FFB454')}
                                    <td style="padding:7px;border:1px solid #ddd;text-align:center">${toPersianDigits(r.total)}</td>
                                    <td style="padding:7px;border:1px solid #ddd;text-align:center;font-weight:700">${toPersianDigits(r.percent)}٪</td>
                                </tr>`).join('')}
                            </tbody>
                        </table>
                        <div style="margin-top:14px;font-size:12px;color:#666">دانش‌آموزان دارای سابقه حضور و غیاب: ${toPersianDigits(studentsWithRecord)} نفر</div>
                    `;
                    document.body.appendChild(el);
                    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
                    const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
                    const { jsPDF } = window.jspdf;
                    const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
                    smartPaginatePdf(pdf, canvas, el, { margin: 8 });
                    document.body.removeChild(el);
                    const attFileName = 'گزارش_کلی_حضور_و_غیاب.pdf';
                    const attDataUrl = pdf.output('datauristring');
                    if (window.Android && typeof window.Android.saveFile === 'function') {
                        window.Android.saveFile(attDataUrl, attFileName, 'application/pdf');
                    } else {
                        pdf.save(attFileName);
                    }
                } catch (err) {
                    console.error('attendance PDF error', err);
                    alert('ساخت فایل PDF با خطا مواجه شد.');
                } finally {
                    if (el && el.parentNode) el.parentNode.removeChild(el);
                    setExporting(false);
                }
            };

            return React.createElement('div', { className: 'modal-overlay', onClick: onClose },
                React.createElement('div', { className: 'modal-box', onClick: e => e.stopPropagation(), style: { maxWidth: 1050 } },
                    React.createElement('div', { className: 'modal-header' },
                        React.createElement('h4', null, '✅ آمار کلی حضور و غیاب'),
                        React.createElement('button', { className: 'btn-ghost', style: { padding: '4px 10px', fontSize: 15 }, onClick: onClose }, '✕')
                    ),
                    React.createElement('div', { className: 'flex flex-wrap gap-8 mb-8', style: { justifyContent: 'space-around' } },
                        React.createElement('div', { className: 'text-center' }, React.createElement('div', { style: { fontSize: 25, fontWeight: 800 } }, students.length), React.createElement('div', { className: 'text-muted text-small' }, 'دانش‌آموز')),
                        React.createElement('div', { className: 'text-center' }, React.createElement('div', { style: { fontSize: 25, fontWeight: 800, color: '#34C77B' } }, totals.present), React.createElement('div', { className: 'text-muted text-small' }, 'حاضر')),
                        React.createElement('div', { className: 'text-center' }, React.createElement('div', { style: { fontSize: 25, fontWeight: 800, color: '#FF6B81' } }, totals.absent), React.createElement('div', { className: 'text-muted text-small' }, 'غایب')),
                        React.createElement('div', { className: 'text-center' }, React.createElement('div', { style: { fontSize: 25, fontWeight: 800, color: '#FFB454' } }, totals.late), React.createElement('div', { className: 'text-muted text-small' }, 'تأخیر')),
                        React.createElement('div', { className: 'text-center' }, React.createElement('div', { style: { fontSize: 25, fontWeight: 800, color: '#2BB3A3' } }, overallPercent + '%'), React.createElement('div', { className: 'text-muted text-small' }, 'درصد حضور'))
                    ),
                    React.createElement('div', { style: { overflowX: 'auto' } },
                        React.createElement('table', { className: 'attendance-table' },
                            React.createElement('thead', null, React.createElement('tr', null,
                                React.createElement('th', null, '#'), React.createElement('th', null, 'نام دانش‌آموز'), React.createElement('th', null, 'کلاس'),
                                React.createElement('th', null, 'حاضر'), React.createElement('th', null, 'غایب'), React.createElement('th', null, 'تأخیر'), React.createElement('th', null, 'کل ثبت'), React.createElement('th', null, 'درصد حضور')
                            )),
                            React.createElement('tbody', null,
                                rows.map(r => React.createElement('tr', { key: r.student.id },
                                    React.createElement('td', null, r.index), React.createElement('td', null, r.student.name || '—'), React.createElement('td', null, r.student.className || (GRADE_ORDER.includes(r.student.grade) ? gradeName(r.student.grade) : '—')),
                                    React.createElement('td', { style: { color: '#34C77B', fontWeight: 700 } }, r.present), React.createElement('td', { style: { color: '#FF6B81', fontWeight: 700 } }, r.absent),
                                    React.createElement('td', { style: { color: '#FFB454', fontWeight: 700 } }, r.late), React.createElement('td', null, r.total), React.createElement('td', { style: { fontWeight: 700 } }, r.percent + '%')
                                ))
                            )
                        )
                    ),
                    React.createElement('div', { className: 'flex gap-8 mt-8', style: { justifyContent: 'flex-end' } },
                        React.createElement('button', { className: 'btn-ghost', onClick: onClose }, 'بستن'),
                        React.createElement('button', { className: 'btn-primary', onClick: exportPdf, disabled: exporting }, exporting ? '⏳ در حال ساخت PDF...' : '📄 خروجی PDF')
                    )
                )
            );
        }

        // ============================================================
        // Student List Modal - فهرست الفبایی دانش‌آموزان داشبورد
        // ============================================================
        function StudentListModal({ data, onClose }) {
            const normalizeFa = (s) => (s || '').trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک');
            const [expandedId, setExpandedId] = React.useState(null);
            const toggleExpand = (id) => setExpandedId(prev => prev === id ? null : id);

            const students = [...(data.students || [])].sort((a, b) => {
                const lastA = normalizeFa(a.lastName || (a.name || '').trim().split(/\s+/).slice(1).join(' '));
                const lastB = normalizeFa(b.lastName || (b.name || '').trim().split(/\s+/).slice(1).join(' '));
                return lastA.localeCompare(lastB, 'fa', { sensitivity: 'base', numeric: true });
            });

            return React.createElement('div', { className: 'modal-overlay', onClick: onClose },
                React.createElement('div', {
                    className: 'modal-box',
                    onClick: e => e.stopPropagation(),
                    style: { maxWidth: 720 }
                },
                    React.createElement('div', { className: 'modal-header' },
                        React.createElement('h4', null, '👨‍🎓 فهرست دانش‌آموزان'),
                        React.createElement('button', {
                            className: 'btn-ghost',
                            style: { padding: '4px 10px', fontSize: 15 },
                            onClick: onClose
                        }, '✕')
                    ),
                    React.createElement('div', {
                        className: 'text-muted text-small mb-8',
                        style: { textAlign: 'right' }
                    }, `تعداد دانش‌آموزان: ${toPersianDigits(students.length)} نفر • مرتب‌شده بر اساس حروف الفبا (نام خانوادگی) • برای مشاهده جزئیات روی نام کلیک کنید`),
                    students.length === 0 ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('div', { className: 'icon' }, '👨‍🎓'),
                        React.createElement('p', null, 'هنوز دانش‌آموزی ثبت نشده')
                    ) :
                    React.createElement('div', { style: { maxHeight: '65vh', overflowY: 'auto' } },
                        students.map((student, index) =>
                            React.createElement('div', {
                                key: student.id,
                                className: 'record-row',
                                style: { marginBottom: 6, flexWrap: 'wrap' }
                            },
                                React.createElement('div', {
                                        className: 'flex items-center gap-8',
                                        style: { cursor: 'pointer' },
                                        onClick: () => toggleExpand(student.id)
                                    },
                                    React.createElement('div', {
                                        style: {
                                            minWidth: 34,
                                            height: 34,
                                            borderRadius: 10,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            background: '#E8F1EF',
                                            color: '#2BB3A3',
                                            fontWeight: 800
                                        }
                                    }, toPersianDigits(index + 1)),
                                    React.createElement('div', null,
                                        React.createElement('div', { style: { fontWeight: 700 } },
                                            student.name || 'بدون نام', ' ',
                                            React.createElement('span', { style: { fontSize: 11, color: '#999' } }, expandedId === student.id ? '▲' : '▼')
                                        ),
                                        React.createElement('div', { className: 'text-muted text-small' }, student.className || 'بدون کلاس')
                                    )
                                ),
                                expandedId === student.id &&
                                React.createElement('ul', {
                                        style: {
                                            width: '100%',
                                            margin: '8px 0 0 0',
                                            padding: '8px 28px',
                                            listStyle: 'disc',
                                            background: '#faf8fc',
                                            borderRadius: 8,
                                            fontSize: 13
                                        }
                                    },
                                    React.createElement('li', null, `نام: ${student.firstName || (student.name || '').split(/\s+/)[0] || '—'}`),
                                    React.createElement('li', null, `نام خانوادگی: ${student.lastName || (student.name || '').split(/\s+/).slice(1).join(' ') || '—'}`),
                                    React.createElement('li', null, `پایه: ${student.className || 'بدون کلاس'}`),
                                    React.createElement('li', null, `کد ملی: ${student.nationalId || '—'}`),
                                    React.createElement('li', null, `شماره تماس پدر: ${student.fatherPhone || '—'}`),
                                    React.createElement('li', null, `شماره تماس مادر: ${student.motherPhone || '—'}`)
                                )
                            )
                        )
                    ),
                    React.createElement('div', { className: 'flex gap-8 mt-8', style: { justifyContent: 'flex-end' } },
                        React.createElement('button', { className: 'btn-primary', onClick: onClose }, 'بستن')
                    )
                )
            );
        }

        // ============================================================
        // Students
        // ============================================================
        // اگر یک دانش‌آموز قدیمی، پیش‌تر «کلاس» را به‌صورت متن آزاد داشته (مثلاً «پنجم الف»)
        // این تابع تلاش می‌کند پایه‌ی متناظر را از همان متن حدس بزند تا هنگام ویرایش
        // فیلد پایه خالی نماند و کاربر مجبور به وارد کردن دوباره‌ی اطلاعات نشود.
        function guessGradeFromText(text) {
            if (!text) return '';
            const t = String(text);
            for (const g of GRADE_ORDER) {
                if (t.includes(GRADE_LABELS[g])) return g;
            }
            const digitMatch = t.match(/[1-6]/);
            return digitMatch ? digitMatch[0] : '';
        }

        function Students({ data, save, showToast }) {
            const [firstName, setFirstName] = React.useState('');
            const [lastName, setLastName] = React.useState('');
            const [nationalId, setNationalId] = React.useState('');
            const [motherPhone, setMotherPhone] = React.useState('');
            const [fatherPhone, setFatherPhone] = React.useState('');
            const [grade, setGrade] = React.useState('');
            const [editingId, setEditingId] = React.useState(null);
            const [expandedId, setExpandedId] = React.useState(null);
            const [photo, setPhoto] = React.useState('');

            const students = data.students || [];

            const normalizeFa = (s) => (s || '').trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک');

            const sortedStudents = React.useMemo(() => {
                return [...students].sort((a, b) => {
                    const lastA = normalizeFa(a.lastName || (a.name || '').trim().split(/\s+/).slice(1).join(' '));
                    const lastB = normalizeFa(b.lastName || (b.name || '').trim().split(/\s+/).slice(1).join(' '));
                    return lastA.localeCompare(lastB, 'fa');
                });
            }, [students]);

            const toggleExpand = (id) => {
                setExpandedId(prev => prev === id ? null : id);
            };

            const addOrUpdate = () => {
                if (!firstName.trim()) {
                    showToast('نام دانش‌آموز را وارد کنید', 'error');
                    return;
                }
                if (!lastName.trim()) {
                    showToast('نام خانوادگی دانش‌آموز را وارد کنید', 'error');
                    return;
                }
                if (!grade) {
                    showToast('پایه‌ی دانش‌آموز را انتخاب کنید', 'error');
                    return;
                }
                const fullName = `${firstName.trim()} ${lastName.trim()}`.trim();
                if (editingId) {
                    const newData = {
                        ...data,
                        students: students.map(s =>
                            s.id === editingId ?
                            {
                                ...s,
                                firstName: firstName.trim(),
                                lastName: lastName.trim(),
                                name: fullName,
                                nationalId: nationalId.trim(),
                                motherPhone: motherPhone.trim(),
                                fatherPhone: fatherPhone.trim(),
                                grade,
                                className: GRADE_LABELS[grade] || '',
                                photo: photo || s.photo || ''
                            } :
                            s
                        )
                    };
                    const ok = save(newData);
                    if (ok !== false) {
                        showToast('ویرایش شد');
                    }
                } else {
                    const newStudent = {
                        id: uid(),
                        firstName: firstName.trim(),
                        lastName: lastName.trim(),
                        name: fullName,
                        nationalId: nationalId.trim(),
                        motherPhone: motherPhone.trim(),
                        fatherPhone: fatherPhone.trim(),
                        grade,
                        className: GRADE_LABELS[grade] || '',
                        photo
                    };
                    const ok = save({ ...data, students: [...students, newStudent] });
                    if (ok !== false) {
                        showToast('دانش‌آموز اضافه شد');
                    }
                }
                setFirstName('');
                setLastName('');
                setNationalId('');
                setMotherPhone('');
                setFatherPhone('');
                setGrade('');
                setPhoto('');
                setEditingId(null);
            };

            const remove = (id) => {
                if (!confirm('«' + ((students.find(s => s.id === id) || {}).name || '') + '» و تمام داده‌های مربوطه (آزمون‌ها، حضور و غیاب، امتیازها، عملکرد، تکالیف) حذف شود؟')) return;
                const newExams = { ...(data.exams || {}) };
                delete newExams[id];
                const newAttendance = { ...(data.attendance || {}) };
                delete newAttendance[id];
                const newData = {
                    ...data,
                    students: students.filter(s => s.id !== id),
                    exams: newExams,
                    attendance: newAttendance
                };
                Object.assign(newData, {
                    studentPoints: Object.fromEntries(Object.entries(data.studentPoints || {}).filter(([k]) => String(k) !== String(id))),
                    studentGroups: Object.fromEntries(Object.entries(data.studentGroups || {}).filter(([k]) => String(k) !== String(id))),
                    pointHistory: (data.pointHistory || []).filter(p => String(p.studentId) !== String(id)),
                    performance: Object.fromEntries(Object.entries(data.performance || {}).filter(([k]) => String(k) !== String(id))),
                    performanceByGrade: Object.fromEntries(Object.entries(data.performanceByGrade || {}).map(([g, gm]) => [g, Object.fromEntries(Object.entries(gm || {}).filter(([k]) => String(k) !== String(id)))])),
                    tasks: (data.tasks || []).map(t => ({ ...t, statuses: Object.fromEntries(Object.entries(t.statuses || {}).filter(([k]) => String(k) !== String(id))), statusDates: Object.fromEntries(Object.entries(t.statusDates || {}).filter(([k]) => String(k) !== String(id))) }))
                });
                const ok = save(newData);
                if (ok !== false) {
                    showToast('حذف شد');
                }
            };

            const edit = (s) => {
                if (s.firstName || s.lastName) {
                    setFirstName(s.firstName || '');
                    setLastName(s.lastName || '');
                } else {
                    const parts = (s.name || '').trim().split(/\s+/);
                    setFirstName(parts.shift() || '');
                    setLastName(parts.join(' '));
                }
                setNationalId(s.nationalId || '');
                setMotherPhone(s.motherPhone || '');
                setFatherPhone(s.fatherPhone || '');
                setGrade(s.grade || guessGradeFromText(s.className));
                setPhoto(s.photo || '');
                setEditingId(s.id);
            };

            const cancelEdit = () => {
                setPhoto('');
                setFirstName('');
                setLastName('');
                setNationalId('');
                setMotherPhone('');
                setFatherPhone('');
                setGrade('');
                setEditingId(null);
            };

            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, editingId ? '✏️ ویرایش دانش‌آموز' :
                    '➕ افزودن دانش‌آموز'),
                    React.createElement('div', { className: 'mb-8', style: { display: 'flex', gap: 8 } },
                        React.createElement('input', {
                            type: 'text',
                            placeholder: 'نام',
                            value: firstName,
                            onChange: e => setFirstName(e.target.value),
                            style: { flex: 1 }
                        }),
                        React.createElement('input', {
                            type: 'text',
                            placeholder: 'نام خانوادگی',
                            value: lastName,
                            onChange: e => setLastName(e.target.value),
                            style: { flex: 1 }
                        })
                    ),
                    React.createElement('div', { className: 'mb-8' },
                        React.createElement('input', {
                            type: 'text',
                            inputMode: 'numeric',
                            placeholder: 'کد ملی',
                            value: nationalId,
                            onChange: e => setNationalId(e.target.value)
                        })
                    ),
                    React.createElement('div', { className: 'mb-8', style: { display: 'flex', gap: 8 } },
                        React.createElement('input', {
                            type: 'tel',
                            inputMode: 'tel',
                            placeholder: 'شماره تماس پدر',
                            value: fatherPhone,
                            onChange: e => setFatherPhone(e.target.value),
                            style: { flex: 1 }
                        }),
                        React.createElement('input', {
                            type: 'tel',
                            inputMode: 'tel',
                            placeholder: 'شماره تماس مادر',
                            value: motherPhone,
                            onChange: e => setMotherPhone(e.target.value),
                            style: { flex: 1 }
                        })
                    ),
                    React.createElement('div', { className: 'mb-8', style: { display: 'flex', alignItems: 'center', gap: 10 } },
                        photo ? React.createElement('img', { src: photo, alt: 'عکس دانش‌آموز', style: { width: 58, height: 58, borderRadius: '50%', objectFit: 'cover', border: '2px solid #1F8A94' } }) : null,
                        React.createElement('label', { style: { flex: 1, display: 'block', padding: 10, border: '1px dashed #1F8A94', borderRadius: 10, cursor: 'pointer', textAlign: 'center' } },
                            '📷 انتخاب عکس دانش‌آموز',
                            React.createElement('input', { type: 'file', accept: 'image/*', style: { display: 'block', width: '100%', marginTop: 6 }, onChange: async e => { const f=e.target.files && e.target.files[0]; if(!f) return; try { setPhoto(await compressImage(f, 500, 0.65)); } catch(err) { showToast('خواندن عکس ممکن نشد','error'); } } })
                        )
                    ),
                    React.createElement('div', { className: 'mb-8' },
                        React.createElement('select', {
                            value: grade,
                            onChange: e => setGrade(e.target.value)
                        },
                            React.createElement('option', { value: '' }, 'پایه را انتخاب کنید...'),
                            GRADE_ORDER.map(g => React.createElement('option', { key: g, value: g }, gradeName(g)))
                        )
                    ),
                    React.createElement('div', { className: 'flex gap-8' },
                        React.createElement('button', {
                            onClick: addOrUpdate,
                            className: editingId ? 'btn-accent' : 'btn-primary',
                            style: { flex: 1 }
                        }, editingId ? '💾 ذخیره' : '➕ افزودن'),
                        editingId &&
                        React.createElement('button', {
                            onClick: cancelEdit,
                            className: 'btn-ghost'
                        }, '❌ انصراف')
                    )
                ),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' },
                        '📋 لیست دانش‌آموزان ', React.createElement('span', { className: 'badge' }, students.length)
                    ),
                    students.length === 0 ?
                    React.createElement('div', { className: 'empty-state' },
                        React.createElement('div', { className: 'icon' }, '👨‍🎓'),
                        React.createElement('p', null, 'هنوز دانش‌آموزی ثبت نشده')
                    ) :
                    sortedStudents.map((s, idx) =>
                        React.createElement(Reveal, { key: s.id, as: 'div', delay: Math.min(idx * 35, 420), className: 'record-row' },
                            React.createElement('div', {
                                    onClick: () => toggleExpand(s.id),
                                    style: { cursor: 'pointer', display: 'flex', gap: 8, alignItems: 'flex-start' }
                                },
                                React.createElement('span', {
                                    className: 'badge',
                                    style: { marginTop: 2, flexShrink: 0 }
                                }, idx + 1),
                                React.createElement('div', { style: { display:'flex', alignItems:'center', gap:8 } },
                                    s.photo ? React.createElement('img',{src:s.photo,alt:s.name,style:{width:42,height:42,borderRadius:'50%',objectFit:'cover'}}) : React.createElement('span',{style:{fontSize:28}},'👨‍🎓'),
                                    React.createElement('div', null,
                                    React.createElement('div', { style: { fontWeight: 600 } },
                                        s.name, ' ', React.createElement('span', { style: { fontSize: 11, color: '#999' } }, expandedId === s.id ? '▲' : '▼')
                                    ),
                                    React.createElement('div', { className: 'text-muted text-small' }, s.className ||
                                        'بدون کلاس')
                                    )
                                )
                            ),
                            React.createElement('div', { className: 'flex gap-4' },
                                React.createElement('button', {
                                    onClick: () => edit(s),
                                    className: 'btn-ghost',
                                    style: { padding: '4px 10px', fontSize: 13 }
                                }, '✏️'),
                                React.createElement('button', {
                                    onClick: () => remove(s.id),
                                    className: 'btn-danger',
                                    style: { padding: '4px 10px', fontSize: 13 }
                                }, '🗑️')
                            ),
                            expandedId === s.id &&
                            React.createElement('ul', {
                                    style: {
                                        width: '100%',
                                        margin: '4px 0 0 0',
                                        padding: '8px 28px',
                                        listStyle: 'disc',
                                        background: '#faf8fc',
                                        borderRadius: 8,
                                        fontSize: 13
                                    }
                                },
                                React.createElement('li', null, `نام: ${s.firstName || (s.name || '').split(/\s+/)[0] || '—'}`),
                                React.createElement('li', null, `نام خانوادگی: ${s.lastName || (s.name || '').split(/\s+/).slice(1).join(' ') || '—'}`),
                                React.createElement('li', null, `پایه: ${s.className || 'بدون کلاس'}`),
                                React.createElement('li', null, `کد ملی: ${s.nationalId || '—'}`),
                                React.createElement('li', null, `شماره تماس پدر: ${s.fatherPhone || '—'}`),
                                React.createElement('li', null, `شماره تماس مادر: ${s.motherPhone || '—'}`)
                            )
                        )
                    )
                )
            );
        }

        // ============================================================
        // Exams - با بارگذاری صحیح تصاویر (روش ساده و تست شده)
        // ============================================================
        function ExamHistory({ data, save, showToast }) {
            const [selectedKey, setSelectedKey] = React.useState(null);
            const [draft, setDraft] = React.useState(null);
            const formatExamDate = value => (value ? toShamsi(value) : '');
            const makeKey = (subject, date, type) => JSON.stringify([subject, date, type || '']);
            const records = React.useMemo(() => {
                const map = new Map();
                Object.entries(data.exams || {}).forEach(([studentId, exams]) => {
                    (Array.isArray(exams) ? exams : []).forEach((exam, index) => {
                        if (!exam || !exam.subject || !exam.date) return;
                        const type = exam.type || '';
                        const key = makeKey(exam.subject, exam.date, type);
                        if (!map.has(key)) map.set(key, { key, subject: exam.subject, date: exam.date, type, entries: [] });
                        map.get(key).entries.push({ studentId: String(studentId), exam, index });
                    });
                });
                return map;
            }, [data.exams]);
            const items = [...records.values()].sort((a, b) => (b.date || '').localeCompare(a.date || '') || a.subject.localeCompare(b.subject, 'fa'));
            const groupedItems = items.reduce((groups, item) => {
                const subject = (item.subject || 'بدون درس').trim();
                if (!groups[subject]) groups[subject] = [];
                groups[subject].push(item);
                return groups;
            }, {});
            const subjectNames = Object.keys(groupedItems).sort((a, b) => a.localeCompare(b, 'fa'));
            const [expandedSubjects, setExpandedSubjects] = React.useState({});
            const active = selectedKey ? records.get(selectedKey) : null;
            React.useEffect(() => { if (selectedKey && !records.has(selectedKey)) { setSelectedKey(null); setDraft(null); } }, [records, selectedKey]);
            const openRecord = item => {
                setSelectedKey(item.key);
                setDraft({ subject: item.subject, oldDate: item.date, oldType: item.type, date: item.date, type: item.type || 'quiz', entries: item.entries.map((entry, i) => ({
                    studentId: entry.studentId,
                    original: entry.exam,
                    token: `${entry.studentId}::${entry.exam.id || entry.index}::${i}`,
                    grade: entry.exam.grade || '',
                    absent: !!entry.exam.absent,
                    description: entry.exam.description || ''
                })) });
            };
            const saveEdits = () => {
                if (!active || !draft) return;
                if (!draft.date) { showToast('لطفاً تاریخ آزمون را مشخص کنید.', 'error'); return; }
                const originalTokens = new Set(draft.entries.map(e => `${e.studentId}::${e.original.id || ''}::${e.original.date}::${e.original.subject}::${e.original.type || ''}`));
                // از ادغام ناخواسته با آزمون دیگری جلوگیری می‌کنیم؛ هیچ داده‌ای حذف یا بازنویسی نمی‌شود.
                const collision = Object.entries(data.exams || {}).some(([studentId, list]) => (Array.isArray(list) ? list : []).some(e => {
                    if (!e || e.subject !== draft.subject || e.date !== draft.date || (e.type || '') !== draft.type) return false;
                    const token = `${studentId}::${e.id || ''}::${e.date}::${e.subject}::${e.type || ''}`;
                    return !originalTokens.has(token);
                }));
                if (collision && (draft.date !== draft.oldDate || draft.type !== (draft.oldType || ''))) {
                    showToast('برای این درس، تاریخ و نوع آزمون، ثبت دیگری وجود دارد. برای جلوگیری از ادغام یا حذف اطلاعات، ابتدا آن مورد را بررسی کنید.', 'error');
                    return;
                }
                const byToken = new Map(draft.entries.map(e => [`${e.studentId}::${e.original.id || ''}::${e.original.date}::${e.original.subject}::${e.original.type || ''}`, e]));
                const nextExams = {};
                Object.entries(data.exams || {}).forEach(([studentId, list]) => {
                    nextExams[studentId] = (Array.isArray(list) ? list : []).map(e => {
                        if (!e || e.subject !== draft.subject || e.date !== draft.oldDate || (e.type || '') !== (draft.oldType || '')) return e;
                        const token = `${studentId}::${e.id || ''}::${e.date}::${e.subject}::${e.type || ''}`;
                        const edited = byToken.get(token);
                        if (!edited) return e;
                        return { ...e, date: draft.date, type: draft.type, grade: edited.absent ? '' : edited.grade, absent: !!edited.absent, description: edited.description };
                    });
                });
                const ok = save({ ...data, exams: nextExams });
                if (ok === false) { showToast('ذخیره تغییرات انجام نشد؛ اطلاعات قبلی دست‌نخورده باقی ماند.', 'error'); return; }
                showToast('تغییرات آزمون ذخیره شد. اطلاعات ثبت‌شده دانش‌آموزان حفظ شد.');
                setSelectedKey(null); setDraft(null);
            };
            return React.createElement('div', null,
                !draft ? React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '🗂️ سوابق آزمون'),
                    React.createElement('div', { className: 'text-muted text-small mb-8' }, 'برای ویرایش، روی درس و تاریخ آزمون بزنید.'),
                    items.length === 0
                        ? React.createElement('div', { className: 'text-muted', style: { textAlign: 'center', padding: '24px 10px' } }, 'هنوز آزمونی ثبت نشده است.')
                        : React.createElement('div', { style: { display: 'grid', gap: 12 } }, subjectNames.map(subject => {
                            const expanded = expandedSubjects[subject] === true;
                            const subjectItems = groupedItems[subject];
                            return React.createElement('section', { key: subject, style: { border: '1px solid #cfe4e1', borderRadius: 14, overflow: 'hidden', background: '#f8fcfb' } },
                                React.createElement('button', {
                                    type: 'button', 'aria-expanded': expanded,
                                    onClick: () => setExpandedSubjects(prev => ({ ...prev, [subject]: !expanded })),
                                    style: { width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '13px 14px', border: 0, background: '#eaf6f4', color: '#176b73', textAlign: 'right', cursor: 'pointer', fontFamily: "'Vazirmatn', Tahoma, sans-serif" }
                                },
                                    React.createElement('span', { style: { display: 'flex', alignItems: 'center', gap: 8, fontWeight: 800, fontSize: 15 } }, '📚 ', subject),
                                    React.createElement('span', { style: { display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 } },
                                        React.createElement('span', { style: { fontSize: 12, background: '#fff', border: '1px solid #cfe4e1', borderRadius: 20, padding: '3px 9px', color: '#176b73' } }, `${subjectItems.length} آزمون`),
                                        expanded ? '⌃' : '⌄'
                                    )
                                ),
                                expanded ? React.createElement('div', { style: { display: 'grid', gap: 7, padding: 9 } }, subjectItems.map(item => React.createElement('button', {
                                    key: item.key, type: 'button', onClick: () => openRecord(item),
                                    style: { width: '100%', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '12px 14px', border: '1px solid #dce9e7', borderRadius: 10, background: '#fff', color: '#334155', textAlign: 'right', cursor: 'pointer', fontFamily: "'Vazirmatn', Tahoma, sans-serif" }
                                }, React.createElement('div', { style: { minWidth: 0, flex: 1 } },
                                    React.createElement('div', { style: { fontWeight: 800, fontSize: 14, color: '#176b73' } }, formatExamDate(item.date)),
                                    React.createElement('div', { style: { fontSize: 12, color: '#64748b', marginTop: 3 } }, getExamTypeLabel(item.type))
                                ), React.createElement('span', { style: { flexShrink: 0, fontSize: 12, color: '#176b73', fontWeight: 700 } }, 'ویرایش ←')))) : null
                            );
                        }))
                ) : React.createElement('div', null,
                    React.createElement('div', { className: 'card' },
                        React.createElement('div', { className: 'flex-between mb-8', style: { gap: 8, flexWrap: 'wrap' } },
                            React.createElement('h4', { className: 'mb-8', style: { margin: 0 } }, '✏️ ویرایش آزمون'),
                            React.createElement('button', { type: 'button', className: 'btn btn-secondary', onClick: () => { setDraft(null); setSelectedKey(null); } }, '← بازگشت')
                        ),
                        React.createElement('div', { className: 'text-muted text-small mb-8' }, 'همان محیط ثبت آزمون؛ تغییرات فقط روی آزمون انتخاب‌شده اعمال می‌شود و فرم ثبت آزمون جدید باز نمی‌شود.'),
                        React.createElement('div', { className: 'subject-tabs', style: { marginBottom: 12 } },
                            React.createElement('button', { type: 'button', className: 'active', 'aria-pressed': true }, draft.subject)
                        ),
                        React.createElement('div', { className: 'mb-8' },
                            React.createElement('div', { className: 'text-muted text-small mb-8' }, '🏷️ نوع آزمون:'),
                            React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(' + Math.min(EXAM_TYPES.length, 2) + ', 1fr)', gap: 8 } },
                                EXAM_TYPES.map(t => {
                                    const on = draft.type === t.value;
                                    return React.createElement('button', {
                                        key: t.value, type: 'button', 'aria-pressed': on,
                                        onClick: () => setDraft(prev => ({ ...prev, type: t.value })),
                                        style: { textAlign: 'center', padding: '10px 8px', borderRadius: 14, cursor: 'pointer', lineHeight: 1.5,
                                            border: on ? '2px solid #2BB3A3' : '1px solid #dce9e7',
                                            background: on ? 'rgba(43,179,163,.13)' : '#fff',
                                            color: on ? '#176b73' : '#4b5563', boxShadow: on ? '0 3px 10px rgba(43,179,163,.18)' : 'none',
                                            fontFamily: "'Vazirmatn', Tahoma, sans-serif" }
                                    },
                                        React.createElement('div', { style: { fontWeight: 800, fontSize: 14 } }, (on ? '✓ ' : t.icon + ' ') + t.label),
                                        React.createElement('div', { style: { fontSize: 11, opacity: .8, marginTop: 2 } }, t.desc)
                                    );
                                })
                            )
                        ),
                        React.createElement('div', { className: 'mb-8', style: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' } },
                            React.createElement('span', { className: 'text-muted text-small' }, '📅 تاریخ آزمون:'),
                            React.createElement(JalaliDatePicker, {
                                value: draft.date,
                                onChange: newDate => setDraft(prev => ({ ...prev, date: newDate }))
                            })
                        ),
                        React.createElement('div', { style: { display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 } },
                            React.createElement('button', { type: 'button', className: 'btn btn-primary', onClick: saveEdits, style: { flex: '1 1 180px', minHeight: 46, fontSize: 15, fontWeight: 800 } }, '💾 ذخیره تغییرات'),
                            React.createElement('button', { type: 'button', className: 'btn btn-secondary', onClick: () => { setDraft(null); setSelectedKey(null); }, style: { flex: '0 1 110px', minHeight: 46 } }, 'انصراف')
                        )
                    ),
                    React.createElement('div', { className: 'flex-between mb-8', style: { gap: 8, flexWrap: 'wrap', marginTop: 12 } },
                        React.createElement('strong', null, `دانش‌آموزان — ${draft.subject} (${getExamTypeLabel(draft.type)})`),
                        React.createElement('span', { className: 'text-muted text-small' }, 'تغییرات پس از زدن دکمه ذخیره اعمال می‌شود')
                    ),
                    draft.entries.length === 0
                        ? React.createElement('div', { className: 'empty-state' }, React.createElement('p', null, 'اطلاعاتی برای این آزمون ثبت نشده است.'))
                        : React.createElement('div', null, draft.entries.map((entry, index) => {
                            const student = (data.students || []).find(s => String(s.id) === entry.studentId);
                            const grade = GRADE_OPTIONS.find(g => g.value === entry.grade);
                            return React.createElement('div', {
                                key: entry.token,
                                className: 'exam-card',
                                style: { marginBottom: 10, padding: 0, overflow: 'hidden' }
                            },
                                React.createElement('details', { open: true, style: { padding: 0 } },
                                    React.createElement('summary', { style: { cursor: 'pointer', padding: '14px 12px', fontWeight: 800, listStylePosition: 'inside', background: 'rgba(43,179,163,.07)' } },
                                        `${index + 1}. ${student ? student.name : 'دانش‌آموز'}${entry.absent ? ' — ❌ غایب (آزمون نداده)' : (grade ? ' — ' + grade.label : (entry.grade ? ' — ' + getGradeLabel(entry.grade) : ''))}`
                                    ),
                                    React.createElement('div', { style: { padding: 12 } },
                                        React.createElement('button', {
                                            type: 'button',
                                            onClick: () => setDraft(prev => ({ ...prev, entries: prev.entries.map(x => x.token === entry.token ? { ...x, absent: !x.absent, grade: !x.absent ? '' : x.grade } : x) })),
                                            style: { marginBottom: 12, padding: '8px 12px', borderRadius: 8, border: '1px solid ' + (entry.absent ? '#dc2626' : '#9ca3af'), background: entry.absent ? 'rgba(220,38,38,.12)' : 'transparent', color: entry.absent ? '#dc2626' : 'inherit', fontWeight: 700, cursor: 'pointer' }
                                        }, entry.absent ? '↩️ لغو غیبت و ثبت آزمون' : '❌ ثبت غیبت (آزمون نداده)'),
                                        entry.absent && React.createElement('div', { className: 'text-small mb-8', style: { color: '#dc2626', fontWeight: 700 } }, 'غیبت این دانش‌آموز برای این درس و تاریخ ذخیره می‌شود؛ برای وارد کردن نمره، غیبت را لغو کنید.'),
                                        React.createElement('div', { className: 'text-muted text-small mb-4' }, 'نمره توصیفی:'),
                                        React.createElement('div', { className: 'flex flex-wrap gap-4 mb-8' },
                                            GRADE_OPTIONS.map(g => React.createElement('span', {
                                                key: g.value,
                                                className: `grade-option ${g.class} ${entry.grade === g.value ? 'selected' : ''}`,
                                                onClick: () => { if (!entry.absent) setDraft(prev => ({ ...prev, entries: prev.entries.map(x => x.token === entry.token ? { ...x, grade: x.grade === g.value ? '' : g.value } : x) })); },
                                                style: entry.absent ? { opacity: 0.4, pointerEvents: 'none' } : { cursor: 'pointer' },
                                                title: entry.grade === g.value ? 'برای لغو انتخاب دوباره کلیک کنید' : 'انتخاب نمره'
                                            }, g.label))
                                        ),
                                        React.createElement('textarea', {
                                            value: entry.description || '',
                                            onChange: e => setDraft(prev => ({ ...prev, entries: prev.entries.map(x => x.token === entry.token ? { ...x, description: e.target.value } : x) })),
                                            placeholder: 'توضیحات عملکرد این دانش‌آموز را بنویسید...',
                                            rows: 2,
                                            style: { width: '100%', boxSizing: 'border-box' }
                                        }),
                                        Array.isArray(entry.original.images) && entry.original.images.length > 0
                                            ? React.createElement('div', { className: 'text-small text-muted', style: { marginTop: 8 } }, `📎 ${entry.original.images.length} تصویر پیوست‌شده حفظ می‌شود.`)
                                            : null
                                    )
                                )
                            );
                        })),
                )
            );
        }

        function Exams({ data, save, showToast, initialSelection, onInitialSelectionConsumed }) {
            const normalizeExamName = (value) => (value || '').trim().replace(/ي/g, 'ی').replace(/ك/g, 'ک');
            const students = [...(data.students || [])].sort((a, b) => {
                const surnameA = normalizeExamName(a.lastName || (a.name || '').trim().split(/\s+/).slice(1).join(' '));
                const surnameB = normalizeExamName(b.lastName || (b.name || '').trim().split(/\s+/).slice(1).join(' '));
                const surnameCompare = surnameA.localeCompare(surnameB, 'fa', { sensitivity: 'base', numeric: true });
                if (surnameCompare !== 0) return surnameCompare;
                const nameA = normalizeExamName(a.firstName || (a.name || '').trim().split(/\s+/)[0]);
                const nameB = normalizeExamName(b.firstName || (b.name || '').trim().split(/\s+/)[0]);
                return nameA.localeCompare(nameB, 'fa', { sensitivity: 'base', numeric: true });
            });
            const [selectedSubject, setSelectedSubject] = React.useState(initialSelection?.subject || null);
            const [date, setDate] = React.useState(initialSelection?.date || todayISO());
            const [drafts, setDrafts] = React.useState({});
            const [lightbox, setLightbox] = React.useState(null);
            const [examType, setExamType] = React.useState(initialSelection?.type || 'quiz');
            const [historyEditing, setHistoryEditing] = React.useState(!!initialSelection);
            React.useEffect(() => { if (initialSelection && onInitialSelectionConsumed) onInitialSelectionConsumed(); }, []);
            // وقتی آزمون از «سوابق آزمون» باز شده، تغییر تاریخ یا نوع باید همان آزمون را ویرایش کند، نه اینکه فقط فهرست را عوض کند.
            const changeExamContext = (field, value) => {
                if (field === 'date' && value === date) return;
                if (field === 'type' && value === examType) return;
                Object.values(window.__examAutoSaveTimers || {}).forEach(t => window.clearTimeout(t)); window.__examAutoSaveTimers = {};
                const oldDate = date;
                const oldType = examType;
                const newDate = field === 'date' ? value : date;
                const newType = field === 'type' ? value : examType;
                if (historyEditing && selectedSubject) {
                    const allExams = { ...(data.exams || {}) };
                    const sourceByStudent = {};
                    let sourceCount = 0;
                    students.forEach(student => {
                        const list = Array.isArray(allExams[student.id]) ? allExams[student.id] : [];
                        const base = e => e && e.subject === selectedSubject && e.date === oldDate;
                        const exact = list.filter(e => base(e) && (e.type || '') === oldType);
                        const source = exact.length ? exact : list.filter(e => base(e) && !e.type);
                        if (source.length) { sourceByStudent[student.id] = source; sourceCount += source.length; }
                    });
                    if (sourceCount > 0 && (newDate !== oldDate || newType !== oldType)) {
                        const hasCollision = students.some(student => {
                            const list = Array.isArray(allExams[student.id]) ? allExams[student.id] : [];
                            const sourceIds = new Set((sourceByStudent[student.id] || []).map(e => e.id).filter(Boolean));
                            return list.some(e => e && e.subject === selectedSubject && e.date === newDate && (e.type || '') === newType && !(e.id && sourceIds.has(e.id)) && !((sourceByStudent[student.id] || []).includes(e)));
                        });
                        if (hasCollision) {
                            showToast('برای این تاریخ و نوع آزمون، اطلاعات دیگری وجود دارد؛ ابتدا آن آزمون را جداگانه بررسی کنید.', 'error');
                            return;
                        }
                        students.forEach(student => {
                            const source = sourceByStudent[student.id] || [];
                            if (!source.length) return;
                            const list = Array.isArray(allExams[student.id]) ? allExams[student.id] : [];
                            const sourceSet = new Set(source);
                            const draft = drafts[student.id];
                            allExams[student.id] = list.map(e => {
                                if (!sourceSet.has(e)) return e;
                                const updated = { ...e, date: newDate, type: newType };
                                if (draft) {
                                    updated.grade = draft.absent ? '' : (draft.grade || '');
                                    updated.description = (draft.description || '').trim();
                                    updated.images = Array.isArray(draft.images) ? draft.images : [];
                                    updated.absent = !!draft.absent;
                                }
                                return updated;
                            });
                        });
                        const ok = save({ ...data, exams: allExams });
                        if (ok === false) {
                            showToast('ذخیره تغییرات آزمون انجام نشد؛ دوباره تلاش کنید.', 'error');
                            return;
                        }
                        showToast('تغییرات آزمون ذخیره شد');
                    }
                }
                if (field === 'date') setDate(value);
                else setExamType(value);
            };
            const requireSubject = () => {
                if (selectedSubject) return true;
                showToast('برای ثبت آزمون، ابتدا یکی از درس‌ها را انتخاب کنید', 'error');
                return false;
            };
            // پیدا کردن ردیف آزمون: اول هم‌نوع، و اگر نبود آزمون قدیمیِ «بدون نوع» همان درس/تاریخ (با ذخیره، نوع می‌گیرد).
            const findSlotIndex = (list) => {
                const same = e => e.subject === selectedSubject && e.date === date;
                let i = -1;
                list.forEach((e, idx) => { if (same(e) && (e.type || '') === examType) i = idx; });
                if (i < 0) list.forEach((e, idx) => { if (same(e) && !e.type) i = idx; });
                return i;
            };

            const getExistingExam = React.useCallback((studentId, subject, examDate) => {
                const exams = (data.exams && data.exams[studentId]) || [];
                const base = e => e.subject === subject && e.date === examDate;
                const exact = exams.filter(e => base(e) && (e.type || '') === examType);
                const legacy = exams.filter(e => base(e) && !e.type);
                const matches = exact.length ? exact : legacy;
                const exam = matches.length ? matches[matches.length - 1] : null;
                return exam || null;
            }, [data.exams, examType]);

            const buildDrafts = React.useCallback(() => {
                const next = {};
                students.forEach(student => {
                    const exam = getExistingExam(student.id, selectedSubject, date);
                    next[student.id] = {
                        grade: exam?.grade || '',
                        description: exam?.description || '',
                        images: Array.isArray(exam?.images) ? exam.images : [],
                        absent: exam?.absent === true || exam?.status === 'absent'
                    };
                });
                return next;
            }, [students, selectedSubject, date, examType, getExistingExam]);

            // Keep text being typed in the description field when autosave updates data.exams.
            // Rebuild drafts only when the selected subject/date changes; on ordinary data
            // updates, add drafts only for students that do not already have one.
            const draftContextRef = React.useRef({ subject: selectedSubject, date, type: examType });
            React.useEffect(() => {
                const contextChanged = draftContextRef.current.subject !== selectedSubject || draftContextRef.current.date !== date || draftContextRef.current.type !== examType;
                if (contextChanged) {
                    draftContextRef.current = { subject: selectedSubject, date, type: examType };
                    setDrafts(buildDrafts());
                    return;
                }
                const built = buildDrafts();
                setDrafts(prev => {
                    const next = { ...prev };
                    students.forEach(student => {
                        if (!Object.prototype.hasOwnProperty.call(next, student.id)) {
                            next[student.id] = built[student.id] || { grade: '', description: '', images: [], absent: false };
                        }
                    });
                    return next;
                });
            }, [buildDrafts, selectedSubject, date, examType, students]);

            const persistExamDraft = (studentId, draft) => {
                if (!requireSubject()) return;
                save(prev => {
                    const currentExamsByStudent = prev.exams || {};
                    const current = Array.isArray(currentExamsByStudent[studentId]) ? currentExamsByStudent[studentId] : [];
                    const idx = findSlotIndex(current);
                    const old = idx >= 0 ? current[idx] : null;
                    const hasContent = !!draft.absent || !!draft.grade || !!(draft.description || '').trim() || (Array.isArray(draft.images) && draft.images.length > 0);
                    if (!hasContent) {
                        if (!old) return prev;
                        return { ...prev, exams: { ...currentExamsByStudent, [studentId]: current.filter((_, i) => i !== idx) } };
                    }
                    const record = {
                        id: old?.id || uid(),
                        subject: selectedSubject, type: examType,
                        grade: draft.absent ? '' : (draft.grade || ''),
                        date,
                        description: (draft.description || '').trim(),
                        images: Array.isArray(draft.images) ? draft.images : [],
                        absent: !!draft.absent
                    };
                    return {
                        ...prev,
                        exams: {
                            ...currentExamsByStudent,
                            [studentId]: idx >= 0 ? current.map((e, i) => i === idx ? record : e) : [...current, record]
                        }
                    };
                });
            };

            const updateDraft = (studentId, field, value) => {
                const currentDraft = drafts[studentId] || { grade: '', description: '', images: [], absent: false };
                const nextDraft = { ...currentDraft, [field]: value, ...(field === 'absent' && value ? { grade: '' } : {}) };
                setDrafts(prev => ({
                    ...prev,
                    [studentId]: { ...(prev[studentId] || { grade: '', description: '', images: [], absent: false }), [field]: value, ...(field === 'absent' && value ? { grade: '' } : {}) }
                }));
                // Persist outside the React state updater so saving is reliable in all React modes.
                window.__examAutoSaveTimers = window.__examAutoSaveTimers || {};
                window.clearTimeout(window.__examAutoSaveTimers[studentId]);
                window.__examAutoSaveTimers[studentId] = window.setTimeout(() => {
                    delete window.__examAutoSaveTimers[studentId];
                    persistExamDraft(studentId, nextDraft);
                }, field === 'description' ? 500 : 0);
            };

            const setGradeForAll = (gradeValue) => {
                if (!requireSubject() || !gradeValue) return;
                save(prev => {
                    const prevExams = prev.exams || {};
                    const allExams = { ...prevExams };
                    students.forEach(student => {
                        const draft = { ...(drafts[student.id] || { grade: '', description: '', images: [], absent: false }), grade: gradeValue };
                        const current = Array.isArray(allExams[student.id]) ? allExams[student.id] : [];
                        const idx = findSlotIndex(current);
                        const old = idx >= 0 ? current[idx] : null;
                        const record = {
                            id: old?.id || uid(), subject: selectedSubject, type: examType,
                            grade: draft.absent ? '' : gradeValue, date,
                            description: (draft.description || '').trim(),
                            images: Array.isArray(draft.images) ? draft.images : [],
                            absent: !!draft.absent
                        };
                        allExams[student.id] = idx >= 0 ? current.map((e, i) => i === idx ? record : e) : [...current, record];
                    });
                    return { ...prev, exams: allExams };
                });
                setDrafts(prev => {
                    const next = { ...prev };
                    students.forEach(s => { next[s.id] = { ...(prev[s.id] || { grade: '', description: '', images: [], absent: false }), grade: gradeValue }; });
                    return next;
                });
                showToast(`نمره «${getGradeLabel(gradeValue)}» برای همه انتخاب و ذخیره شد`);
            };

            const handleImageUpload = async (studentId, e) => {
                if (!requireSubject()) { e.target.value = ''; return; }
                const files = Array.from(e.target.files || []);
                if (!files.length) return;
                const okImages = (await Promise.all(files.map(f => compressImage(f).catch(err => { console.error('Error loading exam image:', err); return null; })))).filter(Boolean);
                if (okImages.length) {
                    const currentDraft = drafts[studentId] || { grade: '', description: '', images: [], absent: false };
                    const nextDraft = {
                        ...currentDraft,
                        images: [...(currentDraft.images || []), ...okImages]
                    };
                    setDrafts(prev => ({
                        ...prev,
                        [studentId]: {
                            ...(prev[studentId] || { grade: '', description: '', images: [], absent: false }),
                            images: [...((prev[studentId] && prev[studentId].images) || []), ...okImages]
                        }
                    }));
                    // ذخیره فوری تصویرهای انتخاب‌شده، بدون انتظار برای تایمر ذخیره خودکار
                    persistExamDraft(studentId, nextDraft);
                    showToast(`${okImages.length} برگه اضافه شد و ذخیره شد`);
                } else {
                    showToast('تصویر قابل بارگذاری نبود', 'error');
                }
                e.target.value = '';
            };

            const removeImage = (studentId, index) => {
                const currentDraft = drafts[studentId] || { grade: '', description: '', images: [], absent: false };
                const nextDraft = {
                    ...currentDraft,
                    images: (currentDraft.images || []).filter((_, i) => i !== index)
                };
                setDrafts(prev => ({
                    ...prev,
                    [studentId]: {
                        ...(prev[studentId] || { grade: '', description: '', images: [], absent: false }),
                        images: (prev[studentId]?.images || []).filter((_, i) => i !== index)
                    }
                }));
                // حذف عکس هم بلافاصله در داده‌های آزمون ذخیره می‌شود
                persistExamDraft(studentId, nextDraft);
            };

            const saveStudents = (studentIds, silent = false) => {
                if (!requireSubject()) return false;
                const ids = studentIds.filter(id => drafts[id] && (
                    drafts[id].grade ||
                    (drafts[id].description || '').trim() ||
                    (drafts[id].images || []).length || drafts[id].absent
                ));
                if (!ids.length) {
                    showToast('حداقل برای یک دانش‌آموز نمره یا توضیحات وارد کنید', 'error');
                    return false;
                }
                save(prev => {
                    const prevExams = prev.exams || {};
                    const allExams = { ...prevExams };
                    ids.forEach(studentId => {
                        const current = Array.isArray(allExams[studentId]) ? allExams[studentId] : [];
                        const draft = drafts[studentId];
                        const existingIndex = findSlotIndex(current);
                        const oldExam = existingIndex >= 0 ? current[existingIndex] : null;
                        const hasAnyContent = !!draft.grade || !!(draft.description || '').trim() || (draft.images || []).length > 0 || !!draft.absent;
                        if (!hasAnyContent) return;
                        const exam = {
                            id: oldExam?.id || uid(), subject: selectedSubject, type: examType,
                            grade: draft.absent ? '' : (draft.grade || oldExam?.grade || ''), date,
                            description: (draft.description || '').trim(),
                            images: Array.isArray(draft.images) ? draft.images : [], absent: !!draft.absent
                        };
                        allExams[studentId] = existingIndex >= 0 ? current.map((item, i) => i === existingIndex ? exam : item) : [...current, exam];
                    });
                    return { ...prev, exams: allExams };
                });
                setDrafts(buildDrafts());
                if (!silent) showToast('آزمون‌ها با موفقیت ثبت شدند');
                return true;
            };


            // حذف آزمون انتخاب‌شده برای همه دانش‌آموزان در درس، تاریخ و نوع فعلی
            const deleteSelectedExam = () => {
                if (!requireSubject()) return;
                Object.values(window.__examAutoSaveTimers || {}).forEach(t => window.clearTimeout(t)); window.__examAutoSaveTimers = {};
                // حذف آزمون انتخاب‌شده از فهرست یک دانش‌آموز (هم برای شمارش و هم برای اعمال روی آخرین داده)
                const removeSelectedFromList = (list) => {
                    const exact = list.filter(e => e.subject === selectedSubject && e.date === date && (e.type || '') === examType);
                    const matches = exact.length ? exact : list.filter(e => e.subject === selectedSubject && e.date === date && !e.type);
                    if (!matches.length) return { list, removed: 0 };
                    const idsToRemove = new Set(matches.map(e => e.id).filter(Boolean));
                    let remainingToRemove = matches.length;
                    const kept = list.filter(e => {
                        if (e.subject !== selectedSubject || e.date !== date) return true;
                        if (exact.length) {
                            if ((e.type || '') !== examType) return true;
                        } else if (e.type) return true;
                        if (e.id && idsToRemove.has(e.id)) return false;
                        if (!e.id && remainingToRemove > 0) { remainingToRemove--; return false; }
                        return true;
                    });
                    return { list: kept, removed: matches.length };
                };
                let removed = 0;
                students.forEach(student => {
                    const list = Array.isArray((data.exams || {})[student.id]) ? data.exams[student.id] : [];
                    removed += removeSelectedFromList(list).removed;
                });
                if (!removed) {
                    showToast('برای این درس، تاریخ و نوع آزمون، موردی برای حذف وجود ندارد', 'error');
                    return;
                }
                if (!window.confirm(`آزمون «${selectedSubject}» در تاریخ ${toShamsi(date)} از نوع «${getExamTypeLabel(examType)}» برای ${removed} مورد ثبت‌شده حذف شود؟ این کار قابل بازگشت نیست.`)) return;
                save(prev => {
                    const nextExams = { ...(prev.exams || {}) };
                    students.forEach(student => {
                        const cur = Array.isArray(nextExams[student.id]) ? nextExams[student.id] : [];
                        const r = removeSelectedFromList(cur);
                        if (r.removed) nextExams[student.id] = r.list;
                    });
                    return { ...prev, exams: nextExams };
                });
                setDrafts(Object.fromEntries(students.map(st => [st.id, { grade: '', description: '', images: [], absent: false }])));
                showToast(`آزمون انتخاب‌شده حذف شد (${removed} مورد)`);
            };

            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📋 ثبت آزمون'),
                    React.createElement('div', { className: 'text-muted text-small mb-8' }, 'درس موردنظر را انتخاب کنید؛ «آزمون جامع» برای ثبت یک آزمون کلی و قابل مشاهده در گزارش‌هاست.'),
                    React.createElement('div', { className: 'subject-tabs', style: { marginBottom: 12 } },
                        SUBJECTS.map(sub =>
                            React.createElement('button', {
                                key: sub,
                                onClick: () => { setHistoryEditing(false); setSelectedSubject(sub); },
                                className: selectedSubject === sub ? 'active' : '',
                                'aria-pressed': selectedSubject === sub,
                                title: sub === 'آزمون جامع' ? 'ثبت و پیگیری آزمون جامع در گزارش‌ها' : `ثبت آزمون درس ${sub}`
                            }, sub === 'آزمون جامع' ? '✦ آزمون جامع' : sub)
                        )
                    ),
                    React.createElement('div', { className: 'mb-8' },
                        React.createElement('div', { className: 'text-muted text-small mb-8' }, '🏷️ نوع آزمون:'),
                        React.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(' + Math.min(EXAM_TYPES.length, 2) + ', 1fr)', gap: 8 } },
                            EXAM_TYPES.map(t => {
                                const on = examType === t.value;
                                return React.createElement('button', {
                                    key: t.value, type: 'button', 'aria-pressed': on,
                                    onClick: () => changeExamContext('type', t.value),
                                    style: { textAlign: 'center', padding: '10px 8px', borderRadius: 14, cursor: 'pointer', lineHeight: 1.5,
                                        border: on ? '2px solid #2BB3A3' : '1px solid #dce9e7',
                                        background: on ? 'rgba(43,179,163,.13)' : '#fff',
                                        color: on ? '#176b73' : '#4b5563', boxShadow: on ? '0 3px 10px rgba(43,179,163,.18)' : 'none' }
                                },
                                    React.createElement('div', { style: { fontWeight: 800, fontSize: 14 } }, (on ? '✓ ' : t.icon + ' ') + t.label),
                                    React.createElement('div', { style: { fontSize: 11, opacity: .8, marginTop: 2 } }, t.desc)
                                );
                            })
                        )
                    ),
                    React.createElement('div', { className: 'mb-8', style: { display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' } },
                        React.createElement('span', { className: 'text-muted text-small' }, '📅 تاریخ آزمون:'),
                        React.createElement(JalaliDatePicker, {
                            value: date,
                            onChange: newDate => changeExamContext('date', newDate)
                        })
                    ),
                    React.createElement('div', { className: 'card', style: { margin: '10px 0', padding: 10, background: 'rgba(43,179,163,.06)' } },
                        React.createElement('div', { className: 'text-muted text-small mb-8' }, '⚡ ثبت کلی نمره'),
                        React.createElement('div', { className: 'flex flex-wrap gap-4' },
                            GRADE_OPTIONS.map(g =>
                                React.createElement('button', {
                                    key: g.value,
                                    className: `grade-option ${g.class}`,
                                    onClick: () => setGradeForAll(g.value),
                                    style: { cursor: 'pointer', border: '1px solid transparent' }
                                }, `ثبت برای همه: ${g.label}`)
                            )
                        ),
                        React.createElement('div', { style: { marginTop: 8, display: 'flex', justifyContent: 'flex-start', direction: 'rtl' } },
                            React.createElement('button', {
                                type: 'button',
                                title: 'حذف آزمون انتخاب‌شده در این تاریخ برای همه دانش‌آموزان',
                                'aria-label': 'حذف آزمون در این تاریخ برای همه',
                                onClick: deleteSelectedExam,
                                style: { background: '#fce8e8', color: '#a83232', border: '1px solid #efcaca', borderRadius: 8, padding: '5px 9px', fontSize: 11, lineHeight: 1.4, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5, width: 'auto', maxWidth: '100%' }
                            }, React.createElement('span', { 'aria-hidden': true }, '🗑️'), 'حذف آزمون در این تاریخ برای همه')
                        )
                    ),
                    React.createElement('div', { className: 'flex-between mb-8', style: { gap: 8, flexWrap: 'wrap' } },
                        React.createElement('strong', null, `دانش‌آموزان — ${selectedSubject || '—'} (${getExamTypeLabel(examType)})`),
                        React.createElement('span', { className: 'text-muted text-small' }, 'ذخیره خودکار فعال است')
                    ),
                    students.length === 0 ?
                    React.createElement('div', { className: 'empty-state' }, React.createElement('p', null, 'هنوز دانش‌آموزی ثبت نشده است')) :
                    React.createElement('div', null,
                        students.map((student, index) => {
                            const draft = drafts[student.id] || { grade: '', description: '', images: [], absent: false };
                            return React.createElement('div', {
                                key: student.id,
                                className: 'exam-card',
                                style: { marginBottom: 10, padding: 0, overflow: 'hidden' }
                            },
                                React.createElement('details', { style: { padding: 0 } },
                                  React.createElement('summary', { style: { cursor: 'pointer', padding: '14px 12px', fontWeight: 800, listStylePosition: 'inside', background: 'rgba(43,179,163,.07)' } },
                                    `${index + 1}. ${student.name}${draft.absent ? ' — ❌ غایب (آزمون نداده)' : (draft.grade ? ' — ' + getGradeLabel(draft.grade) : '')}`
                                  ),
                                  React.createElement('div', { style: { padding: 12 } },
                                React.createElement('button', {
                                    type: 'button',
                                    onClick: () => updateDraft(student.id, 'absent', !draft.absent),
                                    style: { marginBottom: 12, padding: '8px 12px', borderRadius: 8, border: '1px solid ' + (draft.absent ? '#dc2626' : '#9ca3af'), background: draft.absent ? 'rgba(220,38,38,.12)' : 'transparent', color: draft.absent ? '#dc2626' : 'inherit', fontWeight: 700, cursor: 'pointer' }
                                }, draft.absent ? '↩️ لغو غیبت و ثبت آزمون' : '❌ ثبت غیبت (آزمون نداده)'),
                                draft.absent && React.createElement('div', { className: 'text-small mb-8', style: { color: '#dc2626', fontWeight: 700 } }, 'غیبت این دانش‌آموز برای این درس و تاریخ ذخیره می‌شود؛ برای وارد کردن نمره، غیبت را لغو کنید.'),
                                React.createElement('div', { className: 'text-muted text-small mb-4' }, 'نمره توصیفی:'),
                                React.createElement('div', { className: 'flex flex-wrap gap-4 mb-8' },
                                    GRADE_OPTIONS.map(g =>
                                        React.createElement('span', {
                                            key: g.value,
                                            className: `grade-option ${g.class} ${draft.grade === g.value ? 'selected' : ''}`,
                                            onClick: () => { if (!draft.absent) updateDraft(student.id, 'grade', draft.grade === g.value ? '' : g.value); },
                                            style: draft.absent ? { opacity: 0.4, pointerEvents: 'none' } : undefined,
                                            title: draft.grade === g.value ? 'برای لغو انتخاب دوباره کلیک کنید' : 'انتخاب و ذخیره خودکار'
                                        }, g.label)
                                    )
                                ),
                                React.createElement('textarea', {
                                    value: draft.description || '',
                                    onChange: e => updateDraft(student.id, 'description', e.target.value),
                                    placeholder: 'توضیحات عملکرد این دانش‌آموز را بنویسید...',
                                    rows: 2,
                                    style: { width: '100%', resize: 'vertical', marginBottom: 8 }
                                }),
                                React.createElement('div', { className: 'text-muted text-small mb-4' }, '📷 عکس برگه آزمون (اختیاری):'),
                                React.createElement('input', {
                                    type: 'file',
                                    accept: 'image/*',
                                    multiple: true,
                                    onChange: e => handleImageUpload(student.id, e),
                                    disabled: !!draft.absent,
                                    style: { marginBottom: 6 }
                                }),
                                draft.images && draft.images.length > 0 &&
                                React.createElement('div', { className: 'exam-images' },
                                    draft.images.map((img, imgIndex) =>
                                        React.createElement('div', { key: imgIndex, className: 'image-wrapper' },
                                            React.createElement('img', {
                                                src: img,
                                                alt: `برگه ${imgIndex + 1}`,
                                                style: { cursor: 'pointer' },
                                                onClick: () => setLightbox({ images: draft.images, index: imgIndex })
                                            }),
                                            React.createElement('span', {
                                                className: 'remove-img',
                                                onClick: () => removeImage(student.id, imgIndex)
                                            }, '×')
                                        )
                                    )
                                )
                                  )
                                )
                            );
                        })
                    )
                ),
                lightbox &&
                React.createElement(ImageLightbox, {
                    images: lightbox.images,
                    index: lightbox.index,
                    onClose: () => setLightbox(null),
                    onNavigate: newIndex => setLightbox({ images: lightbox.images, index: newIndex })
                })
            );
        }
        // ============================================================
        // Attendance - به صورت جدول دسته‌جمعی
        // ============================================================
        const SP_CSS = `
.sp{--t:#2bb3a3;--td:#218f89;--ink:#254447;--mut:#728486;--line:#e2eeec;--pos:#1f9d6b;--posbg:#e8f7f0;--neg:#c2473f;--negbg:#fdeceb;color:var(--ink)}
.sp button,.sp input,.sp select{font-family:inherit}
.sp .sp-title{margin:0 0 4px;font-size:18px;font-weight:800}
.sp .sp-hint{font-size:13px;color:var(--mut);margin:0 0 12px;line-height:1.7}
.sp .sp-chips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}
.sp button.sp-chip{border:1px solid var(--line);background:#f7fbfa;color:var(--ink);border-radius:999px;padding:6px 13px;font-size:13px;font-weight:700;min-height:38px;box-shadow:none}
.sp button.sp-chip.on{background:var(--t);border-color:var(--t);color:#fff}
.sp button.sp-chip:hover:not(:disabled){transform:none;filter:none;box-shadow:none;border-color:var(--t)}
.sp-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
@media(min-width:520px){.sp-grid{grid-template-columns:repeat(4,1fr)}}
@media(min-width:760px){.sp-grid{grid-template-columns:repeat(6,1fr)}}
.sp button.sp-tile{position:relative;display:flex;flex-direction:column;align-items:center;gap:5px;padding:12px 4px 9px;border:2px solid var(--line);border-radius:16px;background:#fff;color:var(--ink);box-shadow:none;min-height:116px;min-width:0}
.sp button.sp-tile.on{border-color:var(--t);background:#eefaf8}
.sp button.sp-tile:hover:not(:disabled){transform:none;box-shadow:none;filter:none;border-color:#9fd8d1}
.sp-av{border-radius:50%;object-fit:cover;border:3px solid;display:block;background:#f2f4f4;flex-shrink:0}
.sp-av-empty{display:inline-flex;align-items:center;justify-content:center}
.sp-name{font-size:13px;font-weight:700;line-height:1.3;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 4px}
.sp-pts{font-size:12px;color:var(--mut);font-weight:700}
.sp-check{position:absolute;top:6px;left:6px;width:22px;height:22px;border-radius:50%;background:var(--t);color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;font-weight:800}
.sp-pop{position:absolute;top:4px;left:50%;transform:translateX(-50%);font-weight:900;font-size:22px;pointer-events:none;animation:spPop 1.3s ease-out forwards;z-index:3;text-shadow:0 0 6px #fff,0 0 3px #fff}
.sp-pop.pos{color:var(--pos)}
.sp-pop.neg{color:var(--neg)}
@keyframes spPop{0%{opacity:0;transform:translate(-50%,10px) scale(.7)}20%{opacity:1;transform:translate(-50%,-4px) scale(1.15)}100%{opacity:0;transform:translate(-50%,-36px) scale(1)}}
@keyframes spFade{0%,70%{opacity:1}100%{opacity:0}}
@media(prefers-reduced-motion:reduce){.sp-pop{animation:spFade 1.3s forwards;transform:translateX(-50%)}}
.sp-panel{position:sticky;bottom:8px;z-index:5;margin-top:10px;background:#fff;border:1px solid var(--line);border-radius:16px;padding:8px;box-shadow:0 8px 28px rgba(31,90,88,.2)}
.sp-top{display:flex;gap:6px;align-items:center;margin-bottom:6px}
.sp-top .sp-sum{flex:0 1 38%;margin:0;font-size:12px;line-height:1.4;min-height:0;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.sp .sp-top input.sp-reason{flex:1;min-width:0;margin:0}
.sp-sum{font-size:12.5px;font-weight:700}
.sp-sum.none{color:var(--mut);font-weight:600}
.sp-reasons{display:flex;gap:5px;overflow-x:auto;padding-bottom:6px;scrollbar-width:none}
.sp-reasons::-webkit-scrollbar{display:none}
.sp .sp-reasons button.sp-chip{white-space:nowrap;flex:0 0 auto;min-height:30px;padding:2px 11px;font-size:12.5px}
.sp .sp-panel input.sp-reason{min-height:38px;padding:5px 12px;font-size:14px}
.sp .sp-reasons button.sp-chip.neg{background:var(--negbg);border-color:#f3c9c5;color:var(--neg)}
.sp .sp-reasons button.sp-chip.pos{background:var(--posbg);border-color:#bfe6d3;color:var(--pos)}
.sp .sp-reasons button.sp-chip.on{background:var(--ink);border-color:var(--ink);color:#fff}
.sp-row{display:flex;gap:5px;margin-bottom:5px}
.sp button.sp-pt{flex:1;min-width:0;min-height:44px;border-radius:12px;font-size:18px;font-weight:900;border:2px solid;box-shadow:none;padding:0}
.sp button.sp-pt.pos{background:var(--posbg);border-color:#bfe6d3;color:var(--pos)}
.sp button.sp-pt.neg{background:var(--negbg);border-color:#f3c9c5;color:var(--neg)}
.sp button.sp-pt:hover:not(:disabled){transform:none;filter:none;box-shadow:none}
.sp button.sp-pt.pos:active:not(:disabled){background:var(--pos);color:#fff}
.sp button.sp-pt.neg:active:not(:disabled){background:var(--neg);color:#fff}
.sp button.sp-pt.pos.sel{background:var(--pos);border-color:var(--pos);color:#fff}
.sp button.sp-pt.neg.sel{background:var(--neg);border-color:var(--neg);color:#fff}
.sp button.sp-submit{width:100%;min-height:46px;border-radius:12px;font-size:15px;font-weight:800;border:0;color:#fff;background:var(--t);box-shadow:none;margin-top:2px}
.sp button.sp-submit.neg{background:var(--neg)}
.sp button.sp-submit:hover:not(:disabled){transform:none;filter:brightness(.95);box-shadow:none}
.sp button.sp-submit:disabled{background:#cfe3df;color:#fff;cursor:not-allowed}
.sp button.sp-pt:disabled{opacity:.38;cursor:not-allowed}
.sp button.sp-more{flex:1;font-size:13px;min-height:44px;padding:0 8px;border:2px dashed var(--line);background:#fff;color:var(--mut);border-radius:12px;box-shadow:none}
.sp-custom{display:flex;gap:6px;align-items:center}
.sp-custom input{flex:1;min-width:0;text-align:center;font-size:17px;font-weight:800;min-height:44px;padding:4px 8px}
.sp-undo{display:flex;align-items:center;justify-content:space-between;gap:8px;background:#eefaf8;border:1px solid #cdeae6;border-radius:12px;padding:3px 8px 3px 10px;margin-bottom:6px;font-size:13px;font-weight:700}
.sp button.sp-undo-btn{background:#fff;border:1px solid var(--t);color:var(--td);border-radius:10px;padding:2px 12px;font-size:13px;min-height:34px;box-shadow:none;white-space:nowrap}
.sp button.sp-fold{display:flex;width:100%;align-items:center;justify-content:space-between;background:transparent;border:0;padding:4px 0;font-size:17px;font-weight:800;color:var(--ink);box-shadow:none;border-radius:8px}
.sp button.sp-fold:hover:not(:disabled){transform:none;filter:none;box-shadow:none}
.sp button.sp-main{width:100%;min-height:48px;border-radius:14px;background:var(--t);color:#fff;font-size:15px;font-weight:800;box-shadow:none}
.sp button.sp-main:hover:not(:disabled){transform:none;filter:none;box-shadow:none;background:var(--td)}
.sp-item{border-bottom:1px solid var(--line)}
.sp-item:last-child{border-bottom:0}
.sp button.sp-lbrow{display:flex;align-items:center;gap:10px;width:100%;text-align:right;background:transparent;border:0;padding:10px 2px;box-shadow:none;color:inherit;border-radius:10px;font-size:15px;font-weight:600}
.sp button.sp-lbrow:hover:not(:disabled){transform:none;box-shadow:none;filter:none;background:#f7fbfa}
.sp-rank{width:30px;text-align:center;font-size:22px;font-weight:800;color:var(--mut);flex-shrink:0}
.sp-body{flex:1;min-width:0}
.sp-bar{height:7px;border-radius:99px;background:#edf4f3;overflow:hidden;margin-top:6px}
.sp-bar i{display:block;height:100%;border-radius:99px;background:var(--t);transition:width .4s ease}
.sp-bar i.neg{background:var(--neg)}
.sp-tag{display:inline-block;font-size:11px;font-weight:700;padding:1px 8px;border-radius:99px;background:#eef3f2;color:var(--mut);margin-right:6px;vertical-align:middle}
.sp-score{font-weight:900;font-size:17px;min-width:54px;text-align:left;flex-shrink:0}
.sp-crown{position:absolute;top:-15px;left:50%;transform:translateX(-50%);font-size:18px;line-height:1;pointer-events:none}
.sp-hist{background:#f8fbfa;border-radius:12px;padding:4px 12px;margin:0 0 8px}
.sp-hrow{display:flex;justify-content:space-between;gap:8px;align-items:center;padding:9px 0;border-bottom:1px solid var(--line);font-size:13px}
.sp-hrow:last-child{border-bottom:0}
.sp button.sp-del{background:transparent;border:1px solid #f0c5c1;color:var(--neg);border-radius:10px;padding:4px 10px;font-size:12px;min-height:34px;box-shadow:none;white-space:nowrap}
.sp button.sp-del:hover:not(:disabled){transform:none;filter:none;box-shadow:none;background:var(--negbg)}
.sp-empty{border:1px dashed #cfe3df;border-radius:15px;background:#f8fcfb;padding:18px;text-align:center;color:var(--mut);font-size:14px}
.sp button:focus-visible,.sp input:focus-visible,.sp select:focus-visible{outline:3px solid rgba(43,179,163,.55);outline-offset:2px}
`;

        function StudentScores({ data, save, showToast }) {
            const h = React.createElement;
            const students = data.students || [];
            const points = data.studentPoints || {};
            const groups = data.studentGroups || {};
            const history = Array.isArray(data.pointHistory) ? data.pointHistory : [];
            const fa = n => toPersianDigits(n);
            const LRI = '\u2066', PDI = '\u2069';
            const signed = n => LRI + (n < 0 ? '−' : '+') + fa(Math.abs(n)) + PDI;
            const fmtN = n => LRI + (n < 0 ? '−' : '') + fa(Math.abs(n)) + PDI;
            const total = id => Number(points[id]) || 0;

            const [selectedIds, setSelectedIds] = React.useState([]);
            const [reason, setReason] = React.useState('');
            const [showCustom, setShowCustom] = React.useState(false);
            const [customAmount, setCustomAmount] = React.useState('');
            const [amount, setAmount] = React.useState(null);
            const [query, setQuery] = React.useState('');
            const [popup, setPopup] = React.useState(null);
            const [undo, setUndo] = React.useState(null);
            const [showGroups, setShowGroups] = React.useState(false);
            const [groupName, setGroupName] = React.useState('');
            const [groupStudent, setGroupStudent] = React.useState('');
            const [expandedGroup, setExpandedGroup] = React.useState('');
            const [detailStudent, setDetailStudent] = React.useState('');

            React.useEffect(() => {
                if (!popup) return;
                const t = setTimeout(() => setPopup(null), 1400);
                return () => clearTimeout(t);
            }, [popup]);
            React.useEffect(() => {
                if (!undo) return;
                const t = setTimeout(() => setUndo(null), 8000);
                return () => clearTimeout(t);
            }, [undo]);

            const sel = selectedIds.filter(id => students.some(s => s.id === id));
            const realGroups = Array.from(new Set(students.map(s => groups[s.id]).filter(Boolean)));
            const goodReasons = ['مشارکت در کلاس', 'انجام تکلیف', 'نظم و ادب', 'کمک به دیگران', 'پاسخ درست'];
            const badReasons = ['بی‌نظمی', 'نیاوردن تکلیف', 'صحبت بی‌موقع'];

            const toggle = id => setSelectedIds(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);
            const toggleGroup = g => {
                const ids = students.filter(s => groups[s.id] === g).map(s => s.id);
                const all = ids.length > 0 && ids.every(id => sel.includes(id));
                setSelectedIds(p => all ? p.filter(id => !ids.includes(id)) : Array.from(new Set([...p, ...ids])));
            };

            const commit = (n) => {
                if (!sel.length) { showToast('اول دانش‌آموز را انتخاب کنید', 'error'); return; }
                if (!Number.isFinite(n) || n === 0) { showToast('مقدار معتبر وارد کنید', 'error'); return; }
                const why = reason.trim() || (n < 0 ? 'کسر امتیاز' : 'امتیاز مثبت');
                const nowISO = new Date().toISOString();
                const entries = sel.map(id => ({ id: uid(), studentId: id, amount: n, reason: why, date: nowISO }));
                const nextPoints = { ...points };
                entries.forEach(e => { nextPoints[e.studentId] = (Number(nextPoints[e.studentId]) || 0) + n; });
                save({ ...data, studentPoints: nextPoints, pointHistory: [...history, ...entries] });
                const names = sel.map(id => (students.find(s => s.id === id) || {}).name).filter(Boolean);
                setPopup({ ids: sel, amount: n, key: Date.now() });
                setUndo({ entries, n, label: names.length > 2 ? `${names[0]} و ${fa(names.length - 1)} نفر دیگر` : names.join('، '), key: Date.now() });
                setSelectedIds([]); setReason(''); setCustomAmount(''); setAmount(null); setShowCustom(false);
            };
            const undoLast = () => {
                if (!undo) return;
                const ids = new Set(undo.entries.map(e => e.id));
                const nextPoints = { ...points };
                undo.entries.forEach(e => { nextPoints[e.studentId] = (Number(nextPoints[e.studentId]) || 0) - e.amount; });
                save({ ...data, studentPoints: nextPoints, pointHistory: history.filter(x => !ids.has(x.id)) });
                setUndo(null); setPopup(null);
                showToast('امتیاز برگردانده شد');
            };
            const deletePoint = (entry) => {
                if (!entry || !window.confirm('این امتیاز حذف شود؟ امتیاز دانش‌آموز هم به همان میزان اصلاح می‌شود.')) return;
                const nextPoints = { ...points };
                nextPoints[entry.studentId] = (Number(nextPoints[entry.studentId]) || 0) - (Number(entry.amount) || 0);
                save({ ...data, studentPoints: nextPoints, pointHistory: history.filter(x => x.id !== entry.id) });
                showToast('امتیاز از سوابق حذف شد');
            };
            const gs = groupStudent || (students[0] && students[0].id) || '';
            const assignGroup = () => {
                if (!gs || !groupName.trim()) { showToast('دانش‌آموز و نام گروه را انتخاب کنید', 'error'); return; }
                save({ ...data, studentGroups: { ...groups, [gs]: groupName.trim() } });
                setExpandedGroup(groupName.trim()); setGroupName(''); showToast('دانش‌آموز به گروه اضافه شد');
            };
            const removeFromGroup = (studentId) => {
                const next = { ...groups }; delete next[studentId];
                save({ ...data, studentGroups: next }); showToast('دانش‌آموز از گروه خارج شد');
            };

            const ringColors = ['#e0ad20', '#a9b4c2', '#c58a5b'];
            const avatar = (st, size, ring) => st.photo
                ? h('img', { src: st.photo, alt: '', className: 'sp-av', style: { width: size, height: size, borderColor: ring || '#d9ebe8' } })
                : h('span', { className: 'sp-av sp-av-empty', style: { width: size, height: size, fontSize: size * 0.55, borderColor: ring || '#d9ebe8' } }, '🧑‍🎓');

            const q = query.trim();
            const shown = students.filter(st => !q || (st.name || '').includes(q));
            const sorted = [...students].sort((a, b) => total(b.id) - total(a.id));
            const maxAbs = Math.max(1, ...students.map(st => Math.abs(total(st.id))));
            const groupTotals = {};
            students.forEach(st => { const g = groups[st.id]; if (g) groupTotals[g] = (groupTotals[g] || 0) + total(st.id); });
            const maxGroup = Math.max(1, ...Object.values(groupTotals).map(v => Math.abs(v)));

            const names = sel.map(id => (students.find(s => s.id === id) || {}).name).filter(Boolean);
            const sumText = !sel.length
                ? 'دانش‌آموز را انتخاب کنید'
                : `${fa(sel.length)} نفر: ${names.slice(0, 3).join('، ')}${names.length > 3 ? ' و ...' : ''}`;
            const none = !sel.length;
            const ptBtn = (n) => h('button', { key: n, type: 'button', className: 'sp-pt ' + (n < 0 ? 'neg' : 'pos') + (amount === n ? ' sel' : ''), 'aria-pressed': amount === n, onClick: () => { setAmount(amount === n ? null : n); setCustomAmount(''); }, 'aria-label': (n < 0 ? 'کسر ' : 'افزودن ') + Math.abs(n) + ' امتیاز' }, signed(n));
            const setCustom = (sign) => {
                const v = Math.abs(Number(customAmount));
                if (!Number.isFinite(v) || v === 0) { showToast('عدد معتبر وارد کنید', 'error'); return; }
                setAmount(sign * v);
            };
            const cv = Math.abs(Number(customAmount)) || 0;

            if (!students.length) {
                return h('div', { className: 'sp' }, h('style', null, SP_CSS),
                    h('div', { className: 'card' }, h('h3', { className: 'sp-title' }, '🏆 امتیازدهی'),
                        h('div', { className: 'sp-empty' }, 'هنوز دانش‌آموزی ثبت نشده. ابتدا از بخش دانش‌آموزان، دانش‌آموز اضافه کنید.')));
            }

            return h('div', { className: 'sp' },
                h('style', null, SP_CSS),

                // ---------- امتیازدهی ----------
                h('div', { className: 'card' },
                    h('h3', { className: 'sp-title' }, '🏆 امتیازدهی'),
                    h('p', { className: 'sp-hint' }, 'دانش‌آموز را انتخاب کنید، بعد عدد امتیاز را بزنید. ثبت فوری است و می‌توانید بازگردانید.'),
                    students.length > 8 ? h('input', { type: 'search', value: query, onChange: e => setQuery(e.target.value), placeholder: 'جستجوی نام…', style: { marginBottom: 10 } }) : null,
                    h('div', { className: 'sp-chips' },
                        h('button', { type: 'button', className: 'sp-chip', onClick: () => setSelectedIds(students.map(s => s.id)) }, 'همه'),
                        h('button', { type: 'button', className: 'sp-chip', onClick: () => setSelectedIds([]) }, 'هیچ‌کس'),
                        realGroups.map(g => {
                            const ids = students.filter(s => groups[s.id] === g).map(s => s.id);
                            const on = ids.length > 0 && ids.every(id => sel.includes(id));
                            return h('button', { key: g, type: 'button', className: 'sp-chip' + (on ? ' on' : ''), onClick: () => toggleGroup(g) }, '👥 ' + g);
                        })),
                    shown.length ? h('div', { className: 'sp-grid' }, shown.map(st => {
                        const on = sel.includes(st.id);
                        return h('button', { key: st.id, type: 'button', className: 'sp-tile' + (on ? ' on' : ''), onClick: () => toggle(st.id), 'aria-pressed': on },
                            popup && popup.ids.includes(st.id) ? h('span', { key: popup.key, className: 'sp-pop ' + (popup.amount < 0 ? 'neg' : 'pos') }, signed(popup.amount)) : null,
                            on ? h('span', { className: 'sp-check' }, '✓') : null,
                            avatar(st, 52, on ? '#2bb3a3' : null),
                            h('span', { className: 'sp-name' }, st.name),
                            h('span', { className: 'sp-pts' }, fmtN(total(st.id)) + ' ⭐'));
                    })) : h('div', { className: 'sp-empty' }, 'دانش‌آموزی با این نام پیدا نشد.'),

                    h('div', { className: 'sp-panel' },
                        undo ? h('div', { className: 'sp-undo', role: 'status' },
                            h('span', null, `✓ ${signed(undo.n)} برای ${undo.label} ثبت شد`),
                            h('button', { type: 'button', className: 'sp-undo-btn', onClick: undoLast }, '↩ بازگردانی')) : null,
                        h('div', { className: 'sp-top' },
                            h('div', { className: 'sp-sum' + (none ? ' none' : '') }, sumText),
                            h('input', { className: 'sp-reason', value: reason, onChange: e => setReason(e.target.value), placeholder: 'دلیل (اختیاری)', 'aria-label': 'دلیل امتیاز' })),
                        h('div', { className: 'sp-reasons', role: 'group', 'aria-label': 'دلیل امتیاز (اختیاری)' },
                            goodReasons.map(r => h('button', { key: r, type: 'button', className: 'sp-chip pos' + (reason === r ? ' on' : ''), onClick: () => setReason(reason === r ? '' : r) }, r)),
                            badReasons.map(r => h('button', { key: r, type: 'button', className: 'sp-chip neg' + (reason === r ? ' on' : ''), onClick: () => setReason(reason === r ? '' : r) }, r))),
                        h('div', { className: 'sp-row' }, [1, 2, 3, 5, 10].map(ptBtn)),
                        h('div', { className: 'sp-row' }, [-1, -2, -5].map(ptBtn),
                            h('button', { type: 'button', className: 'sp-more', onClick: () => setShowCustom(!showCustom), 'aria-expanded': showCustom }, showCustom ? 'بستن' : 'عدد دلخواه')),
                        showCustom ? h('div', null,
                            h('div', { className: 'sp-custom' },
                                h('button', { type: 'button', className: 'sp-pt neg' + (cv && amount === -cv ? ' sel' : ''), style: { flex: '0 0 64px' }, onClick: () => setCustom(-1) }, '−'),
                                h('input', { type: 'number', inputMode: 'numeric', min: 1, value: customAmount, onChange: e => setCustomAmount(e.target.value), placeholder: 'عدد' }),
                                h('button', { type: 'button', className: 'sp-pt pos' + (cv && amount === cv ? ' sel' : ''), style: { flex: '0 0 64px' }, onClick: () => setCustom(1) }, '+'))) : null,
                        h('button', { type: 'button', disabled: none || amount === null, className: 'sp-submit' + (amount !== null && amount < 0 ? ' neg' : ''), onClick: () => commit(amount) },
                            amount === null ? 'ثبت امتیاز' : `ثبت ${signed(amount)} امتیاز`))
                ),

                // ---------- جدول امتیازها ----------
                h('div', { className: 'card' },
                    h('h3', { className: 'sp-title' }, '📋 جدول امتیازها'),
                    h('p', { className: 'sp-hint' }, 'برای دیدن تاریخ و دلیل امتیازها، روی نام دانش‌آموز بزنید.'),
                    sorted.map((st, i) => {
                        const pts = total(st.id);
                        const top = pts > 0 && i < 3;
                        const hist = history.filter(x => x.studentId === st.id).slice().reverse();
                        const open = detailStudent === st.id;
                        return h('div', { key: st.id, className: 'sp-item' },
                            h('button', { type: 'button', className: 'sp-lbrow', onClick: () => setDetailStudent(open ? '' : st.id), 'aria-expanded': open },
                                h('span', { className: 'sp-rank' }, top ? ['🥇', '🥈', '🥉'][i] : fa(i + 1)),
                                h('span', { style: { position: 'relative', display: 'inline-flex', flexShrink: 0 } },
                                    i === 0 && pts > 0 ? h('span', { className: 'sp-crown' }, '👑') : null,
                                    avatar(st, top ? 52 : 44, top ? ringColors[i] : null)),
                                h('span', { className: 'sp-body' },
                                    h('span', null, st.name, groups[st.id] ? h('span', { className: 'sp-tag' }, groups[st.id]) : null),
                                    h('span', { className: 'sp-bar', style: { display: 'block' } },
                                        h('i', { className: pts < 0 ? 'neg' : '', style: { width: Math.round(Math.abs(pts) / maxAbs * 100) + '%' } }))),
                                h('span', { className: 'sp-score', style: { color: pts < 0 ? '#c2473f' : '#254447' } }, fmtN(pts) + ' ⭐')),
                            open ? h('div', { className: 'sp-hist' },
                                hist.length ? hist.map(x => h('div', { key: x.id, className: 'sp-hrow' },
                                    h('div', null,
                                        h('b', { style: { color: Number(x.amount) < 0 ? '#c2473f' : '#1f9d6b' } }, signed(Number(x.amount) || 0)),
                                        h('span', { style: { margin: '0 8px' } }, x.reason || 'ذکر نشده'),
                                        h('small', { style: { color: '#728486', display: 'block' } }, new Date(x.date).toLocaleString('fa-IR'))),
                                    h('button', { type: 'button', className: 'sp-del', onClick: () => deletePoint(x) }, '🗑 حذف')))
                                    : h('p', { className: 'sp-hint', style: { margin: '10px 0' } }, 'هنوز امتیازی برای این دانش‌آموز ثبت نشده است.')) : null);
                    })),

                // ---------- امتیاز گروه‌ها ----------
                realGroups.length ? h('div', { className: 'card' },
                    h('h3', { className: 'sp-title' }, '📊 امتیاز گروه‌ها'),
                    Object.entries(groupTotals).sort((a, b) => b[1] - a[1]).map(([g, tot], i) => {
                        const open = expandedGroup === g;
                        return h('div', { key: g, className: 'sp-item' },
                            h('button', { type: 'button', className: 'sp-lbrow', onClick: () => setExpandedGroup(open ? '' : g), 'aria-expanded': open },
                                h('span', { className: 'sp-rank' }, i === 0 && tot > 0 ? '🥇' : fa(i + 1)),
                                h('span', { className: 'sp-body' }, g,
                                    h('span', { className: 'sp-bar', style: { display: 'block' } },
                                        h('i', { className: tot < 0 ? 'neg' : '', style: { width: Math.round(Math.abs(tot) / maxGroup * 100) + '%' } }))),
                                h('span', { className: 'sp-score' }, fmtN(tot) + ' ⭐')),
                            open ? h('div', { className: 'sp-hist' }, students.filter(st => groups[st.id] === g).map(st =>
                                h('div', { key: st.id, className: 'sp-hrow' },
                                    h('span', { style: { display: 'flex', alignItems: 'center', gap: 8 } }, avatar(st, 36), h('span', null, st.name)),
                                    h('b', null, fmtN(total(st.id)) + ' ⭐'),
                                    h('button', { type: 'button', className: 'sp-del', onClick: () => removeFromGroup(st.id) }, 'حذف از گروه')))) : null);
                    })) : null,

                // ---------- گروه‌بندی ----------
                h('div', { className: 'card' },
                    h('button', { type: 'button', className: 'sp-fold', onClick: () => setShowGroups(!showGroups), 'aria-expanded': showGroups },
                        h('span', null, '👥 گروه‌بندی دانش‌آموزان'), h('span', null, showGroups ? '▴' : '▾')),
                    showGroups ? h('div', { style: { marginTop: 10 } },
                        h('select', { value: gs, onChange: e => setGroupStudent(e.target.value), style: { width: '100%', marginBottom: 8 }, 'aria-label': 'دانش‌آموز' },
                            students.map(st => h('option', { key: st.id, value: st.id }, st.name + (groups[st.id] ? ` (${groups[st.id]})` : '')))),
                        realGroups.length ? h('div', { className: 'sp-chips' }, realGroups.map(g =>
                            h('button', { key: g, type: 'button', className: 'sp-chip' + (groupName === g ? ' on' : ''), onClick: () => setGroupName(g) }, g))) : null,
                        h('input', { value: groupName, onChange: e => setGroupName(e.target.value), placeholder: 'نام گروه؛ مثلاً ستاره‌ها', style: { marginBottom: 8 } }),
                        h('button', { type: 'button', className: 'sp-main', onClick: assignGroup }, 'افزودن به گروه')) : null)
            );
        }
        // ============================================================
        // درباره سازندگان
        // ============================================================
        function Backup({ data, save, showToast }) {
            const importInputRef = React.useRef(null);
            const [autoBackup, setAutoBackup] = React.useState(null);
            React.useEffect(() => {
                let live = true;
                getAutoBackup().then(record => { if (live) setAutoBackup(record); });
                return () => { live = false; };
            }, [data.activeClassId, data.classes]);
            const restoreInternalBackup = () => {
                if (!autoBackup || !autoBackup.data) return;
                if (!confirm('اطلاعات ذخیره‌شده در بکاپ خودکار جایگزین تمام اطلاعات فعلی برنامه و کلاس‌ها شود؟')) return;
                save(autoBackup.data);
                showToast('بکاپ خودکار داخلی بازیابی شد');
            };

            const displayData = (Array.isArray(data.classes) ? data.classes.find(c => c.id === data.activeClassId)?.data : null) || data;
            const students = displayData.students || [];
            const examDateSet = new Set();
            Object.values(displayData.exams || {}).forEach(arr => (Array.isArray(arr) ? arr : []).forEach(e => examDateSet.add(e.date)));
            const attendanceDateSet = new Set();
            Object.values(displayData.attendance || {}).forEach(arr => (Array.isArray(arr) ? arr : []).forEach(a => attendanceDateSet.add(a.date)));

            const sizeMB = estimateDataSizeMB(data);
            const [storageEstimate, setStorageEstimate] = React.useState(null);
            React.useEffect(() => {
                let cancelled = false;
                getStorageEstimate().then(est => { if (!cancelled) setStorageEstimate(est); });
                return () => { cancelled = true; };
            }, [data]);
            const usagePercent = storageEstimate ? storageEstimate.percent : null;
            const meterColor = usagePercent === null ? '#34C77B' :
                usagePercent >= 90 ? '#FF6B81' : usagePercent >= 70 ? '#FFB454' : '#34C77B';

            const lastBackupAt = data.meta && data.meta.lastBackupAt;
            const daysSinceBackup = lastBackupAt ?
                Math.floor((Date.now() - new Date(lastBackupAt).getTime()) / (1000 * 60 * 60 * 24)) : null;

            const exportBackup = () => {
                try {
                    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `backup-daftar-kelas-${todayISO()}.json`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    showToast('📤 فایل بکاپ دانلود شد');
                    save({ ...data, meta: { ...(data.meta || {}), lastBackupAt: new Date().toISOString() } });
                } catch (e) {
                    console.error('export error', e);
                    showToast('⚠️ خطا در تهیه‌ی بکاپ', 'error');
                }
            };

            const triggerImport = () => {
                if (importInputRef.current) importInputRef.current.click();
            };

            const handleImportFile = (e) => {
                const file = e.target.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = () => {
                    try {
                        const parsed = JSON.parse(reader.result);
                        // بازیابی باید تمام کلیدهای بکاپ را نگه دارد؛ ساختن یک شیء محدود
                        // در اینجا باعث حذف تکالیف، امتیازها و سایر بخش‌های برنامه می‌شد.
                        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
                            throw new Error('ساختار فایل بکاپ معتبر نیست');
                        }
                        const defaults = emptyData();
                        const restored = {
                            ...defaults,
                            ...parsed,
                            students: Array.isArray(parsed.students) ? parsed.students : [],
                            studentPoints: parsed.studentPoints && typeof parsed.studentPoints === 'object' ? parsed.studentPoints : {},
                            studentGroups: parsed.studentGroups && typeof parsed.studentGroups === 'object' ? parsed.studentGroups : {},
                            pointHistory: Array.isArray(parsed.pointHistory) ? parsed.pointHistory : [],
                            exams: parsed.exams && typeof parsed.exams === 'object' ? parsed.exams : {},
                            attendance: parsed.attendance && typeof parsed.attendance === 'object' ? parsed.attendance : {},
                            tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
                            parentMeetings: Array.isArray(parsed.parentMeetings) ? parsed.parentMeetings : [],
                            teacherNotes: Array.isArray(parsed.teacherNotes) ? parsed.teacherNotes : [],
                            weeklySchedule: parsed.weeklySchedule && typeof parsed.weeklySchedule === 'object' ? parsed.weeklySchedule : {},
                            weeklyScheduleFontSizes: parsed.weeklyScheduleFontSizes && typeof parsed.weeklyScheduleFontSizes === 'object' ? parsed.weeklyScheduleFontSizes : {},
                            budgeting: parsed.budgeting && typeof parsed.budgeting === 'object' ? parsed.budgeting : {},
                            budgetingFontSizes: parsed.budgetingFontSizes && typeof parsed.budgetingFontSizes === 'object' ? parsed.budgetingFontSizes : {},
                            performance: parsed.performance && typeof parsed.performance === 'object' ? parsed.performance : {},
                            performanceByGrade: parsed.performanceByGrade && typeof parsed.performanceByGrade === 'object' ? parsed.performanceByGrade : {},
                            performanceRowTexts: parsed.performanceRowTexts && typeof parsed.performanceRowTexts === 'object' ? parsed.performanceRowTexts : {},
                            performanceCustomRows: Array.isArray(parsed.performanceCustomRows) ? parsed.performanceCustomRows : [],
                            performanceHiddenRowIds: Array.isArray(parsed.performanceHiddenRowIds) ? parsed.performanceHiddenRowIds : [],
                            users: parsed.users && typeof parsed.users === 'object' ? parsed.users : (data.users || {}),
                            meta: parsed.meta && typeof parsed.meta === 'object' ? parsed.meta : (data.meta || {}),
                            classes: Array.isArray(parsed.classes) ? parsed.classes : (Array.isArray(data.classes) ? data.classes : []),
                            activeClassId: parsed.activeClassId || data.activeClassId || ''
                        };
                        if (!Array.isArray(parsed.classes) || parsed.classes.length === 0) {
                            const { users: _u, meta: _m, classes: _c, activeClassId: _a, ...legacyPayload } = restored;
                            const newId = uid();
                            restored.classes = [{ id: newId, name: 'کلاس بازیابی‌شده', data: legacyPayload }];
                            restored.activeClassId = newId;
                        }
                        if (!confirm('با بازیابی این بکاپ، تمام اطلاعات فعلی برنامه از جمله دانش‌آموزان، تکالیف، موارد تحویلی، امتیازها، آزمون‌ها و حضور و غیاب با اطلاعات داخل فایل جایگزین می‌شود. ادامه می‌دهید؟')) {
                            if (importInputRef.current) importInputRef.current.value = '';
                            return;
                        }
                        const ok = save(restored);
                        if (ok !== false) {
                            showToast('📥 بکاپ با موفقیت بازیابی شد');
                        }
                    } catch (err) {
                        console.error('import error', err);
                        showToast('⚠️ فایل بکاپ معتبر نیست', 'error');
                    } finally {
                        if (importInputRef.current) importInputRef.current.value = '';
                    }
                };
                reader.onerror = () => {
                    showToast('⚠️ خطا در خواندن فایل', 'error');
                };
                reader.readAsText(file);
            };

            return React.createElement('div', null,
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '🛡️ بکاپ خودکار داخل برنامه'),
                    React.createElement('div', { className: 'text-muted text-small mb-8' },
                        autoBackup ? 'آخرین نسخه داخلی: ' + new Date(autoBackup.savedAt).toLocaleString('fa-IR') + ' — این نسخه در حافظه داخلی مرورگر/برنامه نگهداری می‌شود.' :
                            'با ثبت تغییرات، برنامه به‌صورت خودکار یک نسخه پشتیبان داخلی می‌سازد.'),
                    React.createElement('button', { className: 'btn-secondary w-full', disabled: !autoBackup, onClick: restoreInternalBackup },
                        '↩️ بازیابی آخرین بکاپ خودکار')),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📦 وضعیت فعلی اطلاعات'),
                    React.createElement('div', { className: 'flex flex-wrap gap-8', style: { justifyContent: 'space-around' } },
                        React.createElement('div', { className: 'text-center' },
                            React.createElement('div', { style: { fontSize: 24, fontWeight: 800, color: '#2BB3A3' } },
                                students.length),
                            React.createElement('div', { className: 'text-muted text-small' }, 'دانش‌آموز')
                        ),
                        React.createElement('div', { className: 'text-center' },
                            React.createElement('div', { style: { fontSize: 24, fontWeight: 800, color: '#FFB454' } },
                                examDateSet.size),
                            React.createElement('div', { className: 'text-muted text-small' }, 'روز آزمون ثبت شده')
                        ),
                        React.createElement('div', { className: 'text-center' },
                            React.createElement('div', { style: { fontSize: 24, fontWeight: 800, color: '#34C77B' } },
                                attendanceDateSet.size),
                            React.createElement('div', { className: 'text-muted text-small' }, 'روز حضور و غیاب ثبت شده')
                        )
                    ),
                    React.createElement('div', { style: { marginTop: 14 } },
                        React.createElement('div', {
                            className: 'flex items-center',
                            style: { justifyContent: 'space-between', marginBottom: 4 }
                        },
                            React.createElement('span', { className: 'text-small text-muted' }, 'حجم اطلاعات این برنامه'),
                            React.createElement('span', { className: 'text-small', style: { fontWeight: 700, color: meterColor } },
                                storageEstimate ?
                                    `${toPersianDigits(sizeMB.toFixed(1))} مگابایت (${toPersianDigits(usagePercent)}٪ از فضای مجاز)` :
                                    `${toPersianDigits(sizeMB.toFixed(1))} مگابایت`)
                        ),
                        storageEstimate &&
                        React.createElement('div', {
                            style: { background: '#EEE', borderRadius: 8, height: 10, overflow: 'hidden' }
                        },
                            React.createElement('div', {
                                style: {
                                    width: `${usagePercent}%`,
                                    background: meterColor,
                                    height: '100%',
                                    transition: 'width 0.3s'
                                }
                            })
                        )
                    ),
                    React.createElement('div', { className: 'text-small text-muted', style: { marginTop: 10 } },
                        lastBackupAt ?
                            (daysSinceBackup === 0 ?
                                '✅ آخرین بکاپ: امروز' :
                                `📅 آخرین بکاپ: ${daysSinceBackup} روز پیش`) :
                            '⚠️ تا حالا هیچ بکاپی نگرفته‌اید')
                ),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📤 دریافت بکاپ'),
                    React.createElement('div', { className: 'text-muted text-small mb-8' },
                        'یک فایل بکاپ از تمام کلاس‌ها و همه اطلاعات هر کلاس (دانش‌آموزان، عکس‌ها، آزمون‌ها، تکالیف، امتیازها و حضور و غیاب) دانلود می‌شود. این فایل را جایی امن (گوگل‌درایو، تلگرام، ایمیل) نگه دارید.'
                    ),
                    React.createElement('button', {
                        onClick: exportBackup,
                        className: 'btn-primary w-full',
                        style: { fontSize: 16, padding: '12px' }
                    }, '📤 دریافت فایل بکاپ')
                ),
                React.createElement('div', { className: 'card' },
                    React.createElement('h4', { className: 'mb-8' }, '📥 بازیابی از بکاپ'),
                    React.createElement('div', { className: 'text-muted text-small mb-8' },
                        'فایل بکاپی که قبلاً گرفته‌اید را انتخاب کنید تا اطلاعات برنامه بازیابی شود. توجه: تمام اطلاعات فعلی با اطلاعات داخل فایل جایگزین می‌شود.'
                    ),
                    React.createElement('button', {
                        onClick: triggerImport,
                        className: 'btn-accent w-full',
                        style: { fontSize: 16, padding: '12px' }
                    }, '📥 انتخاب فایل بکاپ و بازیابی'),
                    React.createElement('input', {
                        ref: importInputRef,
                        type: 'file',
                        accept: '.json,application/json',
                        onChange: handleImportFile,
                        style: { display: 'none' }
                    })
                )
            );
        }

        // ============================================================
        // اجرا
        // ============================================================
        class ErrorBoundary extends React.Component {
            constructor(props) { super(props); this.state = { error: null }; }
            static getDerivedStateFromError(error) { return { error }; }
            componentDidCatch(error, info) { console.error('App error:', error, info); }
            render() {
                if (this.state.error) {
                    return React.createElement('div', { className: 'container' },
                        React.createElement('div', { className: 'card', style: { textAlign: 'center', padding: 40 } },
                            React.createElement('div', { style: { fontSize: 48 } }, '⚠️'),
                            React.createElement('h3', null, 'خطایی رخ داد'),
                            React.createElement('div', { style: { color: '#767267', margin: '10px 0 20px' } }, 'اطلاعات شما ذخیره شده است. با بارگذاری مجدد ادامه دهید.'),
                            React.createElement('button', { className: 'btn-primary', onClick: () => window.location.reload() }, 'بارگذاری مجدد')
                        )
                    );
                }
                return this.props.children;
            }
        }

        function AppWrapper() {
            const [toast, setToast] = React.useState(null);

            const app = React.createElement(App);

            React.useEffect(() => {
                const handler = (e) => {
                    setToast(e.detail);
                    setTimeout(() => setToast(null), 3000);
                };
                document.addEventListener('show-toast', handler);
                return () => document.removeEventListener('show-toast', handler);
            }, []);

            return React.createElement('div', null,
                React.createElement(ErrorBoundary, null, app),
                toast && React.createElement(ToastMessage, { toast })
            );
        }

        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(React.createElement(AppWrapper));
